//―――――――――――――――――――――――――――――――――――――――――― ┏  Import Modules ┓ ―――――――――――――――――――――――――――――――――――――――――― \\

const { 
	otakudesu,
	covid,
	filmes1,
	pensadorSearch,
	ongoing,
	komiku,
	tebakgambar,
	surah,
	sholat,
	lirik,
	chara,
	wattpad,
	playstore,
	linkwa,
	pinterest,
	igstalk,
	twitter,
	fbdown,
	youtube,
	ttdownloader,
    wallpaper,
    wikimedia,
    aiovideodl,
	ringtone,
	styletext,
	watuksolatmy,
	musically,
	fbDown2,
	soundcloud,
	telesticker,
	stickersearch,
	ssweb,
	tafsirsurah,
	snapinsta,
	mediafiredl,
	sfilemobiSearch,
	sfilemobi,
	zippyshare,
	ytdl,
	igdl
} = require('./apidl.js')

module.exports.pensadorSearch = pensadorSearch
module.exports.filmes1 = filmes1
module.exports.zippyshare = zippyshare
module.exports.sfilemobiSearch = sfilemobiSearch
module.exports.sfilemobi = sfilemobi
module.exports.mediafiredl = mediafiredl
module.exports.snapinsta = snapinsta
module.exports.tafsirsurah = tafsirsurah
module.exports.ssweb = ssweb
module.exports.stickersearch  = stickersearch
module.exports.telesticker  = telesticker
module.exports.soundcloud  = soundcloud
module.exports.otakudesu = otakudesu
module.exports.covid = covid
module.exports.ongoing = ongoing
module.exports.komiku = komiku
module.exports.tebakgambar = tebakgambar
module.exports.surah = surah
module.exports.sholat = sholat
module.exports.lirik = lirik
module.exports.chara = chara
module.exports.wattpad = wattpad
module.exports.playstore = playstore
module.exports.linkwa = linkwa
module.exports.pinterest = pinterest
module.exports.igdl = igdl
module.exports.igstalk = igstalk
module.exports.twitter = twitter
module.exports.fbdown = fbdown 
module.exports.fbDown2 = fbDown2
module.exports.youtube = youtube
module.exports.ttdownloader = ttdownloader
module.exports.wallpaper = wallpaper
module.exports.wikimedia = wikimedia
module.exports.aiovideodl = aiovideodl
module.exports.ringtone = ringtone
module.exports.styletext = styletext
module.exports.musically = musically
module.exports.watuksolatmy = watuksolatmy
module.exports.ytdl = ytdl
module.exports.photooxy = require("./photooxy.js")