//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

const axios = require('axios')
const cheerio = require('cheerio')
const encodeUrl = require('encodeurl')

const baseUrl = 'https://www.videofk.com/search?url='
async function KwaiScraper(videoUrl) {
try {
const encodedVideoUrl = encodeUrl(videoUrl)
const finalUrl = `${baseUrl}${encodedVideoUrl}&select=`
const { data: html } = await axios.get(finalUrl, {
headers: {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36',
'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'Referer': 'https://www.videofk.com'
}
})
const $ = cheerio.load(html)
const resultados = []
$('.result-body .result-item').each((i, elem) => {
const videoPhoto = $(elem).find('.video-photo a').attr('href')
const videoPhotoImg = $(elem).find('.video-photo a img').attr('src')
const videoTitle = $(elem).find('.video-info h2.h2').text().trim()
const mp4Url = $(elem).find('.video-files a').attr('href')
resultados.push({
título: videoTitle,
foto: videoPhoto,
foto2: videoPhotoImg,
video: mp4Url
})
})
return {
status: true,
criador: '@paulo_mod_domina',
resultados
}
} catch (error) {
console.error('Erro ao buscar a URL:', error.message)
return {
status: false,
criador: '@paulo_mod_domina',
resultados: []
}
}
}

module.exports = { KwaiScraper }