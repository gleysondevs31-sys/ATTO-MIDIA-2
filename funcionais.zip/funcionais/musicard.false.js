//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

const { createCanvas, loadImage } = require('canvas');
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args))
const fs = require('fs');
const path = require('path');

/**
 * Gera um card de música no estilo YouTube
 * @param {string} nome - Nome da música
 * @param {string} foto - URL da foto de perfil
 * @param {string} duracao - Duração da música
 * @param {string} canal - Nome do canal
 * @returns {Promise<Buffer>} Buffer da imagem gerada
 */
async function generateMusicCard(nome, foto, duracao, canal) {
// Selecionar um tema aleatoriamente entre 12 opções completamente diferentes
// A cada requisição, um tema completamente diferente será escolhido
const temaAtual = Math.floor(Math.random() * 12); // 0-11

// Dimensões do YouTube: proporção 16:9
const width = 1280;
const height = 720;

// Criar canvas e contexto
const canvas = createCanvas(width, height);
const ctx = canvas.getContext('2d');

// Definir variável para estilo do card (default = normal)
let cardStyle = 'normal';

// Aplicar tema baseado no número aleatório
if (temaAtual === 0) {
// ===== TEMA 1: NEON CYBERPUNK =====

// Fundo escuro para contraste
ctx.fillStyle = '#050518';
ctx.fillRect(0, 0, width, height);

// Adicionar grade de luz neon
const gridSize = 40;
ctx.strokeStyle = 'rgba(0, 255, 255, 0.1)';
ctx.lineWidth = 1;

// Linhas horizontais
for (let y = 0; y < height; y += gridSize) {
ctx.beginPath();
ctx.moveTo(0, y);
ctx.lineTo(width, y);
ctx.stroke();
}

// Linhas verticais
for (let x = 0; x < width; x += gridSize) {
ctx.beginPath();
ctx.moveTo(x, 0);
ctx.lineTo(x, height);
ctx.stroke();
}

// Adicionar efeito de "sunburst" neon no centro
const centerX = width / 2;
const centerY = height / 2;
const rayCount = 16;
const rayLength = Math.max(width, height);

for (let r = 0; r < rayCount; r++) {
const angle = (Math.PI * 2 / rayCount) * r;
const endX = centerX + Math.cos(angle) * rayLength;
const endY = centerY + Math.sin(angle) * rayLength;

const rayGradient = ctx.createLinearGradient(centerX, centerY, endX, endY);
rayGradient.addColorStop(0, 'rgba(255, 0, 255, 0.7)');
rayGradient.addColorStop(0.1, 'rgba(255, 0, 255, 0.2)');
rayGradient.addColorStop(1, 'rgba(255, 0, 255, 0)');

ctx.beginPath();
ctx.moveTo(centerX, centerY);
ctx.lineTo(endX, endY);
ctx.strokeStyle = rayGradient;
ctx.lineWidth = 3 + Math.random() * 5;
ctx.stroke();
}

// Adicionar círculos concêntricos neon
const circleCount = 4;
for (let c = 0; c < circleCount; c++) {
const radius = (c + 1) * 100;

ctx.beginPath();
ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);

// Alternar entre cores neon
if (c % 2 === 0) {
ctx.strokeStyle = 'rgba(0, 255, 255, 0.2)';
} else {
ctx.strokeStyle = 'rgba(255, 0, 255, 0.2)';
}

ctx.lineWidth = 2;
ctx.stroke();
}

// Adicionar ruído digital por toda a tela
for (let n = 0; n < 1000; n++) {
const noiseX = Math.random() * width;
const noiseY = Math.random() * height;
const noiseSize = Math.random() * 2 + 1;

ctx.beginPath();
ctx.rect(noiseX, noiseY, noiseSize, noiseSize);

// Cores variadas para o ruído
const hue = Math.floor(Math.random() * 360);
const noiseOpacity = Math.random() * 0.3 + 0.1;
ctx.fillStyle = `hsla(${hue}, 100%, 70%, ${noiseOpacity})`;
ctx.fill();
}

// Sobrepor gradiente para dar profundidade
const overlayGradient = ctx.createRadialGradient(
centerX, centerY, 0,
centerX, centerY, Math.max(width, height) / 1.5
);
overlayGradient.addColorStop(0, 'rgba(111, 30, 214, 0.4)');
overlayGradient.addColorStop(0.5, 'rgba(41, 94, 163, 0.2)');
overlayGradient.addColorStop(1, 'rgba(29, 151, 208, 0)');

ctx.fillStyle = overlayGradient;
ctx.fillRect(0, 0, width, height);

// Adicionar "glitches" horizontais
const glitchCount = 8;
for (let g = 0; g < glitchCount; g++) {
const glitchY = Math.random() * height;
const glitchHeight = Math.random() * 5 + 2;
const glitchWidth = Math.random() * width;
const glitchX = Math.random() * (width - glitchWidth);

ctx.fillStyle = 'rgba(255, 0, 255, 0.3)';
ctx.fillRect(glitchX, glitchY, glitchWidth, glitchHeight);
}
} 
else if (temaAtual === 1) {
// ===== TEMA 2: TROPICAL PARADISE =====

// Céu azul degradê
const skyGradient = ctx.createLinearGradient(0, 0, 0, height);
skyGradient.addColorStop(0, '#1a9eeb'); // Azul céu
skyGradient.addColorStop(0.6, '#8cdfff'); // Azul claro
skyGradient.addColorStop(1, '#e0f7ff'); // Quase branco

ctx.fillStyle = skyGradient;
ctx.fillRect(0, 0, width, height);

// Adicionar nuvens suaves
const cloudCount = 8;
for (let c = 0; c < cloudCount; c++) {
const cloudX = Math.random() * width;
const cloudY = Math.random() * (height * 0.5);
const cloudWidth = Math.random() * 300 + 150;
const cloudHeight = cloudWidth * 0.6;

const cloudGradient = ctx.createRadialGradient(
cloudX, cloudY, 0,
cloudX, cloudY, cloudWidth / 2
);
cloudGradient.addColorStop(0, 'rgba(255, 255, 255, 0.9)');
cloudGradient.addColorStop(0.6, 'rgba(255, 255, 255, 0.6)');
cloudGradient.addColorStop(1, 'rgba(255, 255, 255, 0)');

ctx.fillStyle = cloudGradient;
ctx.fillRect(
cloudX - cloudWidth / 2,
cloudY - cloudHeight / 2,
cloudWidth,
cloudHeight
);
}

// Desenhar sol com raios
const sunX = width * 0.85;
const sunY = height * 0.15;
const sunRadius = 60;

// Raios do sol
const sunRayCount = 12;
const sunRayLength = 120;

for (let r = 0; r < sunRayCount; r++) {
const angle = (Math.PI * 2 / sunRayCount) * r;
const rayEndX = sunX + Math.cos(angle) * sunRayLength;
const rayEndY = sunY + Math.sin(angle) * sunRayLength;

const rayGradient = ctx.createLinearGradient(sunX, sunY, rayEndX, rayEndY);
rayGradient.addColorStop(0, 'rgba(255, 200, 0, 0.8)');
rayGradient.addColorStop(1, 'rgba(255, 200, 0, 0)');

ctx.beginPath();
ctx.moveTo(sunX, sunY);
ctx.lineTo(rayEndX, rayEndY);
ctx.strokeStyle = rayGradient;
ctx.lineWidth = 10;
ctx.stroke();
}

// Sol
const sunGradient = ctx.createRadialGradient(
sunX, sunY, 0,
sunX, sunY, sunRadius
);
sunGradient.addColorStop(0, '#ffef00'); // Amarelo brilhante
sunGradient.addColorStop(1, '#ffc800'); // Laranja

ctx.beginPath();
ctx.arc(sunX, sunY, sunRadius, 0, Math.PI * 2);
ctx.fillStyle = sunGradient;
ctx.fill();

// Adicionar linha do horizonte (mar)
const horizonY = height * 0.55;
const seaGradient = ctx.createLinearGradient(0, horizonY, 0, height);
seaGradient.addColorStop(0, '#0a97cc'); // Azul médio
seaGradient.addColorStop(0.7, '#056b99'); // Azul profundo
seaGradient.addColorStop(1, '#023a54'); // Azul escuro

ctx.fillStyle = seaGradient;
ctx.fillRect(0, horizonY, width, height - horizonY);

// Adicionar ondas no mar
const waveCount = 6;
for (let w = 0; w < waveCount; w++) {
const waveY = horizonY + ((height - horizonY) / waveCount) * w;

ctx.beginPath();
ctx.moveTo(0, waveY);

for (let x = 0; x < width; x += 20) {
const waveHeight = Math.sin(x * 0.01 + w) * 10;
ctx.lineTo(x, waveY + waveHeight);
}

ctx.lineTo(width, waveY);
ctx.lineTo(width, waveY + 15);
ctx.lineTo(0, waveY + 15);
ctx.closePath();

ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
ctx.fill();
}

// Desenhar ilha
const islandWidth = width * 0.3;
const islandHeight = height * 0.15;
const islandX = width * 0.35;
const islandY = horizonY;

// Forma da ilha
ctx.beginPath();
ctx.moveTo(islandX - islandWidth / 2, islandY);

// Lado esquerdo da ilha (mais íngreme)
ctx.quadraticCurveTo(
islandX - islandWidth / 3, islandY - islandHeight,
islandX, islandY - islandHeight / 2
);

// Lado direito da ilha (mais suave)
ctx.quadraticCurveTo(
islandX + islandWidth / 3, islandY - islandHeight / 4,
islandX + islandWidth / 2, islandY
);

// Fechar o caminho
ctx.closePath();

// Preencher a ilha com gradiente de terra
const islandGradient = ctx.createLinearGradient(
islandX, islandY - islandHeight,
islandX, islandY
);
islandGradient.addColorStop(0, '#7d5c00'); // Marrom
islandGradient.addColorStop(0.7, '#a87d00'); // Marrom claro
islandGradient.addColorStop(1, '#ffcc00'); // Amarelo areia

ctx.fillStyle = islandGradient;
ctx.fill();

// Adicionar palmeiras
const palmCount = 4;
for (let p = 0; p < palmCount; p++) {
const palmX = islandX - islandWidth / 4 + (p * islandWidth / 3);
const palmY = islandY - islandHeight / 2 - (Math.random() * islandHeight / 2);
const palmHeight = 60 + Math.random() * 40;

// Tronco da palmeira
ctx.beginPath();
ctx.moveTo(palmX, palmY);

// Tronco curvado
ctx.quadraticCurveTo(
palmX + 10, palmY - palmHeight / 2,
palmX + 15, palmY - palmHeight
);

ctx.lineWidth = 8;
ctx.strokeStyle = '#7d5c00';
ctx.stroke();

// Folhas da palmeira
const leafCount = 5;
for (let l = 0; l < leafCount; l++) {
const leafAngle = (Math.PI * 1.2 / leafCount) * l - Math.PI * 0.1;
const leafLength = 30 + Math.random() * 20;

ctx.beginPath();
ctx.moveTo(palmX + 15, palmY - palmHeight);

// Folha curvada
ctx.quadraticCurveTo(
palmX + 15 + Math.cos(leafAngle) * leafLength * 0.5,
palmY - palmHeight + Math.sin(leafAngle) * leafLength * 0.5,
palmX + 15 + Math.cos(leafAngle) * leafLength,
palmY - palmHeight + Math.sin(leafAngle) * leafLength
);

ctx.lineWidth = 5;
ctx.strokeStyle = '#006633';
ctx.stroke();
}
}

// Adicionar brilhos no mar
for (let g = 0; g < 100; g++) {
const glintX = Math.random() * width;
const glintY = horizonY + Math.random() * (height - horizonY);
const glintSize = Math.random() * 3 + 1;
const glintOpacity = Math.random() * 0.5 + 0.1;

ctx.beginPath();
ctx.arc(glintX, glintY, glintSize, 0, Math.PI * 2);
ctx.fillStyle = `rgba(255, 255, 255, ${glintOpacity})`;
ctx.fill();
}
}
else if (temaAtual === 2) {
// ===== TEMA 3: VERMELHO/LARANJA FOGO DINÂMICO =====

// Fundo escuro para melhor contraste
ctx.fillStyle = '#0A0000';
ctx.fillRect(0, 0, width, height);

// Gradiente de vermelho para laranja
const gradient = ctx.createLinearGradient(0, 0, width, height);
gradient.addColorStop(0, 'rgba(120, 0, 0, 0.8)'); // Vermelho escuro
gradient.addColorStop(0.4, 'rgba(180, 30, 0, 0.8)'); // Vermelho
gradient.addColorStop(0.7, 'rgba(220, 70, 0, 0.8)'); // Laranja escuro
gradient.addColorStop(1, 'rgba(255, 120, 0, 0.8)'); // Laranja

ctx.fillStyle = gradient;
ctx.fillRect(0, 0, width, height);

// Adicionar efeito de fogo na parte inferior
const fireHeight = height * 0.5;
const fireStart = height - fireHeight;

for (let y = 0; y < fireHeight; y += 5) {
const fireOpacity = 0.05 * (1 - y / fireHeight);
const waveY = fireStart + y;

ctx.beginPath();
ctx.moveTo(0, waveY);

// Criar chamas com intensidade variável
for (let x = 0; x <= width; x += 10) {
// Usar múltiplas frequências para criar chamas mais naturais
const y1 = Math.sin(x * 0.01 + Date.now() * 0.001) * 20;
const y2 = Math.sin(x * 0.02 + Date.now() * 0.002) * 15;
const y3 = Math.sin(x * 0.03 + Date.now() * 0.001) * 10;

const flameHeight = y1 + y2 + y3;
ctx.lineTo(x, waveY - flameHeight * (1 - y / fireHeight));
}

ctx.lineTo(width, height);
ctx.lineTo(0, height);
ctx.closePath();

const fireGradient = ctx.createLinearGradient(0, waveY, 0, height);
fireGradient.addColorStop(0, `rgba(255, 80, 0, ${fireOpacity})`);
fireGradient.addColorStop(0.5, `rgba(255, 150, 0, ${fireOpacity * 0.8})`);
fireGradient.addColorStop(1, `rgba(255, 200, 0, ${fireOpacity * 0.4})`);

ctx.fillStyle = fireGradient;
ctx.fill();
}

// Adicionar partículas de cinza/brasa subindo
const emberCount = 50;
for (let e = 0; e < emberCount; e++) {
const emberX = Math.random() * width;
const emberY = fireStart + Math.random() * fireHeight;
const emberSize = Math.random() * 3 + 1;
const emberOpacity = Math.random() * 0.7 + 0.3;

ctx.beginPath();
ctx.arc(emberX, emberY, emberSize, 0, Math.PI * 2);

// Variar cores de brasa entre amarelo, laranja e vermelho
const emberHue = Math.floor(Math.random() * 60); // 0 (vermelho) a 60 (amarelo)
ctx.fillStyle = `hsla(${emberHue}, 100%, 50%, ${emberOpacity})`;
ctx.fill();
}

// Adicionar efeito de calor distorcendo o fundo
for (let h = 0; h < 10; h++) {
const heatX = Math.random() * width;
const heatY = fireStart + Math.random() * (fireHeight * 0.7);
const heatRadius = Math.random() * 150 + 50;

const heatGradient = ctx.createRadialGradient(
heatX, heatY, 0,
heatX, heatY, heatRadius
);

heatGradient.addColorStop(0, 'rgba(255, 100, 0, 0.1)');
heatGradient.addColorStop(0.7, 'rgba(255, 150, 0, 0.05)');
heatGradient.addColorStop(1, 'rgba(255, 200, 0, 0)');

ctx.fillStyle = heatGradient;
ctx.fillRect(
heatX - heatRadius,
heatY - heatRadius,
heatRadius * 2,
heatRadius * 2
);
}
}
else if (temaAtual === 3) {
// ===== TEMA 4: ROSA/ROXO CÓSMICO GALÁXICO =====

// Fundo escuro para representar o espaço
ctx.fillStyle = '#0a0010';
ctx.fillRect(0, 0, width, height);

// Adicionar estrelas ao fundo
for (let s = 0; s < 300; s++) {
const starX = Math.random() * width;
const starY = Math.random() * height;
const starSize = Math.random() * 1.5 + 0.5;
const starOpacity = Math.random() * 0.8 + 0.2;

ctx.beginPath();
ctx.arc(starX, starY, starSize, 0, Math.PI * 2);
ctx.fillStyle = `rgba(255, 255, 255, ${starOpacity})`;
ctx.fill();

// Adicionar brilho para algumas estrelas
if (Math.random() > 0.8) {
ctx.beginPath();
ctx.arc(starX, starY, starSize * 3, 0, Math.PI * 2);
ctx.fillStyle = `rgba(255, 255, 255, 0.1)`;
ctx.fill();
}
}

// Adicionar nebulosas cósmicas
for (let n = 0; n < 5; n++) {
const nebulaX = Math.random() * width;
const nebulaY = Math.random() * height;
const nebulaRadius = Math.random() * 350 + 150;

// Escolher cores para a nebulosa entre rosa e roxo
const hue1 = 280 + Math.random() * 40; // Roxos
const hue2 = 320 + Math.random() * 30; // Rosas

const nebulaGradient = ctx.createRadialGradient(
nebulaX, nebulaY, 0,
nebulaX, nebulaY, nebulaRadius
);

nebulaGradient.addColorStop(0, `hsla(${hue2}, 100%, 70%, 0.15)`);
nebulaGradient.addColorStop(0.5, `hsla(${hue1}, 100%, 50%, 0.07)`);
nebulaGradient.addColorStop(1, `hsla(${hue1}, 80%, 30%, 0)`);

ctx.fillStyle = nebulaGradient;
ctx.fillRect(
nebulaX - nebulaRadius,
nebulaY - nebulaRadius,
nebulaRadius * 2,
nebulaRadius * 2
);
}

// Gradiente de rosa para roxo com transparência
const gradient = ctx.createLinearGradient(0, 0, width, height);
gradient.addColorStop(0, 'rgba(99, 0, 156, 0.6)'); // Roxo escuro
gradient.addColorStop(0.3, 'rgba(138, 43, 226, 0.6)'); // Roxo médio
gradient.addColorStop(0.6, 'rgba(218, 112, 214, 0.6)'); // Orquídea
gradient.addColorStop(1, 'rgba(255, 105, 180, 0.6)'); // Rosa choque

ctx.fillStyle = gradient;
ctx.fillRect(0, 0, width, height);

// Adicionar espiral galáctica
const spiralCenter = {
x: width * (0.2 + Math.random() * 0.6),
y: height * (0.2 + Math.random() * 0.6)
};

const spiralRadius = Math.min(width, height) * 0.4;
const spiralArms = 3;
const spiralRotations = 2;
const spiralPoints = 200;

for (let arm = 0; arm < spiralArms; arm++) {
ctx.beginPath();

const armOffset = (Math.PI * 2 / spiralArms) * arm;

for (let i = 0; i < spiralPoints; i++) {
const ratio = i / spiralPoints;
const angle = armOffset + spiralRotations * Math.PI * 2 * ratio;
const distance = ratio * spiralRadius;

const x = spiralCenter.x + Math.cos(angle) * distance;
const y = spiralCenter.y + Math.sin(angle) * distance;

// Variar o tamanho dos pontos ao longo do braço
const pointSize = (1 - ratio) * 5 + 1;

ctx.beginPath();
ctx.arc(x, y, pointSize, 0, Math.PI * 2);

// Colorir pontos com gradiente ao longo do braço
const pointOpacity = (1 - ratio) * 0.5 + 0.1;

// Alternar cores entre rosa e roxo
const color = arm % 2 === 0 ? 
`rgba(255, 105, 180, ${pointOpacity})` : // Rosa
`rgba(138, 43, 226, ${pointOpacity})`; // Roxo

ctx.fillStyle = color;
ctx.fill();
}
}
}
else if (temaAtual === 4) {
// ===== TEMA 5: AZUL/CIANO OCEANO =====

// Gradiente de azul escuro para ciano
const gradient = ctx.createLinearGradient(0, 0, width, height);
gradient.addColorStop(0, 'rgba(0, 51, 102, 1)'); // Azul marinho
gradient.addColorStop(0.4, 'rgba(0, 90, 156, 1)'); // Azul profundo
gradient.addColorStop(0.7, 'rgba(0, 128, 190, 1)'); // Azul médio
gradient.addColorStop(1, 'rgba(0, 190, 218, 1)'); // Ciano

ctx.fillStyle = gradient;
ctx.fillRect(0, 0, width, height);
}
else if (temaAtual === 6) {
// ===== TEMA 7: AURORA BOREAL =====

// Céu noturno como base
ctx.fillStyle = '#051126';
ctx.fillRect(0, 0, width, height);

// Adicionar estrelas no céu
for (let s = 0; s < 300; s++) {
const starX = Math.random() * width;
const starY = Math.random() * (height * 0.7);
const starSize = Math.random() * 1.5 + 0.5;
const starOpacity = Math.random() * 0.8 + 0.2;

ctx.beginPath();
ctx.arc(starX, starY, starSize, 0, Math.PI * 2);
ctx.fillStyle = `rgba(255, 255, 255, ${starOpacity})`;
ctx.fill();
}

// Adicionar montanhas ao fundo
const mountainHeight = height * 0.3;
const horizonY = height * 0.7;

// Primeira cadeia de montanhas (mais escura)
ctx.beginPath();
ctx.moveTo(0, horizonY);

for (let x = 0; x < width; x += 50) {
// Criar picos variados usando múltiplas frequências
const y1 = Math.sin(x * 0.01) * mountainHeight * 0.5;
const y2 = Math.sin(x * 0.02 + 1) * mountainHeight * 0.3;
const y3 = Math.sin(x * 0.04 + 2) * mountainHeight * 0.2;

const peakHeight = y1 + y2 + y3;
ctx.lineTo(x, horizonY - Math.abs(peakHeight));
}

ctx.lineTo(width, horizonY);
ctx.lineTo(width, height);
ctx.lineTo(0, height);
ctx.closePath();

// Gradiente escuro para as montanhas
const mountainGradient = ctx.createLinearGradient(0, horizonY - mountainHeight, 0, horizonY);
mountainGradient.addColorStop(0, '#0a192f');
mountainGradient.addColorStop(1, '#142d4c');

ctx.fillStyle = mountainGradient;
ctx.fill();

// Segunda cadeia de montanhas (mais clara, em primeiro plano)
ctx.beginPath();
ctx.moveTo(0, horizonY + mountainHeight * 0.2);

for (let x = 0; x < width; x += 30) {
// Criar picos variados usando múltiplas frequências deslocadas
const y1 = Math.sin(x * 0.015 + 2) * mountainHeight * 0.4;
const y2 = Math.sin(x * 0.03 + 3) * mountainHeight * 0.25;
const y3 = Math.sin(x * 0.06 + 1) * mountainHeight * 0.15;

const peakHeight = y1 + y2 + y3;
ctx.lineTo(x, horizonY + mountainHeight * 0.2 - Math.abs(peakHeight));
}

ctx.lineTo(width, horizonY + mountainHeight * 0.2);
ctx.lineTo(width, height);
ctx.lineTo(0, height);
ctx.closePath();

// Gradiente mais claro para as montanhas em primeiro plano
const foregroundMountainGradient = ctx.createLinearGradient(0, horizonY, 0, horizonY + mountainHeight * 0.2);
foregroundMountainGradient.addColorStop(0, '#1c3d5a');
foregroundMountainGradient.addColorStop(1, '#2a5173');

ctx.fillStyle = foregroundMountainGradient;
ctx.fill();

// Criar aurora boreal com várias camadas de ondas coloridas
const auroraLayers = 5;
const auroraHeight = height * 0.4;
const auroraBottom = horizonY;

for (let l = 0; l < auroraLayers; l++) {
const layerHeight = auroraHeight * (1 - l / auroraLayers * 0.7);
const waveFrequency = 0.002 + (l * 0.001);
const waveAmplitude = 50 + (l * 10);
const layerOpacity = 0.15 - (l * 0.02);

ctx.beginPath();
ctx.moveTo(0, auroraBottom);

// Gerar ondas para esta camada
for (let x = 0; x <= width; x += 10) {
// Usar múltiplas frequências para criar movimento mais natural
const wave1 = Math.sin(x * waveFrequency) * waveAmplitude;
const wave2 = Math.sin(x * waveFrequency * 2 + 1) * waveAmplitude * 0.5;
const wave3 = Math.sin(x * waveFrequency * 4 + 2) * waveAmplitude * 0.25;

const waveY = auroraBottom - layerHeight + wave1 + wave2 + wave3;
ctx.lineTo(x, waveY);
}

ctx.lineTo(width, auroraBottom);
ctx.closePath();

// Gradiente colorido para a aurora
const auroraGradient = ctx.createLinearGradient(0, auroraBottom - layerHeight, 0, auroraBottom);

// Cada camada tem uma combinação de cores ligeiramente diferente
if (l % 3 === 0) {
// Verde para ciano
auroraGradient.addColorStop(0, `rgba(0, 255, 200, ${layerOpacity})`);
auroraGradient.addColorStop(0.5, `rgba(66, 218, 245, ${layerOpacity})`);
auroraGradient.addColorStop(1, `rgba(0, 0, 0, 0)`);
} else if (l % 3 === 1) {
// Roxo para rosa
auroraGradient.addColorStop(0, `rgba(156, 0, 255, ${layerOpacity})`);
auroraGradient.addColorStop(0.5, `rgba(255, 0, 170, ${layerOpacity})`);
auroraGradient.addColorStop(1, `rgba(0, 0, 0, 0)`);
} else {
// Azul para verde
auroraGradient.addColorStop(0, `rgba(0, 108, 255, ${layerOpacity})`);
auroraGradient.addColorStop(0.5, `rgba(0, 255, 136, ${layerOpacity})`);
auroraGradient.addColorStop(1, `rgba(0, 0, 0, 0)`);
}

ctx.fillStyle = auroraGradient;
ctx.fill();
}
}
else if (temaAtual === 7) {
// ===== TEMA 8: JARDIM MINIMALISTA =====

// Fundo branco com textura sutil
ctx.fillStyle = '#f9f9f9';
ctx.fillRect(0, 0, width, height);

// Adicionar textura de ruído sutil
for (let n = 0; n < 5000; n++) {
const noiseX = Math.random() * width;
const noiseY = Math.random() * height;
const noiseSize = Math.random() * 1.5 + 0.5;
const noiseOpacity = Math.random() * 0.03 + 0.01;

ctx.beginPath();
ctx.arc(noiseX, noiseY, noiseSize, 0, Math.PI * 2);
ctx.fillStyle = `rgba(0, 0, 0, ${noiseOpacity})`;
ctx.fill();
}

// Adicionar retângulos decorativos com cores suaves
const pastels = [
'rgba(243, 229, 245, 0.6)', // Lavanda claro
'rgba(227, 242, 253, 0.6)', // Azul muito claro
'rgba(232, 245, 233, 0.6)', // Verde muito claro
'rgba(255, 243, 224, 0.6)', // Âmbar muito claro
'rgba(251, 233, 231, 0.6)'// Rosa muito claro
];

// Adicionar grandes blocos de cor pastel no fundo
for (let r = 0; r < 5; r++) {
const rectWidth = Math.random() * width * 0.5 + width * 0.3;
const rectHeight = Math.random() * height * 0.4 + height * 0.2;
const rectX = Math.random() * (width - rectWidth);
const rectY = Math.random() * (height - rectHeight);

ctx.fillStyle = pastels[r % pastels.length];
ctx.fillRect(rectX, rectY, rectWidth, rectHeight);
}

// Adicionar linhas finas horizontais e verticais (estilo grade minimalista)
ctx.strokeStyle = 'rgba(0, 0, 0, 0.07)';
ctx.lineWidth = 1;

// Linhas horizontais
for (let y = height * 0.1; y < height * 0.9; y += height * 0.2) {
ctx.beginPath();
ctx.moveTo(width * 0.05, y);
ctx.lineTo(width * 0.95, y);
ctx.stroke();
}

// Linhas verticais
for (let x = width * 0.1; x < width * 0.9; x += width * 0.2) {
ctx.beginPath();
ctx.moveTo(x, height * 0.05);
ctx.lineTo(x, height * 0.95);
ctx.stroke();
}

// Adicionar alguns círculos decorativos
const circleColors = [
'rgba(76, 175, 80, 0.3)',// Verde
'rgba(33, 150, 243, 0.3)', // Azul
'rgba(233, 30, 99, 0.3)',// Rosa
'rgba(255, 152, 0, 0.3)' // Laranja
];

for (let c = 0; c < 12; c++) {
const circleRadius = Math.random() * 40 + 20;
const circleX = Math.random() * width;
const circleY = Math.random() * height;

ctx.beginPath();
ctx.arc(circleX, circleY, circleRadius, 0, Math.PI * 2);
ctx.fillStyle = circleColors[c % circleColors.length];
ctx.fill();
}

// Adicionar linhas orgânicas como folhas ou hastes de plantas
ctx.strokeStyle = 'rgba(76, 175, 80, 0.4)';
ctx.lineWidth = 2;

for (let l = 0; l < 10; l++) {
const startX = Math.random() * width;
const startY = height - (Math.random() * height * 0.3);
const controlX = startX + (Math.random() * 100 - 50);
const controlY = startY - (Math.random() * 150 + 50);
const endX = controlX + (Math.random() * 100 - 50);
const endY = controlY - (Math.random() * 100 + 50);

ctx.beginPath();
ctx.moveTo(startX, startY);
ctx.quadraticCurveTo(controlX, controlY, endX, endY);
ctx.stroke();

// Adicionar uma folha na ponta
const leafSize = Math.random() * 15 + 10;

ctx.beginPath();
ctx.ellipse(
endX, endY,
leafSize, leafSize / 2,
Math.random() * Math.PI, 0, Math.PI * 2
);
ctx.fillStyle = 'rgba(76, 175, 80, 0.3)';
ctx.fill();
}
}
else if (temaAtual === 8) {
// ===== TEMA 9: ANIME KAWAII =====

// Fundo rosa pastel
ctx.fillStyle = '#ffebf3';
ctx.fillRect(0, 0, width, height);

// Adicionar padrão de bolinhas kawaii
for (let i = 0; i < 100; i++) {
const dotX = Math.random() * width;
const dotY = Math.random() * height;
const dotSize = Math.random() * 40 + 10;
const dotOpacity = Math.random() * 0.1 + 0.1;

ctx.beginPath();
ctx.arc(dotX, dotY, dotSize, 0, Math.PI * 2);

// Cores kawaii
const hue = Math.random() > 0.5 ? 320 : 280; // Rosa ou roxo
ctx.fillStyle = `hsla(${hue}, 100%, 85%, ${dotOpacity})`;
ctx.fill();
}

// Adicionar elementos decorativos kawaii
const kawaiiElements = 25;
const kawaiiShapes = ['star', 'heart', 'cloud', 'circle'];

for (let i = 0; i < kawaiiElements; i++) {
const elemX = Math.random() * width;
const elemY = Math.random() * height;
const elemSize = Math.random() * 30 + 15;
const shape = kawaiiShapes[Math.floor(Math.random() * kawaiiShapes.length)];

ctx.save();
ctx.translate(elemX, elemY);
ctx.rotate(Math.random() * Math.PI * 2);

// Cor pastel aleatória
const pastelHue = Math.floor(Math.random() * 360);
ctx.fillStyle = `hsla(${pastelHue}, 100%, 85%, 0.6)`;

// Desenhar forma
if (shape === 'star') {
drawStar(ctx, 0, 0, 5, elemSize, elemSize/2);
} else if (shape === 'heart') {
drawHeart(ctx, 0, 0, elemSize);
} else if (shape === 'cloud') {
drawCloud(ctx, 0, 0, elemSize);
} else {
ctx.beginPath();
ctx.arc(0, 0, elemSize, 0, Math.PI * 2);
ctx.fill();
}

ctx.restore();
}

// Funções para desenhar formas kawaii
function drawStar(ctx, cx, cy, spikes, outerRadius, innerRadius) {
let rot = Math.PI / 2 * 3;
let x = cx;
let y = cy;
let step = Math.PI / spikes;

ctx.beginPath();
ctx.moveTo(cx, cy - outerRadius);

for (let i = 0; i < spikes; i++) {
x = cx + Math.cos(rot) * outerRadius;
y = cy + Math.sin(rot) * outerRadius;
ctx.lineTo(x, y);
rot += step;

x = cx + Math.cos(rot) * innerRadius;
y = cy + Math.sin(rot) * innerRadius;
ctx.lineTo(x, y);
rot += step;
}

ctx.lineTo(cx, cy - outerRadius);
ctx.closePath();
ctx.fill();
}

function drawHeart(ctx, x, y, size) {
ctx.beginPath();
ctx.moveTo(x, y - size/4);
ctx.bezierCurveTo(
x, y - size, 
x - size, y - size, 
x - size, y - size/4
);
ctx.bezierCurveTo(
x - size, y + size/2, 
x, y + size, 
x, y + size/2
);
ctx.bezierCurveTo(
x, y + size, 
x + size, y + size/2, 
x + size, y - size/4
);
ctx.bezierCurveTo(
x + size, y - size, 
x, y - size, 
x, y - size/4
);
ctx.fill();
}

function drawCloud(ctx, x, y, size) {
const numBubbles = 5;
const angles = [0, 0.8, 1.6, 2.4, 3.2];
const radii = [size*0.6, size*0.7, size*0.75, size*0.7, size*0.6];

ctx.beginPath();
for (let i = 0; i < numBubbles; i++) {
const bx = x + Math.cos(angles[i]) * size/2;
const by = y + Math.sin(angles[i]) * size/3;
ctx.arc(bx, by, radii[i], 0, Math.PI * 2);
}
ctx.fill();
}

// Container personalizado para este tema
cardStyle = 'kawaii';
}
else if (temaAtual === 9) {
// ===== TEMA 10: ANIME SHONEN =====

// Fundo dinâmico com cores vibrantes
const bgGradient = ctx.createLinearGradient(0, 0, width, height);
bgGradient.addColorStop(0, '#0a57b5'); // Azul profundo
bgGradient.addColorStop(0.5, '#0f7ce0'); // Azul mais claro
bgGradient.addColorStop(1, '#00a0d6'); // Azul-ciano

ctx.fillStyle = bgGradient;
ctx.fillRect(0, 0, width, height);

// Adicionar linhas de energia/velocidade
const speedLineCount = 60;

ctx.save();
ctx.translate(width/2, height/2);

for (let i = 0; i < speedLineCount; i++) {
const angle = Math.random() * Math.PI * 2;
const length = Math.random() * width;
const thickness = Math.random() * 3 + 1;
const distance = Math.random() * (width/3) + width/8;

// Começar do centro e ir para fora
const startX = Math.cos(angle) * distance;
const startY = Math.sin(angle) * distance;
const endX = Math.cos(angle) * (distance + length);
const endY = Math.sin(angle) * (distance + length);

const lineGradient = ctx.createLinearGradient(startX, startY, endX, endY);
lineGradient.addColorStop(0, 'rgba(255, 255, 255, 0.8)');
lineGradient.addColorStop(1, 'rgba(255, 255, 255, 0)');

ctx.beginPath();
ctx.moveTo(startX, startY);
ctx.lineTo(endX, endY);
ctx.lineWidth = thickness;
ctx.strokeStyle = lineGradient;
ctx.stroke();
}

ctx.restore();

// Adicionar explosões/impactos
const impactCount = 3;

for (let i = 0; i < impactCount; i++) {
const impactX = Math.random() * width;
const impactY = Math.random() * height;
const impactSize = Math.random() * 80 + 40;

// Círculo de impacto
const impactGradient = ctx.createRadialGradient(
impactX, impactY, 0,
impactX, impactY, impactSize
);
impactGradient.addColorStop(0, 'rgba(255, 255, 255, 0.8)');
impactGradient.addColorStop(0.2, 'rgba(255, 230, 150, 0.6)');
impactGradient.addColorStop(0.4, 'rgba(255, 180, 50, 0.4)');
impactGradient.addColorStop(1, 'rgba(255, 120, 0, 0)');

ctx.fillStyle = impactGradient;
ctx.fillRect(
impactX - impactSize,
impactY - impactSize,
impactSize * 2,
impactSize * 2
);

// Adicionar linhas de impacto
const impactLines = 8;

ctx.save();
ctx.translate(impactX, impactY);

for (let j = 0; j < impactLines; j++) {
const lineAngle = (Math.PI * 2 / impactLines) * j;
const lineLength = impactSize * 1.5;

ctx.beginPath();
ctx.moveTo(0, 0);
ctx.lineTo(
Math.cos(lineAngle) * lineLength,
Math.sin(lineAngle) * lineLength
);

const lineGradient = ctx.createLinearGradient(
0, 0,
Math.cos(lineAngle) * lineLength,
Math.sin(lineAngle) * lineLength
);
lineGradient.addColorStop(0, 'rgba(255, 200, 50, 0.8)');
lineGradient.addColorStop(1, 'rgba(255, 120, 0, 0)');

ctx.strokeStyle = lineGradient;
ctx.lineWidth = 3;
ctx.stroke();
}

ctx.restore();
}

// Container personalizado para este tema
cardStyle = 'shonen';
}
else if (temaAtual === 10) {
// ===== TEMA 11: ANIME FANTASY =====

// Céu mágico com cores fantasiosas
const skyGradient = ctx.createLinearGradient(0, 0, 0, height);
skyGradient.addColorStop(0, '#000428'); // Azul escuro
skyGradient.addColorStop(0.5, '#233675'); // Azul médio
skyGradient.addColorStop(0.8, '#3b0e6e'); // Roxo
skyGradient.addColorStop(1, '#2e0350'); // Roxo escuro

ctx.fillStyle = skyGradient;
ctx.fillRect(0, 0, width, height);

// Adicionar estrelas brilhantes
for (let s = 0; s < 200; s++) {
const starX = Math.random() * width;
const starY = Math.random() * height * 0.8;
const starSize = Math.random() * 2 + 1;
const starOpacity = Math.random() * 0.8 + 0.2;

ctx.beginPath();
ctx.arc(starX, starY, starSize, 0, Math.PI * 2);
ctx.fillStyle = `rgba(255, 255, 255, ${starOpacity})`;
ctx.fill();

// Adicionar brilho para algumas estrelas
if (Math.random() > 0.8) {
ctx.beginPath();
ctx.arc(starX, starY, starSize * 3, 0, Math.PI * 2);
ctx.fillStyle = `rgba(255, 255, 255, 0.1)`;
ctx.fill();
}
}

// Adicionar cristais flutuantes mágicos
const crystalCount = 15;

for (let c = 0; c < crystalCount; c++) {
const crystalX = Math.random() * width;
const crystalY = Math.random() * height;
const crystalSize = Math.random() * 40 + 20;

// Cor aleatória do cristal
const hue = Math.floor(Math.random() * 60) + 240; // Azuis a roxos

ctx.save();
ctx.translate(crystalX, crystalY);
ctx.rotate(Math.random() * Math.PI);

// Desenhar cristal
ctx.beginPath();
ctx.moveTo(0, -crystalSize);
ctx.lineTo(crystalSize/2, 0);
ctx.lineTo(0, crystalSize);
ctx.lineTo(-crystalSize/2, 0);
ctx.closePath();

// Gradiente do cristal
const crystalGradient = ctx.createLinearGradient(
-crystalSize/2, 0,
crystalSize/2, 0
);
crystalGradient.addColorStop(0, `hsla(${hue}, 100%, 50%, 0.3)`);
crystalGradient.addColorStop(0.5, `hsla(${hue}, 100%, 80%, 0.5)`);
crystalGradient.addColorStop(1, `hsla(${hue}, 100%, 50%, 0.3)`);

ctx.fillStyle = crystalGradient;
ctx.fill();

// Borda do cristal
ctx.strokeStyle = `hsla(${hue}, 100%, 70%, 0.8)`;
ctx.lineWidth = 1;
ctx.stroke();

// Adicionar reflexo
ctx.beginPath();
ctx.moveTo(-crystalSize/4, -crystalSize/2);
ctx.lineTo(crystalSize/4, crystalSize/2);
ctx.strokeStyle = `rgba(255, 255, 255, 0.7)`;
ctx.lineWidth = 2;
ctx.stroke();

ctx.restore();
}

// Adicionar neblina mágica
const mistCount = 5;
for (let m = 0; m < mistCount; m++) {
const mistX = Math.random() * width;
const mistY = Math.random() * height;
const mistRadius = Math.random() * 300 + 100;

const mistGradient = ctx.createRadialGradient(
mistX, mistY, 0,
mistX, mistY, mistRadius
);

// Cor aleatória para a neblina
const mistHue = Math.floor(Math.random() * 60) + 240; // Tons de azul a roxo
mistGradient.addColorStop(0, `hsla(${mistHue}, 100%, 70%, 0.1)`);
mistGradient.addColorStop(1, `hsla(${mistHue}, 100%, 50%, 0)`);

ctx.fillStyle = mistGradient;
ctx.fillRect(
mistX - mistRadius,
mistY - mistRadius,
mistRadius * 2,
mistRadius * 2
);
}

// Container personalizado para este tema
cardStyle = 'fantasy';
}
else if (temaAtual === 11) {
// ===== TEMA 12: ANIME CYBERPUNK =====

// Fundo escuro urbano
ctx.fillStyle = '#0a0a12';
ctx.fillRect(0, 0, width, height);

// Grid cyberpunk em perspectiva
const horizonY = height * 0.55;
const vanishingPointX = width * 0.5;

// Desenhar prédios no horizonte
const buildingCount = 20;
const maxBuildingWidth = width / buildingCount;

for (let b = 0; b < buildingCount; b++) {
const buildingX = (b * maxBuildingWidth);
const buildingWidth = maxBuildingWidth * 0.8;
const buildingHeight = Math.random() * height * 0.3 + height * 0.1;

// Gradiente para o prédio
const buildingGradient = ctx.createLinearGradient(
buildingX, horizonY - buildingHeight,
buildingX, horizonY
);
buildingGradient.addColorStop(0, '#0f1026');
buildingGradient.addColorStop(1, '#1a1a30');

ctx.fillStyle = buildingGradient;
ctx.fillRect(buildingX, horizonY - buildingHeight, buildingWidth, buildingHeight);

// Adicionar janelas aos prédios
const windowRows = Math.floor(buildingHeight / 15);
const windowCols = Math.floor(buildingWidth / 10);

for (let r = 0; r < windowRows; r++) {
for (let c = 0; c < windowCols; c++) {
if (Math.random() > 0.3) {
const windowX = buildingX + c * 10 + 2;
const windowY = (horizonY - buildingHeight) + r * 15 + 2;
const windowWidth = 6;
const windowHeight = 10;

// Cores neon para as janelas
const neonColors = ['#ff00ff', '#00ffff', '#ffff00', '#00ff00'];
const windowColor = Math.random() > 0.8 
? neonColors[Math.floor(Math.random() * neonColors.length)]
: '#ffffff';

ctx.fillStyle = windowColor;
ctx.globalAlpha = Math.random() * 0.5 + 0.2;
ctx.fillRect(windowX, windowY, windowWidth, windowHeight);
ctx.globalAlpha = 1.0;
}
}
}
}

// Adicionar linhas de grade na rua
const gridLines = 20;
ctx.strokeStyle = '#00ffff';
ctx.lineWidth = 1;

// Linhas horizontais
for (let i = 0; i <= gridLines; i++) {
const y = horizonY + ((height - horizonY) / gridLines) * i;
const perspectiveWidth = (i / gridLines) * width * 2;

ctx.beginPath();
ctx.moveTo(vanishingPointX - perspectiveWidth/2, y);
ctx.lineTo(vanishingPointX + perspectiveWidth/2, y);
ctx.globalAlpha = 0.2 + (i / gridLines) * 0.4;
ctx.stroke();
}

// Linhas verticais
const verticalLines = 20;
for (let i = 0; i <= verticalLines; i++) {
const progress = i / verticalLines;
const startX = vanishingPointX - width + progress * width * 2;

ctx.beginPath();
ctx.moveTo(startX, horizonY);
ctx.lineTo(vanishingPointX + (startX - vanishingPointX) * 5, height);
ctx.globalAlpha = 0.1 + progress * 0.3;
ctx.stroke();
}

ctx.globalAlpha = 1.0;

// Adicionar efeito de chuva neon
const rainDrops = 100;
ctx.strokeStyle = '#00ffff';
ctx.lineWidth = 1.5;

for (let r = 0; r < rainDrops; r++) {
const rainX = Math.random() * width;
const rainHeight = Math.random() * 20 + 10;
const rainY = Math.random() * height;

ctx.beginPath();
ctx.moveTo(rainX, rainY);
ctx.lineTo(rainX, rainY + rainHeight);
ctx.globalAlpha = Math.random() * 0.4 + 0.1;
ctx.stroke();
}

ctx.globalAlpha = 1.0;

// Adicionar luzes neon e hologramas
const neonLights = 8;

for (let n = 0; n < neonLights; n++) {
const neonX = Math.random() * width;
const neonY = Math.random() * height * 0.5 + height * 0.1;
const neonSize = Math.random() * 40 + 20;

// Escolher cor neon aleatória
const neonColors = ['#ff00ff', '#00ffff', '#ff3300', '#00ff99'];
const neonColor = neonColors[Math.floor(Math.random() * neonColors.length)];

// Criar glow neon
const neonGlow = ctx.createRadialGradient(
neonX, neonY, 0,
neonX, neonY, neonSize
);
neonGlow.addColorStop(0, neonColor);
neonGlow.addColorStop(0.3, neonColor.replace('ff', '99'));
neonGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');

ctx.fillStyle = neonGlow;
ctx.fillRect(
neonX - neonSize,
neonY - neonSize,
neonSize * 2,
neonSize * 2
);
}

// Container personalizado para este tema
cardStyle = 'cyberpunk';
}
else {
// ===== TEMA 6: DOURADO/ÂMBAR PREMIUM =====

// Gradiente de dourado para âmbar
const gradient = ctx.createLinearGradient(0, 0, width, height);
gradient.addColorStop(0, 'rgba(100, 60, 0, 1)'); // Marrom dourado
gradient.addColorStop(0.3, 'rgba(153, 101, 21, 1)'); // Dourado escuro
gradient.addColorStop(0.6, 'rgba(212, 175, 55, 1)'); // Dourado
gradient.addColorStop(1, 'rgba(255, 215, 0, 1)'); // Dourado brilhante

ctx.fillStyle = gradient;
ctx.fillRect(0, 0, width, height);
}

// Adicionar efeito de vinheta premium (mais escuro nas bordas) - comum a todos os temas
const vignette = ctx.createRadialGradient(
width/2, height/2, 0,
width/2, height/2, Math.sqrt(Math.pow(width/2, 2) + Math.pow(height/2, 2))
);
vignette.addColorStop(0, 'rgba(0, 0, 0, 0)');
vignette.addColorStop(0.65, 'rgba(0, 0, 0, 0)');
vignette.addColorStop(1, 'rgba(0, 0, 0, 0.7)');

ctx.fillStyle = vignette;
ctx.fillRect(0, 0, width, height);

// Adicionar partículas baseadas no tema atual
let particleColors;

if (temaAtual === 0) {
// Tema 1: Roxo/Azul
particleColors = [
'rgba(255, 255, 255, $opacity)', // Branco
'rgba(66, 230, 245, $opacity)', // Azul claro
'rgba(183, 94, 255, $opacity)', // Roxo
'rgba(247, 64, 230, $opacity)'// Rosa
];
} 
else if (temaAtual === 1) {
// Tema 2: Verde/Ciano
particleColors = [
'rgba(255, 255, 255, $opacity)', // Branco
'rgba(80, 250, 123, $opacity)',// Verde neon
'rgba(0, 210, 210, $opacity)', // Ciano
'rgba(173, 255, 47, $opacity)' // Verde-limão
];
}
else if (temaAtual === 2) {
// Tema 3: Vermelho/Laranja
particleColors = [
'rgba(255, 255, 255, $opacity)', // Branco
'rgba(255, 140, 0, $opacity)', // Laranja
'rgba(255, 69, 0, $opacity)',// Vermelho-laranja
'rgba(255, 215, 0, $opacity)'// Dourado
];
}
else if (temaAtual === 3) {
// Tema 4: Rosa/Roxo
particleColors = [
'rgba(255, 255, 255, $opacity)', // Branco
'rgba(255, 105, 180, $opacity)', // Rosa quente
'rgba(218, 112, 214, $opacity)', // Orquídea
'rgba(138, 43, 226, $opacity)' // Roxo vibrante
];
}
else if (temaAtual === 4) {
// Tema 5: Azul/Ciano
particleColors = [
'rgba(255, 255, 255, $opacity)', // Branco
'rgba(30, 144, 255, $opacity)',// Azul dodger
'rgba(0, 191, 255, $opacity)', // Azul céu profundo
'rgba(127, 255, 212, $opacity)'// Água-marinha
];
}
else if (temaAtual === 6) {
// Tema 7: Aurora Boreal
particleColors = [
'rgba(255, 255, 255, $opacity)', // Branco
'rgba(0, 255, 200, $opacity)', // Verde aurora
'rgba(156, 0, 255, $opacity)', // Roxo aurora
'rgba(0, 108, 255, $opacity)'// Azul aurora
];
}
else if (temaAtual === 7) {
// Tema 8: Jardim Minimalista
particleColors = [
'rgba(255, 255, 255, $opacity)', // Branco
'rgba(76, 175, 80, $opacity)', // Verde folha
'rgba(33, 150, 243, $opacity)',// Azul suave
'rgba(233, 30, 99, $opacity)'// Rosa suave
];
}
else if (temaAtual === 8) {
// Tema 9: Anime Kawaii
particleColors = [
'rgba(255, 255, 255, $opacity)',// Branco
'rgba(255, 153, 240, $opacity)',// Rosa pastel
'rgba(214, 162, 255, $opacity)',// Roxo pastel
'rgba(255, 214, 233, $opacity)' // Rosa claro
];
}
else if (temaAtual === 9) {
// Tema 10: Anime Shonen
particleColors = [
'rgba(255, 255, 255, $opacity)',// Branco
'rgba(0, 180, 255, $opacity)',// Azul brilhante
'rgba(255, 200, 0, $opacity)',// Amarelo brilhante
'rgba(255, 120, 0, $opacity)' // Laranja
];
}
else if (temaAtual === 10) {
// Tema 11: Anime Fantasy
particleColors = [
'rgba(255, 255, 255, $opacity)',// Branco
'rgba(130, 60, 200, $opacity)', // Roxo mágico
'rgba(70, 150, 230, $opacity)', // Azul mágico
'rgba(230, 70, 180, $opacity)'// Rosa mágico
];
}
else if (temaAtual === 11) {
// Tema 12: Anime Cyberpunk
particleColors = [
'rgba(255, 255, 255, $opacity)',// Branco
'rgba(0, 255, 255, $opacity)',// Ciano neon
'rgba(255, 0, 255, $opacity)',// Magenta neon
'rgba(0, 255, 128, $opacity)' // Verde neon
];
}
else {
// Tema 6: Dourado/Âmbar
particleColors = [
'rgba(255, 255, 255, $opacity)', // Branco
'rgba(255, 215, 0, $opacity)', // Dourado
'rgba(218, 165, 32, $opacity)',// Dourado escuro
'rgba(255, 255, 224, $opacity)'// Amarelo claro
];
}

// Adicionar partículas com cores baseadas no tema atual
for (let i = 0; i < 900; i++) {
const x = Math.floor(Math.random() * width);
const y = Math.floor(Math.random() * height);
const size = Math.random() * 3;
const brightness = Math.floor(Math.random() * 100 + 155) / 255;

// Escolher cor aleatória do array de cores do tema
const colorIndex = Math.floor(Math.random() * particleColors.length);
const particleColor = particleColors[colorIndex].replace('$opacity', brightness);

// Criar partícula com brilho
ctx.beginPath();
ctx.arc(x, y, size, 0, Math.PI * 2);
ctx.fillStyle = particleColor;
ctx.fill();

// Efeito de glow para partículas maiores
if (size > 1.5) {
ctx.beginPath();
ctx.arc(x, y, size * 2, 0, Math.PI * 2);
ctx.fillStyle = particleColor.replace(')', ', 0.25)').replace('rgba', 'rgba');
ctx.fill();
}

// Adicionar efeito de estrela para algumas partículas especiais
if (size > 2 && Math.random() > 0.85) {
const starSize = size * 4;

// Desenhar raios da estrela
ctx.beginPath();
for (let ray = 0; ray < 4; ray++) {
const angle = (ray * Math.PI / 2);
ctx.moveTo(x, y);
ctx.lineTo(
x + Math.cos(angle) * starSize,
y + Math.sin(angle) * starSize
);
}
ctx.strokeStyle = particleColor.replace(')', ', 0.15)').replace('rgba', 'rgba');
ctx.lineWidth = 0.5;
ctx.stroke();
}
}

// Obter cor de destaque baseada no tema para os efeitos
let accentColor;
let secondaryColor;
let thirdColor;

if (temaAtual === 0) {
// Tema 1: Roxo/Azul
accentColor = 'rgba(247, 64, 230, $opacity)'; // Rosa
secondaryColor = 'rgba(66, 230, 245, $opacity)'; // Azul claro
thirdColor = 'rgba(183, 94, 255, $opacity)'; // Roxo
} 
else if (temaAtual === 1) {
// Tema 2: Verde/Ciano
accentColor = 'rgba(80, 250, 123, $opacity)'; // Verde neon
secondaryColor = 'rgba(0, 210, 210, $opacity)'; // Ciano
thirdColor = 'rgba(173, 255, 47, $opacity)'; // Verde-limão
}
else if (temaAtual === 2) {
// Tema 3: Vermelho/Laranja
accentColor = 'rgba(255, 140, 0, $opacity)'; // Laranja
secondaryColor = 'rgba(255, 69, 0, $opacity)'; // Vermelho-laranja
thirdColor = 'rgba(255, 215, 0, $opacity)'; // Dourado
}
else if (temaAtual === 3) {
// Tema 4: Rosa/Roxo
accentColor = 'rgba(255, 105, 180, $opacity)'; // Rosa quente
secondaryColor = 'rgba(218, 112, 214, $opacity)'; // Orquídea
thirdColor = 'rgba(138, 43, 226, $opacity)'; // Roxo vibrante
}
else if (temaAtual === 4) {
// Tema 5: Azul/Ciano
accentColor = 'rgba(0, 191, 255, $opacity)'; // Azul céu profundo
secondaryColor = 'rgba(30, 144, 255, $opacity)'; // Azul dodger
thirdColor = 'rgba(127, 255, 212, $opacity)'; // Água-marinha
}
else if (temaAtual === 6) {
// Tema 7: Aurora Boreal
accentColor = 'rgba(0, 255, 200, $opacity)'; // Verde aurora
secondaryColor = 'rgba(156, 0, 255, $opacity)'; // Roxo aurora
thirdColor = 'rgba(0, 108, 255, $opacity)'; // Azul aurora
}
else if (temaAtual === 7) {
// Tema 8: Jardim Minimalista
accentColor = 'rgba(76, 175, 80, $opacity)'; // Verde folha
secondaryColor = 'rgba(33, 150, 243, $opacity)'; // Azul suave
thirdColor = 'rgba(233, 30, 99, $opacity)'; // Rosa suave
}
else if (temaAtual === 8) {
// Tema 9: Anime Kawaii
accentColor = 'rgba(255, 153, 240, $opacity)'; // Rosa pastel
secondaryColor = 'rgba(214, 162, 255, $opacity)'; // Roxo pastel
thirdColor = 'rgba(255, 214, 233, $opacity)'; // Rosa claro
}
else if (temaAtual === 9) {
// Tema 10: Anime Shonen
accentColor = 'rgba(0, 180, 255, $opacity)'; // Azul brilhante
secondaryColor = 'rgba(255, 200, 0, $opacity)'; // Amarelo brilhante
thirdColor = 'rgba(255, 120, 0, $opacity)'; // Laranja
}
else if (temaAtual === 10) {
// Tema 11: Anime Fantasy
accentColor = 'rgba(130, 60, 200, $opacity)'; // Roxo mágico
secondaryColor = 'rgba(70, 150, 230, $opacity)'; // Azul mágico
thirdColor = 'rgba(230, 70, 180, $opacity)'; // Rosa mágico
}
else if (temaAtual === 11) {
// Tema 12: Anime Cyberpunk
accentColor = 'rgba(0, 255, 255, $opacity)'; // Ciano neon
secondaryColor = 'rgba(255, 0, 255, $opacity)'; // Magenta neon
thirdColor = 'rgba(0, 255, 128, $opacity)'; // Verde neon
}
else {
// Tema 6: Dourado/Âmbar
accentColor = 'rgba(255, 215, 0, $opacity)'; // Dourado
secondaryColor = 'rgba(218, 165, 32, $opacity)'; // Dourado escuro
thirdColor = 'rgba(255, 255, 224, $opacity)'; // Amarelo claro
}

// Adicionar linhas cinéticas com cor de destaque do tema
const lineCount = 8;
const lineStartRadius = 500;
const lineEndRadius = 1200;

// Aplicar sombra para as linhas cinéticas
ctx.shadowColor = accentColor.replace('$opacity', '0.5');
ctx.shadowBlur = 10;
ctx.shadowOffsetX = 0;
ctx.shadowOffsetY = 0;

for (let i = 0; i < lineCount; i++) {
const angle = (Math.PI * 2 * i / lineCount) + (Math.PI / 5);
const x1 = width / 2 + Math.cos(angle) * lineStartRadius;
const y1 = height / 2 + Math.sin(angle) * lineStartRadius;
const x2 = width / 2 + Math.cos(angle) * lineEndRadius;
const y2 = height / 2 + Math.sin(angle) * lineEndRadius;

const lineGradient = ctx.createLinearGradient(x1, y1, x2, y2);

// Alternar entre as cores de destaque do tema para mais variedade
if (i % 3 === 0) {
lineGradient.addColorStop(0, accentColor.replace('$opacity', '0.7'));
} else if (i % 3 === 1) {
lineGradient.addColorStop(0, secondaryColor.replace('$opacity', '0.7'));
} else {
lineGradient.addColorStop(0, thirdColor.replace('$opacity', '0.7'));
}

lineGradient.addColorStop(1, 'rgba(0, 0, 0, 0)');

ctx.beginPath();
ctx.moveTo(x1, y1);
ctx.lineTo(x2, y2);
ctx.strokeStyle = lineGradient;
ctx.lineWidth = 2 + Math.random() * 3;
ctx.stroke();
}

// Resetar sombra
ctx.shadowColor = 'transparent';
ctx.shadowBlur = 0;
ctx.shadowOffsetX = 0;
ctx.shadowOffsetY = 0;

// ===== FOTO DE PERFIL COM BORDA PREMIUM =====

// Carregar a foto de perfil com tratamento de erros
let profileImage;
try {
const fotoResponse = await fetch(foto);
const fotoBuffer = await fotoResponse.arrayBuffer();
profileImage = await loadImage(Buffer.from(fotoBuffer));
} catch (error) {
console.error("Erro ao carregar imagem de perfil:", error);
// Criar uma imagem de perfil padrão
const defaultCanvas = createCanvas(280, 280);
const defaultCtx = defaultCanvas.getContext('2d');

// Fundo gradiente
const defaultGradient = defaultCtx.createLinearGradient(0, 0, 280, 280);
defaultGradient.addColorStop(0, 'rgba(70, 70, 70, 1)');
defaultGradient.addColorStop(1, 'rgba(40, 40, 40, 1)');
defaultCtx.fillStyle = defaultGradient;
defaultCtx.fillRect(0, 0, 280, 280);

// Símbolo de pessoa
defaultCtx.font = 'bold 120px Arial';
defaultCtx.fillStyle = 'white';
defaultCtx.textAlign = 'center';
defaultCtx.textBaseline = 'middle';
defaultCtx.fillText('👤', 140, 140);

// Converter para imagem
profileImage = await loadImage(defaultCanvas.toBuffer());
}

// Tamanho e posição da foto de perfil - bem centralizada verticalmente
const profileSize = 350;
const avatarX = 30; // Movido mais para a esquerda (antes era 50)
const avatarY = height / 2 - profileSize / 2;

// Adicionar efeito de sombra para destacar a foto
ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
ctx.shadowBlur = 15;
ctx.shadowOffsetX = 0;
ctx.shadowOffsetY = 0;

// Desenhar a borda animada estilo premium
const borderWidth = 8;
const profileRadius = profileSize / 2;
const animatedBorders = 3; // Aumentar número de anéis na borda para efeito mais rico

for (let b = 0; b < animatedBorders; b++) {
const borderOffset = b * (borderWidth / animatedBorders);

// Criar borda circular com gradiente
ctx.beginPath();
ctx.arc(avatarX + profileSize/2, avatarY + profileSize/2, 
profileRadius + borderWidth - borderOffset, 0, Math.PI * 2);

// Gradiente de cores premium para borda
const borderGradient = ctx.createLinearGradient(
avatarX, 
avatarY,
avatarX + profileSize,
avatarY + profileSize
);

// Arco-íris premium
borderGradient.addColorStop(0, 'rgba(33, 218, 255, 0.85)');// Azul ciano
borderGradient.addColorStop(0.25, 'rgba(183, 94, 255, 0.85)');// Roxo
borderGradient.addColorStop(0.5, 'rgba(247, 64, 230, 0.85)'); // Rosa
borderGradient.addColorStop(0.75, 'rgba(255, 180, 18, 0.85)');// Dourado
borderGradient.addColorStop(1, 'rgba(33, 218, 255, 0.85)'); // Azul ciano

ctx.fillStyle = borderGradient;
ctx.fill();
}

// Remover sombra para não afetar a foto
ctx.shadowColor = 'transparent';
ctx.shadowBlur = 0;

// Salvar contexto atual
ctx.save();

// Desenhar a foto de perfil (circular com borda branca interna)
ctx.beginPath();
ctx.arc(avatarX + profileSize/2, avatarY + profileSize/2, profileRadius, 0, Math.PI * 2);
ctx.closePath();
ctx.clip();

// Desenhar borda branca interna
ctx.beginPath();
ctx.arc(avatarX + profileSize/2, avatarY + profileSize/2, profileRadius, 0, Math.PI * 2);
ctx.strokeStyle = 'white';
ctx.lineWidth = 2;
ctx.stroke();

// Desenhar imagem de perfil
ctx.drawImage(profileImage, avatarX, avatarY, profileSize, profileSize);

// Restaurar contexto
ctx.restore();

// ===== CARD DE INFORMAÇÕES PREMIUM =====

// Dimensões e posição do card - perfeitamente centralizado
const cardWidth = 850;
const cardHeight = 320;
const cardX = 400;
const cardY = height / 2 - cardHeight / 2;

// Desenhar card com efeito glassmorphism moderno
ctx.save();

// Adicionar sombra para o card
ctx.shadowColor = 'rgba(0, 0, 0, 0.4)';
ctx.shadowBlur = 20;
ctx.shadowOffsetX = 0;
ctx.shadowOffsetY = 0;

// Cantos arredondados para o card
const cardRadius = 16;
ctx.beginPath();
ctx.moveTo(cardX + cardRadius, cardY);
ctx.lineTo(cardX + cardWidth - cardRadius, cardY);
ctx.quadraticCurveTo(cardX + cardWidth, cardY, cardX + cardWidth, cardY + cardRadius);
ctx.lineTo(cardX + cardWidth, cardY + cardHeight - cardRadius);
ctx.quadraticCurveTo(cardX + cardWidth, cardY + cardHeight, cardX + cardWidth - cardRadius, cardY + cardHeight);
ctx.lineTo(cardX + cardRadius, cardY + cardHeight);
ctx.quadraticCurveTo(cardX, cardY + cardHeight, cardX, cardY + cardHeight - cardRadius);
ctx.lineTo(cardX, cardY + cardRadius);
ctx.quadraticCurveTo(cardX, cardY, cardX + cardRadius, cardY);
ctx.closePath();

// Fundo semi-transparente com efeito de vidro aprimorado
const cardBgGradient = ctx.createLinearGradient(cardX, cardY, cardX + cardWidth, cardY + cardHeight);
cardBgGradient.addColorStop(0, 'rgba(20, 20, 35, 0.7)');
cardBgGradient.addColorStop(1, 'rgba(20, 20, 30, 0.6)');
ctx.fillStyle = cardBgGradient;
ctx.fill();

// Remover sombra antes de desenhar a borda
ctx.shadowColor = 'transparent';
ctx.shadowBlur = 0;

// Borda brilhante com gradiente
const borderGradient = ctx.createLinearGradient(cardX, cardY, cardX + cardWidth, cardY + cardHeight);
borderGradient.addColorStop(0, 'rgba(255, 255, 255, 0.8)');
borderGradient.addColorStop(0.5, 'rgba(180, 180, 255, 0.5)');
borderGradient.addColorStop(1, 'rgba(255, 255, 255, 0.8)');

ctx.strokeStyle = borderGradient;
ctx.lineWidth = 2;
ctx.stroke();

// Adicionar efeito de brilho nos cantos do card
const glowSize = 40;
const cornerLocations = [
{x: cardX, y: cardY},// Canto superior esquerdo
{x: cardX + cardWidth, y: cardY},// Canto superior direito
{x: cardX, y: cardY + cardHeight}, // Canto inferior esquerdo
{x: cardX + cardWidth, y: cardY + cardHeight}// Canto inferior direito
];

cornerLocations.forEach(corner => {
const glow = ctx.createRadialGradient(
corner.x, corner.y, 0,
corner.x, corner.y, glowSize
);
glow.addColorStop(0, 'rgba(255, 255, 255, 0.2)');
glow.addColorStop(1, 'rgba(255, 255, 255, 0)');

ctx.fillStyle = glow;
ctx.fillRect(corner.x - glowSize, corner.y - glowSize, glowSize * 2, glowSize * 2);
});

ctx.restore();

// ===== TEXTOS MODERNOS PERFEITAMENTE POSICIONADOS =====

// Título - com truncamento se necessário
const tituloX = cardX + 40;
const tituloY = cardY + 40; // Movido para cima
const maxTitleWidth = cardWidth - 80;

// Fonte moderna para o título
ctx.font = 'bold 46px Arial, sans-serif';
ctx.fillStyle = 'white';
ctx.textBaseline = 'top';

// Truncar o título se necessário
const titleText = truncateText(ctx, nome, maxTitleWidth);

// Sombra para o título
ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
ctx.shadowBlur = 5;
ctx.shadowOffsetX = 2;
ctx.shadowOffsetY = 2;
ctx.fillText(titleText, tituloX, tituloY);

// Remover sombra para outros textos
ctx.shadowColor = 'transparent';
ctx.shadowBlur = 0;
ctx.shadowOffsetX = 0;
ctx.shadowOffsetY = 0;

// Canal com @ para estilo YouTube (sem duplicar @)
const canalX = tituloX;
const canalY = cardY + 110; // Movido para cima

ctx.font = '32px Arial, sans-serif';
ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';

// Remover @ duplicado se necessário e adicionar ícone de verificado
let canalText = canal;
if (canal.startsWith('@')) {
canalText = canal;
} else {
canalText = `@${canal}`;
}

// Truncar nome do canal se necessário
canalText = truncateText(ctx, canalText, maxTitleWidth - 40);

// Ícone de canal verificado
const verifiedIcon = '✓';
ctx.fillText(canalText, canalX, canalY);

// Adicionar ícone de verificação em um círculo azul (movido mais para a direita)
const textWidth = ctx.measureText(canalText).width;
const iconX = canalX + textWidth + 20; // Aumentado espaço para 20px (antes era 12)
const iconY = canalY + 16;
const iconRadius = 12;

// Adicionar sombra ao ícone verificado
ctx.shadowColor = 'rgba(56, 151, 240, 0.6)';
ctx.shadowBlur = 8;
ctx.shadowOffsetX = 0;
ctx.shadowOffsetY = 0;

ctx.beginPath();
ctx.arc(iconX, iconY, iconRadius, 0, Math.PI * 2);
ctx.fillStyle = '#3897F0'; // Azul do verificado
ctx.fill();

// Adicionar brilho externo ao ícone
ctx.beginPath();
ctx.arc(iconX, iconY, iconRadius + 3, 0, Math.PI * 2);
const verifiedGlow = ctx.createRadialGradient(
iconX, iconY, iconRadius,
iconX, iconY, iconRadius + 6
);
verifiedGlow.addColorStop(0, 'rgba(56, 151, 240, 0.4)');
verifiedGlow.addColorStop(1, 'rgba(56, 151, 240, 0)');
ctx.fillStyle = verifiedGlow;
ctx.fill();

// Adicionar detalhe de brilho no topo do círculo
ctx.beginPath();
ctx.arc(iconX, iconY - iconRadius/2, iconRadius/3, 0, Math.PI, true);
const verifiedHighlight = ctx.createRadialGradient(
iconX, iconY - iconRadius/2, 0,
iconX, iconY - iconRadius/2, iconRadius/3
);
verifiedHighlight.addColorStop(0, 'rgba(255, 255, 255, 0.7)');
verifiedHighlight.addColorStop(1, 'rgba(255, 255, 255, 0)');
ctx.fillStyle = verifiedHighlight;
ctx.fill();

// Resetar sombra para o ícone de verificação
ctx.shadowColor = 'transparent';
ctx.shadowBlur = 0;
ctx.shadowOffsetX = 0;
ctx.shadowOffsetY = 0;

ctx.font = 'bold 18px Arial, sans-serif';
ctx.fillStyle = 'white';
ctx.textAlign = 'center';
ctx.textBaseline = 'middle';
ctx.fillText(verifiedIcon, iconX, iconY);

// Resetar alinhamento de texto
ctx.textAlign = 'left';
ctx.textBaseline = 'top';

// Duração com ícone de relógio corrigido
const duracaoX = tituloX;
const duracaoY = cardY + 160; // Movido para cima

ctx.font = '32px Arial, sans-serif';
ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';

// Substituir ícone de relógio por ícone de player moderno e formatação de tempo
// Desenhar o ícone de play (triângulo)
const playIconSize = 24;
const playIconX = duracaoX;
const playIconY = duracaoY + 16;

// Círculo externo para o play
ctx.beginPath();
ctx.arc(playIconX, playIconY, playIconSize, 0, Math.PI * 2);
ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
ctx.fill();

// Triângulo de play
ctx.beginPath();
ctx.moveTo(playIconX - 8, playIconY - 12);
ctx.lineTo(playIconX - 8, playIconY + 12);
ctx.lineTo(playIconX + 12, playIconY);
ctx.closePath();
ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
ctx.fill();

// Formatação do tempo como em um player real
let tempoFormatado = "00:50";
// Verificar se já está no formato de tempo
if (!duracao.includes(':')) {
// Converter para formato de tempo se for apenas um número
const minutos = Math.floor(parseFloat(duracao) / 60);
const segundos = Math.floor(parseFloat(duracao) % 60);
tempoFormatado = `${minutos.toString().padStart(2, '0')}:${segundos.toString().padStart(2, '0')}`;
} else {
tempoFormatado = duracao;
}

// Posição do texto de tempo
const tempoX = playIconX + playIconSize + 15;
ctx.fillText(`${tempoFormatado}`, tempoX, duracaoY);

// Adicionar pequeno ícone de volume à direita
const volumeX = tempoX + ctx.measureText(`${tempoFormatado}`).width + 30;
const volumeY = duracaoY + 16;

// Desenhar ícone de volume (alto-falante)
ctx.beginPath();
ctx.moveTo(volumeX - 7, volumeY);
ctx.lineTo(volumeX - 2, volumeY - 5);
ctx.lineTo(volumeX - 2, volumeY + 5);
ctx.lineTo(volumeX - 7, volumeY);
ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
ctx.fill();

// Desenhar ondas de som
ctx.beginPath();
ctx.arc(volumeX + 2, volumeY, 6, -Math.PI/3, Math.PI/3);
ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
ctx.lineWidth = 2;
ctx.stroke();

ctx.beginPath();
ctx.arc(volumeX + 2, volumeY, 10, -Math.PI/3, Math.PI/3);
ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
ctx.lineWidth = 2;
ctx.stroke();

// ===== BARRA DE PROGRESSO MODERNA =====

// Dimensões da barra de progresso estilo YouTube
const barWidth = cardWidth - 80;
const barHeight = 8; // Mais fina como no YouTube
const barX = cardX + 40;
const barY = cardY + 220; // Movido para cima

// Cantos arredondados para as barras
const barRadius = barHeight / 2;

// Barra de fundo
ctx.beginPath();
ctx.moveTo(barX + barRadius, barY);
ctx.lineTo(barX + barWidth - barRadius, barY);
ctx.arc(barX + barWidth - barRadius, barY + barRadius, barRadius, -Math.PI/2, Math.PI/2, false);
ctx.lineTo(barX + barRadius, barY + barHeight);
ctx.arc(barX + barRadius, barY + barRadius, barRadius, Math.PI/2, -Math.PI/2, false);
ctx.closePath();

ctx.fillStyle = 'rgba(90, 90, 90, 0.7)';
ctx.fill();

// Adicionar efeito de brilho à barra (reflexo de luz)
const barGlow = ctx.createLinearGradient(barX, barY - 1, barX, barY + 1);
barGlow.addColorStop(0, 'rgba(255, 255, 255, 0.15)');
barGlow.addColorStop(0.5, 'rgba(255, 255, 255, 0)');
barGlow.addColorStop(1, 'rgba(255, 255, 255, 0)');

ctx.fillStyle = barGlow;
ctx.fillRect(barX, barY - 1, barWidth, 2);

// Calcular preenchimento da barra (metade da barra para o exemplo)
let progressValue = 0.5; // Valor fixo para demonstração - aparência de player real

// Se duracao é um número, calcular com base nele
if (!isNaN(parseFloat(duracao))) {
progressValue = Math.min(parseFloat(duracao) / 100, 1);
}

const fillWidth = Math.max(barHeight, Math.floor(barWidth * progressValue));

// Barra de progresso
if (fillWidth > 0) {
ctx.beginPath();

if (fillWidth >= barWidth - barRadius) {
// Se preenchimento completo, usar mesma forma da barra de fundo
ctx.moveTo(barX + barRadius, barY);
ctx.lineTo(barX + barWidth - barRadius, barY);
ctx.arc(barX + barWidth - barRadius, barY + barRadius, barRadius, -Math.PI/2, Math.PI/2, false);
ctx.lineTo(barX + barRadius, barY + barHeight);
ctx.arc(barX + barRadius, barY + barRadius, barRadius, Math.PI/2, -Math.PI/2, false);
} else {
// Se preenchimento parcial, arredondar apenas as pontas esquerdas
ctx.moveTo(barX + barRadius, barY);
ctx.lineTo(barX + fillWidth, barY);
ctx.lineTo(barX + fillWidth, barY + barHeight);
ctx.lineTo(barX + barRadius, barY + barHeight);
ctx.arc(barX + barRadius, barY + barRadius, barRadius, Math.PI/2, -Math.PI/2, false);
}

ctx.closePath();

// Gradiente para a barra de progresso baseado no tema atual
const progressGradient = ctx.createLinearGradient(barX, barY, barX + fillWidth, barY);
progressGradient.addColorStop(0, accentColor.replace('$opacity', '1'));
progressGradient.addColorStop(0.5, secondaryColor.replace('$opacity', '1'));
progressGradient.addColorStop(1, thirdColor.replace('$opacity', '1'));

ctx.fillStyle = progressGradient;
ctx.fill();

// Efeito de brilho na barra de progresso (resplandor)
const progressGlow = ctx.createLinearGradient(barX, barY - 2, barX, barY + barHeight + 2);
progressGlow.addColorStop(0, 'rgba(255, 255, 255, 0.2)');
progressGlow.addColorStop(0.5, 'rgba(255, 255, 255, 0)');
progressGlow.addColorStop(1, 'rgba(255, 255, 255, 0.1)');

ctx.fillStyle = progressGlow;
ctx.fillRect(barX, barY - 2, fillWidth, barHeight + 4);

// Círculo no final da barra de progresso (como na imagem)
const thumbSize = 16;
const thumbX = barX + fillWidth;
const thumbY = barY + barHeight/2;

// Adicionar brilho externo ao thumb com cor baseada no tema
ctx.beginPath();
ctx.arc(thumbX, thumbY, thumbSize, 0, Math.PI * 2);
const thumbGlow = ctx.createRadialGradient(
thumbX, thumbY, thumbSize/2,
thumbX, thumbY, thumbSize
);
thumbGlow.addColorStop(0, accentColor.replace('$opacity', '0.5'));
thumbGlow.addColorStop(1, accentColor.replace('$opacity', '0'));
ctx.fillStyle = thumbGlow;
ctx.fill();

// Sombra para o círculo
ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
ctx.shadowBlur = 5;
ctx.shadowOffsetX = 1;
ctx.shadowOffsetY = 1;

// Desenhar círculo com borda branca
// Borda branca
ctx.beginPath();
ctx.arc(thumbX, thumbY, thumbSize/2 + 2, 0, Math.PI * 2);
ctx.fillStyle = 'white';
ctx.fill();

// Círculo interno com cor baseada no tema
ctx.beginPath();
ctx.arc(thumbX, thumbY, thumbSize/2, 0, Math.PI * 2);
ctx.fillStyle = accentColor.replace('$opacity', '1');
ctx.fill();

// Brilho no círculo
ctx.beginPath();
ctx.arc(thumbX - thumbSize/5, thumbY - thumbSize/5, thumbSize/5, 0, Math.PI * 2);
ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
ctx.fill();

// Resetar sombra
ctx.shadowColor = 'transparent';
ctx.shadowBlur = 0;
ctx.shadowOffsetX = 0;
ctx.shadowOffsetY = 0;
}

// Adicionar marcadores de tempo nas extremidades da barra
const timeTextY = barY + 25;
ctx.font = '20px Arial, sans-serif';
ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';

// Tempo atual (início da barra) - valor fixo para demonstração
let tempoAtual = "00:25";
if (!isNaN(parseFloat(duracao))) {
const currentSeconds = Math.floor(parseFloat(duracao) * progressValue);
const currentMinutes = Math.floor(currentSeconds / 60);
const remainingSeconds = currentSeconds % 60;
tempoAtual = `${currentMinutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
}
ctx.textAlign = 'left';
ctx.fillText(tempoAtual, barX, timeTextY);

// Tempo total (fim da barra) - valor fixo para demonstração
let tempoTotal = "00:50";
if (!isNaN(parseFloat(duracao))) {
const totalSeconds = Math.floor(parseFloat(duracao));
const totalMinutes = Math.floor(totalSeconds / 60);
const remainingSeconds = totalSeconds % 60;
tempoTotal = `${totalMinutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
} else if (duracao.includes(':')) {
tempoTotal = duracao;
}
ctx.textAlign = 'right';
ctx.fillText(tempoTotal, barX + barWidth, timeTextY);

// Resetar alinhamento
ctx.textAlign = 'left';

// ===== CONTROLES DE PLAYER =====

// Adicionar controles de player abaixo da barra de progresso (posição ajustada para cima)
const controlsY = barY + 50;
const controlCenter = barX + barWidth / 2;
const controlsSpacing = 55; // Menor espaçamento para ficar mais próximo da imagem

// Calcular posições exatas para os 5 controles alinhados com a imagem
const playPosition = controlCenter;
const prevPosition = playPosition - controlsSpacing;
const nextPosition = playPosition + controlsSpacing;
const shufflePosition = prevPosition - controlsSpacing;
const repeatPosition = nextPosition + controlsSpacing;

// Função para desenhar controle circular com melhorias visuais
function drawControl(x, y, isPlay = false) {
// Sombra para os controles
ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
ctx.shadowBlur = 8;
ctx.shadowOffsetX = 0;
ctx.shadowOffsetY = 2;

// Tamanho maior para o botão de play
const buttonSize = isPlay ? 24 : 20;

// Círculo de fundo
ctx.beginPath();
ctx.arc(x, y, buttonSize, 0, Math.PI * 2);
ctx.fillStyle = isPlay ? accentColor.replace('$opacity', '0.9') : 'rgba(255, 255, 255, 0.15)';
ctx.fill();

// Adicionar borda
ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
ctx.lineWidth = 1;
ctx.stroke();

// Adicionar brilho no topo do botão (efeito de luz)
ctx.beginPath();
ctx.arc(x, y - buttonSize/2, buttonSize/2, 0, Math.PI, true);
const glowGradient = ctx.createRadialGradient(x, y - buttonSize/2, 0, x, y - buttonSize/2, buttonSize/2);
glowGradient.addColorStop(0, 'rgba(255, 255, 255, 0.3)');
glowGradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
ctx.fillStyle = glowGradient;
ctx.fill();

// Resetar sombra
ctx.shadowColor = 'transparent';
ctx.shadowBlur = 0;
ctx.shadowOffsetX = 0;
ctx.shadowOffsetY = 0;

return buttonSize;
}

// Botão shuffle (aleatório) - mais à esquerda
const shuffleSize = drawControl(shufflePosition, controlsY);

// Ícone de aleatório (shuffle)
// Primeira linha
ctx.beginPath();
ctx.moveTo(shufflePosition - 7, controlsY - 5);
ctx.lineTo(shufflePosition, controlsY - 5);
ctx.lineTo(shufflePosition + 7, controlsY + 5);
ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
ctx.lineWidth = 1.5;
ctx.stroke();

// Segunda linha
ctx.beginPath();
ctx.moveTo(shufflePosition - 7, controlsY + 5);
ctx.lineTo(shufflePosition, controlsY + 5);
ctx.lineTo(shufflePosition + 7, controlsY - 5);
ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
ctx.lineWidth = 1.5;
ctx.stroke();

// Setas nas pontas
ctx.beginPath();
ctx.moveTo(shufflePosition + 7, controlsY - 7);
ctx.lineTo(shufflePosition + 7, controlsY - 3);
ctx.lineTo(shufflePosition + 4, controlsY - 5);
ctx.closePath();
ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
ctx.fill();

ctx.beginPath();
ctx.moveTo(shufflePosition + 7, controlsY + 7);
ctx.lineTo(shufflePosition + 7, controlsY + 3);
ctx.lineTo(shufflePosition + 4, controlsY + 5);
ctx.closePath();
ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
ctx.fill();

// Botão voltar (anterior)
const prevSize = drawControl(prevPosition, controlsY);

// Ícone de voltar (anterior)
ctx.beginPath();
ctx.moveTo(prevPosition + 5, controlsY - 8);
ctx.lineTo(prevPosition - 5, controlsY);
ctx.lineTo(prevPosition + 5, controlsY + 8);
ctx.closePath();
ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
ctx.fill();

// Linha vertical para completar ícone de anterior
ctx.beginPath();
ctx.moveTo(prevPosition - 5, controlsY - 8);
ctx.lineTo(prevPosition - 5, controlsY + 8);
ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
ctx.lineWidth = 1.5;
ctx.stroke();

// Botão de play (destacado/preenchido)
const playSize = drawControl(playPosition, controlsY, true);

// Adicionar brilho externo ao botão de play
ctx.beginPath();
ctx.arc(playPosition, controlsY, playSize + 5, 0, Math.PI * 2);
const playGlow = ctx.createRadialGradient(
playPosition, controlsY, playSize,
playPosition, controlsY, playSize + 10
);
playGlow.addColorStop(0, accentColor.replace('$opacity', '0.5'));
playGlow.addColorStop(1, accentColor.replace('$opacity', '0'));
ctx.fillStyle = playGlow;
ctx.fill();

// Efeito de pulsação (segundo anel de brilho)
ctx.beginPath();
ctx.arc(playPosition, controlsY, playSize + 15, 0, Math.PI * 2);
const playPulseGlow = ctx.createRadialGradient(
playPosition, controlsY, playSize + 7,
playPosition, controlsY, playSize + 20
);
playPulseGlow.addColorStop(0, accentColor.replace('$opacity', '0.3'));
playPulseGlow.addColorStop(1, accentColor.replace('$opacity', '0'));
ctx.fillStyle = playPulseGlow;
ctx.fill();

// Efeito de pulsação (terceiro anel de brilho)
ctx.beginPath();
ctx.arc(playPosition, controlsY, playSize + 12, 0, Math.PI * 2);
const pulseGlow = ctx.createRadialGradient(
playPosition, controlsY, playSize + 5,
playPosition, controlsY, playSize + 20
);
pulseGlow.addColorStop(0, accentColor.replace('$opacity', '0.2'));
pulseGlow.addColorStop(1, accentColor.replace('$opacity', '0'));
ctx.fillStyle = pulseGlow;
ctx.fill();

// Triângulo de play maior e mais visível
ctx.beginPath();
ctx.moveTo(playPosition - 5, controlsY - 10);
ctx.lineTo(playPosition - 5, controlsY + 10);
ctx.lineTo(playPosition + 10, controlsY);
ctx.closePath();
ctx.fillStyle = 'white';
ctx.fill();

// Botão avançar (próximo)
const nextSize = drawControl(nextPosition, controlsY);

// Ícone de avançar (próximo)
ctx.beginPath();
ctx.moveTo(nextPosition - 5, controlsY - 8);
ctx.lineTo(nextPosition + 5, controlsY);
ctx.lineTo(nextPosition - 5, controlsY + 8);
ctx.closePath();
ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
ctx.fill();

// Linha vertical para completar ícone de próximo
ctx.beginPath();
ctx.moveTo(nextPosition + 5, controlsY - 8);
ctx.lineTo(nextPosition + 5, controlsY + 8);
ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
ctx.lineWidth = 1.5;
ctx.stroke();

// Botão de repetição
const repeatSize = drawControl(repeatPosition, controlsY);

// Ícone de repetição (círculo com seta)
ctx.beginPath();
ctx.arc(repeatPosition, controlsY, 8, 0, Math.PI * 1.7);
ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
ctx.lineWidth = 1.5;
ctx.stroke();

// Seta do ícone de repetição
ctx.beginPath();
ctx.moveTo(repeatPosition + 8, controlsY - 4);
ctx.lineTo(repeatPosition + 10, controlsY + 1);
ctx.lineTo(repeatPosition + 5, controlsY + 1);
ctx.closePath();
ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
ctx.fill();

// ===== EFEITOS ADICIONAIS DE BRILHO NO CARD =====

// Adicionar efeito de brilho nas bordas do card para parecer mais premium
const cardGlowSize = 150;
const cardGlowPositions = [
{x: cardX + cardWidth/4, y: cardY}, // Topo
{x: cardX + cardWidth*3/4, y: cardY}, // Topo
{x: cardX + cardWidth/2, y: cardY + cardHeight} // Parte inferior
];

cardGlowPositions.forEach((pos, index) => {
const glow = ctx.createRadialGradient(
pos.x, pos.y, 0,
pos.x, pos.y, cardGlowSize
);

// Usar cores do tema para o brilho do card
if (index === 0) {
glow.addColorStop(0, accentColor.replace('$opacity', '0.15'));
glow.addColorStop(1, accentColor.replace('$opacity', '0'));
} else if (index === 1) {
glow.addColorStop(0, secondaryColor.replace('$opacity', '0.15'));
glow.addColorStop(1, secondaryColor.replace('$opacity', '0'));
} else {
glow.addColorStop(0, thirdColor.replace('$opacity', '0.15'));
glow.addColorStop(1, thirdColor.replace('$opacity', '0'));
}

ctx.fillStyle = glow;
ctx.fillRect(pos.x - cardGlowSize, pos.y - cardGlowSize, cardGlowSize * 2, cardGlowSize * 2);
});

// ===== MARCAS D'ÁGUA EM AMBOS OS LADOS =====

// Adicionar sombra sutil para as marcas d'água
ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
ctx.shadowBlur = 3;
ctx.shadowOffsetX = 1;
ctx.shadowOffsetY = 1;

// Marca d'água à esquerda
ctx.font = '16px Arial, sans-serif';
ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
ctx.textAlign = 'left';
ctx.fillText("Music Card Generator", 30, height - 20);

// Marca d'água à direita em duas linhas
ctx.textAlign = 'right';
ctx.fillText("By: @paulo_mod_domina", width - 30, height - 20);

// Remover sombra após desenhar as marcas d'água
ctx.shadowColor = 'transparent';
ctx.shadowBlur = 0;
ctx.shadowOffsetX = 0;
ctx.shadowOffsetY = 0;

// ===== EFEITOS DE LUZES E LINHAS CINÉTICAS NA TELA =====

// Adicionar linhas cinéticas em torno da tela para um visual mais dinâmico
// Aplicar sombra para as linhas cinéticas
ctx.shadowColor = accentColor.replace('$opacity', '0.5');
ctx.shadowBlur = 10;
ctx.shadowOffsetX = 0;
ctx.shadowOffsetY = 0;

// Usar as mesmas variáveis definidas anteriormente (lineCount, lineStartRadius, lineEndRadius)
for (let i = 0; i < lineCount; i++) {
const angle = (Math.PI * 2 * i / lineCount) + (Math.PI / 5);
const x1 = width / 2 + Math.cos(angle) * lineStartRadius;
const y1 = height / 2 + Math.sin(angle) * lineStartRadius;
const x2 = width / 2 + Math.cos(angle) * lineEndRadius;
const y2 = height / 2 + Math.sin(angle) * lineEndRadius;

const lineGradient = ctx.createLinearGradient(x1, y1, x2, y2);

// Alternar entre as cores de destaque do tema
if (i % 3 === 0) {
lineGradient.addColorStop(0, accentColor.replace('$opacity', '0.7'));
} else if (i % 3 === 1) {
lineGradient.addColorStop(0, secondaryColor.replace('$opacity', '0.7'));
} else {
lineGradient.addColorStop(0, thirdColor.replace('$opacity', '0.7'));
}

lineGradient.addColorStop(1, 'rgba(0, 0, 0, 0)');

ctx.beginPath();
ctx.moveTo(x1, y1);
ctx.lineTo(x2, y2);
ctx.strokeStyle = lineGradient;
ctx.lineWidth = 2 + Math.random() * 3;
ctx.stroke();
}

// Adicionar efeito de resplandor nos cantos da tela apenas para o tema Dourado/Âmbar Premium
if (temaAtual === 5) { // Mantemos os quadrados de canto apenas para o tema Dourado/Âmbar Premium
const cornerGlowSize = 200; // Tamanho reduzido
const corners = [
{x: 0, y: 0},
{x: width, y: 0},
{x: 0, y: height},
{x: width, y: height}
];

corners.forEach((corner, index) => {
const cornerGlow = ctx.createRadialGradient(
corner.x, corner.y, 0,
corner.x, corner.y, cornerGlowSize
);

// Usar cores baseadas no tema atual, mas com opacidade reduzida
let cornerColor;
if (index === 0) {
cornerColor = accentColor.replace('$opacity', '0.25'); // Aumentado um pouco para o tema dourado
} else if (index === 1) {
cornerColor = secondaryColor.replace('$opacity', '0.25');
} else if (index === 2) {
cornerColor = thirdColor.replace('$opacity', '0.25');
} else {
// Misturar cores para o último canto
cornerColor = accentColor.replace('$opacity', '0.25');
}

cornerGlow.addColorStop(0, cornerColor);
cornerGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');

ctx.fillStyle = cornerGlow;
ctx.fillRect(
corner.x - (corner.x === 0 ? 0 : cornerGlowSize),
corner.y - (corner.y === 0 ? 0 : cornerGlowSize),
cornerGlowSize,
cornerGlowSize
);
});
}

// Adicionar mais estrelas especiais brilhantes em toda a tela
for (let i = 0; i < 30; i++) {
const x = Math.random() * width;
const y = Math.random() * height;
const size = Math.random() * 4 + 2;

// Estrela com raios
ctx.save();
ctx.translate(x, y);

// Brilho da estrela
const starGlow = ctx.createRadialGradient(0, 0, 0, 0, 0, size * 4);
starGlow.addColorStop(0, 'rgba(255, 255, 255, 0.8)');
starGlow.addColorStop(0.5, 'rgba(255, 255, 255, 0.3)');
starGlow.addColorStop(1, 'rgba(255, 255, 255, 0)');

ctx.fillStyle = starGlow;
ctx.fillRect(-size * 4, -size * 4, size * 8, size * 8);

// Raios da estrela
ctx.beginPath();
for (let ray = 0; ray < 4; ray++) {
const rayAngle = (ray * Math.PI / 2);
const rayLength = size * 6;
ctx.moveTo(0, 0);
ctx.lineTo(
Math.cos(rayAngle) * rayLength,
Math.sin(rayAngle) * rayLength
);
}
ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
ctx.lineWidth = 0.5;
ctx.stroke();

// Centro da estrela
ctx.beginPath();
ctx.arc(0, 0, size, 0, Math.PI * 2);
ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
ctx.fill();

ctx.restore();
}

// Adicionar efeito de circuitos digitais ao redor da tela
const circuitPoints = 12;
const circuitRadius = Math.max(width, height) * 0.9;

ctx.save();
ctx.translate(width / 2, height / 2);

// Desenhar linhas de circuito
for (let i = 0; i < circuitPoints; i++) {
const angle1 = Math.PI * 2 * i / circuitPoints;
const angle2 = Math.PI * 2 * ((i + 1) % circuitPoints) / circuitPoints;

const x1 = Math.cos(angle1) * circuitRadius;
const y1 = Math.sin(angle1) * circuitRadius;
const x2 = Math.cos(angle2) * circuitRadius;
const y2 = Math.sin(angle2) * circuitRadius;

// Só conectar alguns pontos para um efeito mais interessante
if (Math.random() > 0.3) {
const circuitGradient = ctx.createLinearGradient(x1, y1, x2, y2);
circuitGradient.addColorStop(0, 'rgba(111, 30, 214, 0.15)');
circuitGradient.addColorStop(1, 'rgba(29, 151, 208, 0.15)');

ctx.beginPath();
ctx.moveTo(x1, y1);
ctx.lineTo(x2, y2);
ctx.strokeStyle = circuitGradient;
ctx.lineWidth = 1.5;
ctx.stroke();

// Adicionar nós nos pontos de conexão
ctx.beginPath();
ctx.arc(x1, y1, 4, 0, Math.PI * 2);
ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
ctx.fill();
}
}

ctx.restore();

// ===== EFEITOS ADICIONAIS NA BORDA DO CARD =====

// Adicionar ondas de energia ao longo das bordas do card
const wavePoints = 100;
const waveAmplitude = 8;
const waveFrequency = 20;

ctx.save();

// Sombra para as ondas
ctx.shadowColor = 'rgba(247, 64, 230, 0.6)';
ctx.shadowBlur = 15;

// Desenhar ondas ao longo das bordas do card (topo e fundo)
ctx.beginPath();

// Topo do card
for (let i = 0; i <= wavePoints; i++) {
const x = cardX + (cardWidth * i / wavePoints);
const wave = Math.sin(i / waveFrequency * Math.PI * 2) * waveAmplitude;
const y = cardY + wave - 5; // Afastar um pouco da borda

if (i === 0) {
ctx.moveTo(x, y);
} else {
ctx.lineTo(x, y);
}
}

// Parte inferior do card
for (let i = wavePoints; i >= 0; i--) {
const x = cardX + (cardWidth * i / wavePoints);
const wave = Math.sin(i / waveFrequency * Math.PI * 2) * waveAmplitude;
const y = cardY + cardHeight - wave + 5; // Afastar um pouco da borda

ctx.lineTo(x, y);
}

// Gradiente para as ondas baseado nas cores do tema
const waveGradient = ctx.createLinearGradient(cardX, cardY, cardX + cardWidth, cardY);
waveGradient.addColorStop(0, accentColor.replace('$opacity', '0.3'));
waveGradient.addColorStop(0.5, secondaryColor.replace('$opacity', '0.3'));
waveGradient.addColorStop(1, thirdColor.replace('$opacity', '0.3'));

ctx.strokeStyle = waveGradient;
ctx.lineWidth = 2;
ctx.stroke();

ctx.restore();

// Adicionar brilhos sutis nos cantos do card em posições estratégicas
const cardCornerGlows = [
{x: cardX, y: cardY}, // Superior esquerdo
{x: cardX + cardWidth, y: cardY}, // Superior direito
{x: cardX, y: cardY + cardHeight}, // Inferior esquerdo
{x: cardX + cardWidth, y: cardY + cardHeight} // Inferior direito
];

cardCornerGlows.forEach((corner, index) => {
// Tamanho diferente para cada canto (mais suave)
const glowSize = 40 + index * 7;

// Cores baseadas no tema atual (mais suaves)
let glowColor;
if (index === 0) glowColor = accentColor.replace('$opacity', '0.25');
else if (index === 1) glowColor = secondaryColor.replace('$opacity', '0.25');
else if (index === 2) glowColor = thirdColor.replace('$opacity', '0.25');
else glowColor = accentColor.replace('$opacity', '0.25');

// Criar brilho
const cornerGlow = ctx.createRadialGradient(
corner.x, corner.y, 0,
corner.x, corner.y, glowSize
);
cornerGlow.addColorStop(0, glowColor);
cornerGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');

ctx.fillStyle = cornerGlow;
ctx.fillRect(
corner.x - glowSize, 
corner.y - glowSize, 
glowSize * 2, 
glowSize * 2
);
});

// Remover sombra antes das marcas d'água
ctx.shadowColor = 'transparent';
ctx.shadowBlur = 0;
ctx.shadowOffsetX = 0;
ctx.shadowOffsetY = 0;

// Retornar o buffer da imagem
return canvas.toBuffer();
}

/**
 * Trunca texto para caber em uma largura máxima
 * @param {CanvasRenderingContext2D} ctx - Contexto do canvas
 * @param {string} text - Texto a ser truncado
 * @param {number} maxWidth - Largura máxima disponível
 * @returns {string} Texto truncado se necessário
 */
function truncateText(ctx, text, maxWidth) {
const ellipsis = '...';
const ellipsisWidth = ctx.measureText(ellipsis).width;

// Se o texto já cabe, retorná-lo sem alterações
if (ctx.measureText(text).width <= maxWidth) {
return text;
}

// Truncar texto
let truncated = text;
let textWidth = ctx.measureText(truncated).width;

while (textWidth + ellipsisWidth > maxWidth && truncated.length > 0) {
truncated = truncated.slice(0, -1);
textWidth = ctx.measureText(truncated).width;
}

return truncated + ellipsis;
}

module.exports = { generateMusicCard };
