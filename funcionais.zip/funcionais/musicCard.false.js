const { createCanvas, loadImage } = require('canvas');

/**
 * Função para desenhar retângulos arredondados
 */
function roundRect(ctx, x, y, width, height, radius, fill = false, stroke = false) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
    if (fill) ctx.fill();
    if (stroke) ctx.stroke();
}

/**
 * Gera o buffer da imagem do Music Card
 */
async function generateMusicCardV2({ nome, autor, thumb, progresso, start, end, opacity = 85 }) {
    const canvas = createCanvas(1100, 450);
    const ctx = canvas.getContext('2d');
    const progressNum = Math.max(0, Math.min(100, Number(progresso)));

    // Carregar Thumbnail
    const thumbImg = await loadImage(thumb);

    // Fundo Imersivo
    ctx.drawImage(thumbImg, 0, 0, canvas.width, canvas.height);
    ctx.fillStyle = `rgba(0, 0, 0, ${opacity / 100})`;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Capa (Thumbnail)
    const thumbSize = 300;
    const thumbX = 80;
    const thumbY = (canvas.height - thumbSize) / 2;
    
    ctx.save();
    roundRect(ctx, thumbX, thumbY, thumbSize, thumbSize, 35);
    ctx.clip();
    ctx.drawImage(thumbImg, thumbX, thumbY, thumbSize, thumbSize);
    ctx.restore();

    // Borda de vidro na capa
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
    ctx.lineWidth = 2;
    roundRect(ctx, thumbX, thumbY, thumbSize, thumbSize, 35, false, true);

    // Textos e Selo de Verificado
    const textX = thumbX + thumbSize + 70;
    
    // Título
    ctx.font = 'bold 50px sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(nome.length > 20 ? nome.substring(0, 17) + "..." : nome, textX, 170);

    // Autor
    ctx.font = '32px sans-serif';
    ctx.fillStyle = '#aaaaaa';
    const authorText = autor.length > 25 ? autor.substring(0, 22) + "..." : autor;
    const authorWidth = ctx.measureText(authorText).width;
    ctx.fillText(authorText, textX, 220);

    // Selo de Verificado
    const vX = textX + authorWidth + 20;
    const vY = 210;
    const vSize = 14;
    ctx.fillStyle = '#3ea6ff';
    ctx.beginPath();
    ctx.arc(vX, vY, vSize, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(vX - 6, vY);
    ctx.lineTo(vX - 2, vY + 5);
    ctx.lineTo(vX + 6, vY - 5);
    ctx.stroke();

    // Barra de Progresso
    const barX = textX;
    const barY = 290;
    const barWidth = 550;
    const barHeight = 6;
    
    ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
    roundRect(ctx, barX, barY, barWidth, barHeight, 3, true);

    const progressWidth = (barWidth * progressNum) / 100;
    ctx.fillStyle = '#ff0000';
    roundRect(ctx, barX, barY, progressWidth, barHeight, 3, true);

    // Marcador (Knob)
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(barX + progressWidth, barY + barHeight / 2, 10, 0, Math.PI * 2);
    ctx.fill();

    // Tempos
    ctx.font = '22px sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(start, barX, barY + 45);
    ctx.textAlign = 'right';
    ctx.fillText(end, barX + barWidth, barY + 45);
    ctx.textAlign = 'left';

    // Controles
    const ctrlX = textX + 220;
    const ctrlY = 380;
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.moveTo(ctrlX - 15, ctrlY - 20);
    ctx.lineTo(ctrlX - 15, ctrlY + 20);
    ctx.lineTo(ctrlX + 25, ctrlY);
    ctx.fill();

    return canvas.toBuffer('image/png');
}

module.exports = { generateMusicCardV2 };
