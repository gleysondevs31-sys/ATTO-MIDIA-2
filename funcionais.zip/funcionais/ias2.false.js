//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

/* 

* EXEMPLO:

const scraper = require('./freeAIScraper');

// Rota para chat com Gemini - Retorna JSON
app.get('/chat', async (req, res) => {
try {
const prompt = req.query.prompt || 'Explique o que é inteligência artificial';
const resposta = await scraper.chatWithGeminiFree(prompt);
res.json({
status: true,
criador: "@paulo_mod_domina",
resultado: resposta
});
} catch (error) {
res.status(500).json({
status: false,
message: error.message
});
}
});

// Rota para gerar imagem com Pollinations - Retorna imagem bruta
app.get('/pollinations-image', async (req, res) => {
try {
const prompt = req.query.prompt || 'uma paisagem futurista';
const image = await scraper.generateImagePollinations(prompt);
res.setHeader('Content-Type', image.contentType);
res.send(image.buffer);
} catch (error) {
res.status(500).send(`Erro ao gerar imagem: ${error.message}`);
}
});

// Rota para gerar rosto aleatório - Retorna imagem bruta
app.get('/random-face', async (req, res) => {
try {
const image = await scraper.generateImageThispersondoesnotexist();
res.setHeader('Content-Type', image.contentType);
res.send(image.buffer);
} catch (error) {
res.status(500).send(`Erro ao gerar rosto: ${error.message}`);
}
});

// Rota para download de imagem
app.get('/download-image', async (req, res) => {
try {
const url = req.query.url;
const filename = req.query.filename || 'imagem_baixada.jpg';
if (!url) {
return res.status(400).send('Parâmetro "url" é obrigatório');
}
const success = await scraper.downloadImage(url, filename);
if (success) {
res.download(filename);
} else {
res.status(500).send('Falha ao baixar imagem');
}
} catch (error) {
res.status(500).send(`Erro ao baixar imagem: ${error.message}`);
}
});

*/

const axios = require("axios")
const { URLSearchParams } = require("url")
const fs = require("fs")
const { GoogleGenerativeAI } = require("@google/generative-ai")

class FreeAIScraper {
constructor() {
this.session = axios.create({
headers: {
"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
}
});
}

async chatWithGeminiFree(prompt) {
try {
const apiKey = "AIzaSyACbd2Srxte_hJQF-2liWWQA-dLu-xxlIs";
if (!apiKey) {
throw new Error("Chave API do Gemini não configurada");
}
const genAI = new GoogleGenerativeAI(apiKey);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
const result = await model.generateContent(prompt);
const response = await result.response;
return response.text();
} catch (e) {
console.error(`Erro ao usar Gemini: ${e.message}`);
throw e;
}
}

async generateImagePollinations(prompt, width = 512, height = 512) {
try {
const encodedPrompt = encodeURIComponent(prompt);
const url = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=${width}&height=${height}`;
const response = await this.session.get(url, { 
responseType: "arraybuffer",
timeout: 60000 
});
if (response.status === 200) {
return {
url,
buffer: Buffer.from(response.data),
contentType: response.headers["content-type"] || "image/jpeg"
};
} else {
throw new Error(`Erro Pollinations: ${response.status}`);
}

} catch (e) {
console.error(`Erro ao gerar imagem com Pollinations: ${e.message}`);
throw e;
}
}

async generateImageThispersondoesnotexist() {
try {
const url = "https://thispersondoesnotexist.com/";
const response = await this.session.get(url, { 
responseType: "arraybuffer",
timeout: 30000 
});
if (response.status === 200) {
return {
url,
buffer: Buffer.from(response.data),
contentType: response.headers["content-type"] || "image/jpeg"
};
} else {
throw new Error(`Erro ThisPersonDoesNotExist: ${response.status}`);
}
} catch (e) {
console.error(`Erro ao gerar rosto: ${e.message}`);
throw e;
}
}

async downloadImage(url, filename) {
try {
const response = await this.session.get(url, { 
responseType: "arraybuffer", 
timeout: 30000 
});
if (response.status === 200) {
fs.writeFileSync(filename, Buffer.from(response.data));
return true;
}
return false;
} catch (e) {
console.error(`Erro ao baixar imagem: ${e.message}`);
return false;
}
}
}

module.exports = new FreeAIScraper();