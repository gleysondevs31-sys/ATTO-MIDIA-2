//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

/*
EXEMPLO:

const createGuraSticker = require('./base de dados/gura-canvas.js')

app.get('/api/canvas/gura', async (req, res) => {
url = req.query.url
if (!url) return res.status(400).json({ error: 'Parâmetro URL ausente' })
try {
const stickerBuffer = await createGuraSticker(url)
res.set({
'Content-Type': 'image/webp',
'Content-Disposition': 'attachment; filename=gura-sticker.webp'
})
res.send(stickerBuffer)
} catch (error) {
console.error(error)
res.status(500).json({ error: error.message })
}
})

*/

const { createCanvas, loadImage } = require('canvas')
const { Sticker, StickerTypes } = require('wa-sticker-formatter')
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args))

async function createGuraSticker(url) {
async function fetchImage(url) {
const response = await fetch(url);
if (!response.ok) throw new Error(`Falha ao baixar imagem: ${response.statusText}`);
return Buffer.from(await response.arrayBuffer());
}
async function gura(imageBuffer) {
const bg = await loadImage('https://files.catbox.moe/trfgwb.png');
const img = await loadImage(imageBuffer);
const c = createCanvas(bg.width, bg.height);
const x = 395, y = 200, w = 310, h = 310;
const ctx = c.getContext('2d');
ctx.drawImage(bg, 0, 0);
const r = img.width / img.height;
let sx, sy, sw, sh;
if (r > 1) {
sh = img.height;
sw = img.height;
sx = (img.width - sw) / 2;
sy = 0;
} else {
sw = img.width;
sh = img.width;
sx = 0;
sy = (img.height - sh) / 2;
}
ctx.drawImage(img, sx, sy, sw, sh, x, y, w, h);
return c.toBuffer('image/png')
}
try {
const imageBuffer = await fetchImage(url)
const processedImage = await gura(imageBuffer)
const sticker = new Sticker(processedImage, {
pack: 'CanvasGura',
author: '@paulo_mod_domina',
type: StickerTypes.FULL,
quality: 80
})
return sticker.toBuffer()
} catch (error) {
throw new Error(`Erro no processamento: ${error.message}`)
}
}

module.exports = createGuraSticker