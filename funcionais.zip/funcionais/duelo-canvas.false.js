//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

const { createCanvas, loadImage } = require('canvas');
const fs = require('fs-extra');
const path = require('path');

function createDuelData(user1, user2) {
return {
user1: {
name: user1.name || 'Player 1',
avatar: user1.avatar || 'https://i.pravatar.cc/300?img=1'
},
user2: {
name: user2.name || 'Player 2',
avatar: user2.avatar || 'https://i.pravatar.cc/300?img=2'
},
duelId: `duel-${Date.now()}`,
createdAt: new Date()
};
}

async function loadImageWithFallback(url) {
try {
return await loadImage(url);
} catch (error) {
console.error(`Error loading image: ${url}`);
return createErrorImage(200, 200);
}
}
function createErrorImage(width, height) {
const canvas = createCanvas(width, height);
const ctx = canvas.getContext('2d');
const gradient = ctx.createLinearGradient(0, 0, width, height);
gradient.addColorStop(0, '#4a6bff');
gradient.addColorStop(1, '#6c5ce7');
ctx.fillStyle = gradient;
ctx.fillRect(0, 0, width, height);
ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
ctx.textAlign = 'center';
ctx.textBaseline = 'middle';
ctx.font = 'bold 20px Arial';
ctx.fillText('Loading duel...', width / 2, height / 2);
return canvas;
}
const DUEL_BACKGROUNDS = [
(ctx, width, height) => {
const gradient = ctx.createLinearGradient(0, 0, width, height);
gradient.addColorStop(0, '#ff4d4d');
gradient.addColorStop(0.5, '#4a6bff');
gradient.addColorStop(1, '#00b4d8');
ctx.fillStyle = gradient;
ctx.fillRect(0, 0, width, height);
for (let i = 0; i < 50; i++) {
const x = Math.random() * width;
const y = Math.random() * height;
const radius = Math.random() * 3 + 1;
const color = Math.random() > 0.5 ? 'rgba(255, 100, 100, 0.7)' : 'rgba(100, 200, 255, 0.7)';
ctx.beginPath();
ctx.arc(x, y, radius, 0, Math.PI * 2);
ctx.fillStyle = color;
ctx.fill();
}
ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
ctx.lineWidth = 2;
for (let i = 0; i < 5; i++) {
ctx.beginPath();
ctx.moveTo(0, height * Math.random());
ctx.bezierCurveTo(
width * 0.3, height * Math.random(),
width * 0.7, height * Math.random(),
width, height * Math.random()
);
ctx.stroke();
}
},
(ctx, width, height) => {
const gradient = ctx.createRadialGradient(width/2, height/2, 0, width/2, height/2, width);
gradient.addColorStop(0, '#1a237e');
gradient.addColorStop(0.5, '#311b92');
gradient.addColorStop(1, '#000000');
ctx.fillStyle = gradient;
ctx.fillRect(0, 0, width, height);
for (let i = 0; i < 200; i++) {
const x = Math.random() * width;
const y = Math.random() * height;
const radius = Math.random() * 1.5;
const opacity = Math.random() * 0.8 + 0.2;
ctx.beginPath();
ctx.arc(x, y, radius, 0, Math.PI * 2);
ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`;
ctx.fill();
}
const nebulaGradient = ctx.createRadialGradient(width*0.7, height*0.3, 0, width*0.7, height*0.3, width*0.5);
nebulaGradient.addColorStop(0, 'rgba(255, 100, 255, 0.2)');
nebulaGradient.addColorStop(0.5, 'rgba(100, 100, 255, 0.1)');
nebulaGradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
ctx.fillStyle = nebulaGradient;
ctx.fillRect(0, 0, width, height);
},
(ctx, width, height) => {
const gradient = ctx.createLinearGradient(0, 0, width, height);
gradient.addColorStop(0, '#8B0000');
gradient.addColorStop(0.5, '#FF4500');
gradient.addColorStop(1, '#FF8C00');
ctx.fillStyle = gradient;
ctx.fillRect(0, 0, width, height);
ctx.globalAlpha = 0.1;
for (let i = 0; i < 20; i++) {
const x = Math.random() * width;
const y = Math.random() * height;
const radius = Math.random() * 100 + 50;
const lavaGradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
lavaGradient.addColorStop(0, '#FFFF00');
lavaGradient.addColorStop(0.7, '#FF4500');
lavaGradient.addColorStop(1, 'transparent');
ctx.fillStyle = lavaGradient;
ctx.beginPath();
ctx.arc(x, y, radius, 0, Math.PI * 2);
ctx.fill();
}
ctx.globalAlpha = 1.0;
for (let i = 0; i < 30; i++) {
const x = Math.random() * width;
const y = Math.random() * height;
const size = Math.random() * 3 + 1;
ctx.fillStyle = 'rgba(255, 255, 100, 0.8)';
ctx.beginPath();
ctx.arc(x, y, size, 0, Math.PI * 2);
ctx.fill();
}
},
(ctx, width, height) => {
const gradient = ctx.createLinearGradient(0, 0, width, height);
gradient.addColorStop(0, '#0D47A1');
gradient.addColorStop(0.5, '#1A237E');
gradient.addColorStop(1, '#000000');
ctx.fillStyle = gradient;
ctx.fillRect(0, 0, width, height);
ctx.strokeStyle = 'rgba(100, 200, 255, 0.7)';
ctx.lineWidth = 2;
for (let i = 0; i < 15; i++) {
const startX = Math.random() * width;
const startY = Math.random() * height;
ctx.beginPath();
ctx.moveTo(startX, startY);
let x = startX;
let y = startY;
for (let j = 0; j < 5; j++) {
x += (Math.random() - 0.5) * 100;
y += (Math.random() - 0.5) * 100;
ctx.lineTo(x, y);
}
ctx.stroke();
}
const glowGradient = ctx.createRadialGradient(width/2, height/2, 0, width/2, height/2, width/4);
glowGradient.addColorStop(0, 'rgba(100, 200, 255, 0.3)');
glowGradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
ctx.fillStyle = glowGradient;
ctx.fillRect(0, 0, width, height);
}
];
async function drawAvatar(ctx, img, x, y, size) {
try {
const centerX = x + size/2;
const centerY = y + size/2;
const radius = size/2;
const glowSize = size * 1.2;
const glowGradient = ctx.createRadialGradient(
centerX, centerY, radius * 0.8,
centerX, centerY, radius * 1.5
);
glowGradient.addColorStop(0, 'rgba(255, 255, 255, 0.4)');
glowGradient.addColorStop(0.5, 'rgba(255, 255, 255, 0.2)');
glowGradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
ctx.fillStyle = glowGradient;
ctx.beginPath();
ctx.arc(centerX, centerY, radius * 1.5, 0, Math.PI * 2);
ctx.fill();
ctx.shadowColor = 'rgba(0, 0, 0, 0.7)';
ctx.shadowBlur = 20;
ctx.shadowOffsetX = 5;
ctx.shadowOffsetY = 5;
const outerBorderWidth = size * 0.12;
ctx.beginPath();
ctx.arc(centerX, centerY, radius + outerBorderWidth/2, 0, Math.PI * 2);
const borderGradient = ctx.createLinearGradient(
centerX - radius - outerBorderWidth,
centerY - radius - outerBorderWidth,
centerX + radius + outerBorderWidth,
centerY + radius + outerBorderWidth
);
borderGradient.addColorStop(0, '#FFD700');
borderGradient.addColorStop(0.5, '#FFF');
borderGradient.addColorStop(1, '#FFD700');
ctx.fillStyle = borderGradient;
ctx.fill();
const innerBorderWidth = size * 0.05;
ctx.beginPath();
ctx.arc(centerX, centerY, radius + innerBorderWidth/3, 0, Math.PI * 2);
ctx.fillStyle = '#fff';
ctx.fill();
ctx.shadowColor = 'transparent';
ctx.shadowBlur = 0;
ctx.shadowOffsetX = 0;
ctx.shadowOffsetY = 0;
ctx.save();
ctx.beginPath();
ctx.arc(centerX, centerY, radius - 2, 0, Math.PI * 2);
ctx.closePath();
ctx.clip();
const image = await loadImageWithFallback(img);
ctx.drawImage(image, x, y, size, size);
const vinhetteGradient = ctx.createRadialGradient(
centerX, centerY, radius * 0.7,
centerX, centerY, radius
);
vinhetteGradient.addColorStop(0, 'rgba(0, 0, 0, 0)');
vinhetteGradient.addColorStop(1, 'rgba(0, 0, 0, 0.3)');
ctx.fillStyle = vinhetteGradient;
ctx.fill();
ctx.restore();
ctx.save();
for (let i = 0; i < 8; i++) {
const angle = (Math.PI * 2 / 8) * i;
const dotX = centerX + Math.cos(angle) * (radius + outerBorderWidth * 1.5);
const dotY = centerY + Math.sin(angle) * (radius + outerBorderWidth * 1.5);
ctx.beginPath();
ctx.arc(dotX, dotY, size * 0.03, 0, Math.PI * 2);
ctx.fillStyle = '#FFD700';
ctx.fill();
}
ctx.restore();
} catch (error) {
console.error('Error drawing avatar:', error);
}
}
async function drawDuel(duelData, canvas) {
const ctx = canvas.getContext('2d');
const width = canvas.width;
const height = canvas.height;
ctx.clearRect(0, 0, width, height);
const randomBackground = DUEL_BACKGROUNDS[Math.floor(Math.random() * DUEL_BACKGROUNDS.length)];
randomBackground(ctx, width, height);
const arenaRadius = Math.min(width, height) * 0.4;
const arenaGradient = ctx.createRadialGradient(
width / 2, height / 2, 0,
width / 2, height / 2, arenaRadius
);
arenaGradient.addColorStop(0, 'rgba(255, 255, 255, 0.1)');
arenaGradient.addColorStop(0.7, 'rgba(255, 255, 255, 0.05)');
arenaGradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
ctx.fillStyle = arenaGradient;
ctx.beginPath();
ctx.arc(width / 2, height / 2, arenaRadius, 0, Math.PI * 2);
ctx.fill();
ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
ctx.lineWidth = 2;
ctx.beginPath();
ctx.arc(width / 2, height / 2, arenaRadius * 0.9, 0, Math.PI * 2);
ctx.stroke();
ctx.beginPath();
ctx.arc(width / 2, height / 2, arenaRadius * 0.5, 0, Math.PI * 2);
ctx.stroke();
ctx.beginPath();
ctx.moveTo(width / 2 - arenaRadius, height / 2);
ctx.lineTo(width / 2 + arenaRadius, height / 2);
ctx.stroke();
ctx.beginPath();
ctx.moveTo(width / 2, height / 2 - arenaRadius);
ctx.lineTo(width / 2, height / 2 + arenaRadius);
ctx.stroke();
const avatarSize = Math.min(width, height) * 0.3;
const padding = 80;
const avatarY = (height - avatarSize) / 2 - 20;
await drawAvatar(ctx, duelData.user1.avatar, padding, avatarY, avatarSize);
await drawAvatar(ctx, duelData.user2.avatar, width - padding - avatarSize, avatarY, avatarSize);
const nameY = avatarY + avatarSize + 40;
const drawNamePlate = (x, y, width, name) => {
ctx.shadowColor = 'rgba(0, 0, 0, 0.7)';
ctx.shadowBlur = 15;
ctx.shadowOffsetX = 3;
ctx.shadowOffsetY = 3;
const plateHeight = 50;
const plateGradient = ctx.createLinearGradient(x, y, x, y + plateHeight);
plateGradient.addColorStop(0, 'rgba(50, 50, 50, 0.8)');
plateGradient.addColorStop(1, 'rgba(20, 20, 20, 0.8)');
ctx.fillStyle = plateGradient;
ctx.beginPath();
ctx.roundRect(x - width/2, y - plateHeight/2, width, plateHeight, 10);
ctx.fill();
ctx.strokeStyle = 'rgba(255, 215, 0, 0.7)';
ctx.lineWidth = 2;
ctx.stroke();
ctx.shadowColor = 'transparent';
ctx.shadowBlur = 0;
ctx.shadowOffsetX = 0;
ctx.shadowOffsetY = 0;
ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
ctx.font = `bold ${Math.min(width, height) / 15}px 'Arial'`;
ctx.textAlign = 'center';
ctx.textBaseline = 'middle';
ctx.fillText(name, x, y);
};
const nameWidth1 = Math.max(avatarSize * 1.2, ctx.measureText(duelData.user1.name).width + 60);
drawNamePlate(
padding + avatarSize / 2,
nameY,
nameWidth1,
duelData.user1.name
);
const nameWidth2 = Math.max(avatarSize * 1.2, ctx.measureText(duelData.user2.name).width + 60);
drawNamePlate(
width - padding - avatarSize / 2,
nameY,
nameWidth2,
duelData.user2.name
);
ctx.save();
ctx.shadowColor = 'rgba(255, 255, 255, 0.8)';
ctx.shadowBlur = 20;
const vsGradient = ctx.createLinearGradient(
width / 2 - 50, height / 2 - 50,
width / 2 + 50, height / 2 + 50
);
vsGradient.addColorStop(0, '#FF4500');
vsGradient.addColorStop(0.5, '#FFD700');
vsGradient.addColorStop(1, '#FF4500');
ctx.fillStyle = vsGradient;
ctx.font = `bold ${Math.min(width, height) / 8}px 'Arial'`;
ctx.textAlign = 'center';
ctx.textBaseline = 'middle';
ctx.strokeStyle = 'rgba(0, 0, 0, 0.8)';
ctx.lineWidth = 8;
ctx.strokeText('VS', width / 2, height / 2);
ctx.fillText('VS', width / 2, height / 2);
ctx.restore();
const overlayGradient = ctx.createLinearGradient(0, 0, 0, height);
overlayGradient.addColorStop(0, 'rgba(0, 0, 0, 0.4)');
overlayGradient.addColorStop(0.5, 'rgba(0, 0, 0, 0.1)');
overlayGradient.addColorStop(1, 'rgba(0, 0, 0, 0.6)');
ctx.fillStyle = overlayGradient;
ctx.fillRect(0, 0, width, height);
const vinhetteGradient = ctx.createRadialGradient(
width / 2, height / 2, Math.min(width, height) * 0.3,
width / 2, height / 2, Math.min(width, height) * 0.8
);
vinhetteGradient.addColorStop(0, 'rgba(0, 0, 0, 0)');
vinhetteGradient.addColorStop(1, 'rgba(0, 0, 0, 0.7)');
ctx.fillStyle = vinhetteGradient;
ctx.fillRect(0, 0, width, height);
ctx.save();
const copyrightText = `© ${new Date().getFullYear()} @paulo_mod_domina - Todos os direitos reservados`;
const textMetrics = ctx.measureText(copyrightText);
const textWidth = textMetrics.width + 20;
ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
ctx.beginPath();
ctx.roundRect(width - textWidth - 10, height - 30, textWidth, 20, 5);
ctx.fill();
ctx.strokeStyle = 'rgba(255, 215, 0, 0.3)';
ctx.lineWidth = 1;
ctx.stroke();
ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
ctx.font = 'bold 12px Arial';
ctx.textAlign = 'right';
ctx.textBaseline = 'middle';
ctx.fillText(copyrightText, width - 20, height - 20);
ctx.restore();
return canvas;
}

async function drawDuelCanvas(duelData, canvas) {
return await drawDuel(duelData, canvas);
}

module.exports = { createDuelData, drawDuelCanvas, drawDuel, drawAvatar, loadImageWithFallback }