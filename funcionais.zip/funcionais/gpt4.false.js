//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B
const { HfInference } = require('@huggingface/inference')
const hf = new HfInference('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')

async function queryModel(query) {
try {
const response = await hf.chatCompletion({
model: 'mistralai/Mistral-7B-Instruct-v0.3',
messages: [{ role: 'user', content: query }]
})
return {
status: true,
criador: '@paulo_mod_domina',
resultado: response.choices[0].message.content
}
} catch (error) {
console.error('Erro no Hugging Face:', error)
return {
status: false,
error: error.message
}
}
}

module.exports = { queryModel }