const cheerio = require('cheerio')
const fetch = require('node-fetch')

const GoogleIa = {
  helper: {
    log(message) {
      console.log('[Google-Ia] ' + message)
    },
    formatError(string) {
      const MAX_LENGTH = 200
      const type = typeof string
      if (type !== 'string') return '(type ' + type + ')'
      if (!string) return '(empty)'
      let message = string
      try { message = JSON.stringify(JSON.parse(string), null, 2) } catch {}
      if (message.length > MAX_LENGTH) {
        message = message.substring(0, MAX_LENGTH) + '... (' + (string.length - MAX_LENGTH) + ')'
      }
      return message
    }
  },

  async getCookie() {
    this.helper.log('get cookie')
    const r = await fetch('https://play.google.com/log?format=json&hasfast=true&authuser=0', {
      headers: { 'accept-encoding': 'gzip, deflate, br, zsdch, zstd' },
      body: '[[1,null,null,null,null,null,null,null,null,null,[null,null,null,null,\'en-ID\',null,null,null,[[[\'Chromium\',\'142\'],[\'Not_A Brand\',\'99\'],[\'Google Chrome\',\'142\']],0,\'Windows\',\'15.0.0\',\'x86\',\'\',\'142.0.7444.163\'],[4,0]]],596,[[\'1763639555843\',null,null,null,null,null,null,"[null,[\\\"2ahUKEwjtoP2h1YCRAxV1yzgGHeqmFYsQiJoOegYIAAgAEBM\\\"],null,null,null,null,null,null,null,[50]]",null,null,null,null,null,null,-28800,null,null,null,null,null,1,null,null,"[[[1763639555842000,0,0],4],null,null,[null,null,3,null,null,null,null,null,null,null,\\\"2ahUKEwjtoP2h1YCRAxV1yzgGHeqmFYsQiJoOegYIAAgAEBM\\\"]]"]],"1763639555843",null,null,null,null,null,null,null,null,null,null,null,null,null,[[null,[null,null,null,null,null,null,null,null,null,null,null,null,89978449]],9]]',
      method: 'POST'
    })
    if (!r.ok) throw Error(r.status + ' ' + r.statusText + '\n' + this.helper.formatError(await r.text()))
    const rawCookie = r.headers.get('set-cookie')
    if (!rawCookie) throw Error('no cookie')
    return { cookie: rawCookie.split(';')[0].trim() }
  },

  async apiSearch(query, cookie) {
    this.helper.log('api search')
    const url = 'https://www.google.com/search?q=' + encodeURIComponent(query)
    const r = await fetch(url, {
      headers: {
        cookie,
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'
      },
      method: 'GET'
    })
    if (!r.ok) throw Error(r.status + ' ' + r.statusText + '\n' + this.helper.formatError(await r.text()))
    return { html: await r.text() }
  },

  parseHtml(html) {
    const $ = cheerio.load(html)
    $('script, style, noscript').remove()
    $('[style*="display:none"]').remove()
    $('[hidden]').remove()
    $('[aria-hidden="true"]').remove()
    $('svg, path').remove()
    $.root().contents().each(function () {
      if (this.type === 'comment') $(this).remove()
    })
    // Pega todo texto visível do body
    const text = $('body').text().replace(/\s+/g, ' ').trim()
    return text || null
  },

  async search(query) {
    if (!query) throw Error('empty query')
    const { cookie } = await this.getCookie()
    const { html } = await this.apiSearch(query, cookie)
    const result = this.parseHtml(html)
    if (!result) throw Error('Nenhum resultado encontrado')
    return result
  }
}

module.exports = GoogleIa