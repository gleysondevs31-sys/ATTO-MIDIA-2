const axios = require('axios')
const fs = require('fs')
const { exec } = require('child_process')
const path = require('path')
const os = require('os')
const { YtdlCore } = require('@ybd-project/ytdl-core')
//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//By: Liedson
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

function cleanOldTempFiles() {
const tempDir = os.tmpdir()
try {
const files = fs.readdirSync(tempDir)
const now = Date.now()
files.forEach(file => {
const filePath = path.join(tempDir, file)
const parsed = path.parse(file)
// Remove only .mp3/.mp4 older than 1 hour
if (['.mp3', '.mp4'].includes(parsed.ext.toLowerCase())) {
const stats = fs.statSync(filePath)
if (now - stats.mtimeMs > 3600 * 1000) {
fs.unlinkSync(filePath)
console.log(`Arquivo antigo ${filePath} deletado.`)
}
}
})
} catch (err) {
console.error('Erro ao listar arquivos temporários:', err)
}
}

console.log("Inicializando o YtdlCore com configurações padrão...")
const ytdl = new YtdlCore({})
console.log("YtdlCore inicializado com sucesso.")

// Limpeza de arquivos antigos ao iniciar
cleanOldTempFiles()

const COOKIES_FILE = path.join(__dirname, 'cookies.json')

function loadCookies() {
try {
const cookiesData = JSON.parse(fs.readFileSync(COOKIES_FILE, 'utf8'))
const cookiesObject = {}
cookiesData.forEach(cookie => {
if (cookie.name && cookie.value) {
cookiesObject[cookie.name] = cookie.value
}
})
return cookiesObject
} catch (error) {
console.error('Erro ao carregar os cookies:', error.message)
return {}
}
}
const options = {
requestOptions: {
headers: {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
'Accept': '*/*',
'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'Origin': 'https://www.youtube.com',
'Referer': 'https://www.youtube.com/',
},
cookies: loadCookies(),
withCredentials: true
}
}

async function baixarMP4(url, format = 'mp4') {
try {
return await downloadContent(url, format, `-f best[ext=${format}]/best`)
} catch (err) {
console.error('Erro ao baixar vídeo:', err)
throw new Error('Falha ao baixar o vídeo.')
}
}

async function baixarMP3(url) {
try {
return await downloadContent(url, 'mp3', '-x --audio-format mp3')
} catch (err) {
console.error('Erro ao baixar áudio:', err)
throw new Error('Falha ao baixar o áudio.')
}
}

async function downloadContent(url, extension, additionalOptions) {
if (!url) throw new Error("Por favor, insira o link do vídeo.")
const ytDlpPath = await ensureYtdlp()
const timestamp = Date.now().toString()
const tempDir = os.tmpdir()
const tempBase = path.join(tempDir, timestamp)
const tempFilePath = `${tempBase}.${extension}`
const cookiesPath = path.join(__dirname, 'cookies.txt')
if (!fs.existsSync(cookiesPath)) {
throw new Error("Arquivo cookies.txt não encontrado!")
}
const command = `${ytDlpPath} --cookies "${cookiesPath}" ${additionalOptions} -o "${tempBase}.%(ext)s" "${url}"`
console.log("Comando sendo executado:", command)
await new Promise((resolve, reject) => {
exec(command, (err) => {
if (err) return reject(`Erro ao baixar ${extension === 'mp3' ? 'áudio' : 'vídeo'}: ${err.message}`)
resolve()
})
})
if (!fs.existsSync(tempFilePath)) {
throw new Error(`Arquivo ${tempFilePath} não encontrado após o download.`)
}
console.log(`${extension === 'mp3' ? 'Áudio' : 'Vídeo'} baixado com sucesso.`)
return tempFilePath
}

async function ensureYtdlp() {
const ytDlpPath = path.join(os.tmpdir(), 'yt-dlp')
if (!fs.existsSync(ytDlpPath)) {
console.log("yt-dlp não encontrado, baixando...")
const url = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp'
const response = await axios({ method: 'get', url, responseType: 'stream' })
const writer = fs.createWriteStream(ytDlpPath)
response.data.pipe(writer)
await new Promise((resolve, reject) => {
writer.on('finish', resolve)
writer.on('error', reject)
})
fs.chmodSync(ytDlpPath, 0o755)
console.log("yt-dlp baixado com sucesso!")
}
return ytDlpPath
}

async function getVideoInfo(url) {
console.log(`Solicitando informações do vídeo: ${url}`)
try {
const info = await ytdl.getBasicInfo(url, options)
console.log("Informações do vídeo obtidas com sucesso.")
console.log("Título do vídeo:", info.videoDetails.title)
console.log("Descrição do vídeo:", info.videoDetails.description)
console.log("Canal do vídeo:", info.videoDetails.ownerChannelName)
console.log("Duração do vídeo:", info.videoDetails.lengthSeconds, "segundos")
console.log("URL da miniatura do vídeo:", info.videoDetails.thumbnails[0]?.url)
return info.videoDetails
} catch (error) {
console.error("Erro ao obter informações do vídeo:", error)
}
}

module.exports = { baixarMP3, baixarMP4, getVideoInfo }