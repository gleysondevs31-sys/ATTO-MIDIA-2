//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

// By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
// Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

const fetch = require('node-fetch').default;
const chalk = require('chalk');

function ytdlMp4(url) {
console.log(chalk.yellow.bold('[ytdlMp4] Iniciando processo para:'), url);
return new Promise((resolve, reject) => {
if (!url.match(/youtu\.be|youtube\.com/i)) {
console.log(chalk.red('[ytdlMp4] ERRO: URL inválida'));
return reject({ error: 'URL do YouTube inválida' });
}
const id = url.match(/(?:youtube\.com\/(?:watch\?v=|v\/|embed\/|shorts\/|live\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})(?:[\?&]|$)/)?.[1] ||
url.match(/(?:[\?&]v=|\/videos\/|embed\/|shorts\/|v\/|%2Fvideos%2F)([a-zA-Z0-9_-]{11})/)?.[1] ||
url.match(/^([a-zA-Z0-9_-]{11})$/)?.[1];
console.log(chalk.cyan('[ytdlMp4] ID extraído:'), id || chalk.red('NÃO ENCONTRADO'));
if (!id) {
console.log(chalk.red('[ytdlMp4] ERRO: Falha ao extrair ID'));
return reject({ error: 'Falha ao extrair ID do vídeo' });
}
const initUrl = `https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`;
console.log(chalk.magenta('[ytdlMp4] Fazendo request INIT:'), initUrl);
fetch(initUrl, {
headers: {
"accept": "*/*",
"accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
"sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
"sec-ch-ua-mobile": "?1",
"sec-ch-ua-platform": "\"Android\"",
"sec-fetch-dest": "empty",
"sec-fetch-mode": "cors",
"sec-fetch-site": "cross-site",
"Referer": "https://id.ytmp3.mobi/",
"Referrer-Policy": "strict-origin-when-cross-origin"
}
})
.then(initial => {
console.log(chalk.blue('[ytdlMp4] Resposta INIT recebida. Status:'), initial.status);
return initial.json();
})
.then(init => {
console.log(chalk.green('[ytdlMp4] INIT JSON:'), JSON.stringify(init, null, 2));
if (!init || !init.convertURL) {
console.log(chalk.red('[ytdlMp4] ERRO: convertURL ausente no INIT'));
throw new Error('Resposta INIT inválida');
}
const convertURL = `${init.convertURL}&v=${id}&f=mp4&_=${Math.random()}`;
console.log(chalk.magenta('[ytdlMp4] Fazendo request CONVERT:'), convertURL);
return fetch(convertURL, {
headers: {
"accept": "*/*",
"accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
"sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
"sec-ch-ua-mobile": "?1",
"sec-ch-ua-platform": "\"Android\"",
"sec-fetch-dest": "empty",
"sec-fetch-mode": "cors",
"sec-fetch-site": "cross-site",
"Referer": "https://id.ytmp3.mobi/",
"Referrer-Policy": "strict-origin-when-cross-origin"
}
});
})
.then(converts => {
console.log(chalk.blue('[ytdlMp4] Resposta CONVERT recebida. Status:'), converts.status);
return converts.json();
})
.then(convert => {
console.log(chalk.green('[ytdlMp4] CONVERT JSON:'), JSON.stringify(convert, null, 2));
if (!convert || !convert.progressURL || !convert.downloadURL) {
console.log(chalk.red('[ytdlMp4] ERRO: Estrutura CONVERT inválida'));
throw new Error('Resposta de conversão inválida');
}
let info = {};
let attempts = 0;
console.log(chalk.yellow(`[ytdlMp4] Iniciando monitoramento (progressURL: ${convert.progressURL})`));
const checkProgress = () => {
console.log(chalk.cyan(`[ytdlMp4] Verificando progresso (tentativa ${attempts + 1}/5):`), convert.progressURL);
fetch(convert.progressURL, {
headers: {
"accept": "*/*",
"accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
"sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
"sec-ch-ua-mobile": "?1",
"sec-ch-ua-platform": "\"Android\"",
"sec-fetch-dest": "empty",
"sec-fetch-mode": "cors",
"sec-fetch-site": "cross-site",
"Referer": "https://id.ytmp3.mobi/",
"Referrer-Policy": "strict-origin-when-cross-origin"
}
})
.then(progressRes => {
console.log(chalk.blue('[ytdlMp4] Resposta PROGRESS recebida. Status:'), progressRes.status);
return progressRes.json();
})
.then(progressInfo => {
console.log(chalk.green('[ytdlMp4] PROGRESS JSON:'), JSON.stringify(progressInfo, null, 2));
info = progressInfo;
if (info.progress === 3 || attempts >= 4) {
if (!info.title || !convert.downloadURL) {
console.log(chalk.red('[ytdlMp4] ERRO: Dados incompletos na conversão'));
throw new Error('Falha na conversão');
}
console.log(chalk.green.bold('[ytdlMp4] Conversão concluída!'));
resolve({
status: true,
criador: "@lucas_mod_domina",
resultado: {
dl_link: convert.downloadURL,
title: info.title,
type: 'video'
}
});
} else {
attempts++;
console.log(chalk.yellow(`[ytdlMp4] Progresso atual: ${info.progress || 'indefinido'}. Nova tentativa em 2s...`));
setTimeout(checkProgress, 2000);
}
})
.catch(error => {
console.log(chalk.red('[ytdlMp4] ERRO no progresso:'), error.message);
reject({ error: error.message });
});
};
checkProgress();
})
.catch(error => {
console.log(chalk.red('[ytdlMp4] ERRO GERAL:'), error.message);
reject({ error: error.message });
});
});
}

function ytdlMp3(url) {
console.log(chalk.yellow.bold('[ytdlMp3] Iniciando processo para:'), url);
return new Promise((resolve, reject) => {
if (!url.match(/youtu\.be|youtube\.com/i)) {
console.log(chalk.red('[ytdlMp3] ERRO: URL inválida'));
return reject({ error: 'URL do YouTube inválida' });
}
const id = url.match(/(?:youtube\.com\/(?:watch\?v=|v\/|embed\/|shorts\/|live\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})(?:[\?&]|$)/)?.[1] ||
url.match(/(?:[\?&]v=|\/videos\/|embed\/|shorts\/|v\/|%2Fvideos%2F)([a-zA-Z0-9_-]{11})/)?.[1] ||
url.match(/^([a-zA-Z0-9_-]{11})$/)?.[1];
console.log(chalk.cyan('[ytdlMp3] ID extraído:'), id || chalk.red('NÃO ENCONTRADO'));
if (!id) {
console.log(chalk.red('[ytdlMp3] ERRO: Falha ao extrair ID'));
return reject({ error: 'Falha ao extrair ID do vídeo' });
}
const initUrl = `https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`;
console.log(chalk.magenta('[ytdlMp3] Fazendo request INIT:'), initUrl);
fetch(initUrl, {
headers: {
"accept": "*/*",
"accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
"sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
"sec-ch-ua-mobile": "?1",
"sec-ch-ua-platform": "\"Android\"",
"sec-fetch-dest": "empty",
"sec-fetch-mode": "cors",
"sec-fetch-site": "cross-site",
"Referer": "https://id.ytmp3.mobi/",
"Referrer-Policy": "strict-origin-when-cross-origin"
}
})
.then(initial => {
console.log(chalk.blue('[ytdlMp3] Resposta INIT recebida. Status:'), initial.status);
return initial.json();
})
.then(init => {
console.log(chalk.green('[ytdlMp3] INIT JSON:'), JSON.stringify(init, null, 2));
if (!init || !init.convertURL) {
console.log(chalk.red('[ytdlMp3] ERRO: convertURL ausente no INIT'));
throw new Error('Resposta INIT inválida');
}
const convertURL = `${init.convertURL}&v=${id}&f=mp3&_=${Math.random()}`;
console.log(chalk.magenta('[ytdlMp3] Fazendo request CONVERT:'), convertURL);
return fetch(convertURL, {
headers: {
"accept": "*/*",
"accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
"sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
"sec-ch-ua-mobile": "?1",
"sec-ch-ua-platform": "\"Android\"",
"sec-fetch-dest": "empty",
"sec-fetch-mode": "cors",
"sec-fetch-site": "cross-site",
"Referer": "https://id.ytmp3.mobi/",
"Referrer-Policy": "strict-origin-when-cross-origin"
}
});
})
.then(converts => {
console.log(chalk.blue('[ytdlMp3] Resposta CONVERT recebida. Status:'), converts.status);
return converts.json();
})
.then(convert => {
console.log(chalk.green('[ytdlMp3] CONVERT JSON:'), JSON.stringify(convert, null, 2));
if (!convert || !convert.progressURL || !convert.downloadURL) {
console.log(chalk.red('[ytdlMp3] ERRO: Estrutura CONVERT inválida'));
throw new Error('Resposta de conversão inválida');
}
let info = {};
let attempts = 0;
console.log(chalk.yellow(`[ytdlMp3] Iniciando monitoramento (progressURL: ${convert.progressURL})`));
const checkProgress = () => {
console.log(chalk.cyan(`[ytdlMp3] Verificando progresso (tentativa ${attempts + 1}/5):`), convert.progressURL);
fetch(convert.progressURL, {
headers: {
"accept": "*/*",
"accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
"sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
"sec-ch-ua-mobile": "?1",
"sec-ch-ua-platform": "\"Android\"",
"sec-fetch-dest": "empty",
"sec-fetch-mode": "cors",
"sec-fetch-site": "cross-site",
"Referer": "https://id.ytmp3.mobi/",
"Referrer-Policy": "strict-origin-when-cross-origin"
}
})
.then(progressRes => {
console.log(chalk.blue('[ytdlMp3] Resposta PROGRESS recebida. Status:'), progressRes.status);
return progressRes.json();
})
.then(progressInfo => {
console.log(chalk.green('[ytdlMp3] PROGRESS JSON:'), JSON.stringify(progressInfo, null, 2));
info = progressInfo;
if (info.progress === 3 || attempts >= 4) {
if (!info.title || !convert.downloadURL) {
console.log(chalk.red('[ytdlMp3] ERRO: Dados incompletos na conversão'));
throw new Error('Falha na conversão');
}
console.log(chalk.green.bold('[ytdlMp3] Conversão concluída!'));
resolve({
status: true,
criador: "@lucas_mod_domina",
resultado: {
dl_link: convert.downloadURL,
title: info.title,
type: 'audio'
}
});
} else {
attempts++;
console.log(chalk.yellow(`[ytdlMp3] Progresso atual: ${info.progress || 'indefinido'}. Nova tentativa em 2s...`));
setTimeout(checkProgress, 2000);
}
})
.catch(error => {
console.log(chalk.red('[ytdlMp3] ERRO no progresso:'), error.message);
reject({ error: error.message });
});
};
checkProgress();
})
.catch(error => {
console.log(chalk.red('[ytdlMp3] ERRO GERAL:'), error.message);
reject({ error: error.message });
});
});
}

module.exports = { ytdlMp3, ytdlMp4 };