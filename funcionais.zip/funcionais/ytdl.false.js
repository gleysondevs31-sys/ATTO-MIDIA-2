// FEITA POR 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
// NÃO TIRE MEUS CRÉDITOS SEU RANDOM BAGULHO DEU TRABALHO PRA FAZER
const ytdl = require('@distube/ytdl-core')
const yts = require('youtube-yts')
const readline = require('readline')
const ffmpeg = require('fluent-ffmpeg')
const ffmpegPath = require('@ffmpeg-installer/ffmpeg').path
ffmpeg.setFfmpegPath(ffmpegPath)
const NodeID3 = require('node-id3')
const path = require('path')
const fs = require('fs')
const { fetchBuffer } = require("./myfunc2")
const ytM = import('node-youtube-music')
const { randomBytes } = require('crypto')
const audioDir = path.join(__dirname, 'audio')
if (!fs.existsSync(audioDir)) {
fs.mkdirSync(audioDir)
}
const videoDir = path.join(__dirname, 'video')
if (!fs.existsSync(videoDir)) {
fs.mkdirSync(videoDir)
}
const ytIdRegex = /(?:youtube\.com\/\S*(?:(?:\/e(?:mbed))?\/|watch\?(?:\S*?&?v\=))|youtu\.be\/)([a-zA-Z0-9_-]{6,11})/
 
class YT2 {
constructor() { }
 
/**
* Checks if it is yt link
* @param {string|URL} url youtube url
* @returns Returns true if the given YouTube URL.
*/
static isYTUrl = (url) => {
return ytIdRegex.test(url)
}
 
/**
* VideoID from url
* @param {string|URL} url to get videoID
* @returns 
*/
static getVideoID = (url) => {
if (!this.isYTUrl(url)) throw new Error('is not YouTube URL')
return ytIdRegex.exec(url)[1]
}
 
/**
* @typedef {Object} IMetadata
* @property {string} Title track title
* @property {string} Artist track Artist
* @property {string} Image track thumbnail url
* @property {string} Album track album
* @property {string} Year track release date
*/
 
/**
* Write Track Tag Metadata
* @param {string} filePath 
* @param {IMetadata} Metadata 
*/
static WriteTags = async (filePath, Metadata) => {
NodeID3.write(
{
title: Metadata.Title,
artist: Metadata.Artist,
originalArtist: Metadata.Artist,
image: {
mime: 'jpeg',
type: {
id: 3,
name: 'front cover',
},
imageBuffer: (await fetchBuffer(Metadata.Image)).buffer,
description: `Cover of ${Metadata.Title}`,
},
album: Metadata.Album,
year: Metadata.Year || ''
},
filePath
);
}
 
/**
* 
* @param {string} query 
* @returns 
*/
static search = async (query, options = {}) => {
const search = await yts.search({ query, hl: 'id', gl: 'ID', ...options })
return search.videos
}
 
/**
* @typedef {Object} TrackSearchResult
* @property {boolean} isYtMusic is from YT Music search?
* @property {string} title music title
* @property {string} artist music artist
* @property {string} id YouTube ID
* @property {string} url YouTube URL
* @property {string} album music album
* @property {Object} duration music duration {seconds, label}
* @property {string} image Cover Art
*/
 
/**
* search track with details
* @param {string} query 
* @returns {Promise<TrackSearchResult[]>}
*/
static searchTrack = (query) => {
return new Promise(async (resolve, reject) => {
try {
let ytMusic = await ytM.searchMusics(query);
let result = []
for (let i = 0; i < ytMusic.length; i++) {
result.push({
isYtMusic: true,
title: `${ytMusic[i].title} - ${ytMusic[i].artists.map(x => x.name).join(' ')}`,
artist: ytMusic[i].artists.map(x => x.name).join(' '),
id: ytMusic[i].youtubeId,
url: 'https://youtu.be/' + ytMusic[i].youtubeId,
album: ytMusic[i].album,
duration: {
seconds: ytMusic[i].duration.totalSeconds,
label: ytMusic[i].duration.label
},
image: ytMusic[i].thumbnailUrl.replace('w120-h120', 'w600-h600')
})

}
resolve(result)
} catch (error) {
reject(error)
}
})
}
 
/**
* @typedef {Object} MusicResult
* @property {TrackSearchResult} meta music meta
* @property {string} path file path
*/
 
/**
* Download music with full tag metadata
* @param {string|TrackSearchResult[]} query title of track want to download
* @returns {Promise<MusicResult>} filepath of the result
*/
static downloadMusic = async (url, metadata = {}, autoWriteTags = false) => {
try {
if (!url) throw new Error('Video ID ou URL do YouTube é necessário')
url = this.isYTUrl(url) ? 'https://www.youtube.com/watch?v=' + this.getVideoID(url) : url
const videoInfo = await ytdl.getInfo(url, {
lang: 'id',
requestOptions: {
headers: {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36',
'Accept-Language': 'id'
}
}
})
const songPath = path.join(audioDir, `${randomBytes(3).toString('hex')}.mp3`)
const stream = ytdl(url, { filter: 'audioonly', quality: 140 })
stream.on('error', (err) => console.log(err))
const file = await new Promise((resolve) => {
ffmpeg(stream)
.audioFrequency(44100)
.audioChannels(2)
.audioBitrate(128)
.audioCodec('libmp3lame')
.audioQuality(5)
.toFormat('mp3')
.save(songPath)
.on('end', () => resolve(songPath))
})
if (Object.keys(metadata).length !== 0) {
await this.WriteTags(file, metadata)
}
if (autoWriteTags) {
await this.WriteTags(file, {
Title: videoInfo.videoDetails.title,
Artist: videoInfo.videoDetails.author.name,
Year: videoInfo.videoDetails.publishDate.split('-')[0],
Image: videoInfo.videoDetails.thumbnails.slice(-1)[0].url
})
}
return {
meta: {
title: videoInfo.videoDetails.title,
channel: videoInfo.videoDetails.author.name,
seconds: videoInfo.videoDetails.lengthSeconds,
image: videoInfo.videoDetails.thumbnails.slice(-1)[0].url
},
path: file,
size: fs.statSync(songPath).size
}
} catch (error) {
throw new Error(error)
}
}

static downloadVideo = async (url, metadata = {}, autoWriteTags = false) => {
try {
if (!url) throw new Error('Video ID ou URL do YouTube é necessário')
url = this.isYTUrl(url) ? 'https://www.youtube.com/watch?v=' + this.getVideoID(url) : url
const videoInfo = await ytdl.getInfo(url, {
lang: 'id',
requestOptions: {
headers: {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36',
'Accept-Language': 'id'
}
}
})
const videoPath = path.join(videoDir, `${randomBytes(3).toString('hex')}-video.mp4`)
const audioPath = path.join(videoDir, `${randomBytes(3).toString('hex')}-audio.mp3`)
const outputPath = path.join(videoDir, `${randomBytes(3).toString('hex')}.mp4`)
await new Promise((resolve, reject) => {
const videoStream = ytdl(url, { quality: 'highestvideo' })
videoStream.pipe(fs.createWriteStream(videoPath))
.on('finish', resolve)
.on('error', reject)
})
await new Promise((resolve, reject) => {
const audioStream = ytdl(url, { quality: 'highestaudio' })
audioStream.pipe(fs.createWriteStream(audioPath))
.on('finish', resolve)
.on('error', reject)
})
await new Promise((resolve, reject) => {
ffmpeg()
.input(videoPath)
.input(audioPath)
.videoCodec('libx264')
.audioCodec('aac')
.toFormat('mp4')
.save(outputPath)
.on('end', resolve)
.on('error', reject)
})
fs.unlinkSync(videoPath)
fs.unlinkSync(audioPath)
if (Object.keys(metadata).length !== 0) {
await this.WriteTags(outputPath, metadata)
}
if (autoWriteTags) {
await this.WriteTags(outputPath, {
Title: videoInfo.videoDetails.title,
Artist: videoInfo.videoDetails.author.name,
Year: videoInfo.videoDetails.publishDate.split('-')[0],
Image: videoInfo.videoDetails.thumbnails.slice(-1)[0].url
})
}
return {
meta: {
title: videoInfo.videoDetails.title,
channel: videoInfo.videoDetails.author.name,
seconds: videoInfo.videoDetails.lengthSeconds,
image: videoInfo.videoDetails.thumbnails.slice(-1)[0].url
},
path: outputPath,
size: fs.statSync(outputPath).size
}
} catch (error) {
throw new Error(error)
}
}

/**
* get downloadable video urls
* @param {string|URL} query videoID or YouTube URL
* @param {string} quality 
* @returns
*/
static mp4 = async (query, quality = 134) => {
try {
if (!query) throw new Error('Video ID or YouTube Url is required')
const videoId = this.isYTUrl(query) ? this.getVideoID(query) : query
const videoInfo = await ytdl.getInfo('https://www.youtube.com/watch?v=' + videoId, { lang: 'id' });
const format = ytdl.chooseFormat(videoInfo.formats, { format: quality, filter: 'videoandaudio' })
return {
title: videoInfo.videoDetails.title,
thumb: videoInfo.videoDetails.thumbnails.slice(-1)[0],
date: videoInfo.videoDetails.publishDate,
duration: videoInfo.videoDetails.lengthSeconds,
channel: videoInfo.videoDetails.ownerChannelName,
quality: format.qualityLabel,
contentLength: format.contentLength,
description:videoInfo.videoDetails.description,
videoUrl: format.url
}
} catch (error) {
throw error
}
}
 
/**
* Download YouTube to mp3
* @param {string|URL} url YouTube link want to download to mp3
* @param {IMetadata} metadata track metadata
* @param {boolean} autoWriteTags if set true, it will auto write tags meta following the YouTube info
* @returns 
*/

static mp3 = async (url, metadata = {}, autoWriteTags = false) => {
try {//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
if (!url) throw new Error('Video ID or YouTube URL is required')
url = this.isYTUrl(url) ? 'https://www.youtube.com/watch?v=' + this.getVideoID(url) : url
const options = {
lang: 'id',
requestOptions: {
headers: {
cookie: 'YSC=CWgC4PfP24s; VISITOR_INFO1_LIVE=flOArU6bUuc; VISITOR_PRIVACY_METADATA=CgJCUhIEGgAgSg%3D%3D; _gcl_au=1.1.1479343865.1728537620; HSID=AWvfTwHzGE6SMRC3f; SSID=Ao5GqmAfvfGPIyexf; APISID=crgYppYIT62PmQAn/Ae3Q2yyurx1FzEJ_-; SAPISID=UqiEIVEySqM6RtLo/AF0wRH8Tg8G1xMxy2; __Secure-1PAPISID=UqiEIVEySqM6RtLo/AF0wRH8Tg8G1xMxy2; __Secure-3PAPISID=UqiEIVEySqM6RtLo/AF0wRH8Tg8G1xMxy2; SID=g.a000owhGrRhk6tNJ2UDgyiTD5ZDnezkOR7gXjUSC-ERtgjidkEoznDfc9QO_byBeZf9w-N84zgACgYKAZYSARQSFQHGX2MiFA_Ui1PjmzQ4PCWb0REVARoVAUF8yKq1-f9pli-jXu4UNSp7ZLDn0076; __Secure-1PSID=g.a000owhGrRhk6tNJ2UDgyiTD5ZDnezkOR7gXjUSC-ERtgjidkEoz_gQDgpAsx9LFkN2ipCkHZwACgYKAX4SARQSFQHGX2Mi5tyb0xyve1GL2zYJfokkMBoVAUF8yKpxjDAcwTgkYskjsuaX9KIm0076; __Secure-3PSID=g.a000owhGrRhk6tNJ2UDgyiTD5ZDnezkOR7gXjUSC-ERtgjidkEozXGVF8qY9M7MbsSKnIYgGeQACgYKAY0SARQSFQHGX2Mifm_kUYvU_7tr3njyk-T5xhoVAUF8yKosbd0zTrX8Wr_aO1P--VGP0076; LOGIN_INFO=AFmmF2swRQIge8_rVCt6tQQ4kDS37NTajsFAEK6l7rFW5YGvbCOpXVoCIQCpjh0IV3ThK4aygMtCbpgeCMWsQfnHMlHXv34xwVvrZg:QUQ3MjNmd1hnV0VtTl9lcXdvNXYwZWpIZGZBWjlHYjZBZmN2MU9XSFdhMmgweGhKS3pmS2FKOWxNWlJ3bHFaVWV5c0V0SXdIUUFubWl5TFBKSVhOaXo5YzFNbTJVZEZaR1BiSm90UTROWXFfT1gwd25SQTdRdThvYzJUOHdOZV9ZM2FHUUN1RVJCWXFldkl6OUd0MWlySVhnNnBoZFlFdkZ3; PREF=volume=20&f6=40000080&repeat=NONE&tz=America.Sao_Paulo&f5=30000&f7=100&guide_collapsed=true&autoplay=true; ST-3opvp5=session_logininfo=AFmmF2swRQIge8_rVCt6tQQ4kDS37NTajsFAEK6l7rFW5YGvbCOpXVoCIQCpjh0IV3ThK4aygMtCbpgeCMWsQfnHMlHXv34xwVvrZg%3AQUQ3MjNmd1hnV0VtTl9lcXdvNXYwZWpIZGZBWjlHYjZBZmN2MU9XSFdhMmgweGhKS3pmS2FKOWxNWlJ3bHFaVWV5c0V0SXdIUUFubWl5TFBKSVhOaXo5YzFNbTJVZEZaR1BiSm90UTROWXFfT1gwd25SQTdRdThvYzJUOHdOZV9ZM2FHUUN1RVJCWXFldkl6OUd0MWlySVhnNnBoZFlFdkZ3; __Secure-1PSIDTS=sidts-CjIBQT4rX5HkQik0-jY4_x3bGZ9xUCx7xGg3hx75IVBoeMqYFX2TQZQvaUHciHHccaparBAA; __Secure-3PSIDTS=sidts-CjIBQT4rX5HkQik0-jY4_x3bGZ9xUCx7xGg3hx75IVBoeMqYFX2TQZQvaUHciHHccaparBAA; SIDCC=AKEyXzWnFF5rqfY34zuW8nE9F5pcrSA1fN8iF0lIVrlMzyI-EfpyT0_j0pG_TiZ2zI5msQyDmtVT; __Secure-1PSIDCC=AKEyXzVZG1xAvqhbRHY_dGRT0B8JlNauxzAM6uErX8tKa5FmrMkLiNI7IfMYvNAX88AjHWkFx2A; __Secure-3PSIDCC=AKEyXzVWFObS2whzEmamHOL7mp1n7WN4BxMsoE3JbZ5LphsPw8QaUpG0FBOkUXb2V3PvfqGKHt4'
}
}
}
const { videoDetails } = await ytdl.getInfo(url, options)
let stream = ytdl(url, { ...options, filter: 'audioonly', quality: 140 })
let songPath = path.join(audioDir, `${randomBytes(3).toString('hex')}.mp4`)
let starttime
stream.once('response', () => {
starttime = Date.now()
})
stream.on('progress', (chunkLength, downloaded, total) => {
const percent = downloaded / total
const downloadedMinutes = (Date.now() - starttime) / 1000 / 60
const estimatedDownloadTime = (downloadedMinutes / percent) - downloadedMinutes
readline.cursorTo(process.stdout, 0)
process.stdout.write(`${(percent * 100).toFixed(2)}% downloaded `)
process.stdout.write(`(${(downloaded / 1024 / 1024).toFixed(2)}MB of ${(total / 1024 / 1024).toFixed(2)}MB)\n`)
process.stdout.write(`running for: ${downloadedMinutes.toFixed(2)}minutes`)
process.stdout.write(`, estimated time left: ${estimatedDownloadTime.toFixed(2)}minutes `)
readline.moveCursor(process.stdout, 0, -1)
})
stream.on('end', () => process.stdout.write('\n\n'))
stream.on('error', (err) => console.log(err))
const file = await new Promise((resolve) => {
ffmpeg(stream)
.audioFrequency(44100)
.audioChannels(2)
.audioBitrate(128)
.audioCodec('libmp3lame')
.audioQuality(5)
.toFormat('mp3')
.save(songPath)
.on('end', () => {
resolve(songPath)
})
})
if (Object.keys(metadata).length !== 0) {
await this.WriteTags(file, metadata)
}
if (autoWriteTags) {
await this.WriteTags(file, {
Title: videoDetails.title,
Album: videoDetails.author.name,
Year: videoDetails.publishDate.split('-')[0],
Image: videoDetails.thumbnails.slice(-1)[0].url
})
}
return {
meta: {
title: videoDetails.title,
channel: videoDetails.author.name,
seconds: videoDetails.lengthSeconds,
image: videoDetails.thumbnails.slice(-1)[0].url
},
path: file,
size: fs.statSync(songPath).size
}
} catch (error) {
throw error
}
}
}
 
module.exports = YT2