//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

const { GoogleGenAI } = require('@google/genai');
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args))

class VideoGenerationError extends Error {
constructor(message) {
super(message);
this.name = 'VideoGenerationError';
}
}

async function generateVideo(prompt, config = {}) {
try {
const ai = new GoogleGenAI({
apiKey: process.env.GEMINI_API_KEY || "AIzaSyACbd2Srxte_hJQF-2liWWQA-dLu-xxlIs",
});
const defaultConfig = {
numberOfVideos: 1,
aspectRatio: '16:9',
personGeneration: 'dont_allow',
durationSeconds: 8,
...config
};
let operation = await ai.models.generateVideos({
model: 'veo-2.0-generate-001',
prompt: prompt,
config: defaultConfig
});
const startTime = Date.now();
const timeout = 600000; // 10 minutos
while (!operation.done) {
if (Date.now() - startTime > timeout) {
throw new VideoGenerationError('Tempo limite excedido na geração do vídeo');
}
await new Promise(resolve => setTimeout(resolve, 10000));
operation = await ai.operations.getVideosOperation({
operation: operation,
});
}
if (!operation.response?.generatedVideos?.length) {
throw new VideoGenerationError('Nenhum vídeo foi gerado pela API');
}
const videos = [];
for (const generatedVideo of operation.response.generatedVideos) {
try {
const videoUri = generatedVideo?.video?.uri;
if (!videoUri) continue;
const response = await fetch(`${videoUri}&key=${process.env.GEMINI_API_KEY}`);
if (!response.ok) {
throw new Error(`HTTP ${response.status} - ${response.statusText}`);
}
const arrayBuffer = await response.arrayBuffer();
videos.push(arrayBuffer);
} catch (error) {
console.error('Erro ao baixar vídeo:', error);
}
}
if (!videos.length) {
throw new VideoGenerationError('Falha ao baixar todos os vídeos gerados');
}
return videos;
} catch (error) {
console.error('Erro na geração de vídeo:', error);
throw new VideoGenerationError(error.message || 'Erro desconhecido na geração de vídeo');
}
}

module.exports = { generateVideo, VideoGenerationError }