/*****
   {credits} Paulo 
*****/
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const { sayLog, inputLog, infoLog, successLog, errorLog, warningLog, eventLog } = require("../database/logger.js");

infoLog("System de Metadinha Ativos e operando Momo Ayase")

class Pinterest {
  async getCookies() {
    const res = await axios.get('https://www.pinterest.com/csrf_error/');
    const setCookieHeaders = res.headers['set-cookie'];
    if (!setCookieHeaders) return null;
    const cookies = setCookieHeaders.map(c => c.split(';')[0].trim());
    return cookies.join('; ');
  }

  async search(query) {
    const cookies = await this.getCookies();
    if (!cookies) throw new Error('Failed to retrieve cookies.');
    const params = {
      source_url: `/search/pins/?q=${query}`,
      data: JSON.stringify({ options: { query, scope: "pins" }, context: {} }),
      _: Date.now()
    };
    const headers = { 'cookie': cookies, 'user-agent': 'Mozilla/5.0', 'x-requested-with': 'XMLHttpRequest' };
    const { data } = await axios.get('https://br.pinterest.com/resource/BaseSearchResource/get/', { headers, params });
    const results = data.resource_response.data.results.filter(v => v.images?.orig);
    return results.map(r => ({ caption: r.grid_title, image: r.images.orig.url, source: "https://br.pinterest.com/pin/" + r.id }));
  }
}

async function uploadToCatbox(buffer, filename = 'meta.png') {
  const formData = new FormData();
  formData.append('reqtype', 'fileupload');
  formData.append('fileToUpload', buffer, filename);
  const { data } = await axios.post('https://catbox.moe/user/api.php', formData, { headers: formData.getHeaders() });
  return data;
}

async function atualizarMetadinhasAnime(limite = 1000, outputFile = 'database/metadinhas.json') {
  const pinterest = new Pinterest();
  const resultados = await pinterest.search("metadinha anime");

  let metadinhas = [];
  if (fs.existsSync(outputFile)) metadinhas = JSON.parse(fs.readFileSync(outputFile));
  const usados = new Set(metadinhas.map(m => `${m.url_parte1}|${m.url_parte2}`));
  let contador = metadinhas.length + 1;

  for (let i = 0; i < resultados.length && contador <= limite; i += 2) {
    if (resultados[i] && resultados[i + 1]) {
      const img1 = resultados[i].image;
      const img2 = resultados[i + 1].image;
      const chave = `${img1}|${img2}`;
      if (usados.has(chave)) continue;
      usados.add(chave);
      try {
        const buf1 = await axios.get(img1, { responseType: 'arraybuffer' });
        const buf2 = await axios.get(img2, { responseType: 'arraybuffer' });
        const url1 = await uploadToCatbox(Buffer.from(buf1.data), `meta${contador}_1.png`);
        const url2 = await uploadToCatbox(Buffer.from(buf2.data), `meta${contador}_2.png`);
        metadinhas.push({ id: contador, nome: resultados[i].caption || `Metadinha Anime ${contador}`, url_parte1: url1, url_parte2: url2, tags: ["anime", "metadinha"] });
        contador++;
      } catch (err) { errorLog("Erro ao processar metadinha: " + err.message); }
    }
  }

  fs.writeFileSync(outputFile, JSON.stringify(metadinhas, null, 2));
  successLog(`✅ JSON atualizado: ${outputFile} com ${metadinhas.length} metadinhas.`);
  return metadinhas;
}

module.exports = { atualizarMetadinhasAnime };