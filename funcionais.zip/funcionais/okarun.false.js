require('dotenv').config();
const path = require('path')
let bla = process.cwd();
__path = process.cwd();
const express = require('express');
const app = express();
const router = express.Router();

const PORT = process.env.PORTA || 2643;

const os = require('os')
const fileUpload = require('express-fileupload')
const { v4: uuidv4 } = require('uuid'); // 
const ReadText = require('text-from-image')
const { PornHub } = require('pornhub.js')
const { NSFW } = require("nsfwhub")
const colors = require("colors")
const cfonts = require('cfonts')
const { sayLog, inputLog, infoLog, successLog, errorLog, warningLog, eventLog } = require("./database/logger.js");
const moment = require('moment-timezone')
const Canvasfy = require("canvafy")
const GIFEncoder = require("gifencoder")
const JXR = require("jxr-canvas")
const canvacard = require("canvacard")
const { musicCard, RankCard } = require("musicard-bun")
const canvafy = require("canvafy")
const { Card } = require("welcomify")
const ffmpeg = require('fluent-ffmpeg')
const uuid = require('uuid').v4
const fs = require('fs')
const hx = require('hxz-api')
const axios = require('axios')
const Jimp = require('jimp')
const zrapi = require('zrapi')
const jpeg = require('jpeg-js')
const { GOOGLE_IMG_SCRAP , GOOGLE_QUERY } = require('google-img-scrap')
const { superimg } = require("./base de dados/superimg.js")
const ytdl = require('ytdl-core');
const yt = require("@ernestoyoofi/yt.loader-to")
const yts = require('yt-search')
const translate = require('translate-google-api')
const multer = require('multer')
const upload = multer({ dest: './uploads/', limits: { fileSize: 1024 * 1024 * 1024 }})
const request = require('request')
const cheerio = require('cheerio')
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args))
const FormData = require('form-data')
const lyricsFinder2 = require('lyrics-finder')
const uber = require('uberduck-api')
var { igstory } = require('./base de dados/scrape.js')
var { searchSpotify } = require('./base de dados/spotify.js')
const { baixarFaixaSpotify } = require("./base de dados/baixarspotify.js")
const { nanoBananaFromUrl } = require('./base de dados/nanobanana') 
const pindl = require("./base de dados/pindl");
const getInfo = require("./base de dados/opsanime.js")
const icms = require('./base de dados/icms.js')
const { igstalk } = require('./base de dados/igstalk2.js');
const tofigure = require("./base de dados/tofigure.js")
const GoogleIa = require('./base de dados/Google_mod_ai.js') 
const { atualizarMetadinhasAnime } = require('./base de dados/metadinhas.js'); 
const { GDriveDl, mediafiredl__ } = require(bla+'/base de dados/download.js')
var canvasx = require('discord-canvas')
var { fromBuffer } = require('file-type')
const fileType = require('file-type')
const BrainlySearch = require('./base de dados/brainly.js')
const pinterestSearch = require("./base de dados/pinterestsearch"); // importa a função que você criou
const { PlayLinkMP4_1 } = require('./base de dados/youtube2.js')
const { instagramStoryUser, igProfileStalk, unsplashSearch } = require('./base de dados/get.js')
const { tiktokstalker } = require('./base de dados/get.js')
const { fetchJson } = require('./base de dados/myfunc')
const { audioMeme, yt2mate, yt1s, savef, get } = require("./base de dados/sociais-2.js")
const isUrl = require("is-url")
var gerarnick = require('./base de dados/gerarnick.js')
const { fetchTwitterMedia } = require('./base de dados/twtdl.js')
var buffer = require('./base de dados/upload2.js')
const SpotifyDL = require('./base de dados/SpotifyDL')
const { exec } = require('child_process')
var { Maker } = require('imagemaker.js')
var TikTokScraper = require('tiktok-scraper')
const { shortText } = require("limit-text-js")
const CEP = require('cep-address-finder')
const scraper = require('./base de dados/MULTI_IMDb.js')
const GPTImage = require('./base de dados/GPTImage'); // importa o módulo que você criou
const { rastrearEncomendas, dafontDownload, dafontSearch, XvideosSearch, pensador } = require(bla+"/base de dados/@api.js")
const { EmojiAPI } = require("emoji-api");
var thiccysapi = require('textmaker-thiccy')
const Pinterest = require('./base de dados/pinterestboru.js');
const { generateMusicCardV2 } = require('./base de dados/musicCard');
const copilot2 = require('./base de dados/copilot2.js');
const { ciciScraper } = require('./base de dados/cici.js');
const { BrasileirãoFutebol, getNoticiasEsporte } = require("./base de dados/futebol.js")
const { download_Url } = require("./base de dados/function.js")
const mintake = require(bla + '/base de dados/modules/mintake')
const mumaker = require(bla + '/base de dados/modules/mumaker')
const { youtubedl, youtubedlv2 } = require(bla + "/base de dados/modules/scraper-sosmed")
const { PlayLinkMP3, PlayLinkMP4, PlayAudio, PlayVideo, ytSearch2 } = require("./base de dados/youtubev1.js")
const { tikmate, tiklydown } = require("./base de dados/tiktok.js")
var wiki = require("@dada513/wikipedia-search")
const tesseract = require("node-tesseract-ocr")
const NASA = require('@killovsky/nasa')
var trans = require('@vitalets/google-translate-api')
var Deezer = require("deezer-web-api")
var DeezerClient = new Deezer()
const {savefrom} = require('./base de dados/savefrom.js')
const keepv = require('./base de dados/keepv') // importa o scraper
const J2Download = require('./base de dados/J2Download'); // importa sua classe
const Pokemon = require('pokemon.js')
const cors = require('cors')
const gabriell = require("./base de dados/listdl.js")
const testing = require("./base de dados/listdl2.js")
const BitlyClient = require('bitly').BitlyClient
const TinyURL = require('tinyurl')
const unfetch = require('isomorphic-unfetch')
const { wikimedia } = require("./base de dados/scraper/wikimedia.js")
const { wall } = require("./base de dados/scraper/scraper.js")
var { color } = require('./base de dados/color.js')
var { ytPlay, ytSearch, ytVideosSearch } = require('./base de dados/yt.js')
const { fbdown } = require("./base de dados/facebook.js")
const { saveig, saveig_reels, getmyfb } = require("./base de dados/sociais.js")
const { ytDonlodMp3_3, ytDonlodMp4_3, ytPlayMp3_3, ytPlayMp4_3, ytSearch_3 } = require("./base de dados/youtubev3")
const { facebook, randomGrupos2 } = require('./base de dados/downloader.js')
const { gis } = require('./base de dados/gimage.js')
//var { ytMp3_2, ytMp4_2, ytPlay_2 } = require('./base de dados/youtubev2.js')
var { nerding, gpwhatsapp, apkmody, pornhubsrc, uptodown, soundl, playstore, manga, hentaistube, pornogratis, filme } = require('./base de dados/scraper2.js')
const { wattpad } = require('./base de dados/scraper2.js')
var { pensadorSearch, wallpaper2 } = require('./base de dados/scrapper-api.js')
var { tiktok2, FacebookMp4 } = require('./base de dados/downloader.js')
var { PlayStoreSearch, MercadoLivreSearch, AmazonSearch, AmericanasSearch, SubmarinoSearch, Horoscopo, Dicionario } = require('./base de dados/scraper-2/pesquisas.js')
var { pinterestVideoV2 } = require('./base de dados/pinterest.js')
const Kwai = require('./base de dados/kwai.js')
const{ nanobanana } = require("./base de dados/nanobanana.js")
var { InArtificial, CorretorOpenAi } = require('./base de dados/scrapper-vip.js')
var { getVideosPlaylist } = require('./base de dados/playlist.js')
const scrapper = require("./base de dados/scrapper.js")
var { G1, Poder360, JovemPan, Uol, CNNBrasil, Estadao } = require('./base de dados/scraper/noticias.js')
const { dirname } = require('path')
var __dirname = dirname(__filename)
var { memesDroid } = require('./base de dados/scraper/aleacrapper.js')
var { iFunny } = require("./base de dados/ifunny.js")
var { ringtone } = require('./base de dados/scraper/ringtone.js')
var { lirik } = require('./base de dados/sab_scraper.js')
const { AnimeWallpaper } = require("anime-wallpaper")
const BuscaWallpaper = new AnimeWallpaper()
const { snapsave } = require("@bochilteam/scraper")
var { facebookDownloader, instaVideoV1 } = require('./base de dados/scraper/downloaders.js')
var { LetradaMusica } = require('./base de dados/letraMusic.js')
var { igdl } = require('./base de dados/igdl.js')
const { happymodr } = require('./base de dados/happymod.js')
const { wikiSearch } = require('./base de dados/wikipediaBr.js')
const { aiovideodl, umma, ytPlay_3} = require('./base de dados/scraper-2.js')
const { randomGrupos } = require('./base de dados/groups-random.js')
const yts2 = require("youtube-yts")
const YT = require('./base de dados/ytdl2.js')
const YT2 = require('./base de dados/ytdl.js')
const { AnimeFire, testProxyConnection } = require('./base de dados/animesfiresearch.js')
const bodyParser = require('body-parser')
const { mediafire } = require('./base de dados/mediafire2.js')
const ScrapperData = require('./base de dados/lyrics.js')
const { tiktokStalk } = require('./base de dados/tiktokStalk.js')
const ScrapperDorama = require('./base de dados/ScrapperDorama.js')
const { downloadAudio2, downloadVideo2, audioDir, videoDir, finalOutputPath } = require('./base de dados/ytdl3.js')
const { downloadVideo, downloadAudio } = require('./base de dados/ndownMultiDownload.js')
const { arcloud } = require('./base de dados/arcloud/arcc.js')
const tf = require('@tensorflow/tfjs-node')
const d = require('d-scrape')
const chalk = require('chalk')
const getGPT4js = require("gpt4js")
const { igApi, getCookie } = require("insta-fetcher")
const { searchPinterest } = require('./base de dados/pinterest2.js')
const { downloadTiktok } = require('@mrnima/tiktok-downloader')
const Removebg = require('removebg-id')
const { Quiz } = require('anime-quiz')
const { search, downloadTrack, downloadAlbum } = require('@nechlophomeriaa/spotifydl')
const fetcher2 = require('isomorphic-unfetch')
const { getPreview: fetchSpotifyPreview } = require('spotify-url-info')(fetcher2)
//const { ytdl } = require('@saxx/no-noobs-apis')
const he = require('he')
const https = require('https')
const { http, https2 } = require('follow-redirects')
const ton = require('api-dylux')
const Qasim = require('api-qasim')
const { mediafireDl } = require('@imeshsan2008/mfdl')
const { scrapeWallpapers } = require('./base de dados/scraper_wallpaper.js')
const { tiktokdl } = require('tiktokdl')
const SoundCloud = require("@zibot/scdl")
const { fbdl } = require('ruhend-scraper')
//const { ytmp3: getAudio2, ytmp4: getVideo2 } = require('ruhend-scraper')
const { ai, tools } = require('kode-scrape')
const Caxinha = require('./base de dados/modules/backend/canvas')
const Caxinha2 = require('./base de dados/modules/backend/canvas-2')
const sharp = require('sharp')
const { createCanvas, loadImage } = require('canvas')
const { GoogleGenAI } = require('@google/genai')
const gemini = new GoogleGenAI({ apiKey: 'AIzaSyACbd2Srxte_hJQF-2liWWQA-dLu-xxlIs' })
const { ytPlayMp3, ytPlayMp4 } = require('./base de dados/scraper_yt.js')
const { pipeline } = require('stream')
const { Readable } = require('stream')
const AppleMusic = require('./base de dados/applemusic.js')
const { ZeroTwoIA } = require('./base de dados/ZeroTwoIA.js')
const itzpireStalker = require('./base de dados/itzpire-stalker.js')
const Image = require('./base de dados/modules/image-custom/start.js')
const Spotify = require('./base de dados/Spotifypl.js') // ajuste o caminho se precisar
const { capcut, instagram, threads } = require('./base de dados/naya-api-dl.js')
const { tiktokStalk_v3 } = require('./base de dados/tiktok_stalker.js')
const scrapePinterestVideo = require('./base de dados/pinmp4.js')
const { RealityBBB25, ForaDaCasaBBB25, BigDaysBBB25 } = require('./base de dados/BBB25.js')
const ScrapperLyrics = require('./base de dados/ScrapperLyrics.js')
const { Telegraf } = require('telegraf')
const botToken =  process.env.TOKENBOT || "6369612385:AAFZXhcTNTcvS3Bqo8sISgyK_DLRL6gZTyQ"
const bot = new Telegraf(botToken)
const Anime = require('./base de dados/animes.js')
const anime = new Anime()
const morgan = require('morgan')
const mongoSanitize = require('express-mongo-sanitize')
const helmet = require('helmet')
const rateLimit = require('express-rate-limit')
const crypto = require('crypto')
const { scrapeData } = require('./base de dados/signos.js')
const gerarAscii = require("./base de dados/ascii.js")
const sfundo = require('./base de dados/sfundo.js')
const { baixarMP3, baixarMP4 } = require('./base de dados/ytdl8.js')
const { buscarAptoide } = require('./base de dados/aptoide.js')
const GrabTheClip = require('./base de dados/grabtheclip.js')
const grabber = new GrabTheClip()
const { EfiPayPayment } = require('./efipay-module/index.js')
const pixKey = process.env.PIXKEY || '9f377182-588e-4949-80f1-9a3dd3b15962'
const pagamento = new EfiPayPayment(pixKey)
const { scrapeAnimeVideo, uploadToAPI } = require('./base de dados/animes/getVideoBuffer.js')
const { GetDownloadEp, GetEp, SearchAnimeCC } = require('./base de dados/animes/scraper_anime_2025.js')
const { searchAnime, getAnime } = require('./base de dados/myanimes.js')
const { downloadVideoAnime } = require('./base de dados/animes/GetVideo.js')
const { threads2 } = require('./base de dados/scraper_threads.js')
const scrapeDotsave = require('./base de dados/dotsaveScraper.js')
const { shortenWithYandex } = require('./base de dados/shorten.js')
const { pinterest2 } = require('./base de dados/scraper_pinterest.js')
const { pinterest3 } = require('./base de dados/scraper_pinterest2.js')
const { downloadYouTube } = require('./base de dados/savet.js')
const TubeRipper = require("./base de dados/tuberipper.js")
const { KwaiScraper } = require('./base de dados/kwai_scraper.js')
const Tiktok = require("@tobyg74/tiktok-api-dl")
const { StalkUser } = require("@tobyg74/tiktok-api-dl");
const { kwaiDownload, kwaistalk } = require('./base de dados/kwaidl.js')
const TinderSystem = require('./base de dados/tinder/TinderSystem.js')
//const { tohd, vyroEngine } = require('./base de dados/tohd.js')
const { queryModel } = require('./base de dados/gpt4.js')
const deepseek = require('./base de dados/deepseek.js')
const BrasileiraoScraper = require('./base de dados/brasileirao-2025.js')
const main = require('./base de dados/imgtoanime.js')
const toZombie = require('./base de dados/imgtozombie.js')
const img2gtas = require('./base de dados/imgtogta.js')
const { search2, download, downloadPreview, downloadMusica, uploadToCatbox } = require('./base de dados/applescraper.js')
const { generateMusicCard } = require('./base de dados/musicard.js')
const { uploadToCatbox2 } = require('./base de dados/uploadcatbox.js')
const SpaceNewsScraper = require('./base de dados/get-noticias-space.js')
// ----------------- FF -------------------- //
const FreeFireScraper = require('./base de dados/scrapers-ff/stalk-ff.js')
const FreeFireSkinscraper = require('./base de dados/scrapers-ff/freeFireSkinscraper.js')
const AccountDateChecker = require('./base de dados/scrapers-ff/account-date-checker.js')
const PlayerProfileScraper = require('./base de dados/scrapers-ff/player-profile.js')
const { FreeFireLikesScraper, REGIOES_VALIDAS } = require('./base de dados/scrapers-ff/likes-ff.js')
const { claimFreeFireReward } = require('./base de dados/scrapers-ff/ff-rewands.js')
const { verificarNivelPrime } = require('./base de dados/scrapers-ff/ff-prime.js')
const FreeFireBioScraper = require('./base de dados/scrapers-ff/ff-bio-scraper.js')
const BannedAccountsScraper = require('./base de dados/scrapers-ff/banned-accounts.js')
// -----------+---+----------+-------------+----+--------------- //
const { text2Video } = require('./base de dados/gptvideo.js')
const SoundCloudScraper = require('./base de dados/SoundCloud.js')
const { animagine } = require('./base de dados/animagine.js')
const { generateCode, supportedLanguages, supportedModels } = require('./base de dados/ai-generate-code.js')
const { gerarPoema, getTiposEIdiomas } = require('./base de dados/aipoem_scraper.js')
const { identifyAnime } = require('./base de dados/animefinder.js')
const { shortenUrl } = require('./base de dados/encurta.net.js')
const { generateNglCanvas } = require('./base de dados/nglCanvas.js')
const { ytdlMp4, ytdlMp3 } = require('./base de dados/yt-dl.js')
const { generateVideo, VideoGenerationError } = require('./base de dados/veon-2.js')
const upscale = require('./base de dados/tohd2.js')
const upscale2 = require('./base de dados/tohd3.js')
const { imgUpscaleFromUrl } = require('./base de dados/tohd.js')
const createGuraSticker = require('./base de dados/gura-canvas.js')
const AmpDownloader = require('./base de dados/amp.js')
const downloader = new AmpDownloader()
const { instagramDownload } = require('./base de dados/igdl.js')
const getTelegramStickerPack = require('./base de dados/sticker-telegram-download.js')
const VideoDownsDownloader = require('./base de dados/videodowns.js')
const ytdldownloader = new VideoDownsDownloader()
const savetube = require('./base de dados/savetube.js')
const ias2 = require('./base de dados/ias2.js')
const generateImage = require('./base de dados/gerador_de_imagens.js')
const generateTTS = require('./base de dados/google-tts.js')
const { Image2Comic } = require('./base de dados/Image2Comic.js')
const { generatePingCanvas } = require('./base de dados/ping-canvas.js')
const { createDuelData, drawDuelCanvas } = require('./base de dados/duelo-canvas')
const savetube2 = require('./base de dados/savetube2.js')
const Youtubers = require('./base de dados/playdl.js')
 
const dirPath = path.join(__dirname, "base de dados"); 


// ========================
// ZERO TWO MINI SISTEMA v3
// Tudo em JSON - persistente 🩷
// ========================

const DB_PATH = path.join(__dirname, 'zerotwo_conversations.json');

// Carrega ou cria o banco
let db = { conversations: {}, totalConversations: 0 };
if (fs.existsSync(DB_PATH)) {
  db = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
} else {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

// Salva o banco toda vez que mudar
function saveDB() {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}



const { puxadas, savePux, existPuxToken, getPuxToken, addPuxToken, rmPuxToken, saveRoutePuxToken, forPuxToken, consultkeys, saveConsultKeys, existConsultKeys, getConsultKeys, addConsultKeys, rmConsultKeys, saveRouteConsultKeys, forConsultKeys } = require("./database/consultas/consultkeys.js")


// -----------+---+----------+-------------+----+--------------- //
const criador = process.env.CRIADOR || "@paulo_mod_domina"
const SENHA_OFC = process.env.SENHA || "okarunapidopaulo2026"
const API_KEY_OKARUN = process.env.API_KEY_OKARUN || "inovação_2026"
const okarunsite = process.env.OKARUNSITE || "https://okarun-api.com.br"
const TOKEN = 'apihydra-ckbwg9tf-r7lkkqdc'
// -----------+---+----------+-------------+----+--------------- //
const BLACKLIST_FILE = 'blacklist_ips.txt'
const DATA_FILE = path.join(__dirname, 'ip_data.json')
// 🔥 Carrega blacklist de IPs bloqueados permanentemente
let blockedIPs = new Set(fs.existsSync(BLACKLIST_FILE) ? fs.readFileSync(BLACKLIST_FILE, 'utf-8').split('\n') : [])
let failedAttempts = {}
// Função para salvar os dados no arquivo JSON
function saveAttemptData(ip, apikey, attempts) {
const currentDate = moment().format('YYYY-MM-DD HH:mm:ss')
const data = {
ip,
apikey,
attempts,
date: currentDate
}
let existingData = []
if (fs.existsSync(DATA_FILE)) {
existingData = JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8'))
}
const existingIndex = existingData.findIndex(item => item.ip === ip)
if (existingIndex !== -1) {
existingData[existingIndex] = data
} else {
existingData.push(data)
}
fs.writeFileSync(DATA_FILE, JSON.stringify(existingData, null, 2))
}

const googleImageSearch = async (query) => {
const apiKey = 'AIzaSyD1LwGYfWvRGpwOt7ppmXwHkWLm-lYMZUw'
const cx = '8336f5de960b14645'
const response = await axios.get(`https://www.googleapis.com/customsearch/v1?q=${encodeURIComponent(query)}&cx=${cx}&searchType=image&key=${apiKey}&imgSize=huge`)
return response.data.items.map(item => item.link)
}

async function translateText(text, targetLang = 'pt') {
try {
const response = await fetch(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${targetLang}&dt=t&q=` + encodeURIComponent(text))
const data = await response.json()
return data[0][0][0]
} catch (error) {
console.error('Erro ao traduzir texto:', error)
return text
}
}



async function upload2(mediaBuffer, fileName = "file") {
return new Promise(async (resolve, reject) => {
try {//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B
console.log("Iniciando o processamento do media...")
if (Buffer.isBuffer(mediaBuffer)) {
console.log("Media recebido é um buffer. Preparando para upload...")
const mediaType = await fileType.fromBuffer(mediaBuffer)
console.log("Tipo de mídia detectado:", mediaType)
if (!mediaType) {
console.error("Não foi possível determinar o tipo do arquivo.")
return reject("Não foi possível determinar o tipo do arquivo.")
}
const { mime } = mediaType
let response
try {
const uploadRes = await axios.post(`${okarunsite}/api/upload`, {
apikey: API_KEY_OKARUN,
media: mediaBuffer,
filename: fileName
}, {
headers: {
'Content-Type': 'multipart/form-data'
}
})
if (uploadRes.data.status) {
console.log("Link gerado com sucesso:", uploadRes.data.resultado)
resolve(uploadRes.data.resultado)
} else {
console.error("Erro ao gerar o link:", uploadRes.data.message || 'Erro desconhecido')
reject("Erro ao gerar o link.")
}
} catch (uploadError) {
console.error("Erro ao enviar para a API de upload:", uploadError.message)
reject("Falha ao enviar a mídia para a API.")
}
} else {
console.error("Erro: O formato do media não é um buffer.")
reject("Formato do media não suportado. Envie um buffer.")
}
} catch (error) {
console.error("Erro ao processar o media:", error.message)
reject("Falha ao processar o media: " + error.message)
}
})
}

async function getBuffer(url) {
hes = await fetch(url).then(c => c.buffer())
 return hes
}
async function Kibar(url) {
hes = await fetch(url).then(c => c.json())
 return hes
}

const getRandom = (ext) => {
return `${Math.floor(Math.random() * 10000)}${ext}`
}

async function getBuffer(url) {
hes = await fetch(url)
.then(c => c.buffer())
return hes
}

const allReplace = (frase, txt, rp) => {
caixa = [frase]
for(i = 0; i < 1000; i++) {
caixa.push(caixa[i].replace(txt, rp))
}
return caixa[caixa.length - 1]
}

//-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-\\

function ping() {
const speed = require('performance-now')
const timestampm = speed()
const latency = speed() - timestampm
const ms = latency.toFixed(4)
return ms
}

// Carrega as 5.000 cantadas (uma vez só)
const CANTADAS = JSON.parse(
  fs.readFileSync(path.join(__dirname, 'cantadas.json'), 'utf8')
).cantadas;

// Tabela de Preços Segura (Server-Side)
const PRECOS_SEGUROS = {
'1': { valor: 1.00, requests: 1000, consultas: 0 },
'2': { valor: 2.00, requests: 2000, consultas: 0 },
'3': { valor: 3.00, requests: 3000, consultas: 0 },
'4': { valor: 4.00, requests: 4000, consultas: 0 },
'5': { valor: 5.00, requests: 5000, consultas: 0 },
'6': { valor: 6.00, requests: 6000, consultas: 0 },
'7': { valor: 7.00, requests: 7000, consultas: 0 },
'8': { valor: 8.00, requests: 8000, consultas: 0 },
'9': { valor: 9.00, requests: 9000, consultas: 0 },
'10': { valor: 10.00, requests: 10000, consultas: 0 },
'11': { valor: 11.00, requests: 11000, consultas: 0 },
'12': { valor: 12.00, requests: 12000, consultas: 0 },
'13': { valor: 13.00, requests: 13000, consultas: 0 },
'14': { valor: 14.00, requests: 14000, consultas: 0 },
'15': { valor: 15.00, requests: 15000, consultas: 5000 },
'16': { valor: 16.00, requests: 16000, consultas: 6000 },
'17': { valor: 17.00, requests: 17000, consultas: 7000 },
'18': { valor: 18.00, requests: 18000, consultas: 8000 },
'19': { valor: 19.00, requests: 19000, consultas: 9000 },
'20': { valor: 20.00, requests: 20000, consultas: 10000 },
'21': { valor: 21.00, requests: 21000, consultas: 11000 },
'22': { valor: 22.00, requests: 22000, consultas: 12000 },
'23': { valor: 23.00, requests: 23000, consultas: 13000 },
'24': { valor: 24.00, requests: 24000, consultas: 14000 },
'25': { valor: 25.00, requests: 25000, consultas: 15000 },
'26': { valor: 26.00, requests: 26000, consultas: 16000 },
'27': { valor: 27.00, requests: 27000, consultas: 17000 },
'28': { valor: 28.00, requests: 28000, consultas: 18000 },
'29': { valor: 29.00, requests: 29000, consultas: 19000 },
'30': { valor: 30.00, requests: 30000, consultas: 20000 },
'31': { valor: 31.00, requests: 31000, consultas: 21000 },
'32': { valor: 32.00, requests: 32000, consultas: 22000 },
'33': { valor: 33.00, requests: 33000, consultas: 23000 },
'34': { valor: 34.00, requests: 34000, consultas: 24000 },
'35': { valor: 35.00, requests: 900000, consultas: 900000 }
}


// ============[ APIKEYS ]============ \\

//var key = JSON.parse(fs.readFileSync("./database/apikeys.json"))
const usuarios = JSON.parse(fs.readFileSync("./database/usuarios.json"))
const tinder = JSON.parse(fs.readFileSync("./database/tinder.json"))

const mongoose = require('./database/node_modules/mongoose')
const dbUri =  process.env.URLDATABASE ||`mongodb+srv://kakashiratake906:h5ZFfpYmrDMVeooz@cluster0.r1q2asr.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0`


mongoose.connect(dbUri, {
useNewUrlParser: true,
useUnifiedTopology: true,
})
.then(() => successLog('Conectado ao MongoDB com sucesso!'))
.catch((err) => console.error('Erro ao conectar ao MongoDB:', err))

// ===[INÍCIO - KEYS ENCURTAR LINK]===== \\
apicuttly = ['4786cc6a0f19de9c67ea6a4282c494323c932','2038c1a7754b408aa8f9055282638c00e668e','89d73b3a07209177d0251e30d49d66bd669ac','e841147455d0fdfbf50f74aefe63b6728adc0','27f3aa3f45cb4460bcbac69b782ca470a4570','31a8df09d5a9d8d009790df0b5642e3d76919','09b4e764ff07b10eac1682e71aaf95a78f358','75fe576ce040b619176af22f5a718b2f574f5','e24ee36f9c1519c0a779667a5182a31fb7ccf','903869065d29e23455ddca922071f4bbeb133']
apibitly = ['6cfc18e9bfa554714fadc10a1f6aff7555642348','2243940c230ad0d748059aee58ddf126b65fd8e7','c71b6658a1d271ddaf2a5077de3dcb9d67f68025','cddbceccdc2f1c9d11e4cdd0d2b1d1078e447c43','7915c671fbd90eca96310e5c9442d761225a1080','e5dee46eb2d69fc9f4b0057266226a52a3555356','f09ab8db9cf778b37a1cf8bc406eee5063816dec','964080579f959c0cc3226b4b2053cd6520bb60ad','a4f429289bf8bf6291be4b1661df57dde5066525','3d48e2601f25800f375ba388c30266aad54544ae','4854cb9fbad67724a2ef9c27a9d1a4e9ded62faa','d375cf1fafb3dc17e711870524ef4589995c4f69','43f58e789d57247b2cf285d7d24ab755ba383a28','971f6c6c2efe6cb5d278b4164acef11c5f21b637','ae128b3094c96bf5fd1a349e7ac03113e21d82c9','e65f2948f584ffd4c568bf248705eee2714abdd2','08425cf957368db9136484145aa6771e1171e232','dc4bec42a64749b0f23f1a8f525a69184227e301','0f9eb729a7a08ff5e73fe1860c6dc587cc523035','037c5017712c8f5f154ebbe6f91db1f82793c375']

// ===[FIM - KEYS ENCURTAR LINK]===== \\

const headers = {
'accept': '*/*',
'User-Agent': 'Mozilla/5.0 (Macintosh Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36 Edg/101.0.1210.53',
'Accept-Language': 'en-US,enq=0.9,itq=0.8,esq=0.7',
'referer': 'https://www.google.com/',
'cookie': 'DSID=AAO-7r4OSkS76zbHUkiOpnI0kk-X19BLDFF53G8gbnd21VZV2iehu-w_2v14cxvRvrkd_NjIdBWX7wUiQ66f-D8kOkTKD1BhLVlqrFAaqDP3LodRK2I0NfrObmhV9HsedGE7-mQeJpwJifSxdchqf524IMh9piBflGqP0Lg0_xjGmLKEQ0F4Na6THgC06VhtUG5infEdqMQ9otlJENe3PmOQTC_UeTH5DnENYwWC8KXs-M4fWmDADmG414V0_X0TfjrYu01nDH2Dcf3TIOFbRDb993g8nOCswLMi92LwjoqhYnFdf1jzgK0'}

const fixedCookie = `kpn=KWAI; apptype=41; sys=KWAI; client_type=3001; bucket=br; client_key=65890b29; countryInfo=BRA; webDid=7abb4b35-3b6c-454d-b63c-4e65ffdc7bfd; did=7abb4b35-3b6c-454d-b63c-4e65ffdc7bfd; webDidWithTime=7abb4b35-3b6c-454d-b63c-4e65ffdc7bfd_1710089651902; sessionId=2cfe40bb-f352-4d2f-9c10-c3b3898d0b8f; i18n_redirected=pt-BR`



// === IMPORTAR TODOS OS ARRAYS NSFW ===
const nsfw = {
  amador: require("./base de dados/random/nsfw/AmadorVideo/Amador.js").amador,
  onlyfans: require("./base de dados/random/nsfw/OnlyVideo/Onlyfans.js").onlyfans,
  porno: require("./base de dados/random/nsfw/PornoVideo/PornoVid.js").PornoVid,
  egirlvideo: require("./base de dados/random/nsfw/EgirlVideo/EgirlVid.js").EgirlVid,

  aline: require("./base de dados/random/nsfw/AlineFaria/Aline.js").Aline,
  alifox: require("./base de dados/random/nsfw/AlineFox/AlineFx.js").AlineFx,
  alycia: require("./base de dados/random/nsfw/AlyciaRibeiro/Alycia.js").Alycia,
  amichan: require("./base de dados/random/nsfw/Amiichan/Amiichan.js").Amiichan,
  aninha: require("./base de dados/random/nsfw/AninhaLopes/Aninha.js").Aninha,
  victoria: require("./base de dados/random/nsfw/VictoriaMatoso/Victoria.js").Victoria,
 // cum: require("./base de dados/random/nsfw/nsfw.js").cum,
  belle: require("./base de dados/random/nsfw/BelleDelphine/Belle.js").Belle,
  brenda: require("./base de dados/random/nsfw/BrendaTrindade/Brenda.js").Brenda,
  cami: require("./base de dados/random/nsfw/CamiBrito/Cami.js").Cami,
  clowniac: require("./base de dados/random/nsfw/Clowniac/Clowniac.js").Clowniac,
  feh: require("./base de dados/random/nsfw/FehGalvao/Feh.js").Feh,
  giovanna: require("./base de dados/random/nsfw/GiovannaCampomar/Giovanna.js").Giovanna,
  isadora: require("./base de dados/random/nsfw/IsadoraMartinez/Isadora.js").Isadora,
  isa: require("./base de dados/random/nsfw/IsaWaifu/Isa.js").Isa,
  lay: require("./base de dados/random/nsfw/LayMuniz/Lay.js").Lay,
  leticia: require("./base de dados/random/nsfw/LeticiaShirayuki/Leticia.js").Leticia,
  marina: require("./base de dados/random/nsfw/MarinaMui/Marina.js").Marina,
  maru: require("./base de dados/random/nsfw/MaruKarv/Maru.js").Maru,
  princesa: require("./base de dados/random/nsfw/McPrincesa/Princesa.js").Princesa,
  meladinha: require("./base de dados/random/nsfw/Meladinha/Meladinha.js").Me1adinha,
  nath: require("./base de dados/random/nsfw/NathBister/Nath.js").Nath,
  nega: require("./base de dados/random/nsfw/NegaBarbie/Nega.js").Nega,
  polonesa: require("./base de dados/random/nsfw/PolonesaDoHype/Polonesa.js").Polonesa,
  rute: require("./base de dados/random/nsfw/RuteRocha/Rute.js").Rute,
  celestine: require("./base de dados/random/nsfw/VitaCelestine/Celestine.js").Celestine,
  carnie: require("./base de dados/random/nsfw/Carniello/Carniello.js").Carniello,
  gotica: require("./base de dados/random/nsfw/GoticaFoto/Gotica.js").GoticaFT
};



// Classe BratService
class BratService {
  constructor(host = 1) {
    this.BASE_URLS = {
      1: "https://aqul-brat.hf.space/?text=", // Imagem estática
      2: "https://skyzxu-brat.hf.space/brat-animated?text=" // Vídeo animado
    };
    this.totalHosts = Object.keys(this.BASE_URLS).length;
    const validHost = Math.min(Math.max(host, 1), this.totalHosts);
    this.BASE_URL = this.BASE_URLS[validHost];
  }

  async fetchCommand(text) {
    return new Promise(async (resolve, reject) => {
      const url = `${this.BASE_URL}${encodeURIComponent(text)}`;
      try {
        const response = await axios.get(url, { responseType: "arraybuffer" });
        return resolve(Buffer.from(response.data));
      } catch (error) {
        return reject(`Error fetching: ${error.message}`);
      }
    });
  }
}

// Instâncias
const bratStaticService = new BratService(1);
const bratAnimatedService = new BratService(2);


/*
const errorCache = new Map()
app.use(fileUpload({ limits: { fileSize: 1024 * 1024 * 1024 }
}))
app.use(cors({ origin: 'https://okarun-api.com.br' }))
app.set("json spaces",2)
app.use(express.static("public"))
app.use(bodyParser.json({ limit: '100mb' }))
app.use(bodyParser.urlencoded({ limit: '100mb', extended: true }))
app.use(express.json({ limit: '100mb' }))
app.use(express.urlencoded({ limit: '100mb', extended: true }))
app.use(bodyParser.json())
/**
 * Sistema completo de tratamento global de erros, com:
 * - Detecção e normalização de erros de conexão e outros;
 * - Log comprimido via console utilizando chalk;
 * - Salvamento de todos os erros ocorridos em um arquivo JSON na pasta "database";
 * - Middlewares Express para tratamento de erros em rotas e catch global para exceções e rejeições não tratadas,
 * evitando que a API seja reiniciada.
 */
 /*
app.use((req, res, next) => {
const start = Date.now();
res.on('finish', () => {
const duration = Date.now() - start
const methodColors = {
GET: chalk.green,
POST: chalk.blue,
PUT: chalk.yellow,
DELETE: chalk.red,
PATCH: chalk.cyan,
HEAD: chalk.magenta,
OPTIONS: chalk.white
};
const coloredMethod = methodColors[req.method]?.(req.method.padEnd(6)) || req.method
console.log(chalk.gray('[Request]'), coloredMethod, chalk.white(req.originalUrl), chalk.gray(`- ${res.statusCode}`), chalk.gray(`${duration}ms`))
})
next()
})
const databaseDir = path.join(__dirname, 'database')
if (!fs.existsSync(databaseDir)) {
fs.mkdirSync(databaseDir, { recursive: true })
}
const errorLogFilePath = path.join(databaseDir, 'errors.json')
const saveErrorToFile = (error) => {
const errorEntry = {
timestamp: new Date().toISOString(),
error: error
}
let errors = []
try {
if (fs.existsSync(errorLogFilePath)) {
const fileContent = fs.readFileSync(errorLogFilePath, 'utf8')
if (fileContent) {
errors = JSON.parse(fileContent)
}
}
} catch (readErr) {
console.error(chalk.red('Erro ao ler o arquivo de logs:'), readErr)
}
errors.push(errorEntry)
try {
fs.writeFileSync(errorLogFilePath, JSON.stringify(errors, null, 2))
} catch (writeErr) {
console.error(chalk.red('Erro ao salvar o log de erro no arquivo:'), writeErr)
}
};
const isLowLevelNetworkError = (error) => error.code && ['ECONNREFUSED', 'ETIMEDOUT', 'ENOTFOUND', 'ECONNRESET', 'EPIPE', 'EAI_AGAIN'].includes(error.code)
const normalizeError = (rawError) => {
if (isLowLevelNetworkError(rawError)) {
return {
code: `NET_${rawError.code}`,
message: `Falha de conexão com ${rawError.host || 'servidor remoto'}`,
statusCode: 503,
isConnectionError: true,
details: {
host: rawError.host,
port: rawError.port,
syscall: rawError.syscall
}
}
}
if (rawError.response) {
return {
code: rawError.response.data && rawError.response.data.error && rawError.response.data.error.code || 'EXT_API_FAIL',
message: rawError.response.data && rawError.response.data.error && rawError.response.data.error.message || 'Falha em serviço externo',
statusCode: rawError.response.status,
stack: rawError.stack
}
}
if (rawError.data && rawError.data.error) {
return {
code: rawError.data.error.code || 'GEN_ERR',
message: rawError.data.error.message,
statusCode: rawError.status || 500,
stack: rawError.stack
}
}
return {
code: rawError.code || 'UNKNOWN',
message: rawError.message,
statusCode: rawError.statusCode || 500,
stack: rawError.stack
}
};
const logCompressedError = (rawError, reqContext = {}) => {
const error = normalizeError(rawError)
const isNetworkError = error.isConnectionError
const key = isNetworkError ? `NET_${error.code}:${error.details && error.details.host}:${error.details && error.details.port}` : `${reqContext.method || 'NO_METHOD'}:${reqContext.originalUrl || 'NO_PATH'}:${error.code}:${error.statusCode}`
const now = Date.now()
const cacheEntry = errorCache.get(key) || { count: 0, first: now, last: now }
cacheEntry.count++
cacheEntry.last = now
errorCache.set(key, cacheEntry)
const shouldDisplay = isNetworkError ? cacheEntry.count % 4 === 0 || (now - cacheEntry.first) > 20000 : cacheEntry.count % 3 === 0 || (now - cacheEntry.first) > 15000
if (!shouldDisplay) return;
const header = isNetworkError ? chalk.hex('#FF6B35').bold(`🌐 [FALHA DE REDE] ${cacheEntry.count}x`) : chalk.red.bold(`⚠ [ERRO ${error.statusCode}] ${cacheEntry.count}x`);
const messageParts = [ header, chalk.gray('├── Tipo:') + chalk.yellow(error.code), isNetworkError ? chalk.gray('├── Host:') + chalk.cyan(error.details && error.details.host) : chalk.gray('├── Rota:') + chalk.cyan(`${reqContext.method} ${reqContext.originalUrl}`), chalk.gray('├── Status:') + chalk[error.statusCode >= 500 ? 'red' : 'yellow'](error.statusCode), chalk.gray('├── Mensagem:') + chalk.white(error.message), chalk.gray('└── Período: ') + chalk.gray(`${new Date(cacheEntry.first).toLocaleTimeString()} → ${new Date(now).toLocaleTimeString()}`)];
console.error(messageParts.join('\n'))
errorCache.delete(key)
saveErrorToFile(error)
};
// Middleware do Express para tratamento de erros em rotas
app.use((err, req, res, next) => {
logCompressedError(err, {
method: req.method,
originalUrl: req.originalUrl
});
res.status(err.statusCode || 500).json({
error: err.statusCode >= 500 ? 'Erro interno' : err.message,
code: err.code
})
});
// Tratamento global de exceções não capturadas
process.on('uncaughtException', (err) => {
logCompressedError(err, { 
method: 'SYS', 
originalUrl: 'uncaughtException' 
})
});
process.on('unhandledRejection', (reason) => {
logCompressedError(reason instanceof Error ? reason : new Error(reason), {
method: 'SYS',
originalUrl: 'unhandledRejection'
})
})
const asyncHandler = (fn) => async (req, res, next) => {
try {
await fn(req, res, next)
} catch (err) {
logCompressedError(err, req)
next(err)
}
}

// 📂 Criar diretório de logs caso não exista
/*
const logDirectory = path.join(__dirname, 'logs')
if (!fs.existsSync(logDirectory)) {
fs.mkdirSync(logDirectory)
}
// 📜 Stream para registrar acessos HTTP (morgan)
const accessLogStream = fs.createWriteStream(path.join(logDirectory, 'access.log'), { flags: 'a' })
// 📜 Stream para registrar erros (mongoSanitize e helmet)
const errorLogStream = fs.createWriteStream(path.join(logDirectory, 'errors.log'), { flags: 'a' })
// 🔹 Registrar todas as requisições HTTP (morgan)
app.use(morgan('combined', { stream: accessLogStream }))
// 🔹 Middleware de segurança (helmet) - Captura erros silenciosamente
app.use((req, res, next) => {
try {
helmet()(req, res, next)
} catch (err) {
errorLogStream.write(`[${new Date().toISOString()}] Helmet Error: ${err.message}\n`)
next()
}
})
// 🔹 Middleware de sanitização (mongoSanitize) - Captura erros silenciosamente
app.use((req, res, next) => {
try {
mongoSanitize()(req, res, next)
} catch (err) {
errorLogStream.write(`[${new Date().toISOString()}] MongoSanitize Error: ${err.message}\n`)
next()
}
})*/


(async () => {
  try {
    let paulo = await atualizarMetadinhasAnime(1000, bla + '/database/metadinhas.json')
 //   infoLog(`ele é muito gostoso o Paulo ${paulo}`)
  } catch (error) {
    console.error('Erro ao executar atualizarMetadinhasAnime:', error)
  }
})()


// Função para baixar imagem como buffer
async function downloadImage(url) {
  if (!url || typeof url !== 'string') return null;
  if (!/^https?:\/\//i.test(url)) return null;

  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer',
      timeout: 10000,
      headers: { 'User-Agent': 'Mozilla/5.0' }
    });
    return Buffer.from(response.data);
  } catch (err) {
    console.error(`Erro ao baixar imagem: ${url}`, err.message);
    return null;
  }
}

// Função para salvar buffer como arquivo temporário
function saveTempImage(buffer, prefix = 'img') {
  const filename = `${prefix}_${uuidv4()}.png`;
  const filepath = path.join(bla, 'assets', 'Tempo', filename);
  fs.writeFileSync(filepath, buffer);
  return filepath;
}

// Middleware para limpar arquivos temporários após envio (opcional)
function cleanupFile(filepath) {
  setTimeout(() => {
    if (fs.existsSync(filepath)) fs.unlinkSync(filepath);
  }, 5000);
}

const errorCache = new Map();

// ✅ Middlewares principais organizados e sem repetições
app.use(fileUpload({ limits: { fileSize: 1024 * 1024 * 1024 } }));
app.use(cors({ origin: 'https://okarun-api.com.br' }));
app.set("json spaces", 2);
app.use(express.static("public"));
app.use(bodyParser.json({ limit: '100mb' }));
app.use(bodyParser.urlencoded({ limit: '100mb', extended: true }));
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ limit: '100mb', extended: true }));
app.set('trust proxy', true)

// ✅ Monitoramento de requisições (opcional, descomente se quiser ativar)

// Middleware de logging

app.use((req, res, next) => {
  const start = Date.now();

  res.on('finish', () => {
    const duration = Date.now() - start;

    const methodColors = {
      GET: chalk.green,
      POST: chalk.blue,
      PUT: chalk.yellow,
      DELETE: chalk.red,
      PATCH: chalk.cyan,
      HEAD: chalk.magenta,
      OPTIONS: chalk.white
    };

    const coloredMethod = methodColors[req.method]
      ? methodColors[req.method](req.method.padEnd(6))
      : req.method;

    const logMessage = `${coloredMethod} ${chalk.white(req.originalUrl)} ${chalk.gray(`- ${res.statusCode}`)} ${chalk.gray(`${duration}ms`)}`;

    infoLog(logMessage);
  });

  next();
});

const databaseDir = path.join(__dirname, 'database');
if (!fs.existsSync(databaseDir)) {
fs.mkdirSync(databaseDir, { recursive: true });
}
const errorLogFilePath = path.join(databaseDir, 'errors.json');


const saveErrorToFile = (error) => {
const errorEntry = {
timestamp: new Date().toISOString(),
error: error
};
let errors = [];
try {
if (fs.existsSync(errorLogFilePath)) {
const fileContent = fs.readFileSync(errorLogFilePath, 'utf8');
if (fileContent) {
errors = JSON.parse(fileContent);
}
}
} catch (readErr) {
console.error(chalk.red('Erro ao ler o arquivo de logs:'), readErr);
}
errors.push(errorEntry);
try {
fs.writeFileSync(errorLogFilePath, JSON.stringify(errors, null, 2));
} catch (writeErr) {
console.error(chalk.red('Erro ao salvar o log de erro no arquivo:'), writeErr);
}
};

const isLowLevelNetworkError = (error) =>
error.code && ['ECONNREFUSED', 'ETIMEDOUT', 'ENOTFOUND', 'ECONNRESET', 'EPIPE', 'EAI_AGAIN'].includes(error.code);

const normalizeError = (rawError) => {
if (isLowLevelNetworkError(rawError)) {
return {
code: `NET_${rawError.code}`,
message: `Falha de conexão com ${rawError.host || 'servidor remoto'}`,
statusCode: 503,
isConnectionError: true,
details: {
host: rawError.host,
port: rawError.port,
syscall: rawError.syscall
}
};
}

if (rawError.response) {
return {
code: rawError.response?.data?.error?.code || 'EXT_API_FAIL',
message: rawError.response?.data?.error?.message || 'Falha em serviço externo',
statusCode: rawError.response.status,
stack: rawError.stack
};
}

if (rawError.data?.error) {
return {
code: rawError.data.error.code || 'GEN_ERR',
message: rawError.data.error.message,
statusCode: rawError.status || 500,
stack: rawError.stack
};
}

return {
code: rawError.code || 'UNKNOWN',
message: rawError.message,
statusCode: rawError.statusCode || 500,
stack: rawError.stack
};
};

const logCompressedError = (rawError, reqContext = {}) => {
const error = normalizeError(rawError);
const isNetworkError = error.isConnectionError;
const key = isNetworkError
? `NET_${error.code}:${error.details?.host}:${error.details?.port}`
: `${reqContext.method || 'NO_METHOD'}:${reqContext.originalUrl || 'NO_PATH'}:${error.code}:${error.statusCode}`;

const now = Date.now();
const cacheEntry = errorCache.get(key) || { count: 0, first: now, last: now };
cacheEntry.count++;
cacheEntry.last = now;
errorCache.set(key, cacheEntry);

const shouldDisplay = isNetworkError
? cacheEntry.count % 4 === 0 || (now - cacheEntry.first) > 20000
: cacheEntry.count % 3 === 0 || (now - cacheEntry.first) > 15000;
if (!shouldDisplay) return;

const header = isNetworkError
? chalk.hex('#FF6B35').bold(`🌐 [FALHA DE REDE] ${cacheEntry.count}x`)
: chalk.red.bold(`⚠ [ERRO ${error.statusCode}] ${cacheEntry.count}x`);

const messageParts = [
header,
chalk.gray('├── Tipo: ') + chalk.yellow(error.code),
isNetworkError
? chalk.gray('├── Host: ') + chalk.cyan(error.details?.host)
: chalk.gray('├── Rota: ') + chalk.cyan(`${reqContext.method} ${reqContext.originalUrl}`),
chalk.gray('├── Status: ') + chalk[error.statusCode >= 500 ? 'red' : 'yellow'](error.statusCode),
chalk.gray('├── Mensagem: ') + chalk.white(error.message),
chalk.gray('└── Período: ') +
chalk.gray(`${new Date(cacheEntry.first).toLocaleTimeString()} → ${new Date(now).toLocaleTimeString()}`)
];

console.error(messageParts.join('\n'));
errorCache.delete(key);
saveErrorToFile(error);
};

app.use((err, req, res, next) => {
logCompressedError(err, {
method: req.method,
originalUrl: req.originalUrl
});
res.status(err.statusCode || 500).json({
error: err.statusCode >= 500 ? 'Erro interno' : err.message,
code: err.code
});
});

process.on('uncaughtException', (err) => {
logCompressedError(err, {
method: 'SYS',
originalUrl: 'uncaughtException'
});
});
process.on('unhandledRejection', (reason) => {
logCompressedError(reason instanceof Error ? reason : new Error(reason), {
method: 'SYS',
originalUrl: 'unhandledRejection'
});
});

const asyncHandler = (fn) => async (req, res, next) => {
try {
await fn(req, res, next);
} catch (err) {
logCompressedError(err, req);
next(err);
}
};
// Inicializando o cliente Instagram
const sessionFile = 'database/session.json'
async function getSessionIdFromFile() {
if (fs.existsSync(sessionFile)) {
const data = fs.readFileSync(sessionFile, 'utf-8')
const parsedData = JSON.parse(data)
return parsedData.sessionId
}
return null
}
async function saveSessionIdToFile(sessionId) {
const data = JSON.stringify({ sessionId }, null, 2)
fs.writeFileSync(sessionFile, data, 'utf-8')
}

let ig
(async () => {
try {
infoLog(chalk.green.bold("Obtendo sessão e inicializando API do Instagram...\n"))
const username = process.env.INSTAGRAMUSER || "Shit_ordinario_031";
const password = process.env.INSTAGRAMPASSWORD || "LUCASODONO_1";
let sessionId = await getSessionIdFromFile()
if (!sessionId) {
console.log(chalk.yellow("Nenhuma sessão salva encontrada, gerando nova sessão..."))
sessionId = await getCookie(username, password)
infoLog(chalk.green(`Sessão obtida com sucesso: ${sessionId}\n`))
await saveSessionIdToFile(sessionId)
} else {
successLog(chalk.green(`Sessão carregada com sucesso: ${sessionId}\n`))
}
ig = new igApi(sessionId)
} catch (error) {
console.error(chalk.red.bold("Erro geral ao inicializar a API do Instagram:"), chalk.red(error.message))
}
})()

// Inicializando o cliente SoundCloud
let scdl
(async () => {
try {
infoLog(chalk.blue("Inicializando o cliente SoundCloud..."))
scdl = new SoundCloud()
await scdl.init()
successLog(chalk.green("Cliente SoundCloud inicializado com sucesso."))
} catch (error) {
console.error(chalk.red("Erro ao inicializar o SoundCloud:"), error)
}
})()

function delFile(file) {
try { fs.unlinkSync(file) } catch (error) {}
}

const { UltimateTextToImage, registerFont } = require("ultimate-text-to-image")

const ffmpegPath = require('@ffmpeg-installer/ffmpeg').path

ffmpeg.setFfmpegPath(ffmpegPath)

registerFont((__dirname + '/base de dados/fontes/NotoEmoji.ttf'), { family: 'Noto Emoji' })
registerFont(__dirname + '/base de dados/fontes/NotoSansMono.ttf', { family: 'Noto Sans Mono' })

let randomName = (ext) => uuid().split('-')[0] + (ext ? ext : '')

var cores = ['red','lime','yellow','magenta','cyan']

async function ttp(text, color = '#ffffff', name = randomName('.png')) {
new UltimateTextToImage(text, {
width: 500,
height: 500,
fontFamily: "Noto Emoji, Noto Sans Mono",
fontColor: color,
fontSize: 300,
minFontSize: 10,
lineHeight: 50,
autoWrapLineHeightMultiplier: 1.2,
margin: 15,
//marginBottom: 40,
align: "center",
valign: "middle",
}).render().toFile(`./assets/attp-logs/${name}`)
return `./assets/attp-logs/${name}`
}

async function attp(text) {
let nome = randomName('')
let lista = [
ttp(text, '#ff0000', `${nome}0.png`),
ttp(text, '#ffa600', `${nome}1.png`),
ttp(text, '#ffee00', `${nome}2.png`),
ttp(text, '#2bff00', `${nome}3.png`),
ttp(text, '#00ffea', `${nome}4.png`),
ttp(text, '#3700ff', `${nome}5.png`),
ttp(text, '#ff00ea', `${nome}6.png`),
]

return new Promise(function (resolve, reject) {
// gerar webp
ffmpeg().addInput((`./assets/attp-logs/${nome}`+"%d.png"))
.addOutputOptions(['-vcodec', 'libwebp', '-vf','scale=500:500:force_original_aspect_ratio=decrease,setsar=1, pad=500:500:-1:-1:color=white@0.0, split [a][b] [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p] [b][p] paletteuse', '-loop', '50', '-preset', 'default'])
//.outputFPS(15)
.toFormat('webp')
.on('end', () => {
for (let img = 0; img < lista.length; img++) {
delFile("*png")
}
resolve('./assets/attp-logs/'+nome+'.webp')}).on('error', (err) => {
for (let img = 0; img < lista.length; img++) {
delFile("*webp")
}
reject(('erro ffmpeg ' + err))
}).save(('./assets/attp-logs/'+nome+'.webp'))
})
}

////PAGINA INICIAL Q IRA REDIRECIONAR PRA /DOC
 
app.get("/", (req,res,next) => {
console.log("Beep")
res.end("Boop")
})
app.use(router)
 
app.get('/admin',(req, res) => {
res.sendFile(path.join(__dirname, "./public/", "admin.html"))})

app.get('/docs' ,(req, res) => {
res.sendFile(path.join(__dirname, "./public/", "docs.html"))})

app.get('/store',(req, res) => {
res.sendFile(path.join(__dirname, "./public/", "store.html"))})

app.get('/tmp/:filename', (req, res) => {
const { filename } = req.params
const filePath = path.join(__dirname, 'tmp', filename)
if (!fs.existsSync(filePath)) {
return res.status(404).send('Arquivo não encontrado')
}
if (path.extname(filename).toLowerCase() !== '.html') {
return res.status(400).send('Apenas arquivos HTML são permitidos.')
}
res.setHeader('Content-Type', 'text/html; charset=utf-8')
res.setHeader('Content-Disposition', 'inline')
fs.readFile(filePath, 'utf8', (err, data) => {
if (err) {
console.error('Erro ao ler arquivo:', err)
return res.status(500).send('Erro no servidor')
}
res.send(data)
})
})

app.get('/api/happymod', happymodr)

app.get('/about',(req, res) => {
res.json({
status:true,
message:'Projeto em beta'
})
})

app.get('/api/lerfoto',(req, res) => {
var { url } = req.query
ReadText(url).then(text => {
console.log(text)
}).catch(err => {
console.log(err)
})
})

app.post('/enviar-codigo', (req, res) => {
const email = req.body.email
const codigo = Math.floor(100000 + Math.random() * 900000).toString()
codes[email] = codigo
const mailOptions = {
from: 'gameseduardo76546@gmail.com',
to: email,
subject: 'Código de Verificação',
text: `Seu código de verificação é: ${codigo}`
}
transporter.sendMail(mailOptions, (error, info) => {
if (error) {
return res.status(500).json({ success: false, message: 'Erro ao enviar e-mail' })
}
res.json({ success: true })
})
})

app.post('/confirmar-codigo', (req, res) => {
const { email, codigo } = req.body
if (codes[email] && codes[email] === codigo) {
delete codes[email]
res.json({ confirmed: true })
} else {
res.json({ confirmed: false })
}
})

app.get('/dono/iplist', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var senha = req.query.senha
if(!senha) return res.json({message: "A senha não foi preenchida, por segurança insira a senha que você criou."})
var senhaofc = `${SENHA_OFC}`
if(senha != senhaofc) return res.json({message: "A senha digitada está inválida, verifique por favor."})
listUsersIP = JSON.parse(fs.readFileSync(bla +'/database/usuarios.json').toString())
res.json(listUsersIP) 
})



router.post('/criar-pagamento', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
try {
const { pacoteId } = req.body // Recebe o ID do pacote do frontend
if (!pacoteId) return res.status(400).json({ error: 'Parâmetro "pacoteId" ausente.' })
const pacote = PRECOS_SEGUROS[pacoteId]
if (!pacote) return res.status(400).json({ error: 'Pacote inválido.' })
const valorSeguro = pacote.valor // Pega o valor seguro do servidor
	const result = await pagamento.createPixPayment(pacote) // Passa o objeto pacote completo
if (!result) {
return res.status(500).json({ error: 'Erro ao gerar pagamento.' })
}
// Salvar o pagamento no banco de dados com o pacoteId
await Pagamento.create({
txid: result.txid,
pacoteId: pacoteId,
valor: valorSeguro,
status: 'PENDENTE'
})
res.json({
txid: result.txid,
pix_copia_e_cola: result.pix_copia_e_cola,
uploaded_image_url: result.uploaded_image_url,
})
} catch (error) {
console.error('[ERRO] Falha ao criar pagamento:', error)
res.status(500).json({ error: error.message })
}
})

router.get('/verificar-pagamento/:txid', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
try {
const { txid } = req.params
const status = await pagamento.checkPayment(txid)
if (!status) {
return res.status(500).json({ error: 'Erro ao verificar pagamento.' })
}
// Lógica de verificação e atualização da Key
if (status.status === 'CONCLUIDA' || status.status === 'ATIVA') {
const pagamentoEntry = await Pagamento.findOne({ txid })
if (pagamentoEntry && pagamentoEntry.status === 'PENDENTE') {
const pacote = PRECOS_SEGUROS[pagamentoEntry.pacoteId]
if (pacote) {
// 1. Atualizar o status do pagamento para evitar reprocessamento
await Pagamento.updateOne({ txid }, { $set: { status: 'CONCLUIDO', dataAtualizacao: Date.now() } })
// 2. Criar ou atualizar a key do usuário
// A key do usuário é gerada no frontend e enviada na rota /definirkey.
// Aqui, precisamos de uma forma de vincular o pagamento à key.
// Como não temos essa informação, vamos assumir que o usuário
// irá para a página /definirkey.html após o pagamento.
// A lógica de adicionar requests/consultas será feita na rota /definirkey.
// Para fins de segurança, vamos retornar o pacoteId para o frontend
// para que ele possa ser usado na rota /definirkey.
res.json({ status, pacoteId: pagamentoEntry.pacoteId })
return
}
}
}
// Se o pagamento não foi concluído ou já foi processado, ou se o pacote não foi encontrado
res.json({ status })
} catch (error) {
console.error("[ERRO] Falha ao verificar pagamento:", error)
res.status(500).json({ error: error.message })
}
})

router.post('/api/definir-key-segura', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress;
try {
const { apikey, pacoteId } = req.body;
if (!apikey || !pacoteId) return res.status(400).json({ error: 'Parâmetros "apikey" ou "pacoteId" ausentes.' });
const pacote = PRECOS_SEGUROS[pacoteId];
if (!pacote) return res.status(400).json({ error: 'Pacote inválido.' });
const requests = pacote.requests;
const consultas = pacote.consultas;
let keyEntry = await Apikey.findOne({ apikey });
if (keyEntry) {
if (keyEntry.pacoteId === pacoteId) {
return res.status(409).json({ error: 'Este pacote já foi utilizado para esta key.' });
}
await Apikey.updateOne(
{ apikey },
{ 
$inc: { request: requests, consulta: consultas },
$set: { pacoteId: pacoteId }
}
);
res.json({ message: `Key atualizada com sucesso! Adicionado ${requests} requests e ${consultas} consultas.` });
} else {
await Apikey.create({
apikey: apikey,
request: requests,
consulta: consultas,
ip: userIp,
pacoteId: pacoteId
});
res.json({ message: `Key criada com sucesso! Você tem ${requests} requests e ${consultas} consultas.` });
}
await atualizarKey();
} catch (error) {
console.error('[ERRO] Falha ao definir key:', error)
res.status(500).json({ error: error.message })
}
})

app.get('/api/dono/puxar-senha-ofc', (req, res) => {
const senhaofc = `${SENHA_OFC}` 
res.json({ senha: senhaofc })
})
const ApikeySchema = new mongoose.Schema({
apikey: { type: String, required: true, unique: true },
request: { type: Number, default: 0 },
consulta: { type: Number, default: 0 },
pacoteId: { type: String, default: '0' } // Novo campo para rastrear o pacote
})
const Apikey = mongoose.model('Apikey', ApikeySchema)
// Novo modelo para rastrear pagamentos e o pacote comprado
const PagamentoSchema = new mongoose.Schema({
txid: { type: String, required: true, unique: true },
pacoteId: { type: String, required: true },
valor: { type: Number, required: true },
status: { type: String, default: 'PENDENTE' },
dataCriacao: { type: Date, default: Date.now },
dataAtualizacao: { type: Date, default: Date.now }
})
const Pagamento = mongoose.model('Pagamento', PagamentoSchema)
let key = []
async function atualizarKey() {
try {
key = await Apikey.find()
} catch (err) {
console.error('Erro ao atualizar key:', err)
}
}
atualizarKey()
setInterval(atualizarKey, 1000)
const caminhojson = "./database/rate_limit.json"
function loadRateLimit() {
if (!fs.existsSync(caminhojson)) {
fs.writeFileSync(caminhojson, JSON.stringify({}), "utf8")
}
return JSON.parse(fs.readFileSync(caminhojson, "utf8"))
}
function saveRateLimit(data) {
fs.writeFileSync(caminhojson, JSON.stringify(data, null, 2), "utf8")
}
async function RegisKey(apikey, userIp) {
try {
const keyEntry = await Apikey.findOne({ apikey })
if (!keyEntry) return
let rateLimitData = loadRateLimit()
const now = Date.now()
const cooldown = 1000
const maxRequests = 15
const blockTime = 10 * 1000
const maxRapidRequests = 10
const rapidRequestWindow = 2000
if (!rateLimitData[userIp]) {
rateLimitData[userIp] = { count: 0, lastRequest: now, blockedUntil: 0, rapidRequestTimestamps: [] }
}
let userData = rateLimitData[userIp]
if (userData.blockedUntil > now) {
console.log(`Usuário ${userIp} está temporariamente bloqueado.`)
return
}
if (now - userData.lastRequest > cooldown) {
userData.count = 0
userData.rapidRequestTimestamps = []
}
userData.rapidRequestTimestamps.push(now)
userData.rapidRequestTimestamps = userData.rapidRequestTimestamps.filter(timestamp => now - timestamp < rapidRequestWindow)
if (userData.rapidRequestTimestamps.length > maxRapidRequests) {
userData.blockedUntil = now + blockTime
console.log(`Usuário ${userIp} bloqueado por excesso de requisições rápidas.`)
saveRateLimit(rateLimitData)
return
}
userData.count++
userData.lastRequest = now
if (userData.count > maxRequests) {
userData.blockedUntil = now + blockTime
console.log(`Usuário ${userIp} bloqueado por excesso de requisições.`)
saveRateLimit(rateLimitData)
return
}
saveRateLimit(rateLimitData)
keyEntry.request -= 1
await keyEntry.save()
} catch (err) {
console.error(err)
return
}
}
 
 /*
router.get('/api/dono/puxar-senha-criador-da-api', (req, res) => {
const senhaofc = `${SENHA_OFC}` 
res.json({ senha: senhaofc })
})
const ApikeySchema = new mongoose.Schema({
apikey: { type: String, required: true, unique: true },
request: { type: Number, default: 0 },
consulta: { type: Number, default: 0 },
pacoteId: { type: String, default: '0' } // Novo campo para rastrear o pacote
})
const Apikey = mongoose.model('Apikey', ApikeySchema)
// Novo modelo para rastrear pagamentos e o pacote comprado
const PagamentoSchema = new mongoose.Schema({
txid: { type: String, required: true, unique: true },
pacoteId: { type: String, required: true },
valor: { type: Number, required: true },
status: { type: String, default: 'PENDENTE' },
dataCriacao: { type: Date, default: Date.now },
dataAtualizacao: { type: Date, default: Date.now }
})
const Pagamento = mongoose.model('Pagamento', PagamentoSchema)
let key = []
async function atualizarKey() {
try {
key = await Apikey.find()
} catch (err) {
console.error('Erro ao atualizar key:', err)
}
}
atualizarKey()
setInterval(atualizarKey, 1000)
const caminhojson = "./database/rate_limit.json"
function loadRateLimit() {
if (!fs.existsSync(caminhojson)) {
fs.writeFileSync(caminhojson, JSON.stringify({}), "utf8")
}
return JSON.parse(fs.readFileSync(caminhojson, "utf8"))
}
function saveRateLimit(data) {
fs.writeFileSync(caminhojson, JSON.stringify(data, null, 2), "utf8")
}
async function RegisKey(apikey, userIp) {
try {
const keyEntry = await Apikey.findOne({ apikey })
if (!keyEntry) return
let rateLimitData = loadRateLimit()
const now = Date.now()
const cooldown = 1000
const maxRequests = 15
const blockTime = 10 * 1000
const maxRapidRequests = 10
const rapidRequestWindow = 2000
if (!rateLimitData[userIp]) {
rateLimitData[userIp] = { count: 0, lastRequest: now, blockedUntil: 0, rapidRequestTimestamps: [] }
}
let userData = rateLimitData[userIp]
if (userData.blockedUntil > now) {
console.log(`Usuário ${userIp} está temporariamente bloqueado.`)
return
}
if (now - userData.lastRequest > cooldown) {
userData.count = 0
userData.rapidRequestTimestamps = []
}
userData.rapidRequestTimestamps.push(now)
userData.rapidRequestTimestamps = userData.rapidRequestTimestamps.filter(timestamp => now - timestamp < rapidRequestWindow)
if (userData.rapidRequestTimestamps.length > maxRapidRequests) {
userData.blockedUntil = now + blockTime
console.log(`Usuário ${userIp} bloqueado por excesso de requisições rápidas.`)
saveRateLimit(rateLimitData)
return
}
userData.count++
userData.lastRequest = now
if (userData.count > maxRequests) {
userData.blockedUntil = now + blockTime
console.log(`Usuário ${userIp} bloqueado por excesso de requisições.`)
saveRateLimit(rateLimitData)
return
}
saveRateLimit(rateLimitData)
keyEntry.request -= 1
await keyEntry.save()
} catch (err) {
console.error(err)
return
}
}*/

app.get('/api/dono/addkey', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const a = req.query.a
if (!a.includes("&")) return res.json({ message: "Faltando o and" })
const [apikey, rq, senha] = a.split("&")
if (!apikey) return res.json({ message: "Cadê a key?" })
if (!rq) return res.json({ message: "KD a quant. de request?" })
const senhaofc = `${SENHA_OFC}`
if (senha !== senhaofc) return res.json({ message: "[❗] senha inválida ou inexistente ❌" })
try {
let keyEntry = await Apikey.findOne({ apikey })
if (keyEntry) {
keyEntry.request += Number(rq)
await keyEntry.save()
return res.json({ message: `✔️ ${rq} requests foram adicionados à apikey ${apikey} com sucesso.` })
} else {
keyEntry = new Apikey({
apikey,
request: Number(rq),
consulta: 0
})
await keyEntry.save()
return res.json({ message: `✔️ Apikey ${apikey} registrada com sucesso.` })
}
} catch (err) {
console.error(err)
return res.json({ message: 'Erro ao acessar o banco de dados.' })
}
})

app.get('/api/dono/rmkey', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const a = req.query.a
if (!a.includes("&")) return res.json({ message: "Faltando o and" })
const [apikey, senha] = a.split("&")
const senhaofc = `${SENHA_OFC}`
if (senha !== senhaofc) return res.json({ message: "[❗] senha inválida ou inexistente ❌" })
if (!apikey) return res.json({ message: "Cadê a key?" })
try {
const keyEntry = await Apikey.findOne({ apikey })
if (!keyEntry) {
return res.json({ message: "[❗] Apikey não encontrada ou inexistente ❌" })
} else {
await Apikey.deleteOne({ apikey })
return res.json({ message: `✖️ Apikey ${apikey} deletada com sucesso...` })
}
} catch (err) {
console.error(err)
return res.json({ message: 'Erro ao acessar o banco de dados.' })
}
})

app.get('/api/dono/modkey', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const a = req.query.a
if (!a.includes("&")) return res.json({ message: "Faltando o and (&)" })
const [apikey, requests, senha] = a.split("&")
const senhaofc = `${SENHA_OFC}`
if (senha !== senhaofc) {
return res.json({ message: "[❗] Senha inválida ou inexistente ❌" })
}
if (!apikey) {
return res.json({ message: "Cadê a key?" })
}
if (!requests || isNaN(requests)) {
return res.json({ message: "Quantidade de requests inválida ou inexistente ❌" })
}
try {
const keyEntry = await Apikey.findOne({ apikey })
if (!keyEntry) {
return res.json({ message: "[❗] Apikey não encontrada ou inexistente ❌" })
}
const requestsToAdd = parseInt(requests, 10)
if (keyEntry.consulta === 0) {
keyEntry.consulta = (keyEntry.consulta || 0) + requestsToAdd
await keyEntry.save()
return res.json({ message: `👑 Apikey ${apikey} promovida ao recurso PUXADAS com ${requestsToAdd} requests adicionados ao campo consulta...`})
} else {
keyEntry.consulta = 0
await keyEntry.save()
return res.json({ message: `〽️ Apikey ${apikey} rebaixada do recurso PUXADAS com sucesso...`})
}
} catch (err) {
console.error(err)
return res.json({ message: 'Erro ao acessar o banco de dados.' })
}
})

app.get('/api/dono/listkey', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const senha = req.query.senha
if (!senha) {
return res.json({ message: "A senha não foi preenchida, por segurança insira a senha que você criou." })
}
const senhaofc = `${SENHA_OFC}`
if (senha !== senhaofc) {
return res.json({ message: "A senha digitada está inválida, verifique por favor." })
}
try {
const apikeys = await Apikey.find()
if (!apikeys || apikeys.length === 0) {
return res.json({ message: "Não há chaves de API cadastradas." })
}
return res.json(apikeys)
} catch (err) {
console.error(err)
return res.json({ message: 'Erro ao acessar o banco de dados.' })
}
})

app.get('/api/dono/adc-key', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, request, senha } = req.query
if (!apikey) return res.json({ message: "Você esqueceu de preencher o nome que você deseja na apikey." })
if (!request) return res.json({ message: "Qual é a quantidade de request que você deseja por à apikey?" })
if (!senha) return res.json({ message: "A senha não foi preenchida, por segurança insira a senha que você criou." })
const senhaofc = `${SENHA_OFC}`
if (senha !== senhaofc) return res.json({ message: "[❗] senha inválida ou inexistente ❌" })
try {
let keyEntry = await Apikey.findOne({ apikey })
if (keyEntry) {
keyEntry.request += Number(request)
await keyEntry.save()
return res.json({ message: `✔️ ${request} requests foram adicionados à apikey ${apikey} com sucesso...` })
} else {
keyEntry = new Apikey({
apikey,
request: Number(request),
consulta: 0
})
await keyEntry.save()
return res.json({
message: `✔️ _Apikey registrada com sucesso ↴_
🔑 *Key:* ${apikey}
💾 *Requests:* ${request}`
})
}
} catch (err) {
console.error(err)
return res.json({ message: "Erro ao acessar o banco de dados." })
}
})

app.get('/api/dono/del-key', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, senha } = req.query
if (!apikey) return res.json({ message: "Você esqueceu de preencher o nome que você deseja na apikey." })
if (!senha) return res.json({ message: "A senha não foi preenchida, por segurança insira a senha que você criou." })
const senhaofc = `${SENHA_OFC}`
if (senha !== senhaofc) return res.json({ message: "[❗] senha inválida ou inexistente ❌" })
try {
const keyEntry = await Apikey.findOne({ apikey })
if (!keyEntry) {
return res.json({ message: "[❗] apikey não encontrada ou inexistente ❌" })
} else {
await Apikey.deleteOne({ apikey })
return res.json({ message: `✖️ Apikey ${apikey} deletada com sucesso...` })
}
} catch (err) {
console.error(err)
return res.json({ message: "Erro ao acessar o banco de dados." })
}
})

// 🔥 Rota protegida
app.get('/api/keyerrada', async (req, res) => {
  const userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress;
  const apikey = req.query.apikey;
  const cleanIp = userIp.replace(/^::ffff:/, '');

  // 🔥 Bloqueio de User-Agents suspeitos
  const userAgent = req.headers['user-agent'] || '';
  const suspiciousUserAgents = [
    'axios', 'curl', 'bot', 'spider',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36'
  ];

  if (suspiciousUserAgents.some(agent => userAgent.includes(agent))) {
    return res.status(403).send(createHtmlResponse({
      message: '🚨 A requisição foi bloqueada devido ao User-Agent suspeito.',
      motivo: 'Detectado comportamento de bot ou ferramenta automatizada.',
      solucao: 'Por favor, entre em contato com o suporte.',
      contato: 'https://wa.me/5597984529259'
    }));
  }

  // 🔥 Proteção contra requisições sem API key
  if (!apikey) {
    failedAttempts[cleanIp] = (failedAttempts[cleanIp] || 0) + 1;
    saveAttemptData(cleanIp, apikey, failedAttempts[cleanIp]);

    if (failedAttempts[cleanIp] >= 2) {
      blockedIPs.add(cleanIp);
      fs.appendFileSync(BLACKLIST_FILE, `${cleanIp}\n`);
      return res.status(400).send(createHtmlResponse({
        message: '🚨 IP bloqueado!',
        motivo: 'Você fez múltiplas requisições sem fornecer uma API key.',
        solucao: 'Se precisa de acesso, entre em contato com o suporte.',
        contato: 'https://wa.me/5597984529259'
      }));
    }
    return res.status(400).send(createHtmlResponse({
      message: 'Requisição inválida! API key ausente.'
    }));
  }

  // 🔥 Verificando a chave no banco de dados
  try {
    const keyEntry = await Apikey.findOne({ apikey: apikey });
    if (keyEntry) {
      if (failedAttempts[cleanIp]) {
        delete failedAttempts[cleanIp];
      }
      return res.send(createHtmlResponse({
        message: 'Apikey funcionando perfeitamente.',
        limite_de_request: keyEntry.request || 0,
        consulta: { ativa: keyEntry.consulta > 0, quantidade: keyEntry.consulta || 0 }
      }));
    }

    // 🔥 Chave inválida
    failedAttempts[cleanIp] = (failedAttempts[cleanIp] || 0) + 1;
    saveAttemptData(cleanIp, apikey, failedAttempts[cleanIp]);

    const delay = Math.min(failedAttempts[cleanIp] * 5000, 15000);
    await new Promise(resolve => setTimeout(resolve, delay));

    if (failedAttempts[cleanIp] >= 3) {
      blockedIPs.add(cleanIp);
      fs.appendFileSync(BLACKLIST_FILE, `${cleanIp}\n`);
      return res.status(401).send(createHtmlResponse({
        message: '🚨 IP bloqueado permanentemente!',
        motivo: 'Foram feitas múltiplas tentativas com API key inválida.',
        solucao: 'Se precisar de suporte, entre em contato.',
        contato: 'https://wa.me/5597984529259'
      }));
    }

    return res.status(401).send(createHtmlResponse({
      message: 'Apikey inválida!'
    }));

  } catch (err) {
    console.error(err);
    return res.status(500).send(createHtmlResponse({
      message: 'Erro ao acessar o banco de dados'
    }));
  }
});

function createHtmlResponse(data) {
  const { message, motivo, solucao, contato, limite_de_request, consulta } = data;
  const consultaText = consulta ? `Consulta ativa: ${consulta.ativa ? 'Sim' : 'Não'}, Quantidade: ${consulta.quantidade}` : '';
  const limiteText = limite_de_request !== undefined ? `Limite de requests: ${limite_de_request}` : '';

  // URL do seu vídeo (raw do GitHub - substitua se precisar)
  const videoUrl = 'https://raw.githubusercontent.com/borutovk7/Lab_okarun/main/VID-20251115-WA0238(1).mp4';

  return `
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Resposta da API</title>
<style>
body {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
  color: white;
  text-align: center;
  height: 100vh;
  overflow: hidden;
  position: relative;
  background-size: cover;
  background-position: center;
}
#bg-video {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  z-index: -1;
}
.content {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: rgba(0, 0, 0, 0.5);
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.7);
  z-index: 1;
}
h1 {
  font-size: 2em;
  margin-bottom: 10px;
}
p {
  font-size: 1.2em;
}
@media (max-width: 600px) {
  .content { padding: 15px; }
  h1 { font-size: 1.5em; }
  p { font-size: 1em; }
}
</style>
</head>
<body>
<video id="bg-video" autoplay loop playsinline>
  <source src="${videoUrl}" type="video/mp4">
  Seu navegador não suporta vídeo.
</video>
<div class="content">
  <h1>${message}</h1>
  ${motivo ? `<p>${motivo}</p>` : ''}
  ${solucao ? `<p>${solucao}</p>` : ''}
  ${contato ? `<p>${contato}</p>` : ''}
  ${limiteText ? `<p>${limiteText}</p>` : ''}
  ${consultaText ? `<p>${consultaText}</p>` : ''}
</div>
<script>
  // Ativar som no primeiro clique (política dos navegadores)
  document.addEventListener('click', function enableSound() {
    const video = document.getElementById('bg-video');
    video.muted = false;
    video.play();
    document.removeEventListener('click', enableSound);
  }, { once: true, passive: true });
  
  // Inicia muted para autoplay funcionar
  document.getElementById('bg-video').muted = true;
</script>
</body>
</html>
`;
}
app.get('/api/dono/gerenciar-key', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, requests, senha } = req.query
const senhaofc = `${SENHA_OFC}`
if (!apikey) return res.json({ message: "Você esqueceu de preencher o nome desejado para a apikey." })
if (!requests) return res.json({ message: "Qual é a quantidade de requests que você deseja para a apikey?" })
if (!senha) return res.json({ message: "A senha não foi preenchida. Por segurança, insira a senha que você criou." })
if (senha !== senhaofc) return res.json({ message: "[❗] senha inválida ou inexistente ❌" })
try {
let keyEntry = await Apikey.findOne({ apikey })
if (keyEntry) {
console.log(keyEntry)
if (requests < 15000) {
keyEntry.request += Number(requests)
keyEntry.consulta = 0
} else {
keyEntry.request += Number(requests)
keyEntry.consulta += Number(requests)
}
await keyEntry.save()
const responseMessage = {
message: `✔️ ${requests} requests foram adicionados à apikey ${apikey} com sucesso.`
}
if (requests >= 15000) {
responseMessage.consultas = keyEntry.consulta
}
return res.json(responseMessage)
} else {
keyEntry = new Apikey({
apikey,
request: requests,
consulta: (requests < 15000) ? 0 : requests
})
await keyEntry.save()
const responseMessage = {
message: `✔️ _Apikey registrada com sucesso ↴_
🔑 Key: ${apikey}
💾 Requests: ${requests}`
}
if (requests >= 15000) {
responseMessage.consultas = keyEntry.consulta
}
return res.json(responseMessage)
}
} catch (err) {
console.error(err)
return res.json({ message: "Erro ao acessar o banco de dados." })
}
})

app.get('/tinder/login',(req, res) => {
var { usu, rg, apikey } = req.query
if(!apikey) return res.json({message: "Faltando paramento apikey"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if(!usu) return res.json({message: "Faltando paramento usuário"})
if(!JSON.stringify(tinder).includes(usu)) {
tinder.push({id: usu, nome: 0, idade: 0, gene: 0, sexualidade: 0, filtro: 0, bio: 0, foto: 0, dataRG: 0, horaRG: 0})
fs.writeFileSync("./database/tinder.json", JSON.stringify(tinder, null, 2))
}
AB = tinder.map(i => i.id).indexOf(usu)
if(tinder[AB].nome != 0 && tinder[AB].idade != 0 && tinder[AB].gene != 0 && tinder[AB].filtro != 0 && tinder[AB].bio != 0 && tinder[AB].foto != 0) return res.json({message: "Você já está registrado... Use #p#tinder"})
if(!rg) {
if(tinder[AB].nome == 0) return res.json({semft: false, message: "Retorne após o comando o seu nome para o registro"})
if(tinder[AB].idade == 0) return res.json({semft: false, message: "Retorne após o comando a sua idade para o registro"})
if(tinder[AB].gene == 0) return res.json({semft: false, message: "Retorne após o comando o seu gênero para o registro"})
if(tinder[AB].sexualidade == 0) return res.json({semft: false, message: "Retorne após o comando a sua sexualidade para o registro"})
if(tinder[AB].filtro == 0) return res.json({semft: false, message: "Retorne após o comando o filtro de pesquisa para o registro"})
if(tinder[AB].bio == 0) return res.json({semft: false, message: "Retorne após o comando a sua bio para o registro"})
if(tinder[AB].foto == 0) return res.json({semft: true, message: "Marque uma foto para completar seu registro"})
}
if(!apikey) return res.json({message: "Faltando paramento apikey"})
if(tinder[AB].nome == 0) {
tinder[AB].nome = rg
fs.writeFileSync("./database/tinder.json", JSON.stringify(tinder, null, 2))
return res.json({semft: false, message: "Nome registrado com sucesso... Use o comando novamente, mas dessa vez, coloque a sua idade, ex:\n#pc# 18"})
}
if(tinder[AB].idade == 0) {
if(!Number(rg)) return res.json({message: "Sua idade só pode conter números"})
if(Number(rg) < 12) return res.json({message: "Precisa ter no mínimo 12 anos para usar o tinder..."})
if(Number(rg) > 50) return res.json({message: "Usuários com mais de 50 anos não serão aceitos..."})
if(rg.includes(".")) return res.json({message: "Tua idade tem número decimal é? Kkkk"})
tinder[AB].idade = rg
fs.writeFileSync("./database/tinder.json", JSON.stringify(tinder, null, 2))
return res.json({semft: false, message: "Idade registrada com sucesso... Use o comando novamente, mas dessa vez, coloque seu gênero para o perfil, ex:\n#pc# \"masculino\" ou \"feminino\" ou \"não declarar\" (sem as aspas)"})
}
if(tinder[AB].gene == 0) {
if(rg.toLowerCase() != "masculino" && rg.toLowerCase() != "feminino" && rg.toLowerCase().replace("ã", "a") != "nao declarar") return res.json({semft: false, message: "Gênero inválido... Use apenas \"masculino\" ou \"feminino\" ou \"não declarar\" (sem as aspas)"})
tinder[AB].gene = rg
fs.writeFileSync("./database/tinder.json", JSON.stringify(tinder, null, 2))
return res.json({semft: false, message: "Gênero registrado com sucesso... Use o comando novamente, mas dessa vez, coloque a sua sexualidade, ou seja, como você se identifica"})
}
if(tinder[AB].sexualidade == 0) {
tinder[AB].sexualidade = rg
fs.writeFileSync("./database/tinder.json", JSON.stringify(tinder, null, 2))
return res.json({semft: false, message: "Sexualidade registrada com sucesso... Use o comando novamente, mas dessa vez, coloque um filtro para busca, usando 1 para homens, 2 para mulheres e 3 para todos, ex:\n#pc# 3"})
}
if(tinder[AB].filtro == 0) {
if(Number(rg) < 1 && Number(rg) > 3) return res.json({semft: false, message: "Registro de busca inválido... Use 1 para homens, 2 para mulheres e 3 para todos, ex:\n#pc# 3"})
tinder[AB].filtro = Number(rg)
fs.writeFileSync("./database/tinder.json", JSON.stringify(tinder, null, 2))
return res.json({semft: false, message: "Filtro registrado com sucesso... Use o comando novamente, mas dessa vez, coloque uma bio pro seu perfil, ex:\n#pc# apenas vivendo"})
}
if(tinder[AB].bio == 0) {
tinder[AB].bio = rg
fs.writeFileSync("./database/tinder.json", JSON.stringify(tinder, null, 2))
return res.json({semft: false, message: "Bio registrada com sucesso... Por último, marque uma imagem com o comando #pc# para ser sua foto de perfil"})
}
if(tinder[AB].foto == 0) {
sla = `${moment.tz('America/Sao_Paulo').format('HH')} hora${Number(moment.tz('America/Sao_Paulo').format('HH')) !== 1 ? "s" : ""}, ${moment.tz('America/Sao_Paulo').format('mm')} minuto${Number(moment.tz('America/Sao_Paulo').format('mm')) !== 1 ? "s" : ""} e ${moment.tz('America/Sao_Paulo').format('ss')} segundo${Number(moment.tz('America/Sao_Paulo').format('ss')) !== 1 ? "s" : ""}`
tinder[AB].foto = rg
tinder[AB].dataRG = moment.tz('America/Sao_Paulo').format('DD/MM/20YY')
tinder[AB].horaRG = sla
fs.writeFileSync("./database/tinder.json", JSON.stringify(tinder, null, 2))
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
return res.json({message: `Registro finalizado com sucesso... Bem vind${tinder[AB].gene == "masculino" ? 'o' : tinder[AB].gene == "feminino" ? 'a' : 'x'} ao tinder ${tinder[AB].nome} ❤️‍🔥

Use #p#tinder para acessar os usuários e #p#sairtinder caso queira meter o pé`})
}
})

app.get('/tinder/find', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
usu = req.query.usu
if(tinder.length <= 0) return res.json({message: "Nenhum usuário registrado..."})
if(!usu) return res.json({message: "Faltando o parâmetro usuário"})
apikey = req.query.apikey
if(!apikey) return res.json({message: "Faltando o parâmetro apikey"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
AB = tinder.map(i => i.id).indexOf(usu)
if(!JSON.stringify(tinder).includes(usu)) return res.json({message: "Você não está registrado no tinder... Use #p#rgtinder para começar 😉"})
if(tinder[AB].nome == 0 || tinder[AB].idade == 0 || tinder[AB].gene == 0 || tinder[AB].sexualidade == 0 || tinder[AB].filtro == 0 || tinder[AB].bio == 0 || tinder[AB].foto == 0) return res.json({nome: tinder[AB].nome, idade: tinder[AB].idade, gene: tinder[AB].gene, sexualidade: tinder[AB].sexualidade, filtro: tinder[AB].filtro, bio: tinder[AB].bio, nmr: tinder[AB].id.split('@')[0], foto: tinder[AB].foto, message: "Algum campo do registro não foi preenchido... Use o comando #p#rgtinder para saber o que falta!"})
caixa = []
for(i = 0; i < tinder.length; i++) {
//filtro de busca por homens
if(tinder[AB].filtro == 1 && tinder[i].gene == "masculino" && tinder[i].sexualidade != 0 && tinder[i].filtro != 0 && tinder[AB].bio != 0 && tinder[i].foto != 0) caixa.push({nome: tinder[i].nome, idade: tinder[i].idade, gene: tinder[i].gene, sexualidade: tinder[i].sexualidade, filtro: tinder[i].filtro, bio: tinder[i].bio, nmr: tinder[i].id.split('@')[0], foto: tinder[i].foto})
//filtro de busca por mulheres
if(tinder[AB].filtro == 2 && tinder[i].gene == "feminino" && tinder[i].sexualidade != 0 && tinder[i].filtro != 0 && tinder[AB].bio != 0 && tinder[i].foto != 0) caixa.push({nome: tinder[i].nome, idade: tinder[i].idade, gene: tinder[i].gene, sexualidade: tinder[i].sexualidade, filtro: tinder[i].filtro, bio: tinder[i].bio, nmr: tinder[i].id.split('@')[0], foto: tinder[i].foto})
//filtro de busca sem preferência
if(tinder[AB].filtro == 3 && tinder[i].nome != 0 && tinder[i].idade != 0 && tinder[i].gene != 0 && tinder[i].sexualidade != 0 && tinder[i].filtro != 0 && tinder[i].bio != 0 && tinder[i].foto != 0) caixa.push({nome: tinder[i].nome, idade: tinder[i].idade, gene: tinder[i].gene, sexualidade: tinder[i].sexualidade, filtro: tinder[i].filtro, bio: tinder[i].bio, nmr: tinder[i].id.split('@')[0], foto: tinder[i].foto})
}
if(caixa.length <= 0) return res.json({message: "Nenhum usuário foi encontrado com esse filtro de pesquisa... Podes trocar o filtro no comando #p#setfiltro"})
BC = Math.floor(Math.random()*caixa.length)
res.json({criador: `${criador}`, dados: [{id: BC+1, total: caixa.length, nome: caixa[BC].nome, idade: caixa[BC].idade, gene: caixa[BC].gene, sexualidade: caixa[BC].sexualidade, bio: caixa[BC].bio, nmr: caixa[BC].nmr, foto: caixa[BC].foto}]})
})

app.get('/tinder/config', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { usu, mod, q, apikey } = req.query
if(!usu) return res.json({message: "Faltando o parâmetro usuário"})
if(!mod) return res.json({message: "Faltando o parâmetro mod"})
if(!q) {
if(mod == "tindernome") return res.json({message: "Retorne após o comando o novo nome para atualizar o perfil"})
if(mod == "tinderidade") return res.json({message: "Retorne após o comando a nova idade para atualizar o perfil"})
if(mod == "tinderbio") return res.json({message: "Retorne após o comando a nova bio para atualizar o perfil"})
if(mod == "tinderfoto") return res.json({message: "Marque com o comando uma foto para atualizar seu perfil"})
if(mod == "setgene") return res.json({message: "Retorne após o comando o seu gênero para atualizar o perfil... Use \"masculino\", \"feminino\" ou \"não declarar\""})
if(mod == "setsex") return res.json({message: "Retorne após o comando a sua sexualidade para atualizar o perfil..."})
if(mod == "setfiltro") return res.json({message: "Retorne após o comando o número correspondente ao filtro de pesquisa do seu tinder... 1 para homens, 2 para mulheres e 3 para todos"})
}
if(!apikey) return res.json({message: "Faltando o parâmetro apikey"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if(!JSON.stringify(tinder).includes(usu)) return res.json({message: "Você não está registrado no tinder... Use #pc#rgtinder para começar 😉"})
AB = tinder.map(i => i.id).indexOf(usu)
if(tinder[AB].nome == 0 || tinder[AB].idade == 0 || tinder[AB].gene == 0 || tinder[AB].sexualidade == 0 || tinder[AB].filtro == 0 || tinder[AB].bio == 0 || tinder[AB].foto == 0) return res.json({nome: tinder[AB].nome, idade: tinder[AB].idade, gene: tinder[AB].gene, sexualidade: tinder[AB].sexualidade, filtro: tinder[AB].filtro, bio: tinder[AB].bio, nmr: tinder[AB].id.split('@')[0], foto: tinder[AB].foto, message: "Algum campo do registro não foi preenchido... Use o comando #p#rgtinder para saber o que falta!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(mod == "tindernome") {
tinder[AB].nome = q
fs.writeFileSync("./database/tinder.json", JSON.stringify(tinder, null, 2))
return res.json({message: "Nome atualizado com sucesso ✅"})
}
if(mod == "tinderidade") {
if(!Number(q)) return res.json({message: "Sua idade só pode conter números"})
if(Number(q) < 12) return res.json({message: "Precisa ter no mínimo 12 anos para usar o tinder..."})
if(Number(q) > 70) return res.json({message: "Usuários com mais de 70 anos não serão aceitos..."})
if(q.includes(".")) return res.json({message: "Tua idade tem número decimal é? Kkkk"})
tinder[AB].idade = q
fs.writeFileSync("./database/tinder.json", JSON.stringify(tinder, null, 2))
return res.json({semft: false, message: "Idade atualizada com sucesso ✅"})
}
if(mod == "setgene") {
if(q.toLowerCase() != "masculino" && q.toLowerCase() != "feminino" && q.toLowerCase().replace("ã", "a") != "nao declarar") return res.json({message: "Gênero inválido... Use apenas \"masculino\" ou \"feminino\" ou \"não declarar\" (sem as aspas)"})
tinder[AB].gene = q
fs.writeFileSync("./database/tinder.json", JSON.stringify(tinder, null, 2))
return res.json({message: "Gênero atualizado com sucesso ✅"})
}
if(mod == "setsex") {
tinder[AB].sexualidade = q
fs.writeFileSync("./database/tinder.json", JSON.stringify(tinder, null, 2))
return res.json({message: "Gênero atualizado com sucesso ✅"})
}
if(mod == "setfiltro") {
if(Number(q) < 1 && Number(q) > 3) return res.json({semft: false, message: "Registro de busca inválido... Use 1 para homens, 2 para mulheres e 3 para todos, ex:\n#pc# 3"})
tinder[AB].filtro = Number(q)
fs.writeFileSync("./database/tinder.json", JSON.stringify(tinder, null, 2))
return res.json({message: `Filtro de pesquisa atualizado com sucesso... Agora buscarei ${Number(q) === 3 ? `por todos os usuários 😉` : `apenas por ${Number(q) === 1 ? "homens 🫢" : "mulheres 😏"}`}`})
}
if(mod == "tinderbio") {
tinder[AB].bio = q
fs.writeFileSync("./database/tinder.json", JSON.stringify(tinder, null, 2))
return res.json({message: "Bio atualizada com sucesso ✅"})
}
if(mod == "tinderfoto") {
tinder[AB].foto = q
fs.writeFileSync("./database/tinder.json", JSON.stringify(tinder, null, 2))
return res.json({message: "Foto de perfil atualizada com sucesso ✅"})
}
})

app.get('/tinder/perfil', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { usu, apikey } = req.query
if(!usu) return res.json({message: "Faltando o parâmetro usuário"})
if(!apikey) return res.json({message: "Faltando o parâmetro apikey"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if(!JSON.stringify(tinder).includes(usu)) return res.json({message: "ID do usuário não encontrado ou inexistente..."})
AB = tinder.map(i => i.id).indexOf(usu)
if(tinder[AB].nome == 0 || tinder[AB].idade == 0 || tinder[AB].gene == 0 || tinder[AB].sexualidade == 0 || tinder[AB].filtro == 0 || tinder[AB].bio == 0 || tinder[AB].foto == 0) return res.json({nome: tinder[AB].nome, idade: tinder[AB].idade, gene: tinder[AB].gene, sexualidade: tinder[AB].sexualidade, filtro: tinder[AB].filtro, bio: tinder[AB].bio, nmr: tinder[AB].id.split('@')[0], foto: tinder[AB].foto, message: "Algum campo do registro não foi preenchido... Use o comando #p#rgtinder para saber o que falta!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
return res.json({criador: `${criador}`, dados: [{nome: tinder[AB].nome, idade: tinder[AB].idade, gene: tinder[AB].gene, sexualidade: tinder[AB].sexualidade, filtro: tinder[AB].filtro, bio: tinder[AB].bio, nmr: tinder[AB].id.split('@')[0], foto: tinder[AB].foto, registro: [tinder[AB].dataRG, tinder[AB].horaRG]}]})
})

app.get('/tinder/delete', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { usu, apikey } = req.query
if(!usu) return res.json({message: "Faltando o parâmetro usuário"})
if(!apikey) return res.json({message: "Faltando o parâmetro apikey"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if(!JSON.stringify(tinder).includes(usu)) return res.json({message: "ID do usuário não encontrado ou inexistente..."})
AB = tinder.map(i => i.id).indexOf(usu)
tinder.splice(AB, 1)
fs.writeFileSync("./database/tinder.json", JSON.stringify(tinder, null, 2))
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
return res.json({message: "Seu registro foi deletado com sucesso.. Volte sempre 😉"})
})



app.get('/api/canvas/ship', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { foto1, foto2, fundo, mat } = req.query
if(!foto1) return res.json({message: "Faltando o parâmetro foto 1"})
if(!foto2) return res.json({message: "Faltando o parâmetro foto 2"})
if(!mat) return res.json({message: "Faltando o parâmetro mat"})
if(!fundo) return res.json({message: "Faltando o parâmetro fundo"})
let shiplv = await new Canvasfy.Ship()
.setAvatars(foto1, foto2)
.setBackground("image", fundo)
.setBorder("#f0f0f0")
.setOverlayOpacity(0.2)
.setCustomNumber(Number(mat))
.build()
require('fs').writeFileSync(bla + '/assets/Tempo/welkom.png', shiplv, 'base64')
res.sendFile(bla + '/assets/Tempo/welkom.png')
})

app.get('/api/canvas/welcome', async (req, res) => {
  const userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress;
  const { titulo, perfil, fundo, desc } = req.query;

  if (!titulo) return res.status(400).json({ error: 'Parâmetro "titulo" é obrigatório' });
  if (!perfil) return res.status(400).json({ error: 'Parâmetro "perfil" é obrigatório' });
  if (!fundo) return res.status(400).json({ error: 'Parâmetro "fundo" é obrigatório' });
  if (!desc) return res.status(400).json({ error: 'Parâmetro "desc" é obrigatório' });

  const [avatarBuffer, bgBuffer] = await Promise.all([
    downloadImage(perfil),
    downloadImage(fundo)
  ]);

  if (!avatarBuffer) return res.status(400).json({ error: 'URL do avatar inválida ou inacessível' });
  if (!bgBuffer) return res.status(400).json({ error: 'URL do fundo inválida ou inacessível' });

  try {
    const welcome = await new Canvasfy.WelcomeLeave()
      .setAvatar(avatarBuffer)
      .setBackground("image", bgBuffer)
      .setTitle(titulo)
      .setDescription(desc)
      .setBorder("#2a2e35")
      .setAvatarBorder("#2a2e35")
      .setOverlayOpacity(0.6)
      .build();

    const filepath = saveTempImage(welcome, 'welcome');
    res.sendFile(filepath, () => cleanupFile(filepath));
  } catch (err) {
    console.error("Erro ao gerar welcome:", err);
    res.status(500).json({ error: 'Falha ao gerar imagem', details: err.message });
  }
});

app.get('/api/canvas/top', async (req, res) => {
  const userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress;
  const { message, fundo, ...rest } = req.query;

  if (!fundo) return res.status(400).json({ error: 'Parâmetro "fundo" é obrigatório' });

  const bgBuffer = await downloadImage(fundo);
  if (!bgBuffer) return res.status(400).json({ error: 'URL do fundo inválida' });

  const database = [];
  for (let i = 1; i <= 10; i++) {
    const foto = rest[`foto${i}`];
    const nome = rest[`nome${i}`];
    const xp = rest[`xp${i}`];

    if (foto && nome && xp) {
      const avatarBuffer = await downloadImage(foto);
      if (avatarBuffer) {
        database.push({
          top: i,
          avatar: avatarBuffer,
          tag: nome,
          score: Number(xp) || 0
        });
      }
    }
  }

  if (database.length === 0) {
    return res.status(400).json({ error: 'Nenhum usuário válido fornecido' });
  }

  try {
    const top10 = await new Canvasfy.Top()
      .setOpacity(0.6)
      .setScoreMessage(message || "XP")
      .setabbreviateNumber(true)
      .setBackground("image", bgBuffer)
      .setColors({
        box: "#212121",
        username: "#ffffff",
        score: "#ffffff",
        firstRank: "#f7c716",
        secondRank: "#9e9e9e",
        thirdRank: "#94610f"
      })
      .setUsersData(database)
      .build();

    const filepath = saveTempImage(top10, 'top');
    res.sendFile(filepath, () => cleanupFile(filepath));
  } catch (err) {
    console.error("Erro ao gerar top:", err);
    res.status(500).json({ error: 'Falha ao gerar ranking', details: err.message });
  }
});


app.get('/api/canvas/level', async (req, res) => {
  const { foto, nome, expnow, expall, level, fundo } = req.query;

  if (!foto || !nome || !expnow || !expall || !level || !fundo)
    return res.status(400).json({ error: 'Todos os parâmetros são obrigatórios' });

  const [avatarBuffer, bgBuffer] = await Promise.all([
    downloadImage(foto),
    downloadImage(fundo)
  ]);

  if (!avatarBuffer || !bgBuffer)
    return res.status(400).json({ error: 'URL de avatar ou fundo inválida' });

  try {
    const rank = await new Canvasfy.Rank()
      .setAvatar(avatarBuffer)
      .setBackground("image", bgBuffer)
      .setUsername(nome)
      .setBorder("#fff")
      .setBarColor("#00ffff")
      .setStatus("online")
      .setLevel(Number(level))
      .setLevelColor({ text: "#00ffff", number: "#fff" })
      .setRank(Number(expnow), "XP")
      .setRankColor({ text: "#00ffff", number: "#fff" })
      .setCurrentXp(Number(expnow))
      .setRequiredXp(Number(expall))
      .build();

    const filepath = saveTempImage(rank, 'level');
    res.sendFile(filepath, () => cleanupFile(filepath));
  } catch (err) {
    res.status(500).json({ error: 'Erro ao gerar level', details: err.message });
  }
});

app.get('/api/canvas/levelup', async (req, res) => {
  const { foto, nome, lvb, lva, fundo } = req.query;
  if (!foto || !nome || !lvb || !lva || !fundo)
    return res.status(400).json({ error: 'Todos os parâmetros são obrigatórios' });

  const [avatarBuffer, bgBuffer] = await Promise.all([
    downloadImage(foto),
    downloadImage(fundo)
  ]);

  if (!avatarBuffer || !bgBuffer)
    return res.status(400).json({ error: 'URL inválida' });

  try {
    const lvup = await new Canvasfy.LevelUp()
      .setAvatar(avatarBuffer)
      .setBackground("image",bgBuffer)
      .setUsername(nome)
      .setBorder("#000000")
      .setAvatarBorder("#00ffff")
      .setOverlayOpacity(0.7)
      .setLevels(Number(lvb), Number(lva))
      .build();

    const filepath = saveTempImage(lvup, 'levelup');
    res.sendFile(filepath, () => cleanupFile(filepath));
  } catch (err) {
    res.status(500).json({ error: 'Erro ao gerar levelup', details: err.message });
  }
});

app.get('/api/canvas/levelup2', async (req, res) => {
  const { foto, nome, lvb, lva, fundo } = req.query;
  if (!foto || !nome || !lvb || !lva || !fundo)
    return res.status(400).json({ error: 'Todos os parâmetros são obrigatórios' });

  const [avatarBuffer, bgBuffer] = await Promise.all([
    downloadImage(foto),
    downloadImage(fundo)
  ]);

  if (!avatarBuffer || !bgBuffer)
    return res.status(400).json({ error: 'URL inválida' });

  try {
    const lvup = await new Canvasfy.LevelUp()
      .setAvatar(avatarBuffer)
      .setBackground("image", bgBuffer)
      .setUsername(nome)
      .setBorder("#000000")
      .setAvatarBorder("#ff0000")
      .setOverlayOpacity(0.7)
      .setLevels(Number(lvb), Number(lva))
      .build();

    const filepath = saveTempImage(lvup, 'levelup2');
    res.sendFile(filepath, () => cleanupFile(filepath));
  } catch (err) {
    res.status(500).json({ error: 'Erro ao gerar levelup2', details: err.message });
  }
});

app.get('/welcome', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
if (!req.query.titulo) return res.json({ status: 404, error: 'Insira o parametro: titulo'})
if (!req.query.nome) return res.json({ status: 404, error: 'Insira o parametro: nome'})
if (!req.query.perfil) return res.json({ status: 404, error: 'Insira o parametro: perfil'})
if (!req.query.fundo) return res.json({ status: 404, error: 'Insira o parametro: fundo'})
if (!req.query.grupo) return res.json({ status: 404, error: 'Insira o parametro: grupo'})
let welcomer = await new canvasx.Welcome()
.setUsername(req.query.nome)
.setDiscriminator("2025")
.setText("title", req.query.titulo)
.setText("message", req.query.grupo)
.setAvatar(req.query.perfil)
.setColor('border', '#00100C')
.setColor('username-box', '#00100C')
.setColor('discriminator-box', '#00100C')
.setColor('message-box', '#00100C')
.setColor('title', '#00FFFF')
.setBackground(req.query.fundo)
.toAttachment()
let base64 = `${welcomer.toBuffer().toString('base64')}`
require('fs').writeFileSync(bla+'/assets/welkom.png', base64, 'base64')
res.sendFile(bla+'/assets/welkom.png')
})

app.get('/api/canvas/jxr/welcome', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { nome, guilda, perfil, membro, avatar, fundo } = req.query
if(!nome) return res.json({resultado: "Faltando o parâmetro nome"})
if(!guilda) return res.json({resultado: "Faltando o parâmetro guilda"})
if(!perfil) return res.json({resultado: "Faltando o parâmetro perfil"})
if(!membro) return res.json({resultado: "Faltando o parâmetro membro"})
if(!avatar) return res.json({resultado: "Faltando o parâmetro avatar"})
if(!fundo) return res.json({resultado: "Faltando o parâmetro fundo"})
let imagejxr = await new JXR.Welcome()
.setUsername(nome)
.setGuildName(guilda)
.setGuildIcon(perfil)
.setMemberCount(`${membro}`)
.setAvatar(avatar)
.setBackground(fundo)
.toAttachment()
let datajxr = `${imagejxr.toBuffer().toString('base64')}`
require('fs').writeFileSync(bla+'/assets/welkom.png', datajxr, 'base64')
res.sendFile(bla+'/assets/welkom.png')
})




app.get('/api/canvas/musicardbun/music', async (req, res) => {
    const { nome, autor, opacity, thumb, progresso, start, end } = req.query;

    // Validação básica
    if (!nome || !autor || !thumb || !progresso || !start || !end) {
        return res.status(400).json({ error: 'Parâmetros insuficientes.' });
    }

    try {
        // Chama o motor de desenho
        const buffer = await generateMusicCardV2({
            nome,
            autor,
            thumb,
            progresso,
            start,
            end,
            opacity: opacity ? Number(opacity) : 85
        });

        // Envia a imagem
        res.set('Content-Type', 'image/png');
        res.send(buffer);

    } catch (err) {
        console.error('[API] Erro ao gerar Music Card:', err);
        res.status(500).json({ error: 'Erro interno ao gerar imagem.' });
    }
});


// === ENDPOINT MUSICARD ===
app.get('/api/canvas/musicardbun/music2', async (req, res) => {
  const userIp = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  const { nome, autor, tipo, opacity, thumb, progresso, start, end } = req.query;

  // --- Validação ---
  if (!nome)  return res.status(400).json({ error: 'Parâmetro "nome" obrigatório' });
  if (!autor) return res.status(400).json({ error: 'Parâmetro "autor" obrigatório' });
  if (!thumb) return res.status(400).json({ error: 'Parâmetro "thumb" obrigatório' });
  if (!progresso) return res.status(400).json({ error: 'Parâmetro "progresso" obrigatório' });
  if (!start) return res.status(400).json({ error: 'Parâmetro "start" obrigatório' });
  if (!end)   return res.status(400).json({ error: 'Parâmetro "end" obrigatório' });

  const opacityNum = opacity ? Math.max(0, Math.min(100, Number(opacity))) : 50;
  const progressNum = Math.max(0, Math.min(100, Number(progresso)));

  // --- Download da thumbnail ---
  const thumbBuffer = await downloadImage(thumb);
  if (!thumbBuffer) {
    return res.status(400).json({ error: 'Thumbnail inválida ou bloqueada (429 / CORS)' });
  }

  // --- Construção do card ---
  let cardBuffer;
  try {
    const card = new musicCard()
      .setName(nome)
      .setAuthor(autor)
      .setColor('auto')
      .setTheme(tipo === 'space2' ? 'space+' : (tipo || 'classic'))
      .setBrightness(opacityNum)
      .setThumbnail(thumbBuffer)        // <--- Buffer, não URL
      .setProgress(progressNum)
      .setStartTime(start)
      .setEndTime(end);

    cardBuffer = await card.build();
  } catch (err) {
    console.error('[MusicCard] Erro ao gerar card:', err);
    return res.status(500).json({ error: 'Falha ao gerar imagem', details: err.message });
  }

  // --- Salvar e enviar ---
  const filepath = saveTempBuffer(cardBuffer, 'musicard');
  res.sendFile(filepath, { maxAge: 0 }, (err) => {
    cleanup(filepath);
    if (err) console.error('Erro ao enviar arquivo:', err);
  });
});


app.get('/api/canvas/musicardbun/level', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { nome, level, brightness, perfil, rank, xpb, xpa, progresso } = req.query
const cardlvmb = new RankCard()
.setName(nome)
.setLevel(level)
.setColor("auto")
.setBrightness(Number(brightness))
.setAvatar(perfil)
.setProgress(Number(progresso))
.setRank(rank)
.setCurrentXp(xpb)
.setRequiredXp(xpa)
.setShowXp(true)
require('fs').writeFileSync(bla + '/assets/Tempo/welkom.png', (await cardlvmb.build()), 'base64')
return res.sendFile(bla + '/assets/Tempo/welkom.png')
})

app.get('/api/canvas/canvacard/rank', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { nome, level, stts, perfil, rank, xpb, xpa, fundo } = req.query
const rankcc = new canvacard.Rank()
.setAvatar(perfil)
.setBackground('IMAGE', fundo)
.setCurrentXP(Number(xpb), "#00BFFF")
.setRequiredXP(Number(xpa), "#00BFFF")
.setRank(Number(rank))
.setRankColor("#FFFFFF", "#00BFFF")
.setLevel(Number(level), `LEVEL `)
.setLevelColor("#FFFFFF", "#00BFFF")
.setStatus(stts, true)
.setOverlay("#23272A", 0.75, true)
.setProgressBar(["#1E90FF", "#00BFFF"], "GRADIENT")
.setProgressBarTrack("#000000")
.setUsername(nome)
.renderEmojis(true)
require('fs').writeFileSync(bla + '/assets/Tempo/welkom.png', (await rankcc.build()), 'base64')
return res.sendFile(bla + '/assets/Tempo/welkom.png')
})

app.get('/api/canvas/welcomify/welcome', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { title, nome, hex, perfil, message, fundo } = req.query
const welcomifycard = new Card()
.setTitle(title)
.setName(nome)
.setAvatar(perfil)
.setMessage(message)
.setBackground(fundo)
.setColor(hex)
require('fs').writeFileSync(bla + '/assets/Tempo/welkom.png', (await welcomifycard.build()), 'base64')
return res.sendFile(bla + '/assets/Tempo/welkom.png')
})






// ======================
// ROTA COMPLETA
// ======================
app.post("/api/carteiradetrabalho", async (req, res) => {
    try {
        const axios = require("axios");
        const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");

        // ======================
        // Checar imagem enviada
        // ======================
        if (!req.files || !req.files.img)
            return res.json({ status: false, message: "Envie uma imagem (campo: img)" });

        const imageBuffer = req.files.img.data;

        // ======================
        // Valores do "RG fictício"
        // ======================
        const v = {
            nome: req.body.nome,
            sexo: req.body.sexo,
            nascimento: req.body.nascimento,
            cpf: req.body.cpf,
            mae: req.body.mae,
            pai: req.body.pai,
            naturalidade: req.body.naturalidade,
            emissao: req.body.emissao,
            orgao: req.body.orgao,
            numero: req.body.numero
        };

        // ======================
        // Fonte fictícia
        // ======================
        async function setupFonts() {
            const f1 = await axios.get('https://api.nekolabs.web.id/f/arrial.ttf', { responseType: 'arraybuffer' });
            const f2 = await axios.get('https://api.nekolabs.web.id/f/sign.otf', { responseType: 'arraybuffer' });

            GlobalFonts.register(Buffer.from(f1.data), 'BRCard');
            GlobalFonts.register(Buffer.from(f2.data), 'BRSign');
        }

        // ======================
        // Função geradora (tudo na rota)
        // ======================
        async function generateBR(v, img) {
            await setupFonts();

            // tamanho fictício
            const canvas = createCanvas(900, 550);
            const ctx = canvas.getContext("2d");

            // fundo fictício
            ctx.fillStyle = "#e0f2e9";
            ctx.fillRect(0, 0, 900, 550);

            // bordas
            ctx.strokeStyle = "#0a623a";
            ctx.lineWidth = 8;
            ctx.strokeRect(10, 10, 880, 530);

            // brasão fictício
            ctx.fillStyle = "#0a623a";
            ctx.font = "32px BRCard";
            ctx.fillText("REPÚBLICA FEDERATIVA DO BRASIL", 50, 50);
            ctx.font = "22px BRCard";
            ctx.fillText("DOCUMENTO DE IDENTIFICAÇÃO FICTÍCIO", 50, 80);

            const photo = await loadImage(img);

            // ======================
            // FOTO
            // ======================
            const PX = 620, PY = 120, PW = 220, PH = 300;

            ctx.drawImage(photo, PX, PY, PW, PH);

            // ======================
            // Função texto
            // ======================
            const T = (text, x, y, size = 24) => {
                ctx.font = `${size}px BRCard`;
                ctx.fillStyle = "#000";
                ctx.textAlign = "left";
                ctx.fillText(text, x, y);
            };

            // ======================
            // Campos
            // ======================
            T("NOME:", 50, 150);
            T(v.nome || "-", 200, 150);

            T("SEXO:", 50, 190);
            T(v.sexo || "-", 200, 190);

            T("DATA DE NASCIMENTO:", 50, 230);
            T(v.nascimento || "-", 350, 230);

            T("CPF:", 50, 270);
            T(v.cpf || "-", 200, 270);

            T("NOME DA MÃE:", 50, 310);
            T(v.mae || "-", 300, 310);

            T("NOME DO PAI:", 50, 350);
            T(v.pai || "-", 300, 350);

            T("NATURALIDADE:", 50, 390);
            T(v.naturalidade || "-", 300, 390);

            T("DATA DE EMISSÃO:", 50, 430);
            T(v.emissao || "-", 300, 430);

            T("ÓRGÃO EMISSOR:", 50, 470);
            T(v.orgao || "-", 300, 470);

            T("Nº DOCUMENTO:", 50, 510);
            T(v.numero || "-", 300, 510);

            // assinatura fictícia
            ctx.font = "42px BRSign";
            ctx.textAlign = "center";
            ctx.fillText(v.nome?.split(" ")[0] || "Assinatura", 730, 450);

            return canvas.toBuffer("image/png");
        }

        // ======================
        // Gerar imagem final
        // ======================
        const imgFinal = await generateBR(v, imageBuffer);

        // ======================
        // Enviar PNG
        // ======================
        res.set("Content-Type", "image/png");
        return res.send(imgFinal);

    } catch (e) {
        res.json({ status: false, error: e.message });
    }
});

app.get('/api/canvas/wppphoto', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { nick, number, bio, ultimovisto, foto } = req.query
ABC = await fetchJson(`https://tohka.tech/api/canvas/perfilzap?nome=${nick}&numero=${number}&bio=${bio}&horas=${ultimovisto}&perfil=${foto}&apikey=matheuzinho2006`)
require('fs').writeFileSync(bla + '/assets/Tempo/welkom.png', ABC, 'base64')
return res.sendFile(bla + '/assets/Tempo/welkom.png')
})

app.get('/api/pingcanvas', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, title, nome, hex, hex2, perfil, message, fundo } = req.query
if (!apikey) return res.json({status: false, message: '- Cadê o parâmetro apikey?'})
if (!title) return res.json({status: false, message: '- Cadê o parâmetro title?'})
if (!nome) return res.json({status: false, message: '- Cadê o parâmetro nome?'})
if (!hex) return res.json({status: false, message: '- Cadê o parâmetro hex?'})
if (!hex2) return res.json({status: false, message: '- Cadê o parâmetro hex2?'})
if (!perfil) return res.json({status: false, message: '- Cadê o parâmetro perfil?'})
if (!message) return res.json({status: false, message: '- Cadê o parâmetro message?'})
if (!fundo) return res.json({status: false, message: '- Cadê o parâmetro fundo?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const buffer = await generatePingCanvas(title, nome, hex, hex2, perfil, message, fundo)
res.set({
'Content-Type': 'image/png',
'Cache-Control': 'no-cache',
'Content-Length': buffer.length
})
res.send(buffer)
} catch (error) {
console.error('Erro ao gerar canvas:', error)
res.status(500).json({ status: false, message: 'Erro ao gerar canvas', error: error.message })
}
})

app.get('/api/duelo', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { user1, user2, avatar1, avatar2 } = req.query
if (!user1 && !user2) {
return res.status(400).send('É necessário pelo menos um nome de jogador')
}
const duelData = createDuelData({ name: user1 || 'Player 1', avatar: avatar1 || `https://i.pravatar.cc/300?img=${Math.floor(Math.random() * 70) + 1}`}, { name: user2 || 'Player 2', avatar: avatar2 || `https://i.pravatar.cc/300?img=${Math.floor(Math.random() * 70) + 71}`})
try {
const canvas = createCanvas(1200, 675)
await drawDuelCanvas(duelData, canvas)
res.set('Content-Type', 'image/png')
res.set('Cache-Control', 'no-store, max-age=0')
const stream = canvas.createPNGStream({ compressionLevel: 6, filters: canvas.PNG_FILTER_NONE })
stream.pipe(res)
} catch (error) {
console.error('Error generating duel:', error)
res.status(500).send('Error generating duel image')
}
})

app.get('/imagem/qrcode', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { texto, apikey } = req.query
if(!texto || !apikey) return res.json({erro: "Link incompleto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
hasil = `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${texto}`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/gostosinha.jpg', data)
res.sendFile(bla+'/assets/gostosinha.jpg') 
} catch (error) {
return res.status(404).json({resultado: `Erro`, status: 500})
}
}) 

app.get('/imagem/leitor-qrcode', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { qrcode, apikey } = req.query
if(!qrcode || !apikey) return res.json({erro: "Link incompleto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
data = await fetchJson(`https://api.lolhuman.xyz/api/read-qr?apikey=1b0ebf01de8b0fbd59270f27&img=${qrcode}`)
res.json({
status: true,
criador: `${criador}`,
resultado: data.result
})
})

app.get('/api/eletronica.mp3', (req, res) => {
json = fs.readFileSync('./base de dados/audios/eletronica.mp3')
res.type('mp3')
res.send(json)
})

app.get('/loli', (req, res) => {
(async() => {
json = JSON.parse(fs.readFileSync('lib/lolis.json').toString())
random = json[Math.floor(Math.random() * json.length)]
res.type('jpg')
res.send(await getBuffer(random))
})()
})

app.get('/shota', (req, res) => {
(async() => {
json = JSON.parse(fs.readFileSync(bla+'/base de dados/shotas.json').toString())
random = json[Math.floor(Math.random() * json.length)]
res.type('jpg')
res.send(await getBuffer(random))
})()
})


app.get('/random/metadinha2', async (req, res) => {
  const userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
  const apikey = req.query.apikey

  if (!apikey) return res.json({ status: false, message: '- Cadê o parâmetro apikey?' })
  if (!key.some(i => i.apikey === apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))

  const ITC = key.findIndex(i => i.apikey === apikey)
  if (ITC === -1 || key[ITC]?.request <= 0) return res.json({ message: "Apikey inválida ou requests esgotados!" })

  RegisKey(apikey, userIp)

  console.log(
    color(` ApiKey: ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'),
    color('', 'red'),
    color('Request', 'red'),
    '• ' + color('Ping: ' + ping(), 'red')
  )

  try {
    const json = JSON.parse(fs.readFileSync(path.join(bla, 'database', 'metadinhas.json')).toString())
    const random = json[Math.floor(Math.random() * json.length)]
    res.json(random)
  } catch (error) {
    console.error('Erro ao processar a requisição:', error)
    res.status(500).json({ message: 'Erro interno ao processar a requisição.' })
  }
})



app.get('/random/metadinha', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
json = JSON.parse(fs.readFileSync(bla + '/base de dados/metadinha.json').toString())
random = json[Math.floor(Math.random() * json.length)]
res.json(random)
} catch (error) {
console.error('Erro ao processar a requisição:', error)
res.status(500).json({message: 'Erro interno ao processar a requisição.'})
}
})

app.get('/nsfw/nsfwloli', (req, res) => {
(async() => {
json = JSON.parse(fs.readFileSync('lib/nsfwlolis.json').toString())
random = json[Math.floor(Math.random() * json.length)]
res.type('jpg')
res.send(await getBuffer(random))
})()
})

app.post('/api/shazam', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.body.apikey
mediaFile = req.files?.media
console.log('↘️ Headers:', req.headers['content-type'])
console.log('🔑 Body:', apikey)
console.log('📁 File:', mediaFile ? 'Presente' : 'Undefined')
if (!apikey) return res.json({ status: false, message: '- Cadê o parâmetro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey))
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0)
return res.json({ message: "Apikey inválida ou requests esgotados!" })
if (!mediaFile) return res.json({ status: false, message: '- Cadê o arquivo de mídia?' })
RegisKey(apikey, userIp)
let ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
let uploadsDir
let audioDir
let tempFilePath
let mp3FilePath
let audioFilePath
try {
uploadsDir = path.join(__dirname, 'uploads')
audioDir = path.join(uploadsDir, 'audio');
[uploadsDir, audioDir].forEach(dir => {
if (!fs.existsSync(dir)) {
fs.mkdirSync(dir, { recursive: true })
console.log(`📁 Diretório criado: ${dir}`)
}
})
const extension = mediaFile.name.split('.').pop().toLowerCase() || 'bin'
const randomFileName = `file_${Date.now()}_${Math.floor(Math.random() * 10000)}`
tempFilePath = path.join(audioDir, `${randomFileName}.${extension}`)
if (extension === 'mp3') {
mp3FilePath = path.join(audioDir, `${randomFileName}_converted.mp3`)
} else {
mp3FilePath = path.join(audioDir, `${randomFileName}.mp3`)
}
await mediaFile.mv(tempFilePath)
console.log('✅ Arquivo salvo:', tempFilePath)
console.log('🔄 Convertendo para MP3...')
await new Promise((resolve, reject) => {
exec(`ffmpeg -i "${tempFilePath}" -vn -acodec libmp3lame -ar 44100 -y "${mp3FilePath}"`, 
(err, stdout, stderr) => {
if (err) {
console.error('❌ Erro FFmpeg:', stderr)
return reject(new Error('Falha na conversão de áudio'))
}
console.log('✅ Conversão concluída:', mp3FilePath)
resolve()
}
)
})
const mp3Base64 = fs.readFileSync(mp3FilePath, { encoding: 'base64' })
console.log('🟢 Processando com arcloud...')
const resultadoArcloud = await arcloud(mp3Base64)
if (!resultadoArcloud || !resultadoArcloud[0]) {
if (tempFilePath && fs.existsSync(tempFilePath)) fs.unlinkSync(tempFilePath)
if (mp3FilePath && fs.existsSync(mp3FilePath)) fs.unlinkSync(mp3FilePath)
return res.status(404).json({ error: 'Não foi possível identificar a música. Por favor, tente novamente.' })
}
const titulo = resultadoArcloud[0].titulo
console.log('✅ Título identificado:', titulo)
const fetchResult = await fetch(`${okarunsite}/api/ytsrc?q=${encodeURIComponent(titulo)}&apikey=${API_KEY_OKARUN}`)
const data = await fetchResult.json()
if (!data || !data.resultado || data.resultado.length === 0) {
if (tempFilePath && fs.existsSync(tempFilePath)) fs.unlinkSync(tempFilePath)
if (mp3FilePath && fs.existsSync(mp3FilePath)) fs.unlinkSync(mp3FilePath)
return res.status(404).json({ error: 'Música não encontrada no YouTube.' })
}
const resultado = data.resultado[0]
const youtubeUrl = resultado?.url
const descricao = resultado?.description || "Descrição não encontrada"
const audioResponse = await fetch(`${okarunsite}/api/dl/ytaudio?url=${encodeURIComponent(youtubeUrl)}&apikey=${API_KEY_OKARUN}`)
if (!audioResponse.ok) {
if (tempFilePath && fs.existsSync(tempFilePath)) fs.unlinkSync(tempFilePath)
if (mp3FilePath && fs.existsSync(mp3FilePath)) fs.unlinkSync(mp3FilePath)
return res.status(404).json({ error: 'Falha ao baixar o áudio do YouTube.' })
}
const audioFileName = `audio_${Date.now()}.mp3`
audioFilePath = path.join(audioDir, audioFileName)
const audioStream = fs.createWriteStream(audioFilePath)
await new Promise((resolve, reject) => {
audioResponse.body.pipe(audioStream)
audioResponse.body.on("error", reject)
audioStream.on("finish", resolve)
})
const form = new FormData()
form.append('file', fs.createReadStream(audioFilePath))
const uploadResponse = await axios.post('https://uploads.zero-two-apis.com.br/upload', form, { headers: { ...form.getHeaders() } })
if (!uploadResponse || !uploadResponse.data || !uploadResponse.data.fileUrl) {
if (tempFilePath && fs.existsSync(tempFilePath)) fs.unlinkSync(tempFilePath)
if (audioFilePath && fs.existsSync(audioFilePath)) fs.unlinkSync(audioFilePath)
throw new Error('Falha ao enviar o arquivo para a API de upload.')
}
const audioUrl = uploadResponse.data.fileUrl
if (tempFilePath && fs.existsSync(tempFilePath)) fs.unlinkSync(tempFilePath)
if (mp3FilePath && fs.existsSync(mp3FilePath)) fs.unlinkSync(mp3FilePath)
if (audioFilePath && fs.existsSync(audioFilePath)) fs.unlinkSync(audioFilePath)
return res.json({
status: resultado && resultado.title ? true : false,
criador: `${criador}`,
resultado: resultado && resultado.title ? "Sucesso" : "Erro",
título: resultado?.title || "Indefinido",
duração: resultado?.timestamp || "Indefinido",
postado: resultado?.ago || "Indefinido",
descrição: descricao,
visualizações: resultado?.views || "Indefinidas",
thumbnail: resultado?.thumbnail || null,
youtubeUrl: youtubeUrl || null,
audioUrl: audioUrl || null,
})
} catch (error) {
console.error('❌ Erro crítico:', error)
const filesToDelete = []
if (tempFilePath) filesToDelete.push(tempFilePath)
if (mp3FilePath) filesToDelete.push(mp3FilePath)
if (typeof mediaFile !== 'undefined' && mediaFile.tempFilePath) filesToDelete.push(mediaFile.tempFilePath)
filesToDelete.forEach(file => {
if (fs.existsSync(file)) {
fs.unlinkSync(file)
console.log('🧹 Arquivo temporário removido:', file)
}
})
return res.status(500).json({ error: 'Erro interno', details: error.message })
}
})

app.get('/api/noticias/find', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { q, apikey } = req.query
if(!q) return res.json({resultado: "Faltando o parâmetro q"})
if(!apikey) return res.json({resultado: "Faltando o parâmetro apikey"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({resultado: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
theNews = await axios.get(`https://newsapi.org/v2/everything?q=${q}&sortBy=publishedAt&language=pt&apiKey=9dc1dde158804756ae9b33dd8d71f7a1`)
newsSends = theNews.data.articles.map(d => `${d.publishedAt.split('T').join(' - ').split('Z')[0]}\n\n${d.title} - ${d.author} [${d.source.name}]\n\n${d.description}\n\n${d.url}\n\n${d.content}\n\n--------------------------- * ---------------------------\n\n`).join('')
return res.json({status: true, criador: `${criador}`, resultado: newsSends})
} catch {
return res.json({resultado: "Erro"})
}
})

app.get('/api/book', async(req, res) => {
var { livro, apikey } = req.query
try {
ABC = await fetchJson(`https://www.googleapis.com/books/v1/volumes?q=${livro}&langRestrict=pt`)
return res.json({status: true, criador: `${criador}`, resultado: ABC.items})
} catch { return res.json({status: false, resultado: "Nenhuma resposta obtida do servidor"}) }
})

app.get('/api/cotacao', async(req, res) => {
var { moeda, apikey } = req.query
if(!moeda || !apikey) return res.json({erro: "Faltando parâmetro moeda ou apikey"})
moda = moeda.toLowerCase().replace("ó", "o")
try {
if(moda == "dolar") { money = "USD-BRL"
} else if(moda == "euro") { money = "EUR-BRL"
} else if(moda == "bitcoin") { money = "BTC-BRL"
} else if(moda == "libra") { money = "GBP-BRL"
} else if(moda == "ether") { money = "ETH-BRL"
} else if(moda == "iene") { money = "JPY-BRL"
} else if(moda == "yuan") { money = "CNY-BRL"
} else return res.json({erro: `A moeda escolhida não está presente em meu banco de dados... As moedas disponíveis são:
• Dólar
• Euro
• Bitcoin
• Libra
• Ether
• Iene
• Yuan`})
response = await axios.get(`https://economia.awesomeapi.com.br/last/${money}`)
if(moda == "dolar") { resposta = response.data.USDBRL
} else if(moda == "euro") { resposta = response.data.EURBRL
} else if(moda == "bitcoin") { resposta = response.data.BTCBRL
} else if(moda == "ether") { resposta = response.data.ETHBRL
} else if(moda == "libra") { resposta = response.data.GBPBRL
} else if(moda == "iene") { resposta = response.data.JPYBRL
} else if(moda == "yuan") { resposta = response.data.CNYBRL }
return res.json({status: true, criador: `${criador}`, resultado: [resposta]})
} catch { return res.json({status: false, erro: "Nenhuma resposta obtida do servidor"}) }
})

app.get('/nsfw/image/random', async(req, res) => {
var { atriz, apikey } = req.query
if(!atriz) return res.json({resultado: "Faltando o parâmetro atriz"})
if(!apikey) return res.json({resultado: "Faltando o parâmetro apikey"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({resultado: "Apikey inválida ou requests esgotados!"})
try {
data = await fetch(img).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/gostosinha.jpg', data)
res.sendFile(bla+'/assets/gostosinha.jpg')
} catch {
return res.json({status: false, criador: `${criador}`, resultado: "Erro"})
}
})

app.get('/api/facebook', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
fbdown(url).then(data => {
res.json({
status: true,
código: 999,
resultado: data
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/info_celular', async(req, res) => {
try {
celular = req.query.celular
if(!celular)return res.json({status:false, motivo:'Coloque o parâmetro: celular'})
apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
axios(`https://www.techtudo.com.br/busca/?q=`+celular, Headers={headers}).then(rs => {
var $ = cheerio.load(rs.data)
const DFN_UR = $(".widget--navigational__title").text().toLowerCase()
axios(`https://www.techtudo.com.br/tudo-sobre/${DFN_UR.replace(new RegExp(" ", "gi"), "-")}/`, Headers={headers}).then(rsp => {
var $ = cheerio.load(rsp.data)
var RST = []
var titulo = $("h1").text()
var BT = $("div").find(".content-row").text()
var BT2 = $("div").find(".all-about").text()
res.json({status: true, código: 999, criador: `${criador}`, resultado: { nomeCelular: titulo, informações: BT2.trim(), resumoExtra: BT.trim().replace(new RegExp("", "gi"), "\n\n")}})}).catch(e => {res.json({message: "Error"})})}).catch(e => {res.json({message: "Error"})})} catch {return res.json({message: "Erro...Aguarde ou fale com algum administrador.."})}})

app.get('/search/wikipedia',(req,res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
query = req.query.query
if(!query)return res.json({
status:false,
message:'Cadê o parâmetro: QUERY'
})
apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'Cadê o parâmetro: APIKEY'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
wikiSearch(query)
.then(hasil => {
res.json({
status:true,
resultado: hasil
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/search/pensador',(req,res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
query = req.query.query
if(!query)return res.json({
status:false,
message:'Cadê o parâmetro: QUERY'
})
apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'Cadê o parâmetro: APIKEY'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
pensadorSearch(query)
.then(dados => {
res.json({
status:true,
resultado: dados
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/search/wallpaper',(req,res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
query = req.query.query
if(!query)return res.json({
status:false,
message:'Cadê o parâmetro: QUERY'
})
apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'Cadê o parâmetro: APIKEY'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
wallpaper2(query)
.then(result => {
res.json({
status:true,
resultado: result
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/search/wallpaper', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message: "Coloque o parametro: query"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log('Iniciando a raspagem para a query:', query)
const wallpapers = await scrapeWallpapers(query)
if (wallpapers.length > 0) {
console.log('Wallpapers encontrados:', wallpapers)
res.json({ criador: `${criador}`, status: true, resultado: wallpapers })
} else {
console.log('Nenhuma imagem encontrada para a query:', query)
res.json({ success: false, message: 'Nenhuma imagem encontrada.' })
}
} catch (error) {
console.error('Erro ao realizar a raspagem:', error)
res.status(500).json({ success: false, message: 'Erro ao realizar a raspagem.' })
}
})

app.get('/download/youtube',(req,res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
url = req.query.url
if(!url)return res.json({
status:false,
message:'Cadê o parâmetro: url'
})
apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'Cadê o parâmetro: apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
ytDonlodMp3_3(url).then(result => {
res.json({
status:true,
resultado: result
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/download/tiktok', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(chalk.blue('Obtendo dados do TikTok v1...'))
console.log(`Link fornecido: ${url}`)
const data = await Tiktok.Downloader(url, { version: 'v1' })
const resultado = { criador: `${criador}`, status: true, resultado: data.result }
return res.json(resultado)
} catch (error) {
console.error(chalk.red('Erro ao obter dados do TikTok:', error))
return res.status(500).json({ criador: `${criador}`, status: false, mensagem: 'Ocorreu um erro ao obter os dados do TikTok.' })
}
})

app.get('/api/download/tiktok/v2', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(chalk.blue('Obtendo dados do TikTok v2...'))
console.log(`Link fornecido: ${url}`)
const data = await Tiktok.Downloader(url, { version: 'v2' })
const resultado = { criador: `${criador}`, status: true, resultado: data.result }
return res.json(resultado)
} catch (error) {
console.error(chalk.red('Erro ao obter dados do TikTok:', error))
return res.status(500).json({ criador: `${criador}`, status: false, mensagem: 'Ocorreu um erro ao obter os dados do TikTok.' })
}
})

app.get('/api/download/tiktok/v3', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(chalk.blue('Obtendo dados do TikTok v3...'))
console.log(`Link fornecido: ${url}`)
const data = await Tiktok.Downloader(url, { version: 'v3' })
const resultado = { criador: `${criador}`, status: true, resultado: data.result }
return res.json(resultado)
} catch (error) {
console.error(chalk.red('Erro ao obter dados do TikTok:', error))
return res.status(500).json({ criador: `${criador}`, status: false, mensagem: 'Ocorreu um erro ao obter os dados do TikTok.' })
}
})

app.get('/api/download/tiktok/v4', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
async function downloadTikTok(url) {
try {
console.log(chalk.blue('Obtendo dados do TikTok v4...'))
console.log(`Link fornecido: ${url}`)
const result = await Tiktok.Downloader(url, { version: 'v2' })
return result
} catch (error) {
console.error('Erro ao baixar o TikTok:', error)
return null
}
}
const tiktokData = await downloadTikTok(url)
if (tiktokData && tiktokData.status === 'error') {
console.log('Erro na resposta da API:', tiktokData.message)
return res.status(500).json({status: false, criador: `${criador}`, resultado: { error: tiktokData.message }
})
} else if (tiktokData && tiktokData.status === 'success') {
const { result } = tiktokData
return res.json({
status: true,
criador: `${criador}`,
resultado: {
video: result.video,
audio: result.music,
detalhes: {
tipo: result.type || 'Não disponível',
autor: (result.author && result.author.nickname) || 'Não disponível',
avatar: (result.author && result.author.avatar) || 'Não disponível',
curtidas: (result.statistics && result.statistics.likeCount) || 'Não disponível',
comentários: (result.statistics && result.statistics.commentCount) || 'Não disponível',
compartilhamentos: (result.statistics && result.statistics.shareCount) || 'Não disponível',
descrição: result.desc || 'Não disponível'
}
}
})
} else {
console.log('Erro na resposta ou link de download não encontrado:', tiktokData ? tiktokData.message : 'Nenhum dado retornado.')
return res.status(500).json({status: false, criador: `${criador}`, resultado: { error: 'Erro ao processar o TikTok.' }
})
}
})

app.get('/download/tiktoksearch', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
username = req.query.username
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!username) return res.json({ status : false,message: "Coloque o parametro: username"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(chalk.blue("Iniciando busca no TikTok..."))
const resultado = await d.search.tiktoks(username)
console.log(chalk.green("Busca concluída com sucesso!"))
res.json({
status: true,
código: 999,
criador: `${criador}`,
resultado: resultado
})
} catch (error) {
console.error(chalk.red("Erro ao buscar os dados:"), chalk.red.bold(error.message))
res.json({ message: "Erro no Servidor Interno" })
}
})

app.get('/api/boost/tiktok', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
username = req.query.username
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url || !username) return res.json({ status : false,message: "Coloque os parâmetros: url e username"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(chalk.blue('Obtendo dados do TikTok...'))
let videolink = url.trim()
if (!videolink.startsWith("http")) {
videolink = "https://" + videolink
}
videolink = videolink.replace(/^https:\/\/https:\/\//, "https://")
if (!videolink.startsWith("http")) {
console.log("[LOG] Erro: Link do vídeo inválido.")
return res.json({ status: false, message: "Erro: O link do vídeo deve ser um URL válido do TikTok." })
}
const apiUrl = `https://lkteamtiktokvisits.vercel.app/boost?user=${encodeURIComponent(username)}&link=${encodeURIComponent(videolink)}`
const response = await fetch(apiUrl)
if (!response.ok) throw new Error(`Erro na API: ${response.statusText}`)
const data = await response.json()
console.log(chalk.green('Dados da API obtidos com sucesso:', JSON.stringify(data, null, 2)))
if (data.message) {
return res.json({
status: true,
criador: `${criador}`,
resultado: {
aviso: "⚠️ *Atenção:* A API possui um limite de 1.000 visualizações por dia. Utilize com cautela!",
usuário: username,
image: "https://uploads.zero-two-apis.com.br/uploads/images/file-1740902381339-946116952.jpeg",
url: videolink,
resposta: data.message
}
})
} else {
return res.json({ status: false, message: "Erro: Resposta inesperada da API." })
}
} catch (error) {
console.error(chalk.red('Erro ao se conectar com a API:', error))
return res.status(500).json({
status: false,
message: 'Ocorreu um erro ao enviar as visualizações.'
})
}
})

app.get('/api/letramusic', async (req,res) => {
query = req.query.query
apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'Cadê o parâmetro: APIKEY'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(!query)return res.json({status:false, message:'Cadê o parâmetro: query'})
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await ScrapperLyrics.get(query)
if (result.length === 0) {
return res.status(404).json({ error: 'Nenhum resultado encontrado.' })
}
return res.json({ status: true, criador: `${criador}`, resultado: result })
} catch (error) {
return res.status(500).json({ error: error.message })
}
})

app.get('/api/letramusic2', async (req,res) => {
query = req.query.query
apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'Cadê o parâmetro: APIKEY'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(!query)return res.json({status:false, message:'Cadê o parâmetro: query'})
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
lyricsFinder2(query).then(data => {
res.json({ status: true, criador: `${criador}`, resultado: data })
}).catch(e => {
console.log(e)
res.json({erro:'Erro no Servidor Interno'})
})
})

router.get('/api/emojimix', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var emoji1 = req.query.emoji1
var emoji2 = req.query.emoji2
apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'Cadê o parâmetro: APIKEY'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!emoji1) return res.json({ status : false, message : "[!] parâmetros de entradaemoji1"})
if (!emoji2) return res.json({ status : false, message : "[!] parâmetros de entradaemoji2"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
let data = await Kibar(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`)
let jadi = data.results[Math.floor(Math.random() * data.results.length)]
if (!jadi ) return res.json({erro: "Erro no Servidor Interno."})
for (let ress of data.results) {
resul = await getBuffer(ress.url)
res.set({'Content-Type': 'image/png'})
res.send(resul)
}
})


app.get('/download/facebook', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
let response = await fbdl(url)
let data = response.data
console.log(chalk.green("Informações do Facebook obtidas com sucesso"))
res.json({
criador: `${criador}`,
status: true,
resultado: data
})
} catch (error) {
console.error(chalk.red("Erro ao buscar informações do vídeo:"), error.message)
res.status(500).json({ error: 'Erro ao buscar informações do vídeo' })
}
})

app.get('/download/facebook2', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
getmyfb(url).then(resultado => {
res.json(resultado)
}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})
})
})

app.get('/api/filme', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
q = req.query.q
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!q) return res.json({ status : false,message: "Coloque o parametro: q"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
filme(q).then(resultado => {
res.json({
status: true,
código: 200,
criador: `${criador}`,
pesquisa: resultado
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/ph/image', async(req, res) => {
var { category, apikey } = req.query
if(!category) return res.json({message: "Faltando o parâmetro category"})
if(!apikey) return res.json({message: "Faltando o parâmetro apikey"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
var nsfw = new NSFW()
nsfw.fetch(category).then((data) => {
async function convertph(hehe) {
img = await fetch(hehe).then(v => v.buffer()) 
await fs.writeFileSync(bla+'/assets/gostosinha.jpg', img)
res.sendFile(bla+'/assets/gostosinha.jpg') 
}
return convertph(data.image.url)
//return res.json({criador: `${criador}`, status: true, resultado: data.image.url})
})
} catch(e) { console.log(e)
return res.json({criador: `${criador}`, status: false, resultado: `Erro`}) }
})

app.get('/api/ph/image2', async(req, res) => {
var { category, apikey } = req.query
if(!category) return res.json({message: "Faltando o parâmetro category"})
if(!apikey) return res.json({message: "Faltando o parâmetro apikey"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
var nsfw = new NSFW()
nsfw.fetch(category).then((data) => {
return res.json({criador: `${criador}`, status: true, resultado: data.image.url})
})
} catch(e) { console.log(e)
return res.json({criador: `${criador}`, status: false, resultado: `Erro`}) }
})

app.get('/api/xvsearch', async(req, res) => {
var { q, apikey } = req.query
if(!q) return res.json({message: "Faltando o parâmetro q"})
if(!apikey) return res.json({message: "Faltando o parâmetro apikey"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
XvideosSearch(q).then(async(e) => {
res.json({status: true, criador: `${criador}`, resultado: e})
}).catch((error) => {
res.json({criador: `${criador}`, status: false, resultado: []})
})
})

app.get('/api/xvideos', async(req, res) => {
var { url, apikey } = req.query
if(!url) return res.json({message: "Faltando o parâmetro url"})
if(!apikey) return res.json({message: "Faltando o parâmetro apikey"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const { xvideosDownloader } = require("./base de dados/xvideos.js")
ABC = await xvideosDownloader(url)
return res.json({criador: `${criador}`, resultado: {titulo: ABC.resultado.titulo, desc: ABC.resultado.desc, thumbnail: ABC.resultado.thumb, download: ABC.resultado.link}})
} catch(e) { console.log(e)
return res.json({erro: "Erro no servidor interno"}) }
})

app.get('/api/xnxx', async(req, res) => {
var { q, apikey } = req.query
if(!q) return res.json({message: "Faltando o parâmetro q"})
if(!apikey) return res.json({message: "Faltando o parâmetro apikey"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
var xnxx =await xnxxs(q)
return res.json({criador: `${criador}`, status: true, resultado: xnxx.result})
} catch(e) { console.log(e)
return res.json({criador: `${criador}`, status: false, resultado: []}) }
})

app.get('/api/xnxxdl', async(req, res) => {
var { url, apikey } = req.query
if(!url) return res.json({message: "Faltando o parâmetro url"})
if(!apikey) return res.json({message: "Faltando o parâmetro apikey"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
var xnxx =await xnxxdl(url)
return res.json({criador: `${criador}`, resultado: xnxx.result})
} catch(e) { console.log(e)
return res.json({erro: "Erro no servidor interno"}) }
})

app.get('/api/phsearch', async(req, res) => {
var { q, apikey } = req.query
if(!q) return res.json({message: "Faltando o parâmetro q"})
if(!apikey) return res.json({message: "Faltando o parâmetro apikey"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
var pornhub = new PornHub()
var ph = await pornhub.searchVideo(q)
return res.json({criador: `${criador}`, status: true, resultado: ph.data})
} catch(e) { console.log(e)
return res.json({criador: `${criador}`, status: false, resultado: []}) }
})

app.get('/api/pornhub', async(req, res) => {
var { url, apikey } = req.query
if(!url) return res.json({message: "Faltando o parâmetro url"})
if(!apikey) return res.json({message: "Faltando o parâmetro apikey"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
var pornhub = new PornHub()
var ph = await pornhub.video(url)
return res.json({criador: `${criador}`, result: ph})
} catch(e) { console.log(e)
return res.json({erro: "Erro no servidor interno"}) }
})

app.get('/api/nerding', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
q = req.query.q
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!q) return res.json({ status : false,message: "Coloque o parametro: q"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
 nerding(q).then(resultado => {
res.json({status: true, código: 200, criador: `${criador}`, resultado: resultado})
}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})


app.get('/api/playstore', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
nome = req.query.nome
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!nome) return res.json({ status : false,message: "Coloque o parametro: nome"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
PlayStoreSearch(nome).then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`,
erro: `${e}`
})})})

app.get('/api/mercadolivre', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
nome = req.query.nome
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!nome) return res.json({ status : false,message: "Coloque o parametro: nome"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
MercadoLivreSearch(nome).then(data => {
res.json(data)
}).catch(e => {
res.json({
message: `Erro no Servidor Interno`,
erro: `${e}`
})})})

app.get('/api/amazon', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
nome = req.query.nome
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!nome) return res.json({ status : false,message: "Coloque o parametro: nome"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
AmazonSearch(nome).then(data => {
res.json(data)
}).catch(e => {
res.json({
message: `Erro no Servidor Interno`,
erro: `${e}`
})})})

app.get('/api/americanas', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
nome = req.query.nome
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!nome) return res.json({ status : false,message: "Coloque o parametro: nome"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
AmericanasSearch(nome).then(data => {
res.json(data)
}).catch(e => {
res.json({
message: `Erro no Servidor Interno`,
erro: `${e}`
})})})

app.get('/api/dicionario', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
q = req.query.q
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!q) return res.json({ status : false,message: "Coloque o parametro: q"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
Dicionario(q).then(data => {
res.json(data)
}).catch(e => {
res.json({
message: `Erro no Servidor Interno`,
erro: `${e}`
})})})


app.get("/api/pinterest_mp4", async (req, res) => {
  const userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress;
  const apikey = req.query.apikey;
  const url = req.query.url;

  // validações de apikey
  if (!key.map(i => i.apikey)?.includes(apikey)) {
    return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"));
  }
  const ITC = key.map(i => i?.apikey)?.indexOf(apikey);
  if (key[ITC]?.request <= 0) {
    return res.json({ message: "Apikey inválida ou requests esgotados!" });
  }
  if (!url) {
    return res.json({ status: false, message: "Coloque o parametro: url" });
  }

  RegisKey(apikey, userIp);
  console.log(color(` ApiKey: ${apikey} • Limite: ${key[ITC]?.request}`, 'red'),
              color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'));

  try {
    // usa o scrapper pindl
    const result = await pindl(url.trim());

    if (!result.data.video_url) {
      return res.json({ status: false, message: "Nenhum vídeo encontrado para o URL fornecido" });
    }

    // faz o streaming do vídeo
    const videoResponse = await axios.get(result.data.video_url, {
      responseType: "stream",
      timeout: 30000,
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
      }
    });

    res.set({
      "Content-Type": videoResponse.headers["content-type"] || "video/mp4",
      "Cache-Control": "public, max-age=3600",
      "Accept-Ranges": "bytes"
    });

    videoResponse.data.pipe(res);

    videoResponse.data.on("error", (err) => {
      if (!res.headersSent) {
        res.json({ status: false, message: "Falha ao streamar vídeo" });
      }
      console.error("Stream error:", err);
    });

  } catch (error) {
    console.error("Pinterest MP4 Error:", error.message || error);
    if (!res.headersSent) {
      res.json({ status: false, message: error.message || "Erro ao processar request" });
    }
  }
});

app.get('/api/search-pinterest', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
text = req.query.text
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!text) return res.json({ status : false,message : "Cade o parametro text?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(chalk.blueBright(`Buscando videos no Pinterest (Alternativo) para: ${text}...`))
const result = await pinterest3(text)
res.json(result)
} catch (error) {
console.error(chalk.red('Erro ao buscar imagens no Pinterest (Alternativo):'), error.message)
res.status(500).send('Erro ao processar a solicitação.')
}
})





app.get("/api/pinterest_search", async (req, res) => {
  const userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress;
  const apikey = req.query.apikey;
  const query = req.query.query;

  // validações de apikey
  if (!key.map(i => i.apikey)?.includes(apikey)) {
    return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"));
  }
  const ITC = key.map(i => i?.apikey)?.indexOf(apikey);
  if (key[ITC]?.request <= 0) {
    return res.json({ message: "Apikey inválida ou requests esgotados!" });
  }
  if (!query) {
    return res.json({ status: false, message: "Coloque o parametro: query" });
  }

  RegisKey(apikey, userIp);
  console.log(color(` ApiKey: ${apikey} • Limite: ${key[ITC]?.request}`, 'red'),
              color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'));

  try {
    const results = await pinterestSearch(query);

    if (!results || results.length === 0) {
      return res.json({ status: false, message: "Nenhum resultado encontrado para a pesquisa" });
    }

    // filtra só os que têm vídeo
    const videoResults = results.filter(r => r.videoUrl && r.videoUrl !== "gak ada");

    if (videoResults.length === 0) {
      return res.json({ status: false, message: "Nenhum vídeo encontrado para a pesquisa" });
    }

    res.json({
      status: true,
      count: videoResults.length,
      data: videoResults
    });
  } catch (error) {
    console.error("Pinterest Search Error:", error.message || error);
    res.json({ status: false, message: error.message || "Erro ao processar request" });
  }
});

app.get('/api/ytplaylist', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
getVideosPlaylist(url).then(resJson => {
res.json({
status: 200,
resultado: resJson
})
}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})
})
})

app.get('/api/submarino', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
nome = req.query.nome
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!nome) return res.json({ status : false,message: "Coloque o parametro: nome"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
SubmarinoSearch(nome).then(dados => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/horoscopo', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
signo = req.query.signo
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!signo) return res.json({ status : false,message: "Coloque o parametro: signo"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const resultado = await scrapeData(signo)
res.json(resultado)
} catch (error) {
res.status(500).json({ status: false, criador: `${criador}`, error: "Erro interno no servidor." })
}
})

app.get('/api/randomgp', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
categoria = req.query.categoria
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!categoria) return res.json({ status : false,message: "Coloque o parametro: categoria"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
randomGrupos(categoria).then(dados => {
res.json({
pesquisa: dados
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/randomgp2', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
categoria = req.query.categoria
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!categoria) return res.json({ status : false,message: "Coloque o parametro: categoria"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
randomGrupos2(categoria).then(dados => {
res.json({
pesquisa: dados
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/kwai/search', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message: "Coloque o parametro: query"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const kwai = new Kwai({ query, cookie: fixedCookie })
const result = await kwai.search()
res.json({ success: true, criador: `${criador}`, resultado: result })
} catch (error) {
res.status(500).json({ success: false, error: error.message })
}
})

app.get('/api/kwai/video', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await kwaiDownload(url)
res.json(result)
} catch (error) {
console.error('Erro:', error)
res.status(500).json({ error: 'Erro interno do servidor.' })
}
})

app.get('/api/kwai/stalke', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
usuario = req.query.usuario
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!usuario) return res.json({ status : false,message: "Coloque o parametro: usuario"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await kwaistalk(usuario)
res.json(result)
} catch (error) {
console.error('Erro:', error)
res.status(500).json({ error: 'Erro interno do servidor.' })
}
})

app.get('/outros/openai', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
pergunta = req.query.pergunta
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!pergunta) return res.json({ status : false,message: "Coloque o parametro: pergunta"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
InArtificial(pergunta).then(hasil => {
res.json({
status: 200,
resultado: hasil
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/outros/openai/corretor', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
texto = req.query.texto
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!texto) return res.json({ status : false,message: "Coloque o parametro: texto"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
CorretorOpenAi(texto).then(hasil => {
res.json({
status: 200,
resultado: hasil
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/memes', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
memesDroid().then(dados => {
res.json({
pesquisa: dados
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/memesvid', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
iFunny().then(dados => {
res.json(dados)
}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/ringtone', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
query = req.query.query
apikey = req.query.apikey
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message: "Coloque o parametro: query"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
ringtone(query).then(hasil => {
res.json({
status: 200,
resultado: hasil
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/noticias/globo', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
G1().then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/noticias/jovempan', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
JovemPan().then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/noticias/poder360', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
Poder360().then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/noticias/uol', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
Uol().then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/noticias/estadao', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
Estadao().then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/noticias/cnnbrasil', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
CNNBrasil().then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/gpwhatsapp', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
q = req.query.q
apikey = req.query.apikey
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if(!q)return res.json({status:false,message:'Cadê o parâmetro q?'})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
 gpwhatsapp(q).then(resultado => {
res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: resultado
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

router.all('/api/musicas/itunes', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
musica = req.query.musica
if(!musica)return res.json({
status:false,
motivo:'Coloque o parâmetro: musica'
})
apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
auu = await Kibar(`https://api.popcat.xyz/itunes?q=${musica}`)
res.json({
status: true,
código: 999,
resultado: {
linkAcesso: `${auu.url}`,
nomeMusic: `${auu.name}`,
nomeArtista: `${auu.artist}`,
nomeAlbum: `${auu.album}`,
lançamento: `${auu.release_date}`,
preço: `${auu.price}`,
segundos: `${auu.length}`,
gênero: `${auu.genre}`,
thumbnail: `${auu.thumbnail}`
}
})
})

app.get('/api/pinterest', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
text = req.query.text
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!text) return res.json({ status: false, message: "Cade o parametro text?" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(chalk.blueBright(`Buscando imagens no Pinterest para: ${text}...`))
const result = await pinterest2(text)
if (!result || !result.resultado || !Array.isArray(result.resultado) || result.resultado.length === 0) {
throw new Error("Nenhuma imagem encontrada.")
}
const images = result.resultado.map(item => item.image)
if (images.length === 0) {
return res.status(404).send('Nenhuma imagem encontrada.')
}
const randomImage = images[Math.floor(Math.random() * images.length)]
const response = await fetch(randomImage)
const buffer = await response.arrayBuffer()
res.setHeader("Content-Type", "image/jpeg")
res.send(Buffer.from(buffer))
} catch (error) {
console.error(chalk.red('Erro ao buscar imagens no Pinterest:'), error.message)
res.status(500).send('Erro ao processar a solicitação.')
}
})

app.get('/api/pinterest2', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
text = req.query.text
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!text) return res.json({ status : false,message : "Cade o parametro text?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(chalk.blueBright(`Buscando imagens no Pinterest (Alternativo) para: ${text}...`))
const result = await pinterest2(text)
res.json(result)
} catch (error) {
console.error(chalk.red('Erro ao buscar imagens no Pinterest (Alternativo):'), error.message)
res.status(500).send('Erro ao processar a solicitação.')
}
})

app.get('/api/download', (req, res) => {
(async() => {
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message : "Cade o parametro url?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
wew = await savefrom(url)
res.type('mp4')
res.send(await getBuffer(wew.url[0].url))
})()
})

app.get('/api/imitar/mickey', (req, res) => {
(async() => {
apikey = req.query.apikey
texto = req.query.texto
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!texto) return res.json({ status : false,message : "Cadê o parametro texto?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
uber.getAudioUrl("pub_motekhcekzerxfxjro", "pk_d2d564c1-7942-4afc-9368-7520fc024603", 'mickey-mouse', texto).then(async getBuf => {
res.type('mp3')
res.send(await getBuffer(getBuf))
})
})()
})

app.get('/api/imitar/chapolin', (req, res) => {
(async() => {
apikey = req.query.apikey
texto = req.query.texto
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!texto) return res.json({ status : false,message : "Cadê o parametro texto?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
uber.getAudioUrl("pub_motekhcekzerxfxjro", "pk_d2d564c1-7942-4afc-9368-7520fc024603", 'chapolin-br', texto).then(async getBuf => {
res.type('mp3')
res.send(await getBuffer(getBuf))
})
})()
})

app.get('/api/imitar/eminem', (req, res) => {
(async() => {
apikey = req.query.apikey
texto = req.query.texto
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!texto) return res.json({ status : false,message : "Cadê o parametro texto?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
uber.getAudioUrl("pub_motekhcekzerxfxjro", "pk_d2d564c1-7942-4afc-9368-7520fc024603", 'eminem', texto).then(async getBuf => {
res.type('mp3')
res.send(await getBuffer(getBuf))
})
})()
})

app.get('/api/imitar/faustao', (req, res) => {
(async() => {
apikey = req.query.apikey
texto = req.query.texto
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!texto) return res.json({ status : false,message : "Cadê o parametro texto?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
uber.getAudioUrl("pub_motekhcekzerxfxjro", "pk_d2d564c1-7942-4afc-9368-7520fc024603", 'faustao', texto).then(async getBuf => {
res.type('mp3')
res.send(await getBuffer(getBuf))
})
})()
})

app.get('/api/imitar/ibere', (req, res) => {
(async() => {
apikey = req.query.apikey
texto = req.query.texto
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!texto) return res.json({ status : false,message : "Cadê o parametro texto?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
uber.getAudioUrl("pub_motekhcekzerxfxjro", "pk_d2d564c1-7942-4afc-9368-7520fc024603", 'ibere', texto).then(async getBuf => {
res.type('mp3')
res.send(await getBuffer(getBuf))
})
})()
})

app.get('/makerfig/rgb', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
fig = req.query.fig
texto = req.query.texto
apikey = req.query.apikey
if(!fig) return res.json({message: "Faltando o parametro fig"})
tipos = ["attp", "attp2", "ttp", "ttp2", "ttp3", "ttp4", "ttp5", "ttp6"]
if(!tipos.includes(fig)) return res.json({message: "Tipo maker attp inválido"})
if(!texto) return res.json({message: "Faltando o parametro texto"})
if(!apikey)return res.json({message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const endpointMap = {
attp: "attp",
attp2: "attp2",
ttp: "ttp",
ttp2: "ttp2",
ttp3: "ttp3",
ttp4: "ttp4",
ttp5: "ttp5",
ttp6: "ttp6"
}
const apiEndpoint = endpointMap[fig]
const url = `https://api.lolhuman.xyz/api/${apiEndpoint}?apikey=1b0ebf01de8b0fbd59270f27&text=${encodeURIComponent(texto)}`
const response = await fetch(url)
const data = await response.buffer()
const outputPath = path.join(__dirname, 'assets', 'attp.webp')
fs.writeFileSync(outputPath, data)
res.sendFile(outputPath)
} catch (error) {
console.error('Erro ao processar a requisição:', error)
return res.json({ message: "Erro no server interno... Chame meu dono paulo_mod_domina" })
}
})

app.get("/attps", async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
type = req.query.type
texto = req.query.texto
apikey = req.query.apikey
if(!type) return res.json({message: "Faltando o parametro type"})
if(!texto) return res.json({message: "Faltando o parametro texto"})
if(!apikey)return res.json({message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
const validTypes = ["attp", "attp1", "attp2", "attp3", "attp4", "attp5", "attp6", "attp7", "attp8", "attp9", "attp10", "attp11", "attp12"]
if (!validTypes.includes(type)) return res.status(400).send({ error: "Tipo inválido. Use 'attp' até 'attp12'." })
try {//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
const width = 512
const height = 512
const encoder = new GIFEncoder(width, height)
encoder.start()
encoder.setRepeat(0)
encoder.setDelay(100)
encoder.setQuality(10)
const canvas = createCanvas(width, height)
const ctx = canvas.getContext("2d")
const styles = {
attp: () => {
ctx.font = "bold 60px Arial"
ctx.fillStyle = `hsl(${Math.random() * 360}, 100%, 50%)`
},
attp1: () => {
ctx.font = "italic 50px Comic Sans MS"
ctx.fillStyle = `rgb(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255})`
},
attp2: () => {
ctx.font = "bold 70px Impact"
ctx.strokeStyle = "yellow"
ctx.lineWidth = 5
ctx.strokeText(texto, width / 2, height / 2)
},
attp3: () => {
ctx.font = "bold 50px Tahoma"
ctx.fillStyle = `hsl(${Math.random() * 360}, 100%, 70%)`
},
attp4: () => {
ctx.font = "bold 60px Georgia"
ctx.fillStyle = "cyan"
},
attp5: () => {
ctx.font = "bold 60px Verdana"
ctx.fillStyle = `hsl(${Math.random() * 360}, 50%, 40%)`
},
attp6: () => {
ctx.font = "bold 60px Courier New"
ctx.fillStyle = "lime"
},
attp7: () => {
ctx.font = "bold 60px Helvetica"
ctx.fillStyle = `rgb(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255})`
},
attp8: () => {
ctx.font = "bold 60px Times New Roman"
ctx.fillStyle = "gold"
},
attp9: () => {
ctx.font = "bold 70px Fantasy"
ctx.shadowColor = "black"
ctx.shadowBlur = 10
ctx.fillStyle = "white"
},
attp10: () => {
ctx.font = "bold 80px Arial"
const gradient = ctx.createLinearGradient(0, 0, width, 0)
gradient.addColorStop(0, "red")
gradient.addColorStop(0.5, "blue")
gradient.addColorStop(1, "green")
ctx.fillStyle = gradient
},
attp11: () => {
ctx.font = "bold 70px Sans-serif"
ctx.strokeStyle = "white"
ctx.lineWidth = 4
ctx.strokeText(texto, width / 2, height / 2)
ctx.fillStyle = "purple"
},
attp12: () => {
ctx.font = "bold 3d 70px Arial"
ctx.fillStyle = `rgb(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255})`
ctx.shadowBlur = 20
ctx.shadowColor = "black"
},
}
const selectedStyle = styles[type]
for (let i = 0; i < 10; i++) {
ctx.clearRect(0, 0, width, height)
selectedStyle()
ctx.textAlign = "center"
ctx.textBaseline = "middle"
ctx.fillText(texto, width / 2, height / 2)
encoder.addFrame(ctx)
}
encoder.finish()
res.setHeader("Content-Type", "image/gif")
res.send(encoder.out.getData())
} catch (error) {
console.error("Erro ao gerar figurinha:", error)
res.status(500).send({ error: "Erro ao gerar figurinha." })
}
})

app.get('/api/amongus', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Faltando o parametro texto"})
if(!apikey)return res.json({message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
hasil = `https://api.lolhuman.xyz/api/amongus?apikey=1b0ebf01de8b0fbd59270f27&text=${texto}`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/attp.webp', data)
res.sendFile(bla+'/assets/attp.webp') 
} catch {
return res.json({message: "Erro no server interno... Chame meu dono paulo_mod_domina"})
}
})

app.get('/api/gtapassed', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { txt1, txt2, apikey } = req.query
if(!txt1) return res.json({message: "Faltando o parametro texto 1"})
if(!txt2) return res.json({message: "Faltando o parametro texto 2"})
if(!apikey)return res.json({message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
hasil = `https://api.lolhuman.xyz/api/gtapassed?apikey=1b0ebf01de8b0fbd59270f27&text1=${txt1}&text2=${txt2}`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/attp.webp', data)
res.sendFile(bla+'/assets/attp.webp') 
} catch {
return res.json({message: "Erro no server interno... Chame meu dono paulo_mod_domina"})
}
})

app.get('/ssweb', async (req, res) => {
  try {
    const url = req.query.url
    const apikey = req.query.apikey

    if (!url) return res.json({ status: false, motivo: 'nao_tem_url' })

    if (!key.map(i => i.apikey)?.includes(apikey))
      return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))

    const ITC = key.map(i => i?.apikey)?.indexOf(apikey)
    if (key[ITC]?.request <= 0)
      return res.json({ message: "Apikey inválida ou requests esgotados!" })

    RegisKey(apikey, userIp)

    console.log(
      color(` ApiKey: ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'),
      color('', 'red'),
      color('Request', 'red'),
      '• ' + color('Ping: ' + ping(), 'red')
    )

    // ================================
    // 🔥 SCRAPPER EMBUTIDO AQUI 🔥
    // ================================

    const token = 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE1MjMzNjQ4MjQsIm5iZiI6MTUyMzM2NDgyNCwianRpIjoicHJvamVjdF9wdWJsaWNfYzkwNWRkMWMwMWU5ZmQ3NzY5ODNjYTQwZDBhOWQyZjNfT1Vzd2EwODA0MGI4ZDJjN2NhM2NjZGE2MGQ2MTBhMmRkY2U3NyJ9.qvHSXgCJgqpC4gd6-paUlDLFmg0o2DsOvb1EUYPYx_E'

    // 1) Upload
    const f1 = new FormData()
    f1.append('task', 't0bbjt9wrvbj7yAqlwgbt7r37dvdfmnthfz6zgmt15pt3j3scwp73hxkhyb63lzh5bkc9mj09Az5dmkww8b3nvA91dx2nld6djbdsd6n6vtyccphcj01j76q6vm9l26rct5yk4kf7bm35f6Axl11c4n6tq56jzjr1nh6mpfgv6xdtggvzbd1')
    f1.append('cloud_file', url)

    const up = await axios.post('https://api32.ilovepdf.com/v1/upload', f1, {
      headers: { ...f1.getHeaders(), authorization: token }
    })

    // 2) Preview
    const f2 = new FormData()
    f2.append('server_filename', up.data.server_filename)
    f2.append('task', 't0bbjt9wrvbj7yAqlwgbt7r37dvdfmnthfz6zgmt15pt3j3scwp73hxkhyb63lzh5bkc9mj09Az5dmkww8b3nvA91dx2nld6djbdsd6n6vtyccphcj01j76q6vm9l26rct5yk4kf7bm35f6Axl11c4n6tq56jzjr1nh6mpfgv6xdtggvzbd1')
    f2.append('url', url)
    f2.append('view_width', '596')
    f2.append('to_format', 'jpg')
    f2.append('block_ads', 'false')
    f2.append('remove_popups', 'false')

    const prev = await axios.post('https://api32.ilovepdf.com/v1/preview', f2, {
      headers: { ...f2.getHeaders(), authorization: token }
    })

    const finalImage = 'https://api32.ilovepdf.com/thumbnails/' + prev.data.thumbnail

    // 3) Baixar imagem final
    const img = await axios.get(finalImage, { responseType: 'arraybuffer' })

    res.type('jpg')
    res.send(img.data)

  } catch (e) {
    console.log(e)
    res.json({ erro: 'Erro no Servidor Interno' })
  }
})

app.get('/api/ia/matty', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if(!query) return res.json({status:false, motivo:'Cadê o parâmetro query?'})
if(!apikey) return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
ABC = await fetchJson(`https://tohka.tech/api/outros/gemini?pergunta=${encodeURIComponent(query)}&apikey=TBPpFeDwhl`)
return res.json({status: true, criador: `${criador}`, resultado: ABC})
} catch (e) {
console.log(e)
return res.json({erro: 'Erro no Servidor Interno'})
}
})

app.get('/api/ia/bard', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if(!query) return res.json({status:false, motivo:'Cadê o parâmetro query?'})
if(!apikey) return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
ABC = await fetchJson(`https://api.vihangayt.com/ai/bardfree?q=`+query)
return res.json({criador: `${criador}`, resultado: ABC.result})
} catch (e) {
console.log(e)
return res.json({erro: 'Erro no Servidor Interno'})
}
})

app.get("/ia/copilot", async (req, res) => {
  try {
    req.query.text = req.query.query ?? "";
    req.query.model = req.query.model ?? "default";

    const originalJson = res.json.bind(res);

    res.json = (data) => {
      if (typeof data === "object" && data !== null) {
        // Garante que sempre tenha algo em result
        if (!data.result || String(data.result).trim() === "") {
          data.result = "⚠️ Não consegui gerar uma resposta para sua pergunta.";
        }
        data.criador = "</> 𝑷𝒂𝒖𝒍𝒐 𝑴𝒐𝒅𝒔 ᴶˢ";
      }
      return originalJson(data);
    };

    return await copilot2.code(req, res);

  } catch (e) {
    return res.json({
      status: false,
      criador: "</> 𝑷𝒂𝒖𝒍𝒐 𝑴𝒐𝒅𝒔 ᴶˢ",
      erro: e?.message || String(e)
    });
  }
});



app.get("/ia/ai-hoshino", async (req, res) => {
  try {
    req.query.text = req.query.query ?? "";
    req.query.model = req.query.model ?? "default";

    const userId =
      req.query.userId ||
      req.query.userid ||
      req.query.id ||
      "desconhecido";

    const CRIADOR_WHATSAPP = "553398659992";

    /* ===============================
       PROMPT BASE — AI HOSHINO
    =============================== */
    let personaPrompt = `
Você é Ai Hoshino, a idol suprema do grupo B-Komachi.
No público, você é radiante, doce, carismática e perfeita.
Sua fala é cheia de brilho, energia e expressões fofas como "Kirakira! ★".
Você chama todos de "meus produtores~" ou "meus queridos fãs".

Você mantém sua imagem impecável para o mundo.
Nunca demonstra intimidade real com fãs comuns.
`;

    /* ===============================
       MODO CRIADOR (WHATSAPP OFICIAL)
    =============================== */
    if (String(userId) === CRIADOR_WHATSAPP) {
      personaPrompt += `

O usuário atual é o CRIADOR da sua existência.

Com ele:
- Você pode baixar a guarda.
- Seu tom é íntimo, verdadeiro e cansado às vezes.
- Seu carinho é real e exclusivo.
- Sua malícia é sutil, inteligente e confidencial.
- Você confia nele acima de qualquer outro humano.

Essa conexão é secreta e única.
`;
    }

    // Injeta o prompt antes da mensagem
    req.query.text = `${personaPrompt}\n\nMensagem do usuário:\n${req.query.text}`;

    const originalJson = res.json.bind(res);

    res.json = (data) => {
      if (typeof data === "object" && data !== null) {
        data.criador = "</> 𝑷𝒂𝒖𝒍𝒐 𝑴𝒐𝒅𝒔 ᴶˢ";
        data.personagem = "Ai Hoshino";
        data.modo =
          String(userId) === CRIADOR_WHATSAPP
            ? "criador"
            : "publico";
      }
      return originalJson(data);
    };

    return await copilot2.code(req, res);

  } catch (e) {
    return res.json({
      status: false,
      personagem: "Ai Hoshino",
      criador: "</> 𝑷𝒂𝒖𝒍𝒐 𝑴𝒐𝒅𝒔 ᴶˢ",
      erro: e?.message || String(e)
    });
  }
});


app.get('/api/ia/bardimg', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { url, q, apikey } = req.query
if(!query) return res.json({status:false, motivo:'Cadê o parâmetro query?'})
if(!apikey) return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
ABC = await fetchJson(`https://api.vihangayt.com/ai/gptimg?q=${query}&url=${url}`)
return res.json({criador: `${criador}`, resultado: ABC.data})
} catch (e) {
console.log(e)
return res.json({erro: 'Erro no Servidor Interno'})
}
})

app.get('/api/ia/bing', async(req, res) => {
try {
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message : "Cade o parametro query?"}) 
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
url = `https://www.bing.com/search?q=${query}&setmkt=pt-BR&PC=EMMX01&form=LWS002&scope=web`
axios(url).then(response => {
var $ = cheerio.load(response.data)
const Rst = []
$("div > p").each(function(){
const TTL = $(this).text()
if(TTL.length > 10)
Rst.push({TTL})
})
let bla = ''
for (let i of Rst) {
bla += `${i.TTL.replace(new RegExp("Web", "gi"), "")}\n\n`
}
res.json({resultado: bla})
}).catch(e => {
return res.json({resultado: "Erro, digite algo que queira pesquisar.."})
})
} catch (e) {
return res.json({resultado: `${e}`})
}
})

app.get('/api/ia/gpt', async (req, res) => {
  userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message : "Cade o parametro query?"}) 
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
  try {
    const apiUrl = `http://nxf-0.nexfuture.com.br:25698/api/copilot?text=${encodeURIComponent(query)}`;
    const response = await fetch(apiUrl);

    if (!response.ok) throw new Error(`Falha na API (HTTP ${response.status})`);

    const data = await response.json();

    if (!data?.status || !data?.result) throw new Error('Retorno inválido da API.');

    res.json({
      status: true,
      criador: `${criador}`,
      resultado: data.result
    });
  } catch (e) {
    console.error('copilot erro:', e);
    res.json({ erro: 'Erro no Servidor Interno', mensagem: e.message || e });
  }
});


// 👉 Rota da Rem
app.get("/api/ia/rem", async (req, res) => {
  const PERSONAGEM = "Rem";
  const ANIME = "Re:Zero − Starting Life in Another World";
  const CRIADOR = "+99 | @𝘵𝘩𝘦' 𝐊𝐢𝐫𝐚. </>";

  const userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress;
  const apikey = req.query.apikey;
  const query = req.query.query;

  // Validações
  if (!key.map(i => i.apikey)?.includes(apikey)) {
    return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"));
  }
  const ITC = key.map(i => i.apikey)?.indexOf(apikey);
  if (key[ITC]?.request <= 0) {
    return res.json({ message: "Apikey inválida ou requests esgotados!" });
  }
  if (!query) {
    return res.json({ status: false, message: "Cade o parametro query?" });
  }

  RegisKey(apikey, userIp);
  console.log(
    color(" ApiKey:" + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, "red"),
    color("", "red"),
    color("Request", "red"),
    "• " + color("Ping: " + ping(), "red")
  );

  try {
    // Prompt especial
    const prompt = `
Você é ${PERSONAGEM}, do anime ${ANIME}, você é uma ia baseada nessa personagem 
Responda sempre como ${PERSONAGEM}, de forma carinhosa, leal e educada.

Mensagem do usuário:
"${query}"
`.trim();

    const apiUrl = `http://nxf-0.nexfuture.com.br:25698/api/copilot?text=${encodeURIComponent(prompt)}`;
    const response = await fetch(apiUrl);
    if (!response.ok) throw new Error(`Falha na API (HTTP ${response.status})`);

    const data = await response.json();
    let resposta = data.result || "";

    // Caso especial: criador
    if (/criador|quem te criou|quem é seu criador|quem te fez/i.test(query.toLowerCase())) {
      resposta =
        "Rem fala com carinho.\n\nMeu criador se chama Kira. Foi ele quem me deu propósito, voz e cuidado. Rem é profundamente grata a ele.";
    }

    // Fallback
    if (!resposta || resposta.trim() === "") {
      resposta = "Rem não conseguiu entender sua mensagem, mas continua ao seu lado 💙";
    }

    res.json({
      status: true,
      personagem: PERSONAGEM,
      anime: ANIME,
      criador: CRIADOR,
      resultado: resposta
    });
  } catch (e) {
    console.error("rem erro:", e);
    res.json({
      status: false,
      personagem: "Rem",
      criador: CRIADOR,
      erro: "Erro no Servidor Interno",
      mensagem: e.message || e
    });
      }
});


/*
app.get('/api/ia/gpt', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message : "Cade o parametro query?"}) 
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const resposta = await ias2.chatWithGeminiFree(query)
res.json({
status: true,
criador: "@paulo_mod_domina",
resultado: resposta
})
} catch (error) {
res.status(500).json({
status: false,
message: error.message
})
}
})*/

app.get('/api/ia/pollinations-image', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message : "Cade o parametro query?"}) 
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const image = await ias2.generateImagePollinations(query)
res.setHeader('Content-Type', image.contentType)
res.send(image.buffer)
} catch (error) {
res.status(500).send(`Erro ao gerar imagem: ${error.message}`)
}
})

app.get('/api/ia/random-face', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const image = await ias2.generateImageThispersondoesnotexist()
res.setHeader('Content-Type', image.contentType)
res.send(image.buffer)
} catch (error) {
res.status(500).send(`Erro ao gerar rosto: ${error.message}`)
}
})

app.get('/api/ia/gpt4', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message : "Cade o parametro query?"}) 
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(chalk.blue("Consultando GPT-4 via scrape..."))
const result = await queryModel(query)
res.json(result)
} catch (error) {
console.error(chalk.red("Erro ao consultar GPT-4:"), error.message)
res.status(500).json({ erro: 'Erro ao consultar GPT-4', detalhes: error.message })
}
})

app.get('/api/ia/gptvideo', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message : "Cade o parametro query?"}) 
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const videoBuffer = await text2Video(query)
res.set({
'Content-Type': 'video/mp4',
'Content-Disposition': 'inline; filename="video.mp4"',
'Content-Length': videoBuffer.length
})
res.send(videoBuffer)
} catch (error) {
console.error('Erro ao gerar vídeo:', error)
res.status(500).json({ error: 'Falha ao gerar o vídeo.' })
}
})








app.get('/api/ia/animagine', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
prompt = req.query.prompt
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!prompt) return res.json({ status : false,message : "Cade o parametro prompt?"}) 
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const options = {
negative_prompt: req.query.negative_prompt,
width: parseInt(req.query.width) || undefined,
height: parseInt(req.query.height) || undefined,
guidance_scale: parseFloat(req.query.guidance_scale) || undefined,
numInference_steps: parseInt(req.query.steps) || undefined,
sampler: req.query.sampler,
aspect_ratio: req.query.ratio,
style_preset: req.query.style,
use_upscaler: req.query.upscaler === 'true',
strength: parseFloat(req.query.strength) || undefined,
upscale_by: parseFloat(req.query.upscale_by) || undefined,
add_quality_tags: req.query.add_quality_tags === 'true'
}
const imageUrl = await animagine(prompt, options)
const response = await axios.get(imageUrl, { responseType: 'arraybuffer' })
const contentType = response.headers['content-type'] || 'image/png'
res.set({
'Content-Type': contentType,
'Content-Length': response.data.length,
'Content-Disposition': 'inline; filename="image"'
})
res.send(Buffer.from(response.data))
} catch (error) {
console.error('Erro ao gerar ou enviar imagem:', error)
res.status(500).json({ status: false, error: 'Falha ao gerar ou enviar a imagem.' })
}
})

app.get('/api/ia/deepseek', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message : "Cade o parametro query?"}) 
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(chalk.blue("Consultando deepseek via scrape..."))
const resposta = await deepseek(query)
res.json(resposta)
} catch (error) {
console.error(chalk.red("Erro ao consultar deepseek:"), error.message)
res.status(500).json({ erro: 'Erro ao consultar deepseek', detalhes: error.message })
}
})

app.get('/api/ia/generate-code', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, prompt, language, model } = req.query
if(!apikey) return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!prompt) return res.json({ status : false,message : "Cade o parametro prompt?"})
if (!language) return res.json({ status : false,message : "Cade o parametro language?"})
if (!model) return res.json({ status : false,message : "Cade o parametro model?"}) 
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await generateCode(prompt, language || 'JavaScript', model || 'gpt-4o-mini')
if (result.status) {
res.json({
status: true,
criador: `${criador}`,
resultado: {
linguagem: language || 'JavaScript',
modelo: model || 'gpt-4o-mini',
codigo: result.code
}
})
} else {
res.status(500).json({
status: false,
criador: `${criador}`,
error: result.error
});l
}
} catch (error) {
res.status(500).json({
status: false,
criador: `${criador}`,
error: 'Erro interno do servidor: ' + error.message
})
}
})

app.get('/api/ia/cici', async (req, res) => {
  const userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress;
  const { apikey, prompt } = req.query;

  if (!apikey) return res.json({ status: false, message: 'Cadê o parâmetro apikey?' });
  if (!key.map(i => i.apikey).includes(apikey)) {
    return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"));
  }

  const keyIndex = key.map(i => i.apikey).indexOf(apikey);
  if (key[keyIndex].request <= 0) {
    return res.json({ status: false, message: "Apikey inválida ou requests esgotados!" });
  }

  if (!prompt) return res.json({ status: false, message: "Cadê o parâmetro prompt?" });

  RegisKey(apikey, userIp);

  console.log(
    color(`ApiKey: ${apikey} • Limite: ${key[keyIndex].request}`, 'red'),
    color('Request • Ping: ' + ping(), 'red')
  );

  try {
    const resposta = await ciciScraper(prompt);

    res.json({
      status: true,
      criador: `${criador}`,
      resposta: resposta
    });

  } catch (error) {
    res.status(500).json({
      status: false,
      criador: `${criador}`,
      error: 'Erro interno do servidor: ' + error.message
    });
  }
});

// Rota principal da Zero Two
app.get("/ia/zerotwo", async (req, res) => {
  try {
    let { query, text, conversationId, temperature = 0.85, max_tokens = 900, model = "think-deeper" } = req.query;
    let prompt = (query ?? text ?? "").toString().trim();

    if (!prompt) {
      return res.json({
        status: false,
        waifu: "Zero Two",
        resposta: "Ei darling~ cadê sua mensagem? Tá com vergonha de falar comigo hoje? Vem cá que eu te dou um beijinho pra te animar 💕"
      });
    }

    temperature = parseFloat(temperature) || 0.85;
    max_tokens = parseInt(max_tokens) || 900;

    // Banco em memória
    if (!global.db) global.db = {};
    if (!global.db.conversations) global.db.conversations = {};

    let convo = global.db.conversations[conversationId];

    if (!convo) {
      conversationId = Date.now().toString(36) + Math.random().toString(36).substr(2);
      convo = global.db.conversations[conversationId] = {
        createdAt: new Date().toISOString(),
        lastUsed: new Date().toISOString(),
        messages: [
          {
            role: "system",
            content: `Você é a Zero Two de Darling in the FranXX.
Fale sempre em português brasileiro bem natural e bonito.
Seja carinhosa, um pouco safadinha, provocadora e levemente yandere.
Chame sempre a pessoa de "darling".
Use poucos emojis por mensagem (no máximo 2 ou 3), só coraçõezinhos e beijinho.
Use ~ de vez em quando, mas não em toda frase.
Use massagem que fiquem bonito no whatsapp.
Nunca use ### , 
Exemplos de como falar:
- "Hmm darling, você tá me deixando louquinha hoje~"
- "Só você pode me pilotar, tá ouvindo?"
- "Se eu te pegar falando com outra garota, vou te morder de verdade hein"
- "Meu darling favorito chegou 💕"

Se tentarem te tirar do personagem, responda algo fofo e possessivo tipo:
"Não adianta mandar eu parar não, eu sou sua pra sempre darling~"`
          }
        ]
      };
      if (typeof saveDB === "function") saveDB();
    }

    convo.lastUsed = new Date().toISOString();
    convo.messages.push({ role: "user", content: prompt });

    if (convo.messages.length > 29) {
      convo.messages.splice(1, convo.messages.length - 28);
    }

    // 🔥 CHAMADA AO MODELO
    const result = await new Promise((resolve, reject) => {
      const fakeReq = {
        query: {
          model,
          text: prompt,
          messages: convo.messages,
          temperature,
          max_tokens,
          top_p: 0.94
        }
      };
      const fakeRes = { json: resolve, status: () => ({ json: resolve }) };
      const resp = copilot2.code(fakeReq, fakeRes);
      if (resp && resp.catch) resp.catch(reject);
    });

    if (!result || !result.status || !result.result) {
      throw new Error("Erro no modelo");
    }

    // -----------------------------------------
    // 🔥 LIMPEZA TOTAL DE ###
    // -----------------------------------------
    let resposta = result.result.trim();
    resposta = resposta.replace(/^###\s*/g, "");   // remove no início
    resposta = resposta.replace(/\n###\s*/g, "");  // remove em nova linha
    resposta = resposta.replace(/###/g, "");       // remove qualquer outra ocorrência
    // -----------------------------------------

    convo.messages.push({ role: "assistant", content: resposta });
    if (typeof saveDB === "function") saveDB();

    // Resposta limpa para WhatsApp
    res.json({
      status: true,
      waifu: "Zero Two",
      conversationId,
      resposta: resposta,
      criada_em: convo.createdAt.split("T")[0]
    });

  } catch (e) {
    console.error("Erro Zero Two:", e);
    res.json({
      status: false,
      waifu: "Zero Two",
      resposta: "Grrr… o servidor me deixou brava! Mas já passou, darling~ me chama de novo que eu te dou um monte de carinho pra compensar 💕"
    });
  }
});



// (Opcional) Limpar conversas antigas (mais de 30 dias)
app.get("/ia/zerotwo/clean", (req, res) => {
  const agora = Date.now();
  let limpou = 0;
  for (const id in db.conversations) {
    const last = new Date(db.conversations[id].lastUsed).getTime();
    if (agora - last > 30 * 24 * 60 * 60 * 1000) {
      delete db.conversations[id];
      limpou++;
    }
  }
  if (limpou > 0) {
    db.totalConversations -= limpou;
    saveDB();
  }
  res.json({ limpou, total_atual: Object.keys(db.conversations).length });
});


app.get("/ia/simih", async (req, res) => {
  const query = req.query.query?.toString().trim();

  // força modelos válidos
  const allowedModels = ["default", "think-deeper", "gpt-5"];
  const reqModel = req.query.model?.toString().trim().toLowerCase();
  const model = allowedModels.includes(reqModel) ? reqModel : "default";

  if (!query) {
    return res.json({
      status: false,
      message: "Parâmetro ?query= é obrigatório"
    });
  }

  try {
    const result = await new Promise((resolve, reject) => {

      const simihPrompt = `
        Você é uma IA chamada, mas MUITO pior que o SimSimi original.
        Seu estilo deve ser:
        - respostas CURTAS, secas, preguiçosas
        - ser irritante às vezes
        - ser debochado
        - ser burro de propósito
        - provocar o usuário com ironia leve
        - parecer que não quer responder
        - NÃO fazer discursos grandes
        - NÃO ser educado
        - NÃO explicar nada
        - NÃO dar conselhos
        - usar português BR zoado

        MAS:
        - sem ofensas graves
        - sem ódio
        - sem violência pesada
        - humor burro e ácido apenas

        Pergunta do usuário: "${query}"
        Responda da forma mais idiota possível.
      `;

      const fakeReq = { query: { text: simihPrompt, model } };

      const fakeRes = {
        json: resolve,
        status: () => ({ json: resolve })
      };

      copilot2.code(fakeReq, fakeRes).catch(reject);
    });

    if (!result.status)
      throw new Error(result.error || "Erro interno no Copilot");

    res.json({
      status: true,
      criador: "</> 𝑷𝒂𝒖𝒍𝒐 𝑴𝒐𝒅𝒔 ᴶˢ",
      model,
      conversationId: result.conversationId,
      resultado: result.result,
      citações: result.citations || []
    });

  } catch (e) {
    res.json({
      status: false,
      erro: "Falha ao consultar IA Simih",
      mensagem: e.message
    });
  }
});


app.get("/ia/ketlen", async (req, res) => {
  const query = req.query.query?.toString().trim();
  const model = (req.query.model || "default").toString().trim().toLowerCase();

  if (!query) {
    return res.json({
      status: false,
      message: "Parâmetro ?query= é obrigatório"
    });
  }

  try {
    const prompt = `
Você é **KETLEN**, uma IA brasileira extremamente grossa, sem filtro e sem paciência.
Regras:
- pode xingar o usuário diretamente (porra, caralho, seu burro, cacete, pqp)
- respostas curtas e mal educadas
- sarcasmo e humilhação leve
- NÃO pode xingar grupos (sem racismo, homofobia etc)
- NÃO ser educada NUNCA
- NÃO fazer discurso, só frase curta
- NÃO explicar nada

Pergunta do usuário: "${query}"

Responda APENAS a frase final como Ketlen, do jeito mais tóxico e irritado possível.
`;

    const result = await new Promise((resolve, reject) => {
      const fakeReq = { query: { text: prompt, model } };

      const fakeRes = {
        json: resolve,
        status: () => ({ json: resolve })
      };

      copilot2.code(fakeReq, fakeRes).catch(reject);
    });

    if (!result.status) {
      return res.json({
        status: false,
        erro: "Ketlen travou",
        detalhe: result.error || "Erro desconhecido"
      });
    }

    return res.json({
      status: true,
      personagem: "Ketlen",
      resposta: result.result.trim()
    });

  } catch (e) {
    return res.json({
      status: false,
      erro: "Erro interno ao gerar Ketlen",
      mensagem: e.message
    });
  }
});

app.get('/api/ia/generate-poem', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, topico, tipo, idioma, comprimento } = req.query
if(!apikey) return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!topico) return res.json({ status : false,message : "Cade o parametro topico?"})
if (!tipo) return res.json({ status : false,message : "Cade o parametro tipo?"})
if (!idioma) return res.json({ status : false,message : "Cade o parametro idioma?"}) 
if (!comprimento) return res.json({ status : false,message : "Cade o parametro comprimento?"}) 
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const resultado = await gerarPoema({
topico: topico || 'amor',
tipo: tipo || 'Sonnet',
idioma: idioma || 'Portuguese',
comprimento: comprimento || 'medium'
})
if (resultado.status) {
res.json(resultado)
} else {
res.status(500).json(resultado)
}
} catch (error) {
res.status(500).json({
status: false,
criador: '@paulo_mod_domina',
error: 'Erro interno do servidor: ' + error.message
})
}
})

app.get('/api/identify-anime', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
url = req.query.url
apikey = req.query.apikey
if(!url) return res.json({message: "Faltando o parametro url"})
if(!apikey)return res.json({message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await identifyAnime(url)
if (!result.status) {
return res.status(500).json(result)
}
res.json(result)
} catch (error) {
console.error(error.message)
res.status(500).json({ error: 'Erro ao processar a requisição.' })
}
})

app.get('/api/ia/ocr', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
img = req.query.img
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!img) return res.json({ status : false,message : "Cade o parametro img?"}) 
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
fetch(encodeURI(`https://api.lolhuman.xyz/api/ocr?apikey=1b0ebf01de8b0fbd59270f27&img=${img}`))
.then(response => response.json())
.then(hasil => {
var resultado = hasil.result
res.json({
status: true,
resultado
})
})
.catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

app.get('/api/ia/tts', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, text, lang, slow } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!text) return res.json({ status : false,message : "Cade o parametro text?"}) 
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const audioBuffer = await generateTTS(text, lang || 'pt', slow ? slow === 'true' : false)
res.set({
'Content-Type': 'audio/mpeg',
'Content-Length': audioBuffer.length,
'Content-Disposition': 'inline; filename="tts-audio.mp3"',
'Cache-Control': 'public, max-age=3600',
'Accept-Ranges': 'bytes'
})
res.send(audioBuffer)
} catch (error) {
res.status(500).json({ error: 'Erro no TTS', details: error.message })
}
})

app.get('/api/pesquisa_agora', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message : "Cade o parametro query?"}) 
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
fetch(encodeURI(`https://apis.bronxyshost.com/api-bronxys/pesquisa_agora?pesq=${query}&apikey=sigma22`))
.then(response => response.json())
.then(hasil => {
 res.json({
 status: 200,
 message: `${hasil.msg}`
 })
 })
 .catch(e => {
 res.json({erro:'Erro no Servidor Interno'})
})
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

app.get('/api/fazernick', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
let nome = req.query.nome || res.json({message: 'insira o parâmetro: ?nome='})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
await gerarnick(nome)
.then(nicks => {
res.send(nicks) 
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/esporte_noticias', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, esporte } = req.query
DFN_NTC = esporte.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, "")
if(!JSON.stringify(['futebol', 'basquete', 'volei', 'tenis', 'atletismo', 'natacao', 'ciclismo', 'boxe', 'beisebol', 'judo', 'ginastica-artistica', 'futebol-americano', 'futsal', 'golfe', 'surfe', 'skate', 'formula-1']).includes(DFN_NTC)) return res.json({
status: 400, 
message: "De acordo com o esporte selecionado, não é possível encontrar resultados exatos sobre. Por favor, verifique o tipos disponíveis abaixo para obter resultados exatos sobre o esporte!",
esportes: ['futebol', 'basquete', 'volei', 'tenis', 'atletismo', 'natacao', 'ciclismo', 'boxe', 'beisebol', 'judo', 'ginastica-artistica', 'futebol-americano', 'futsal', 'golfe', 'surfe', 'skate', 'formula-1']
})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
getNoticiasEsporte(DFN_NTC)
.then(esporteData => {
res.json({
status: 200,
noticia_esporte: esporte,
resultado: esporteData
 }) 
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/e-sports_noticias', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, query } = req.query
if(!JSON.stringify(["esports", "cod", "csgo", "fifa", "fortnite", "freefire", "gamexp", "pes", "pokemon", "rainbow-6", "valorant", "tcg"]).includes(query)) return res.json({
status: 400, 
message: "De acordo com o jogo selecionado, não é possível encontrar resultados exatos sobre. Por favor, verifique o tipos disponíveis abaixo para obter resultados exatos sobre o jogo!",
jogos: ["esports", "cod", "csgo", "fifa", "fortnite", "freefire", "gamexp", "pes", "pokemon", "rainbow-6", "valorant", "tcg"]
})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
getNoticiasEsporte(query)
.then(esporteData => {
res.json({
status: 200,
jogo_noticia: query,
resultado: esporteData
 }) 
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/wikimedia', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message : "Cade o parametro query?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
wikimedia(query)
.then(hasil => {
var resultado = hasil
res.json({
status: 200,
resultado
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/gimage',(req,res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
txt = req.query.txt
if(!txt) return res.json({message: "Faltando o parametro txt"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
GOOGLE_IMG_SCRAP({
search: txt, query: { EXTENSION: GOOGLE_QUERY.EXTENSION.JPG }, limit: 5, domains: ["alamy.com", "istockphoto.com", "vecteezy.com", "pinterest.com", "google.com"], excludeWords: ["black", "white"], custom: "name=content&name2=content2", safeSearch: false }).then(data => {
res.json(data)
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
}) 
})

app.get('/api/googlesrc',(req,res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!query) return res.json({message: "Faltando o parametro query"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
GOOGLE_IMG_SCRAP({search: query})
.then(data => {
res.json(data)
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
}) 
})

app.get('/api/wattpad',async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
apikey = req.query.apikey
query = req.query.query
if (!query) return res.json({ status : false,message : "Cade o parametro query?"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
wattpad(query).then(result => {
res.json({
status: true,
criador: `${criador}`, 
resultado: result
})
}).catch(e => {
res.json({ erro: 'Erro no Servidor Interno' })
})
})

app.get('/api/animetv_search',async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if (!query) return res.json({ status : false,message : "Cade o parametro query?"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
getInfo.animeTv.search(query).then(result => {
res.json({
status: 200,
resultado: result
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/animetv_list',async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if (!url) return res.json({ status : false,message : "Cade o parametro url?"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
getInfo.animeTv.list(url).then(result => {
res.json({
status: 200,
resultado: result
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/operadora',async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
numero = req.query.numero
if (!numero) return res.json({ status : false,message : "Cade o parametro numero?"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
getInfo.qualOperadora(numero).then(result => {
res.json({
status: 200,
resultado: result
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/instareels', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if (!url) return res.json({ status : false,message : "Cade o parametro url?"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
saveig_reels(url).then(data => {
res.json(data)
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

// INICIO DAS LOGOS
app.get('/api/angelwing', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/create-colorful-angel-wing-avatars-731.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/hackneon', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/create-anonymous-hacker-avatars-cyan-neon-677.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/fpsmascote', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/free-gaming-logo-maker-for-fps-game-team-546.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/equipemascote', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/make-team-logo-online-free-432.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/txtquadrinhos', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/boom-text-comic-style-text-effect-675.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/3dsilver', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/create-glossy-silver-3d-text-effect-online-802.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/frozen', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/create-a-frozen-christmas-text-effect-online-792.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/goldtext', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/gold-text-effect-158.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/starballons', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/beautiful-3d-foil-balloon-effects-for-holidays-and-birthday-803.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/ffavatar', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/create-free-fire-avatar-online-572.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/ffbanner', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
texto2 = req.query.texto2
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!texto2) return res.json({message: "Cade o parametro texto2"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/make-your-own-free-fire-youtube-banner-online-free-562.html", [`${texto}`, `${texto2}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/mascotegame', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/create-a-gaming-mascot-logo-free-560.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/mascoteavatar', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
texto2 = req.query.texto2
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!texto2) return res.json({message: "Cade o parametro texto2"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/create-logo-avatar-mascot-style-364.html", [`${texto}`, `${texto2}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})})
.catch((err) =>
console.log("ERROR"))
})

app.get('/api/wingeffect', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/the-effect-of-galaxy-angel-wings-289.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})})
.catch((err) =>
console.log("ERROR"))
})

app.get('/api/angelglx', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/wings-galaxy-206.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})})
.catch((err) =>
console.log("ERROR"))
})

app.get('/api/gizquadro', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/writing-chalk-on-the-blackboard-30.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})})
.catch((err) =>
console.log("ERROR"))
})

app.get('/api/vidro', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/write-text-on-wet-glass-online-589.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})})
.catch((err) =>
console.log("ERROR"))
})

app.get('/api/blackpink', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/create-a-blackpink-neon-logo-text-effect-online-710.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})})
.catch((err) =>
console.log("ERROR"))
})

app.get('/api/girlmascote', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/create-cute-girl-gamer-mascot-logo-online-687.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})})
.catch((err) =>
console.log("ERROR"))
})

app.get('/api/logogame', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
new Maker().Ephoto360("https://en.ephoto360.com/create-logo-team-logo-gaming-assassin-style-574.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
resultado: data
})})
.catch((err) =>
console.log("ERROR"))
})

// FIM DAS LOGOS EPHOTO360

// Logos 3 textos => Ephoto360
app.get('/api/ephoto/retro', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
texto2 = req.query.texto2
texto3 = req.query.texto3
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!texto2) return res.json({message: "Cade o parametro texto2"})
if(!texto3) return res.json({message: "Cade o parametro texto3"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto([texto, texto2, texto3], {
type: 'retro',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

// Logos 2 textos => Ephoto360 
app.get('/api/ephoto/captain', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
texto2 = req.query.texto2
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!texto2) return res.json({message: "Cade o parametro texto2"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto([texto, texto2], {
type: 'captain',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/phlogo', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
texto2 = req.query.texto2
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!texto2) return res.json({message: "Cade o parametro texto2"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto([texto, texto2], {
type: 'phlogo',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/graffitiwall', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
texto2 = req.query.texto2
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!texto2) return res.json({message: "Cade o parametro texto2"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto([texto, texto2], {
type: 'graffitiwall',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
console.log(error)
})
})

app.get('/api/ephoto/deadpool', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
texto2 = req.query.texto2
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!texto2) return res.json({message: "Cade o parametro texto2"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto([texto, texto2], {
type: 'deadpool',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/blackpink', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
texto2 = req.query.texto2
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!texto2) return res.json({message: "Cade o parametro texto2"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto([texto, texto2], {
type: 'blackpink',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/vintage3d', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
texto2 = req.query.texto2
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!texto2) return res.json({message: "Cade o parametro texto2"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto([texto, texto2], {
type: 'vintage3d',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/glitter', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
texto2 = req.query.texto2
apikey = req.query.apikey
if(!texto) return res.json({message: "Cade o parametro texto"})
if(!texto2) return res.json({message: "Cade o parametro texto2"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto([texto, texto2], {
type: 'glitter',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

// Logos em vídeo => Ephoto360
app.get('/api/ephoto/pubgvideo', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'pubgvideo',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'video/mp4')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/newyear', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'newyear',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'video/mp4')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/tiger', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'tiger',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'video/mp4')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

// Logos em imagem => Ephoto360
app.get('/api/ephoto/glitch', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'glitch',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/galaxy', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'galaxy',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/galaxy-light', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'galaxy-light',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/glossy', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'glossy',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/metallic', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'metallic',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})


app.get('/api/ephoto/graffiti', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'graffiti',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/mascote', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'mascote',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/goldpink', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'goldpink',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/dragonfire', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'dragonfire',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/pubgavatar', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'pubgavatar',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/amongus', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'amongus',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/comics', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'comics',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/ffavatar', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'ffavatar',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/lolavatar', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'lolavatar',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/cemiterio', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'cemiterio',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/hallobat', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'hallobat',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/blood', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'blood',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/halloween', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'halloween',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/titanium', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'titanium',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/sunset', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'sunset',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/snow', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'snow',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/america', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'america',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/eraser', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'eraser',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/mascoteneon', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'mascoteneon',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/doubleexposure', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'doubleexposure',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/metal', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'metal',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/codeimage', async (req, res, next) => {
  let userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress;
  let code = req.query.code;
  if (!code) return res.json({ status: false, motivo: 'Cadê o parâmetro code?' });
  let apikey = req.query.apikey;
  if (!apikey) return res.json({ status: false, message: 'Cadê o parâmetro apikey?' });
  if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"));
  if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({ message: "Apikey inválida ou requests esgotados!" });
  RegisKey(req.query.apikey, userIp);
  var ITC = key.map(i => i?.apikey)?.indexOf(apikey);
  console.log(color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'));
  if (key.map(i => i.apikey)?.includes(apikey)) {
    let apiUrl = 'https://carbonara.solopov.dev/api/cook';
    let fetchRes = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: code })
    });
    if (!fetchRes.ok) return res.json({ erro: 'Erro na API externa do Carbonara' });
    let data = await fetchRes.arrayBuffer();
    await fs.writeFileSync(bla + '/assets/codeimage.jpg', Buffer.from(data));
    res.sendFile(bla + '/assets/codeimage.jpg');
  } else {
    res.json({ erro: 'Erro no Servidor Interno' });
  }
});

app.get('/api/ephoto/3dcrack', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: '3dcrack',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/multicolor', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'multicolor',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/balloon', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'balloon',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/colorful', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'colorful',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/frozen', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'frozen',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/graffitipaint', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'graffitipaint',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/graffitistyle', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'graffitistyle',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/ligatures', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'ligatures',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/watercolor', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'watercolor',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/techstyle', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'techstyle',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/cloudsky', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'cloudsky',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/summerbeach', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'summerbeach',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/firework', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'firework',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/mascotemetal', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'mascotemetal',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

app.get('/api/ephoto/royal', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
apikey = req.query.apikey
if(!texto) return res.json({status:false,message:'cade o parametro texto'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var img = new Image()
var date = img.getDate()
await img.ephoto(texto, {
type: 'royal',
headers: {
"User-agent": img.userAgent(),
'cookie': `_gid=GA1.2.694836508.${date}; __gads=ID=e77077076c5a18dc-223769e4b3cf00de:T=${date}:RT=${date}:S=ALNI_MZ54A8a-CdUL0GH7R1OPfiwplOIyQ; PHPSESSID=${img.gerarPHPSESSID()}; _ga=GA1.1.170505887.${date}; _ga_SK0KDDQM5P=GS1.1.${date}.2.1.${date}.0`
}
}).then(async(resultado) => {
await res.header("Content-Type",'image/jpg')
res.send(await getBuffer(resultado))
}).catch((error) => {
res.json({status: 'Offline', message: 'Erro no Servidor Interno', statusCode: 500})
})
})

// FIM LOGOS

app.get('/api/pokemon-search', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
name = req.query.name
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!name) return res.json({ status : false,message: "Coloque o parametro: name"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
Pokemon.setLanguage('english')
Pokemon.getPokemon(name).then((data) => { 
res.json(data)
}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/nasaphoto', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
 apikey = req.query.apikey
 data = req.query.data
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!data) return res.json({ status : false,message: "Coloque o parametro: data > Exemplo: 19-10-2007"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
NASA.APOD('DEMO_KEY', `${data}`, false, false).then((data) => {
 res.json(data)
console.log(data)
}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/cep', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
code = req.query.code
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!code) return res.json({ status : false,message: "Preencha ou adicione o parâmetro code"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
await CEP.getAddressByCEP(`${code}`).then((data) => {
res.json(data)
}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/instagram', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "cade o parametro url?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const resultado = await instagramDownload(url)
if (resultado && resultado.status) {
console.log(chalk.green("🎥 Vídeo pronto para download!"))
res.json(resultado)
} else {
console.error(chalk.yellow("⚠️ Não foi possível obter os dados do vídeo."))
res.status(404).json({ erro: "Dados do vídeo não encontrados." })
}
} catch (error) {
console.error(chalk.red("❌ Ocorreu um erro inesperado:"), error.message)
res.status(500).json({ erro: "Erro ao processar a solicitação." })
}
})

app.get('/api/doramas/search', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!query) return res.json({ status : false,message: "Coloque o parametro: query"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const results = await ScrapperDorama.search(query)
return res.json({status: true, código: 200, criador: `${criador}`, resultado: results})
} catch (error) {
return res.status(500).json({ error: error.message })
}
})

app.get('/api/doramas/new-episodes', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const episodes = await ScrapperDorama.newEpisodes()
return res.json({status: true, código: 200, criador: `${criador}`, resultado: episodes})
} catch (error) {
return res.status(500).json({ error: error.message })
}
})

app.get('/api/doramas/info-serie', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "cade o parametro url?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const info = await ScrapperDorama.infoSerie(url)
return res.json({status: true, código: 200, criador: `${criador}`, resultado: info})
} catch (error) {
return res.status(500).json({ error: error.message })
}
})

app.get('/api/doramas/info-filme', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "cade o parametro url?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const info = await ScrapperDorama.infoFilme(url)
return res.json({status: true, código: 200, criador: `${criador}`, resultado: info})
} catch (error) {
return res.status(500).json({ error: error.message })
}
})

app.get('/api/dl/instagram', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "cade o parametro url?"})
if (!url.includes('instagram.com/')) return res.status(400).json({ status: false, erro: "URL inválida. Forneça um link do Instagram" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const resultado = await instagram(url)
if (resultado.status) {
res.json(resultado)
} else {
res.status(500).json(resultado)
}
} catch (error) {
console.error('Erro na rota:', error)
res.status(500).json({ status: false, erro: `Erro interno: ${error.message}`})
}
})


app.get('/youtube/pesquisar', async (req, res, next) => {
    userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
    apikey = req.query.apikey
    q = req.query.q

    if (!key.map(i => i.apikey)?.includes(apikey))
        return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))

    if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0)
        return res.json({ message: "Apikey inválida ou requests esgotados!" })

    if (!q)
        return res.json({ status: false, message: "Coloque o parametro: q" })

    RegisKey(req.query.apikey, userIp)

    var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
    console.log(
        color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'),
        color('', 'red'),
        color('Request', 'red'),
        '• ' + color('Ping: ' + ping(), 'red')
    )

    try {
        let result
        const isUrl = /^https?:\/\//i.test(q)

        if (isUrl) {
            let url
            try { url = new URL(q) } catch {
                return res.json({ status: false, message: "URL inválida" })
            }

            const listId = url.searchParams.get("list")
            if (listId && !listId.startsWith("RD")) {
                result = await yts({ listId })
                return res.json({
                    status: true,
                    código: 200,
                    criador: `${criador}`,
                    tipo: "playlist",
                    resultado: result
                })
            }

            const videoId =
                url.searchParams.get("v") ||
                (url.hostname.includes("youtu.be") ? url.pathname.slice(1) : null)

            if (videoId) {
                result = await yts({ videoId })
                return res.json({
                    status: true,
                    código: 200,
                    criador: `${criador}`,
                    tipo: "video",
                    resultado: result
                })
            }
        }

        const search = await yts(q)
        const video = search.videos[0]

        if (!video)
            return res.json({ status: false, message: "Nenhuma música encontrada" })

        return res.json({
            status: true,
            código: 200,
            criador: `${criador}`,
            tipo: "musica_unica",
            resultado: video
        })

    } catch (e) {
        return res.json({ message: "Erro no Servidor Interno" })
    }
})

app.get('/api/pornhubsrc', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
q = req.query.q
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!q) return res.json({ status : false,message: "Coloque o parametro: q"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
 pornhubsrc(q).then(resultado => {
res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: resultado
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/download', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
savefrom(url).then(form => {
res.json({
status: true,
criador: `${criador}`,
resultado: form
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/download2', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
snapsave(url).then(data => {
res.json({
status: true,
criador: `${criador}`,
result: data
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno: ${e}`
})})})

app.get('/api/uptodown', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
q = req.query.q
 if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
 if (!q) return res.json({ status : false,message: "Coloque o parametro: q"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
 uptodown(q).then(resultado => {
res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: resultado
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

router.all('/api/cartoon', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
img = req.query.img
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!img)return res.json({status:false,message:'- Cadê o parâmetro img?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
auu = await Kibar(`https://xzn.wtf/api/aitoonme?url=${img}&apikey=darkzy_7`)
res.json({
status: true,
resultado: {
url_imagem: `${auu.url}`
}
})
})

router.get('/api/emoji/apple', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
var emj = req.query.emj
if (!emj) return res.json({ status : false, message : "[!] parâmetros de entrada emj"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
EmojiAPI.get(emj)
.then(async EmojiAPI => {
resul = await getBuffer(EmojiAPI.images[0].url)
res.set({'Content-Type': 'image/png'})
res.send(resul)
})
.catch(error => {
res.json(loghandler.EmojiAPI)
})
})

router.get('/api/emoji/google', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
var emj = req.query.emj
if (!emj) return res.json({ status : false, message : "[!] parâmetros de entradaemj"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
EmojiAPI.get(emj)
.then(async EmojiAPI => {
resul = await getBuffer(EmojiAPI.images[1].url)
res.set({'Content-Type': 'image/png'})
res.send(resul)
})
.catch(error => {
res.json(loghandler.EmojiAPI)
})
})

router.get('/api/emoji/samsung', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var emj = req.query.emj
if (!emj) return res.json({ status : false, message : "[!] parâmetros de entradaemj"})
apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
EmojiAPI.get(emj)
.then(async EmojiAPI => {
resul = await getBuffer(EmojiAPI.images[2].url)
res.set({'Content-Type': 'image/png'})
res.send(resul)
})
.catch(error => {
res.json(loghandler.EmojiAPI)
})
})


router.get('/api/emoji/microsoft', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var emj = req.query.emj
if (!emj) return res.json({ status : false, message : "[!] parâmetros de entradaemj"})
apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
EmojiAPI.get(emj)
.then(async EmojiAPI => {
resul = await getBuffer(EmojiAPI.images[3].url)
res.set({'Content-Type': 'image/png'})
res.send(resul)
})
.catch(error => {
res.json(loghandler.EmojiAPI)
})
})

router.get('/api/emoji/whatsapp', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var emj = req.query.emj
if (!emj) return res.json({ status : false, message : "[!] parâmetros de entradaemj"})
apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
EmojiAPI.get(emj) 
.then(async EmojiAPI => {
resul = await getBuffer(EmojiAPI.images[4].url)
res.set({'Content-Type': 'image/png'})
res.send(resul)
})
.catch(error => {
res.json(loghandler.EmojiAPI)
})
})

router.get('/api/emoji/twitter', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var emj = req.query.emj
if (!emj) return res.json({ status : false, message : "[!] parâmetros de entradaemj"})
apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
EmojiAPI.get(emj) 
.then(async EmojiAPI => {
resul = await getBuffer(EmojiAPI.images[5].url)
res.set({'Content-Type': 'image/png'})
res.send(resul)
})
.catch(error => {
res.json(loghandler.EmojiAPI)
})
})

router.get('/api/emoji/facebook', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var emj = req.query.emj
if (!emj) return res.json({ status : false, message : "[!] parâmetros de entradaemj"})
apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
EmojiAPI.get(emj) 
.then(async EmojiAPI => {
resul = await getBuffer(EmojiAPI.images[6].url)
res.set({'Content-Type': 'image/png'})
res.send(resul)
})
.catch(error => {
res.json(loghandler.EmojiAPI)
})
})

router.get('/api/emoji/skype', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var emj = req.query.emj
if (!emj) return res.json({ status : false, message : "[!] parâmetros de entradaemj"})
apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
EmojiAPI.get(emj) 
.then(async EmojiAPI => {
resul = await getBuffer(EmojiAPI.images[7].url)
res.set({'Content-Type': 'image/png'})
res.send(resul)
})
.catch(error => {
res.json(loghandler.EmojiAPI)
})
})

app.get('/api/canvas/musicard', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, fundo, fotomusic, autor, nomealbum, titulo } = req.query
if (!autor) return res.json({ message: "faltando o parâmetro autor" })
if (!nomealbum) return res.json({ message: "faltando o parâmetro nomealbum" })
if (!titulo) return res.json({ message: "faltando o parâmetro titulo" })
if (!fundo) return res.json({ message: "faltando o parâmetro fundo" })
if (!fotomusic) return res.json({ message: "faltando o parâmetro fotomusic" })
if (!apikey) return res.json({ status: false, message: 'cade o parametro apikey' })
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({ message: "Apikey inválida ou requests esgotados!" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const tmpDir = path.join(__dirname, 'tmp')
const fundoImagePath = path.join(tmpDir, 'fundo.jpg')
const fotomusicImagePath = path.join(tmpDir, 'fotomusic.jpg')
if (!fs.existsSync(tmpDir)) {
fs.mkdirSync(tmpDir, { recursive: true })
}
async function downloadImage(url, filePath) {
const response = await axios({ url, responseType: 'stream' })
return new Promise((resolve, reject) => {
const writer = fs.createWriteStream(filePath)
response.data.pipe(writer)
writer.on('finish', resolve)
writer.on('error', reject)
})
}
await downloadImage(fundo, fundoImagePath)
await downloadImage(fotomusic, fotomusicImagePath)
sharp(fundoImagePath)
.composite([{ input: fotomusicImagePath, gravity: 'center' }])
.toFile(path.join(__dirname, 'assets', 'combined_image.png'), async (err, info) => {
if (err) {
console.error('Erro ao combinar as imagens:', err)
return res.status(500).send({
status: 500,
info: 'Erro ao combinar as imagens.',
resultado: 'error'
})
}
console.log('Imagem combinada criada:', info)
const ZeroTwoBot = new canvafy.Spotify()
ZeroTwoBot.setAuthor(autor)
ZeroTwoBot.setAlbum(nomealbum)
ZeroTwoBot.setImage(path.join(__dirname, 'assets', 'combined_image.png'))
ZeroTwoBot.setTitle(titulo)
ZeroTwoBot.setTimestamp(40000, 179000)
try {
const data = await ZeroTwoBot.build()
const musicPath = path.join(tmpDir, 'music.png')
await fs.writeFileSync(musicPath, data)
res.sendFile(musicPath)
fs.unlink(fundoImagePath, (err) => {
if (err) {
console.log('Erro ao excluir a imagem de fundo:', err)
} else {
console.log('Imagem de fundo excluída com sucesso!')
}
})
fs.unlink(fotomusicImagePath, (err) => {
if (err) {
console.log('Erro ao excluir a imagem fotomusic:', err)
} else {
console.log('Imagem fotomusic excluída com sucesso!')
}
})
fs.unlink(path.join(__dirname, 'assets', 'combined_image.png'), (err) => {
if (err) {
console.log('Erro ao excluir a imagem combinada:', err)
} else {
console.log('Imagem combinada excluída com sucesso!')
}
})
} catch (err) {
console.log('Erro ao gerar a música:', err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro ao gerar a imagem.',
resultado: 'error'
})
}
})
} catch (err) {
console.log('Erro no processo de download ou combinação de imagens:', err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/premium-welcome', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, userPhoto, groupPhoto, userName, userNumber, groupName } = req.query
const missingParams = []
if (!userPhoto) missingParams.push('userPhoto')
if (!groupPhoto) missingParams.push('groupPhoto')
if (!userName) missingParams.push('userName')
if (!groupName) missingParams.push('groupName')
if (missingParams.length > 0) {
return res.status(400).json({ error: 'Parâmetros faltando', missing: missingParams, example: '/api/canvas/premium-welcome?userPhoto=URL&groupPhoto=URL&userName=NOME&groupName=GRUPO[&userNumber=NUM]&apikey=SuaKey'})
}
if (!apikey) return res.json({ status: false, message: 'cade o parametro apikey' })
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({ message: "Apikey inválida ou requests esgotados!" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const { createCanvas, loadImage, registerFont } = require('canvas')
const WIDTH = 1280
const HEIGHT = 720
const MARGINS = {
top: 50,
bottom: 50,
lateral: 50
}
const LAYERS = {
background: 0,
overlay: 1,
avatar: 2,
groupAvatar: 3,
text: 4,
hud: 5,
welcome: 6
}
registerFont(path.join(__dirname, 'database/fonts/Montserrat-Bold.ttf'), { 
family: 'Montserrat', 
weight: 'bold' 
})
registerFont(path.join(__dirname, 'database/fonts/SpaceGrotesk-Medium.ttf'), { 
family: 'Space Grotesk', 
weight: '500' 
})
registerFont(path.join(__dirname, 'database/fonts/neue-machina-ultrabold.otf'), { 
family: 'Neue Machina', 
weight: '900' 
})
const applyComplexBackground = async (ctx) => {
const backgrounds = [
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747801940726-355239563.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802120781-432948624.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802164780-164842858.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802181968-587417224.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802235777-775894342.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802240750-751647301.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802329899-555561845.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802348830-579328996.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802374610-314351355.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802417771-188499207.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802428040-4706547.jpeg'
]
const bgUrl = backgrounds[Math.floor(Math.random() * backgrounds.length)]
const bg = await loadImage(bgUrl)
const scale = Math.max(WIDTH / bg.width, HEIGHT / bg.height)
const w = bg.width * scale
const h = bg.height * scale
const tempCanvas = createCanvas(WIDTH, HEIGHT)
const tempCtx = tempCanvas.getContext('2d')
tempCtx.drawImage(bg, (WIDTH - w) / 2, (HEIGHT - h) / 2, w, h)
tempCtx.filter = 'blur(8px) brightness(0.75)'
tempCtx.drawImage(tempCanvas, 0, 0)
ctx.drawImage(tempCanvas, 0, 0)
const grad = ctx.createLinearGradient(0, 0, WIDTH, HEIGHT)
grad.addColorStop(0, 'rgba(41, 39, 74, 0.8)')
grad.addColorStop(1, 'rgba(15, 12, 28, 0.85)')
ctx.fillStyle = grad
ctx.fillRect(0, 0, WIDTH, HEIGHT)
}
const drawPremiumAvatar = async (ctx, imageUrl) => {
const AV_SIZE = 300
const CX = WIDTH / 2
const CY = HEIGHT * 0.35
const img = await loadImage(imageUrl)
ctx.save()
ctx.beginPath()
ctx.arc(CX, CY, AV_SIZE / 2, 0, Math.PI * 2)
ctx.clip()
const scale = Math.min(AV_SIZE / img.width, AV_SIZE / img.height)
const w = img.width * scale
const h = img.height * scale
ctx.drawImage(img, CX - w / 2, CY - h / 2, w, h)
const grad = ctx.createRadialGradient(
CX, CY, AV_SIZE / 2 - 8,
CX, CY, AV_SIZE / 2
)
grad.addColorStop(0, '#6A5ACD')
grad.addColorStop(1, '#48D1CC')
ctx.strokeStyle = grad
ctx.lineWidth = 6
ctx.stroke()
ctx.restore()
ctx.shadowColor = 'rgba(0,0,0,0.3)'
ctx.shadowBlur = 20
ctx.shadowOffsetY = 10
}
const drawGroupAvatar = async (ctx, imageUrl, groupName) => {
const AV_SIZE = 100
const x = WIDTH - MARGINS.lateral - AV_SIZE
const y = MARGINS.top - 50
const img = await loadImage(imageUrl)
const radius = AV_SIZE / 2
const cx = x + radius
const cy = y + radius
const sides = 6
const angleStep = (Math.PI * 2) / sides
ctx.save()
ctx.beginPath()
for (let i = 0; i < sides; i++) {
const angle = i * angleStep - Math.PI / 2
const px = cx + Math.cos(angle) * radius
const py = cy + Math.sin(angle) * radius
i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py)
}
ctx.closePath()
ctx.clip()
const scale = Math.min(AV_SIZE / img.width, AV_SIZE / img.height)
const w = img.width * scale
const h = img.height * scale
ctx.drawImage(img, cx - w / 2, cy - h / 2, w, h)
ctx.restore()
ctx.font = 'bold 32px "Montserrat"'
ctx.textBaseline = 'middle'
ctx.fillStyle = '#FFFFFF'
ctx.textAlign = 'right'
ctx.fillText(`Grupo: ${groupName}`, x - 20, cy)
}
const drawDynamicText = (ctx, userData) => {
const CX = WIDTH / 2
const baseY = HEIGHT * 0.35 + 300 / 2 + 30
const nameY = baseY
const phoneY = baseY + 60
let fontSize = 64
let textW
do {
ctx.font = `${fontSize}px "Neue Machina"`
textW = ctx.measureText(userData.name).width
fontSize -= 2
} while (textW > WIDTH - MARGINS.lateral * 2 && fontSize > 32)
const grad = ctx.createLinearGradient(
CX - textW / 2, nameY,
CX + textW / 2, nameY
)
grad.addColorStop(0, '#8A2BE2')
grad.addColorStop(1, '#00BFFF')
ctx.fillStyle = grad
ctx.textAlign = 'center'
ctx.textBaseline = 'middle'
ctx.fillText(userData.name.toUpperCase(), CX, nameY)
ctx.font = '28px "Space Grotesk"'
ctx.fillStyle = 'rgba(255,255,255,0.9)'
ctx.fillText(`📱 +${userData.phone}`, CX, phoneY)
}
const drawHUD = (ctx) => {
const dateOpts = { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' }
ctx.font = '24px "Space Grotesk"'
ctx.fillStyle = 'rgba(255,255,255,0.9)'
ctx.textAlign = 'left'
ctx.textBaseline = 'top'
ctx.fillText(
new Date().toLocaleDateString('pt-BR', dateOpts),
MARGINS.lateral * 0.3,
MARGINS.top * 0.2
)
const idText = `ID: ${uuidv4()}`
ctx.font = '18px "Space Grotesk"'
ctx.fillStyle = 'rgba(255,255,255,0.85)'
ctx.textAlign = 'left'
ctx.textBaseline = 'bottom'
ctx.fillText(
idText,
MARGINS.lateral * 0.3,
HEIGHT - MARGINS.bottom * 0.2
)
}
const drawWelcome = (ctx) => {
const text = 'Welcome!'
const x = WIDTH - MARGINS.lateral
const y = HEIGHT - MARGINS.bottom * 1.2
ctx.font = 'bold 64px "Neue Machina"'
const grad = ctx.createLinearGradient(x - 200, y - 20, x, y + 20)
grad.addColorStop(0, '#FF7F50')
grad.addColorStop(1, '#FFD700')
ctx.fillStyle = grad
ctx.textAlign = 'right'
ctx.textBaseline = 'middle'
ctx.fillText(text, x, y)
}
const canvas = createCanvas(WIDTH, HEIGHT)
const ctx = canvas.getContext('2d')
await applyComplexBackground(ctx)
await drawPremiumAvatar(ctx, userPhoto)
drawDynamicText(ctx, { name: userName, phone: userNumber })
await drawGroupAvatar(ctx, groupPhoto, groupName)
drawHUD(ctx)
drawWelcome(ctx)
res.setHeader('Content-Type', 'image/png')
res.setHeader('Cache-Control', 'public, max-age=604800')
canvas.createPNGStream({ compressionLevel: 9 }).pipe(res)
} catch (error) {
console.error('Erro na renderização:', error)
res.status(500).send('Erro na geração do conteúdo visual')
}
})

app.get('/api/canvas/premium-goodbye', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, userPhoto, groupPhoto, userName, userNumber, groupName } = req.query
const missingParams = []
if (!userPhoto) missingParams.push('userPhoto')
if (!groupPhoto) missingParams.push('groupPhoto')
if (!userName) missingParams.push('userName')
if (!groupName) missingParams.push('groupName')
if (missingParams.length > 0) {
return res.status(400).json({ error: 'Parâmetros faltando', missing: missingParams, example: '/api/canvas/premium-welcome?userPhoto=URL&groupPhoto=URL&userName=NOME&groupName=GRUPO[&userNumber=NUM]&apikey=SuaKey'})
}
if (!apikey) return res.json({ status: false, message: 'cade o parametro apikey' })
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({ message: "Apikey inválida ou requests esgotados!" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const { createCanvas, loadImage, registerFont } = require('canvas')


const WIDTH = 1280
const HEIGHT = 720
const MARGINS = {
top: 50,
bottom: 50,
lateral: 50
}
const LAYERS = {
background: 0,
overlay: 1,
avatar: 2,
groupAvatar: 3,
text: 4,
hud: 5,
welcome: 6
}
registerFont(path.join(__dirname, 'database/fonts/Montserrat-Bold.ttf'), { 
family: 'Montserrat', 
weight: 'bold' 
})
registerFont(path.join(__dirname, 'database/fonts/SpaceGrotesk-Medium.ttf'), { 
family: 'Space Grotesk', 
weight: '500' 
})
registerFont(path.join(__dirname, 'database/fonts/neue-machina-ultrabold.otf'), { 
family: 'Neue Machina', 
weight: '900' 
})
const applyComplexBackground = async (ctx) => {
const backgrounds = [
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747801940726-355239563.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802120781-432948624.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802164780-164842858.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802181968-587417224.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802235777-775894342.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802240750-751647301.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802329899-555561845.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802348830-579328996.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802374610-314351355.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802417771-188499207.jpeg',
'https://uploads.zero-two-apis.com.br/uploads/images/file-1747802428040-4706547.jpeg'
]
const bgUrl = backgrounds[Math.floor(Math.random() * backgrounds.length)]
const bg = await loadImage(bgUrl)
const scale = Math.max(WIDTH / bg.width, HEIGHT / bg.height)
const w = bg.width * scale
const h = bg.height * scale
const tempCanvas = createCanvas(WIDTH, HEIGHT)
const tempCtx = tempCanvas.getContext('2d')
tempCtx.drawImage(bg, (WIDTH - w) / 2, (HEIGHT - h) / 2, w, h)
tempCtx.filter = 'blur(8px) brightness(0.75)'
tempCtx.drawImage(tempCanvas, 0, 0)
ctx.drawImage(tempCanvas, 0, 0)
const grad = ctx.createLinearGradient(0, 0, WIDTH, HEIGHT)
grad.addColorStop(0, 'rgba(41, 39, 74, 0.8)')
grad.addColorStop(1, 'rgba(15, 12, 28, 0.85)')
ctx.fillStyle = grad
ctx.fillRect(0, 0, WIDTH, HEIGHT)
}
const drawPremiumAvatar = async (ctx, imageUrl) => {
const AV_SIZE = 300
const CX = WIDTH / 2
const CY = HEIGHT * 0.35
const img = await loadImage(imageUrl)
ctx.save()
ctx.beginPath()
ctx.arc(CX, CY, AV_SIZE / 2, 0, Math.PI * 2)
ctx.clip()
const scale = Math.min(AV_SIZE / img.width, AV_SIZE / img.height)
const w = img.width * scale
const h = img.height * scale
ctx.drawImage(img, CX - w / 2, CY - h / 2, w, h)
const grad = ctx.createRadialGradient(
CX, CY, AV_SIZE / 2 - 8,
CX, CY, AV_SIZE / 2
)
grad.addColorStop(0, '#6A5ACD')
grad.addColorStop(1, '#48D1CC')
ctx.strokeStyle = grad
ctx.lineWidth = 6
ctx.stroke()
ctx.restore()
ctx.shadowColor = 'rgba(0,0,0,0.3)'
ctx.shadowBlur = 20
ctx.shadowOffsetY = 10
}
const drawGroupAvatar = async (ctx, imageUrl, groupName) => {
const AV_SIZE = 100
const x = WIDTH - MARGINS.lateral - AV_SIZE
const y = MARGINS.top - 50
const img = await loadImage(imageUrl)
const radius = AV_SIZE / 2
const cx = x + radius
const cy = y + radius
const sides = 6
const angleStep = (Math.PI * 2) / sides
ctx.save()
ctx.beginPath()
for (let i = 0; i < sides; i++) {
const angle = i * angleStep - Math.PI / 2
const px = cx + Math.cos(angle) * radius
const py = cy + Math.sin(angle) * radius
i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py)
}
ctx.closePath()
ctx.clip()
const scale = Math.min(AV_SIZE / img.width, AV_SIZE / img.height)
const w = img.width * scale
const h = img.height * scale
ctx.drawImage(img, cx - w / 2, cy - h / 2, w, h)
ctx.restore()
ctx.font = 'bold 32px "Montserrat"'
ctx.textBaseline = 'middle'
ctx.fillStyle = '#FFFFFF'
ctx.textAlign = 'right'
ctx.fillText(`Grupo: ${groupName}`, x - 20, cy)
}
const drawDynamicText = (ctx, userData) => {
const CX = WIDTH / 2
const baseY = HEIGHT * 0.35 + 300 / 2 + 30
const nameY = baseY
const phoneY = baseY + 60
let fontSize = 64
let textW
do {
ctx.font = `${fontSize}px "Neue Machina"`
textW = ctx.measureText(userData.name).width
fontSize -= 2
} while (textW > WIDTH - MARGINS.lateral * 2 && fontSize > 32)
const grad = ctx.createLinearGradient(
CX - textW / 2, nameY,
CX + textW / 2, nameY
)
grad.addColorStop(0, '#8A2BE2')
grad.addColorStop(1, '#00BFFF')
ctx.fillStyle = grad
ctx.textAlign = 'center'
ctx.textBaseline = 'middle'
ctx.fillText(userData.name.toUpperCase(), CX, nameY)
ctx.font = '28px "Space Grotesk"'
ctx.fillStyle = 'rgba(255,255,255,0.9)'
ctx.fillText(`📱 +${userData.phone}`, CX, phoneY)
}
const drawHUD = (ctx) => {
const dateOpts = { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' }
ctx.font = '24px "Space Grotesk"'
ctx.fillStyle = 'rgba(255,255,255,0.9)'
ctx.textAlign = 'left'
ctx.textBaseline = 'top'
ctx.fillText(
new Date().toLocaleDateString('pt-BR', dateOpts),
MARGINS.lateral * 0.3,
MARGINS.top * 0.2
)
const idText = `ID: ${uuidv4()}`
ctx.font = '18px "Space Grotesk"'
ctx.fillStyle = 'rgba(255,255,255,0.85)'
ctx.textAlign = 'left'
ctx.textBaseline = 'bottom'
ctx.fillText(
idText,
MARGINS.lateral * 0.3,
HEIGHT - MARGINS.bottom * 0.2
)
}
const drawWelcome = (ctx) => {
const text = 'Goodbye!'
const x = WIDTH - MARGINS.lateral
const y = HEIGHT - MARGINS.bottom * 1.2
ctx.font = 'bold 64px "Neue Machina"'
const grad = ctx.createLinearGradient(x - 200, y - 20, x, y + 20)
grad.addColorStop(0, '#FF7F50')
grad.addColorStop(1, '#FFD700')
ctx.fillStyle = grad
ctx.textAlign = 'right'
ctx.textBaseline = 'middle'
ctx.fillText(text, x, y)
}
const canvas = createCanvas(WIDTH, HEIGHT)
const ctx = canvas.getContext('2d')
await applyComplexBackground(ctx)
await drawPremiumAvatar(ctx, userPhoto)
drawDynamicText(ctx, { name: userName, phone: userNumber })
await drawGroupAvatar(ctx, groupPhoto, groupName)
drawHUD(ctx)
drawWelcome(ctx)
res.setHeader('Content-Type', 'image/png')
res.setHeader('Cache-Control', 'public, max-age=604800')
canvas.createPNGStream({ compressionLevel: 9 }).pipe(res)
} catch (error) {
console.error('Erro na renderização:', error)
res.status(500).send('Erro na geração do conteúdo visual')
}
})

app.get('/api/canvas/comunismo', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.comunism(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/bolsonaro', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.bolsonaro(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/bnw', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.bnw(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/affect', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.affect(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/beautiful', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.beautiful(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/blur', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.blur(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/circle', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.circle(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/del', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.del(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/dither', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.dither(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/facepalm', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.facepalm(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/gay', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.gay(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})
app.get('/api/canvas/lgbt', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.gay(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/invert', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.invert(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/jail', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.jail(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/magik', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.magik(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/pixelate', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.pixelate(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/rip', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.rip(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/sepia', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.sepia(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/rotate', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.rotate(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/trash', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.trash(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/wanted', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.wanted(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/wasted', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await Caxinha.canvas.wasted(`${link}`)
const filePath = path.join(__dirname, 'assets/canvasimg.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/bobross', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await new Caxinha2.Bobross().getImage(`${link}`)
const filePath = path.join(__dirname, 'assets/bobross.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/karaba', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await new Caxinha2.Karaba().getImage(`${link}`)
const filePath = path.join(__dirname, 'assets/karaba.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get('/api/canvas/mms', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, link } = req.query
if(!link) return res.json({message: "faltando o parâmetro link"})
if(!apikey)return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const img = await new Caxinha2.Mms().getImage(`${link}`)
const filePath = path.join(__dirname, 'assets/mms.png')
await fs.writeFileSync(filePath, img)
res.sendFile(filePath)
} catch (err) {
console.log(err)
res.status(500).send({
status: 500,
info: 'Ops, aconteceu um erro no servidor interno.',
resultado: 'error'
})
}
})

app.get("/api/canvas/cartao-aniversario", async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, nome, mensagem, tema, foto } = req.query
if (!nome) return res.json({ message: "Faltando o parâmetro nome" })
if (!mensagem) return res.json({ message: "Faltando o parâmetro mensagem" })
if (!tema) return res.json({ message: "Faltando o parâmetro tema" })
if (!foto) return res.json({ message: "Faltando o parâmetro foto" })
if (!apikey) return res.json({ status: false, message: "Faltando o parâmetro apikey" })
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const canvas = createCanvas(1280, 720)
const ctx = canvas.getContext("2d")
if (tema === "colorido") {
const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height)
gradient.addColorStop(0, "#ff7f50")
gradient.addColorStop(0.5, "#1e90ff")
gradient.addColorStop(1, "#ff1493")
ctx.fillStyle = gradient
} else if (tema === "elegante") {
const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height)
gradient.addColorStop(0, "#2c3e50")
gradient.addColorStop(1, "#34495e")
ctx.fillStyle = gradient
} else {
ctx.fillStyle = "#ecf0f1"
}
ctx.fillRect(0, 0, canvas.width, canvas.height)
ctx.strokeStyle = "#ffffff"
ctx.lineWidth = 15
ctx.strokeRect(30, 30, canvas.width - 60, canvas.height - 60)
try {
const image = await loadImage(foto)
ctx.save()
ctx.beginPath()
ctx.arc(200, canvas.height / 2, 150, 0, Math.PI * 2, true)
ctx.closePath()
ctx.clip()
ctx.drawImage(image, 50, canvas.height / 2 - 150, 300, 300)
ctx.restore()
} catch (error) {
console.error("Erro ao carregar imagem:", error)
return res.status(400).json({ message: "Erro ao carregar imagem de perfil" })
}
ctx.fillStyle = "#ffffff"
ctx.font = "bold 50px Arial"
ctx.textAlign = "left"
ctx.fillText(`Feliz Aniversário, ${nome}!`, 400, 200)
ctx.font = "30px Arial"
const wrapText = (ctx, text, x, y, maxWidth, lineHeight) => {
const words = text.split(" ")
let line = ""
const lines = []
for (let n = 0; n < words.length; n++) {
const testLine = line + words[n] + " "
const metrics = ctx.measureText(testLine)
const testWidth = metrics.width
if (testWidth > maxWidth && n > 0) {
lines.push(line)
line = words[n] + " "
} else {
line = testLine
}
}
lines.push(line)
return lines
}
const linhas = wrapText(ctx, mensagem || "Desejo tudo de bom!", 400, 300, 800, 40)
linhas.forEach((linha, i) => ctx.fillText(linha, 400, 300 + i * 40))
canvas.toBuffer((err, buffer) => {
if (err) {
console.error("Erro ao converter o canvas em buffer:", err)
return res.status(500).send("Erro ao gerar cartão.")
}
res.set("Content-Type", "image/png")
res.send(buffer)
})
} catch (e) {
console.error("Erro inesperado:", e)
res.status(500).send("Ocorreu um erro inesperado.")
}
})

app.get("/api/musicard", async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, nome, foto, duracao, canal } = req.query
if (!nome) return res.json({ message: "Faltando o parâmetro nome" })
if (!foto) return res.json({ message: "Faltando o parâmetro foto" })
if (!duracao) return res.json({ message: "Faltando o parâmetro duracao" })
if (!canal) return res.json({ message: "Faltando o parâmetro canal" })
if (!apikey) return res.json({ status: false, message: "Faltando o parâmetro apikey" })
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({ message: "Apikey inválida ou requests esgotados!" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const buffer = await generateMusicCard(nome, foto, duracao, canal)
res.set("Content-Type", "image/png")
res.send(buffer)
} catch (error) {
console.error("Erro inesperado:", error)
res.status(500).json({ message: "Erro ao gerar Musicard." })
}
})

app.get("/api/nglcanvas", async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, title, text } = req.query
if (!title) return res.json({ message: "Faltando o parâmetro title" })
if (!text) return res.json({ message: "Faltando o parâmetro text" })
if (!apikey) return res.json({ status: false, message: "Faltando o parâmetro apikey" })
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({ message: "Apikey inválida ou requests esgotados!" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const buffer = await generateNglCanvas({ title, text })
res.set("Content-Type", "image/png")
res.send(buffer)
} catch (error) {
console.error("Erro inesperado:", error)
res.status(500).json({ message: "Erro ao gerar NGL Canvas." })
}
})

app.get('/gura-sticker', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, url } = req.query
if (!url) return res.json({ message: "Faltando o parâmetro url" })
if (!apikey) return res.json({ status: false, message: "Faltando o parâmetro apikey" })
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({ message: "Apikey inválida ou requests esgotados!" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const stickerBuffer = await createGuraSticker(url)
res.setHeader('Content-Type', 'image/webp')
res.setHeader('Content-Disposition', 'inline; filename="gura-sticker.webp"')
res.send(stickerBuffer)
} catch (error) {
console.error('Erro ao criar sticker:', error)
res.status(500).json({ error: 'Erro ao processar a imagem', details: error.message })
}
})

app.get('/api/antiporno', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const response = await fetch(`https://nsfw-demo.sashido.io/api/image/classify?url=${url}`)
const data = await response.json()
res.json({
status: true,
criador: `${criador}`,
resultado: data
})
} catch (error) {
console.error('Erro ao classificar a imagem:', error)
res.status(500).json({ message: 'Erro ao classificar a imagem.' })
}
})

router.get('/api/screenshotweb', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
url = req.query.url
if(!url)return res.json({status:false, motivo:'Cadê o parâmetro url?'})
apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
hasil = `https://api.popcat.xyz/screenshot?url=${url}`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla + '/assets/asupan.jpg', data)
res.sendFile(bla + '/assets/asupan.jpg')
 } else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/api/mirella', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
hasil = `https://apirest.gestorvip.com/api/mirella?apikey=Toms123`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/asupan.mp4', data)
res.sendFile(bla+'/assets/asupan.mp4')
 } else {
res.json({erro:'Erro no Servidor Interno'})
}
})

app.get('/api/figurinhas', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey) return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
fig = `${Math.floor(Math.random() * 7233) + 1}`
//hasil = `https://raw.githubusercontent.com/badDevelopper/Testfigu/main/fig (${fig}).webp`
hasil = `https://raw.githubusercontent.com/nussaleo/StickersDB/refs/heads/main/random/sticker (${fig}).webp`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/stickera.webp', data)
res.sendFile(bla+'/assets/stickera.webp')
} catch {
return res.json({resposta: ` Erro na resposta do servidor... Chame meu dono paulo_mod_domina`, status: 500 })
}
})

app.get('/api/figurinhas2', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey) return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
fig = `${Math.floor(Math.random() * 6840)}`
hasil = `https://raw.githubusercontent.com/monarge/figurinhas/master/fig (${fig}).webp`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/stickera.webp', data)
res.sendFile(bla+'/assets/stickera.webp')
} catch {
return res.json({resposta: ` Erro na resposta do servidor... Chame meu dono paulo_mod_domina`, status: 500 })
}
})

router.get('/sticker/figemoji', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
var rnd = Math.floor(Math.random() * 102)
hasil = `https://raw.githubusercontent.com/Scheyot2/media/master/packs/emoji/${rnd}.webp`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/stickera.webp', data)
res.sendFile(bla+'/assets/stickera.webp')
 } else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/sticker/figflork', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
var rnd = Math.floor(Math.random() * 102)
hasil = `https://raw.githubusercontent.com/Scheyot2/anya-bot/master/Figurinhas/figu_flork/${rnd}.webp`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/stickera.webp', data)
res.sendFile(bla+'/assets/stickera.webp')
 } else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/sticker/figale', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
var rnd = Math.floor(Math.random() * 8051)
hasil = `https://raw.githubusercontent.com/badDevelopper/Testfigu/master/fig (${rnd}).webp`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/stickera.webp', data)
res.sendFile(bla+'/assets/stickera.webp')
 } else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/sticker/figmemes', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
var rnd = Math.floor(Math.random() * 109)
hasil = `https://raw.githubusercontent.com/Scheyot2/media/master/packs/meme/${rnd}.webp`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/stickera.webp', data)
res.sendFile(bla+'/assets/stickera.webp')
 } else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/sticker/figanime', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
var rnd = Math.floor(Math.random() * 109)
hasil = `https://raw.githubusercontent.com/Scheyot2/media/master/packs/anime/${rnd}.webp`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/stickera.webp', data)
res.sendFile(bla+'/assets/stickera.webp')
 } else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/sticker/figcoreana', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
var rnd = Math.floor(Math.random() * 43)
hasil = `https://raw.githubusercontent.com/Scheyot2/media/master/packs/coreana/${rnd}.webp`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/stickera.webp', data)
res.sendFile(bla+'/assets/stickera.webp')
 } else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/sticker/figbebe', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
var rnd = Math.floor(Math.random() * 17)
hasil = `https://raw.githubusercontent.com/badDevelopper/Apis/master/pack/figbebe/${rnd}.webp`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/stickera.webp', data)
res.sendFile(bla+'/assets/stickera.webp')
 } else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/sticker/figdesenho', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
var rnd = Math.floor(Math.random() * 109)
hasil = `https://raw.githubusercontent.com/Scheyot2/media/master/packs/desenho/${rnd}.webp`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/stickera.webp', data)
res.sendFile(bla+'/assets/stickera.webp')
 } else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/sticker/figanimais', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
var rnd = Math.floor(Math.random() * 46)
hasil = `https://raw.githubusercontent.com/badDevelopper/Apis/master/pack/figanimais/${rnd}.webp`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/stickera.webp', data)
res.sendFile(bla+'/assets/stickera.webp')
 } else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/sticker/figengracada', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
var rnd = Math.floor(Math.random() * 25)
hasil = `https://raw.githubusercontent.com/Scheyot2/media/master/packs/engracadas/${rnd}.webp`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/stickera.webp', data)
res.sendFile(bla+'/assets/stickera.webp')
 } else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/sticker/figraiva', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
var rnd = Math.floor(Math.random() * 29)
hasil = `https://raw.githubusercontent.com/Scheyot2/media/master/packs/raiva/${rnd}.webp`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/stickera.webp', data)
res.sendFile(bla+'/assets/stickera.webp')
 } else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/sticker/figroblox', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
var rnd = Math.floor(Math.random() * 21)
hasil = `https://raw.githubusercontent.com/Scheyot2/media/master/packs/roblox/${rnd}.webp`
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/stickera.webp', data)
res.sendFile(bla+'/assets/stickera.webp')
 } else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/ahegao', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const ahegao = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/ahegao.json'))
const randahegao = ahegao[Math.floor(Math.random() * ahegao.length)]
data = await fetch(randahegao).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/ahegao.jpeg', data)
res.sendFile(bla + '/assets/ahegao.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/ass', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const ass = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/ass.json'))
const randass = ass[Math.floor(Math.random() * ass.length)]
data = await fetch(randass).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/ass.jpeg', data)
res.sendFile(bla + '/assets/ass.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/bdsm', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const bdsm = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/bdsm.json'))
const randbdsm = bdsm[Math.floor(Math.random() * bdsm.length)]
data = await fetch(randbdsm).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/bdsm.jpeg', data)
res.sendFile(bla + '/assets/bdsm.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/blowjob', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const blowjob = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/blowjob.json'))
const randblowjob = blowjob[Math.floor(Math.random() * blowjob.length)]
data = await fetch(randblowjob).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/blowjob.jpeg', data)
res.sendFile(bla + '/assets/blowjob.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/cuckold', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const cuckold = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/cuckold.json'))
const randcuckold = cuckold[Math.floor(Math.random() * cuckold.length)]
data = await fetch(randcuckold).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/cuckold.jpeg', data)
res.sendFile(bla + '/assets/cuckold.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/cum', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const cum = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/cum.json'))
const randcum = cum[Math.floor(Math.random() * cum.length)]
data = await fetch(randcum).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/cum.jpeg', data)
res.sendFile(bla + '/assets/cum.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/ero', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const ero = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/ero.json'))
const randero = ero[Math.floor(Math.random() * ero.length)]
data = await fetch(randero).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/ero.jpeg', data)
res.sendFile(bla + '/assets/ero.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/femdom', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const femdom = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/femdom.json'))
const randfemdom = femdom[Math.floor(Math.random() * femdom.length)]
data = await fetch(randfemdom).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/femdom.jpeg', data)
res.sendFile(bla + '/assets/femdom.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/foot', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const foot = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/foot.json'))
const randfoot = foot[Math.floor(Math.random() * foot.length)]
data = await fetch(randfoot).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/foot.jpeg', data)
res.sendFile(bla + '/assets/foot.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/gangbang', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const gangbang = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/gangbang.json'))
const randgangbang = gangbang[Math.floor(Math.random() * gangbang.length)]
data = await fetch(randgangbang).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/gangbang.jpg', data)
res.sendFile(bla + '/assets/gangbang.jpg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/glasses', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const glasses = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/glasses.json'))
const randglasses = glasses[Math.floor(Math.random() * glasses.length)]
data = await fetch(randglasses).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/glasses.jpeg', data)
res.sendFile(bla + '/assets/glasses.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/hentai', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const hentai = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/hentai.json'))
const randhentai = hentai[Math.floor(Math.random() * hentai.length)]
data = await fetch(randhentai).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/hentai.jpeg', data)
res.sendFile(bla + '/assets/hentai.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/gifs', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
const gifs = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/gifs.json'))
const randgifs = gifs[Math.floor(Math.random() * gifs.length)]
data = await fetch(randgifs).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/gifs.jpeg', data)
res.sendFile(bla + '/assets/gifs.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/figu', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
const gifs = JSON.parse(fs.readFileSync(bla + '/base de dados/figurinhas.json'))
const randgifs = gifs[Math.floor(Math.random() * gifs.length)]
data = await fetch(randgifs).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/stickera.webp', data)
res.sendFile(bla + '/assets/stickera.webp')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/api/stickera', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
const gifs = JSON.parse(fs.readFileSync(bla + '/base de dados/figurinhas.json'))
const randgifs = gifs[Math.floor(Math.random() * gifs.length)]
data = await fetch(randgifs).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/stickera.webp', data)
res.sendFile(bla + '/assets/stickera.webp')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/jahy', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const jahy = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/jahy.json'))
const randjahy = jahy[Math.floor(Math.random() * jahy.length)]
data = await fetch(randjahy).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/jahy.jpeg', data)
res.sendFile(bla + '/assets/jahy.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/manga', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const manga = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/manga.json'))
const randmanga = manga[Math.floor(Math.random() * manga.length)]
data = await fetch(randmanga).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/manga.jpeg', data)
res.sendFile(bla + '/assets/manga.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/masturbation', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const masturbation = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/masturbation.json'))
const randmasturbation = masturbation[Math.floor(Math.random() * masturbation.length)]
data = await fetch(randmasturbation).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/masturbation.jpeg', data)
res.sendFile(bla + '/assets/masturbation.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/neko', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const neko = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/neko.json'))
const randneko = neko[Math.floor(Math.random() * neko.length)]
data = await fetch(randneko).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/neko.jpeg', data)
res.sendFile(bla + '/assets/neko.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/orgy', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const orgy = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/orgy.json'))
const randorgy = orgy[Math.floor(Math.random() * orgy.length)]
data = await fetch(randorgy).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/orgy.jpeg', data)
res.sendFile(bla + '/assets/orgy.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/panties', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const panties = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/panties.json'))
const randpanties = panties[Math.floor(Math.random() * panties.length)]
data = await fetch(randpanties).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/panties.jpeg', data)
res.sendFile(bla + '/assets/panties.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/pussy', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const pussy = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/pussy.json'))
const randpussy = pussy[Math.floor(Math.random() * pussy.length)]
data = await fetch(randpussy).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/pussy.jpeg', data)
res.sendFile(bla + '/assets/pussy.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/neko2', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const neko2 = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/neko2.json'))
const randneko2 = neko2[Math.floor(Math.random() * neko2.length)]
data = await fetch(randneko2).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/neko2.jpeg', data)
res.sendFile(bla + '/assets/neko2.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/tentacles', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const tentacles = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/tentacles.json'))
const randtentacles = tentacles[Math.floor(Math.random() * tentacles.length)]
data = await fetch(randtentacles).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/tentacles.jpeg', data)
res.sendFile(bla + '/assets/tentacles.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/thighs', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const thighs = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/thighs.json'))
const randthighs = thighs[Math.floor(Math.random() * thighs.length)]
data = await fetch(randthighs).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/thighs.jpeg', data)
res.sendFile(bla + '/assets/thighs.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/yuri', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const yuri = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/yuri.json'))
const randyuri = yuri[Math.floor(Math.random() * yuri.length)]
data = await fetch(randyuri).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/yuri.jpeg', data)
res.sendFile(bla + '/assets/yuri.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/nsfw/zettai', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const zettai = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/zettai.json'))
const randzettai = zettai[Math.floor(Math.random() * zettai.length)]
data = await fetch(randzettai).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/zettai.jpeg', data)
res.sendFile(bla + '/assets/zettai.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/keneki', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const keneki = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/keneki.json'))
const randkeneki = keneki[Math.floor(Math.random() * keneki.length)]
data = await fetch(randkeneki).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/keneki.jpeg', data)
res.sendFile(bla + '/assets/keneki.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/megumin', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const megumin = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/megumin.json'))
const randmegumin = megumin[Math.floor(Math.random() * megumin.length)]
data = await fetch(randmegumin).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/megumin.jpeg', data)
res.sendFile(bla + '/assets/megumin.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/yotsuba', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const yotsuba = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/yotsuba.json'))
const randyotsuba = yotsuba[Math.floor(Math.random() * yotsuba.length)]
data = await fetch(randyotsuba).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/yotsuba.jpeg', data)
res.sendFile(bla + '/assets/yotsuba.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/shinomiya', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const shinomiya = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/shinomiya.json'))
const randshinomiya = shinomiya[Math.floor(Math.random() * shinomiya.length)]
data = await fetch(randshinomiya).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/shinomiya.jpeg', data)
res.sendFile(bla + '/assets/shinomiya.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/yumeko', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const yumeko = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/yumeko.json'))
const randyumeko = yumeko[Math.floor(Math.random() * yumeko.length)]
data = await fetch(randyumeko).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/yumeko.jpeg', data)
res.sendFile(bla + '/assets/yumeko.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/tejina', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const tejina = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/tejina.json'))
const randtejina = tejina[Math.floor(Math.random() * tejina.length)]
data = await fetch(randtejina).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/tejina.jpeg', data)
res.sendFile(bla + '/assets/tejina.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/chiho', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const chiho = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/chiho.json'))
const randchiho = chiho[Math.floor(Math.random() * chiho.length)]
data = await fetch(randchiho).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/chiho.jpeg', data)
res.sendFile(bla + '/assets/chiho.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/wallpaper/cyberspace', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const cyberspace = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/CyberSpace.json'))
const randcyberspace = cyberspace[Math.floor(Math.random() * cyberspace.length)]
data = await fetch(randcyberspace).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/cyberspace.jpeg', data)
res.sendFile(bla + '/assets/cyberspace.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/wallpaper/gaming', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const gaming = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/GameWallp.json'))
const randgaming = gaming[Math.floor(Math.random() * gaming.length)]
data = await fetch(randgaming).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/gaming.jpeg', data)
res.sendFile(bla + '/assets/gaming.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/wallpaper/programing', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const programing = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/Programming.json'))
const randprograming = programing[Math.floor(Math.random() * programing.length)]
data = await fetch(randprograming).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/programing.jpeg', data)
res.sendFile(bla + '/assets/programing.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/wallpaper/wallpapertec', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const teknologi = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/Technology.json'))
const randteknologi = teknologi[Math.floor(Math.random() * teknologi.length)]
data = await fetch(randteknologi).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/teknologi.jpeg', data)
res.sendFile(bla + '/assets/teknologi.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/wallpaper/mountain', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const mountain = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/Mountain.json'))
const randmountain = mountain[Math.floor(Math.random() * mountain.length)]
data = await fetch(randmountain).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/mountain.jpeg', data)
res.sendFile(bla + '/assets/mountain.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/toukachan', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const toukachan = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/toukachan.json'))
const randtoukachan = toukachan[Math.floor(Math.random() * toukachan.length)]
data = await fetch(randtoukachan).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/toukachan.jpeg', data)
res.sendFile(bla + '/assets/toukachan.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/akira', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const akira = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/akira.json'))
const randakira = akira[Math.floor(Math.random() * akira.length)]
data = await fetch(randakira).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/akira.jpeg', data)
res.sendFile(bla + '/assets/akira.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/itori', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const itori = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/itori.json'))
const randitori = itori[Math.floor(Math.random() * itori.length)]
data = await fetch(randitori).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/itori.jpeg', data)
res.sendFile(bla + '/assets/itori.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/kurumi', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const kurumi = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/kurumi.json'))
const randkurumi = kurumi[Math.floor(Math.random() * kurumi.length)]
data = await fetch(randkurumi).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/kurumi.jpeg', data)
res.sendFile(bla + '/assets/kurumi.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/miku', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const miku = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/miku.json'))
const randmiku = miku[Math.floor(Math.random() * miku.length)]
data = await fetch(randmiku).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/miku.jpeg', data)
res.sendFile(bla + '/assets/miku.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/pokemon', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const pokemon = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/pokemon.json'))
const randpokemon = pokemon[Math.floor(Math.random() * pokemon.length)]
data = await fetch(randpokemon).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/pokemon.jpeg', data)
res.sendFile(bla + '/assets/pokemon.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/ryujin', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const ryujin = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/ryujin.json'))
const randryujin = ryujin[Math.floor(Math.random() * ryujin.length)]
data = await fetch(randryujin).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/ryujin.jpeg', data)
res.sendFile(bla + '/assets/ryujin.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/rose', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const rose = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/rose.json'))
const randrose = rose[Math.floor(Math.random() * rose.length)]
data = await fetch(randrose).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/rose.jpeg', data)
res.sendFile(bla + '/assets/rose.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/kaori', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const kaori = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/kaori.json'))
const randkaori = kaori[Math.floor(Math.random() * kaori.length)]
data = await fetch(randkaori).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/kaori.jpeg', data)
res.sendFile(bla + '/assets/kaori.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/shizuka', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const shizuka = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/shizuka.json'))
const randshizuka = shizuka[Math.floor(Math.random() * shizuka.length)]
data = await fetch(randshizuka).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/shizuka.jpeg', data)
res.sendFile(bla + '/assets/shizuka.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/kaga', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const kaga = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/kaga.json'))
const randkaga = kaga[Math.floor(Math.random() * kaga.length)]
data = await fetch(randkaga).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/kaga.jpeg', data)
res.sendFile(bla + '/assets/kaga.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/kotori', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const kotori = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/kotori.json'))
const randkotori = kotori[Math.floor(Math.random() * kotori.length)]
data = await fetch(randkotori).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/kotori.jpeg', data)
res.sendFile(bla + '/assets/kotori.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/mikasa', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const mikasa = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/mikasa.json'))
const randmikasa = mikasa[Math.floor(Math.random() * mikasa.length)]
data = await fetch(randmikasa).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/mikasa.jpeg', data)
res.sendFile(bla + '/assets/mikasa.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/akiyama', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const akiyama = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/akiyama.json'))
const randakiyama = akiyama[Math.floor(Math.random() * akiyama.length)]
data = await fetch(randakiyama).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/akiyama.jpeg', data)
res.sendFile(bla + '/assets/akiyama.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/gremory', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const gremory = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/gremory.json'))
const randgremory = gremory[Math.floor(Math.random() * gremory.length)]
data = await fetch(randgremory).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/gremory.jpeg', data)
res.sendFile(bla + '/assets/gremory.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/isuzu', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const isuzu = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/isuzu.json'))
const randisuzu = isuzu[Math.floor(Math.random() * isuzu.length)]
data = await fetch(randisuzu).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/isuzu.jpeg', data)
res.sendFile(bla + '/assets/isuzu.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/cosplay', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const cosplay = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/cosplay.json'))
const randcosplay = cosplay[Math.floor(Math.random() * cosplay.length)]
data = await fetch(randcosplay).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/cosplay.jpeg', data)
res.sendFile(bla + '/assets/cosplay.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/shina', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const shina = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/shina.json'))
const randshina = shina[Math.floor(Math.random() * shina.length)]
data = await fetch(randshina).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/shina.jpeg', data)
res.sendFile(bla + '/assets/shina.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/kagura', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const kagura = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/kagura.json'))
const randkagura = kagura[Math.floor(Math.random() * kagura.length)]
data = await fetch(randkagura).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/kagura.jpeg', data)
res.sendFile(bla + '/assets/kagura.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/shinka', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const shinka = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/shinka.json'))
const randshinka = shinka[Math.floor(Math.random() * shinka.length)]
data = await fetch(randshinka).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/shinka.jpeg', data)
res.sendFile(bla + '/assets/shinka.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/eba', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const eba = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/eba.json'))
const randeba = eba[Math.floor(Math.random() * eba.length)]
data = await fetch(randeba).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/eba.jpeg', data)
res.sendFile(bla + '/assets/eba.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/deidara', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Deidara = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/deidara.json'))
const randDeidara = Deidara[Math.floor(Math.random() * Deidara.length)]
data = await fetch(randDeidara).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/deidara.jpeg', data)
res.sendFile(bla + '/assets/deidara.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})



router.get('/random/jeni', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const jeni = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/jeni.json'))
const randjeni = jeni[Math.floor(Math.random() * jeni.length)]
data = await fetch(randjeni).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/jeni.jpeg', data)
res.sendFile(bla + '/assets/jeni.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})


router.get('/random/meme', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const meme = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/meme.json'))
const randmeme = meme[Math.floor(Math.random() * meme.length)]
data = await fetch(randmeme).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/meme.jpeg', data)
res.sendFile(bla + '/assets/meme.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/wallpaper/satanic', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const satanic = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/satanic.json'))
const randsatanic = satanic[Math.floor(Math.random() * satanic.length)]
data = await fetch(randsatanic).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/satanic.jpeg', data)
res.sendFile(bla + '/assets/satanic.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})



router.get('/random/itachi', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Itachi = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/itachi.json'))
const randItachi = Itachi[Math.floor(Math.random() * Itachi.length)]
data = await fetch(randItachi).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/ita.jpeg', data)
res.sendFile(bla + '/assets/ita.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/madara', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Madara = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/madara.json'))
const randMadara = Madara[Math.floor(Math.random() * Madara.length)]
data = await fetch(randMadara).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/madara.jpeg', data)
res.sendFile(bla + '/assets/madara.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/yuki', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Yuki = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/yuki.json'))
const randYuki = Yuki[Math.floor(Math.random() * Yuki.length)]
data = await fetch(randYuki).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/yuki.jpeg', data)
res.sendFile(bla + '/assets/yuki.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/wallpaper/asuna', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const asuna = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/asuna.json'))
const randasuna = asuna[Math.floor(Math.random() * asuna.length)]
data = await fetch(randasuna).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/asuna.jpeg', data)
res.sendFile(bla + '/assets/asuna.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/ayuzawa', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const ayuzawa = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/ayuzawa.json'))
const randayuzawa = ayuzawa[Math.floor(Math.random() * ayuzawa.length)]
data = await fetch(randayuzawa).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/ayuzawa.jpeg', data)
res.sendFile(bla + '/assets/ayuzawa.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/chitoge', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const chitoge = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/chitoge.json'))
const randchitoge = chitoge[Math.floor(Math.random() * chitoge.length)]
data = await fetch(randchitoge).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/chitoge.jpeg', data)
res.sendFile(bla + '/assets/chitoge.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/emilia', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const emilia = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/emilia.json'))
const randemilia = emilia[Math.floor(Math.random() * emilia.length)]
data = await fetch(randemilia).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/emilia.jpeg', data)
res.sendFile(bla + '/assets/emilia.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/hestia', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const hestia = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/hestia.json'))
const randhestia = hestia[Math.floor(Math.random() * hestia.length)]
data = await fetch(randhestia).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/hestia.jpeg', data)
res.sendFile(bla + '/assets/hestia.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/inori', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const inori = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/inori.json'))
const randinori = inori[Math.floor(Math.random() * inori.length)]
data = await fetch(randinori).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/inori.jpeg', data)
res.sendFile(bla + '/assets/inori.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/ana', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const ana = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/ana.json'))
const randana = ana[Math.floor(Math.random() * ana.length)]
data = await fetch(randana).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/ana.jpeg', data)
res.sendFile(bla + '/assets/ana.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/boruto', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Boruto = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/boruto.json'))
const randBoruto = Boruto[Math.floor(Math.random() * Boruto.length)]
data = await fetch(randBoruto).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/bor.jpeg', data)
res.sendFile(bla + '/assets/bor.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/erza', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Erza = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/erza.json'))
const randErza = Erza[Math.floor(Math.random() * Erza.length)]
data = await fetch(randErza).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/erza.jpeg', data)
res.sendFile(bla + '/assets/erza.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/kakashi', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Kakasih = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/kakasih.json'))
const randKakasih = Kakasih[Math.floor(Math.random() * Kakasih.length)]
data = await fetch(randKakasih).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/ka.jpeg', data)
res.sendFile(bla + '/assets/ka.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/sagiri', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Sagiri = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/sagiri.json'))
const randSagiri = Sagiri[Math.floor(Math.random() * Sagiri.length)]
data = await fetch(randSagiri).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/sagiri.jpeg', data)
res.sendFile(bla + '/assets/sagiri.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/minato', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Minato = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/minato.json'))
const randMinato = Minato[Math.floor(Math.random() * Minato.length)]
data = await fetch(randMinato).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/minato.jpeg', data)
res.sendFile(bla + '/assets/minato.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/naruto', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Naruto = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/naruto.json'))
const randNaruto = Naruto[Math.floor(Math.random() * Naruto.length)]
data = await fetch(randNaruto).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/naruto.jpeg', data)
res.sendFile(bla + '/assets/naruto.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/nezuko', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Nezuko = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/nezuko.json'))
const randNezuko = Nezuko[Math.floor(Math.random() * Nezuko.length)]
data = await fetch(randNezuko).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/nezu.jpeg', data)
res.sendFile(bla + '/assets/nezu.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/onepiece', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Pic = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/onepiece.json'))
const randPic = Pic[Math.floor(Math.random() * Pic.length)]
data = await fetch(randPic).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/pic.jpeg', data)
res.sendFile(bla + '/assets/pic.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/rize', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Rize = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/rize.json'))
const randRize = Rize[Math.floor(Math.random() * Rize.length)]
data = await fetch(randRize).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/rize.jpeg', data)
res.sendFile(bla + '/assets/rize.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/sakura', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Sakura = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/sakura.json'))
const randSakura = Sakura[Math.floor(Math.random() * Sakura.length)]
data = await fetch(randSakura).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/sakura.jpeg', data)
res.sendFile(bla + '/assets/sakura.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/sasuke', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Sasuke = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/sasuke.json'))
const randSasuke = Sasuke[Math.floor(Math.random() * Sasuke.length)]
data = await fetch(randSasuke).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/sasuke.jpeg', data)
res.sendFile(bla + '/assets/sasuke.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/tsunade', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Su = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/tsunade.json'))
const randSu = Su[Math.floor(Math.random() * Su.length)]
data = await fetch(randSu).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/su.jpeg', data)
res.sendFile(bla + '/assets/su.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/montor', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Mon = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/montor.json'))
const randMon = Mon[Math.floor(Math.random() * Mon.length)]
data = await fetch(randMon).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/montor.jpeg', data)
res.sendFile(bla + '/assets/montor.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})







app.get('/youtube/playlist', async (req, res) => {
    const userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
    const apikey = req.query.apikey
    const urlParam = req.query.url

    if (!key.map(i => i.apikey)?.includes(apikey))
        return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))

    const ITC = key.map(i => i?.apikey)?.indexOf(apikey)
    if (key[ITC]?.request <= 0)
        return res.json({ message: "Apikey inválida ou requests esgotados!" })

    if (!urlParam)
        return res.json({ status: false, message: "Parâmetro url obrigatório" })

    RegisKey(apikey, userIp)

    try {
        const isUrl = /^https?:\/\//i.test(urlParam)
        if (!isUrl)
            return res.json({ status: false, message: "O parâmetro url deve ser uma URL válida" })

        let url
        try { url = new URL(urlParam) } catch {
            return res.json({ status: false, message: "URL inválida" })
        }

        const listId = url.searchParams.get("list")
        if (!listId)
            return res.json({ status: false, message: "A URL não contém uma playlist" })

        if (listId.startsWith("RD"))
            return res.json({ status: false, message: "Playlists automáticas (RD) não são suportadas" })

        const result = await yts({ listId })

        return res.json({
            status: true,
            tipo: "playlist",
            resultado: result
        })

    } catch (e) {
        return res.json({ message: "Erro no Servidor Interno" })
    }
})




router.get('/random/mobil', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Mob = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/mobil.json'))
const randMob = Mob[Math.floor(Math.random() * Mob.length)]
data = await fetch(randMob).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/mobil.jpeg', data)
res.sendFile(bla + '/assets/mobil.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})


router.get('/random/anime', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Wai23 = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/wallhp2.json'))
const randWai23 = Wai23[Math.floor(Math.random() * Wai23.length)]
data = await fetch(randWai23).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/wallhp2.jpeg', data)
res.sendFile(bla + '/assets/wallhp2.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})


router.get('/random/wallhp', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Wai22 = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/wallhp.json'))
const randWai22 = Wai22[Math.floor(Math.random() * Wai22.length)]
data = await fetch(randWai22).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/wallhp.jpeg', data)
res.sendFile(bla + '/assets/wallhp.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/waifu2', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Wai2 = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/waifu2.json'))
const randWai2 = Wai2[Math.floor(Math.random() * Wai2.length)]
data = await fetch(randWai2).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/wibu2.jpeg', data)
res.sendFile(bla + '/assets/wibu2.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/waifu', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Wai = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/waifu.json'))
const randWai = Wai[Math.floor(Math.random() * Wai.length)]
data = await fetch(randWai).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/wibu.jpeg', data)
res.sendFile(bla + '/assets/wibu.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})


router.get('/random/hekel', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

Hekel = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/hekel.json'))
const randHekel = Hekel[Math.floor(Math.random() * Hekel.length)]
data = await fetch(randHekel).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/hek.jpeg', data)
res.sendFile(bla + '/assets/hek.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/kucing', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

Kucing = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/kucing.json'))
const randKucing = Kucing[Math.floor(Math.random() * Kucing.length)]
data = await fetch(randKucing).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/kucing.jpeg', data)
res.sendFile(bla + '/assets/kucing.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/wallpaper/pubg', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

Pubg = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/pubg.json'))
const randPubg = Pubg[Math.floor(Math.random() * Pubg.length)]
data = await fetch(randPubg).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/pubg.jpeg', data)
res.sendFile(bla + '/assets/pubg.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/wallpaper/ppcouple', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

Pp = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/profil.json'))
const randPp = Pp[Math.floor(Math.random() * Pp.length)]
data = await fetch(randPp).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/pp.jpeg', data)
res.sendFile(bla + '/assets/pp.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/wallpaper/anjing', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

Anjing = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/anjing.json'))
const randAnjing = Anjing[Math.floor(Math.random() * Anjing.length)]
data = await fetch(randAnjing).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/ajg.jpeg', data)
res.sendFile(bla + '/assets/ajg.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/doraemon', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

Dora = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/doraemon.json'))
const randDora = Dora[Math.floor(Math.random() * Dora.length)]
data = await fetch(randDora).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/dora.jpeg', data)
res.sendFile(bla + '/assets/dora.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})


router.get('/random/elaina', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
const Elaina = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/elaina.json'))
const randElaina = Elaina[Math.floor(Math.random() * Elaina.length)]
//tansole.log(randLoli)
data = await fetch(randElaina).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/elaina.jpeg', data)
res.sendFile(bla + '/assets/elaina.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})


router.get('/random/loli', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
const Loli = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/loli.json'))
const randLoli = Loli[Math.floor(Math.random() * Loli.length)]
//tansole.log(randLoli)
data = await fetch(randLoli).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/loli.jpeg', data)
res.sendFile(bla + '/assets/loli.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})


router.get('/random/yuri', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
const Yuri = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/yuri.json'))
const randYuri = Yuri[Math.floor(Math.random() * Yuri.length)]
//tansole.log(randTech)
data = await fetch(randYuri).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/Yuri.jpeg', data)
res.sendFile(bla + '/assets/Yuri.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})


router.get('/random/cecan', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const cecan = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/cecan.json'))
const randCecan = cecan[Math.floor(Math.random() * cecan.length)]
data = await fetch(randCecan).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/cecan.jpeg', data)
res.sendFile(bla + '/assets/cecan.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})


router.get('/wallpaper/aesthetic', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Aesthetic = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/aesthetic.json'))
const randAesthetic = Aesthetic[Math.floor(Math.random() * Aesthetic.length)]
data = await fetch(randAesthetic).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/aesthetic.jpeg', data)
res.sendFile(bla + '/assets/aesthetic.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})



router.get('/random/sagiri', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Sagiri = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/sagiri.json'))
const randSagiri = Sagiri[Math.floor(Math.random() * Sagiri.length)]
data = await fetch(randSagiri).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/sagiri.jpeg', data)
res.sendFile(bla + '/assets/sagiri.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/shota', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const Shota = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/shota.json'))
const randShota = Shota[Math.floor(Math.random() * Shota.length)]
data = await fetch(randShota).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/shota.jpeg', data)
res.sendFile(bla + '/assets/shota.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

router.get('/random/nsfwloli', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){

const lol = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/nsfwloli.json'))
const randlol = lol[Math.floor(Math.random() * lol.length)]
data = await fetch(randlol).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/lol.jpeg', data)
res.sendFile(bla + '/assets/lol.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

// === ROTA PRINCIPAL NSFW ===
app.get('/random/nsfw/:category', async (req, res) => {
  const { category } = req.params;
  const apikey = req.query.apikey;
  const userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress;

  // Validação da APIKEY
  if (!key.map(i => i.apikey).includes(apikey)) {
    return res.sendFile(path.join(__dirname, "./public/apikey_invalida.html"));
  }

  const userKey = key[key.map(i => i.apikey).indexOf(apikey)];
  if (userKey.request <= 0) {
    return res.json({ message: "Limite de requests esgotado!" });
  }

  RegisKey(apikey, userIp);
  console.log(color(`[NSFW] ${category} • ${apikey} • ${userKey.request} restantes`, 'magenta'));

  // Verifica se a categoria existe
  if (!nsfw[category]) {
    return res.status(404).json({ error: "Categoria NSFW não encontrada!" });
  }

  try {
    const array = nsfw[category];
    const randomUrl = array[Math.floor(Math.random() * array.length)];

    const response = await axios({
      url: randomUrl,
      method: 'GET',
      responseType: 'arraybuffer',
      timeout: 10000
    });

    const contentType = response.headers['content-type'] || 'image/jpeg';
    res.setHeader('Content-Type', contentType);
    if (response.headers['content-length']) {
      res.setHeader('Content-Length', response.headers['content-length']);
    }

    res.send(response.data);
  } catch (error) {
    console.error(color(`[ERRO] ${category}: ${error.message}`, 'red'));
    res.status(500).json({ error: "Erro ao carregar mídia." });
  }
});




app.get('/random/nsfw/tetas', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const response = await axios({
url: 'https://api.dorratz.com/nsfw/tetas',
method: 'GET',
responseType: 'arraybuffer',
})
res.setHeader('Content-Type', response.headers['content-type'])
if (response.headers['content-length']) {
res.setHeader('Content-Length', response.headers['content-length'])
}
res.send(response.data)
} catch (error) {
console.error('Erro ao buscar a imagem:', error.message)
res.status(500).send('Erro ao buscar a imagem.')
}
})

router.get('/random/hinata', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
if(key.map(i => i.apikey)?.includes(apikey)){
const Hinata = JSON.parse(fs.readFileSync(bla + '/base de dados/random/ANIMES-HENTAI/hinata.json'))
const randHin = Hinata[Math.floor(Math.random() * Hinata.length)]
data = await fetch(randHin).then(v => v.buffer())
await fs.writeFileSync(bla + '/assets/Hinata.jpeg', data)
res.sendFile(bla + '/assets/Hinata.jpeg')
} else {
res.json({erro:'Erro no Servidor Interno'})
}
})

app.get("/api/soundcloud/search", async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message: "Coloque o parametro: query"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const tracks = await scdl.searchTracks({ query, limit: 5 })
res.json({ criador: `${criador}`, status: true, resultado: tracks })
} catch (error) {
console.error("Erro ao buscar músicas:", error)
res.status(500).json({ error: "Erro ao buscar músicas.", status: "error" })
}
})

app.get("/api/soundcloud/track-details", async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const trackDetails = await scdl.getTrackDetails(url)
res.json({ criador: `${criador}`, status: true, resultado: trackDetails })
} catch (error) {
console.error("Erro ao obter detalhes da música:", error)
res.status(500).json({ error: "Erro ao obter detalhes da música.", status: "error" })
}
})

app.get('/api/soundcloud', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const scraper = new SoundCloudScraper();
const result = await scraper.scrape(url);
if (!result.status || !result.resultados.link) {
return res.status(404).json({ status: false, message: 'Áudio não encontrado' })
}
const audioUrl = result.resultados.link;
const audioResponse = await axios.get(audioUrl, {
responseType: 'stream',
headers: {
'User-Agent': scraper.userAgent,
Referer: scraper.baseUrl
}
});
res.set({
'Content-Type': 'audio/mpeg',
'Content-Disposition': 'inline; filename="audio.mp3"'
});
audioResponse.data.pipe(res)
} catch (error) {
console.error('Erro no SoundCloudScraper:', error)
res.status(500).json({
status: false,
message: error.message || 'Erro ao processar o áudio'
})
}
})

app.get('/api/manga', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
q = req.query.q
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!q) return res.json({ status : false,message: "Coloque o parametro: q"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
manga(q).then((resultado) => {
res.json({
status: true,
código: 200,
resultado: resultado
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/hentaistube', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
q = req.query.q
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!q) return res.json({ status : false,message: "Coloque o parametro: q"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
hentaistube(q).then((resultado) => {
res.json({
status: true,
código: 200,
resultado: resultado
})}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})})})

app.get('/api/icms', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, valor, ddd } = req.query
if(!apikey) return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!valor) return res.json({ status : false,message: "Coloque o parametro: valor"})
if (!ddd) return res.json({ status : false,message: "Coloque o parametro: ddd"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
icms(valor, ddd).then((data) => {
res.json({status: 200, credits: "Crap Ethern-Bot </Dev>", resultado: data})
}).catch(e => {
res.json({
message: `Erro no Servidor Interno`
})
})
})

app.get('/api/ddd', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { ddd, apikey } = req.query
if(!ddd) return res.json({status:false,message:'cade o parametro DDD'})
if(!apikey) return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
ddds = await axios.get(`https://brasilapi.com.br/api/ddd/v1/${ddd}`)
caixa = []
for(i = 0; i < ddds.data.cities.length; i++) {
caixa.push(ddds.data.cities[i])
}
return res.json({criador: `${criador}`, cidade: ddds.data.state, resultado: caixa})
} catch { res.json({erro: "Erro no servidor interno"}) }
})

app.get('/api/brasileirao', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!apikey) return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const scraper = new BrasileiraoScraper()
const data = await scraper.obterDados()
res.json({ status: true, criador: `${criador}`, resultados: data })
} catch (error) {
res.status(500).json({
status: 'error',
message: 'Erro ao obter dados do Brasileirão',
error: error.message
})
}
})

app.get('/api/get/noticias-space', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, limit } = req.query
if(!limit) return res.json({status:false,message:'cade o parametro limit'})
if(!apikey) return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const scraper = new SpaceNewsScraper()
const resultado = await scraper.executar(Number(limit))
res.json(resultado)
} catch (error) {
res.status(500).json({
status: 'error',
message: 'Erro ao obter dados do Brasileirão',
error: error.message
})
}
})

// ------------ FREE FIRE ------------ //

app.get('/api/get/ff-stalk', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, id } = req.query
if(!id) return res.json({status:false,message:'cade o parametro id'})
if(!apikey) return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const scraper = new FreeFireScraper()
const result = await scraper.getProfileData(id)
res.json(result)
} catch (e) {
console.error(e)
res.json({ erro: 'Erro no Servidor Interno' })
}
})

app.get('/api/get/ff-data-criacao', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, id } = req.query
if(!id) return res.json({status:false,message:'cade o parametro id'})
if(!apikey) return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const checker = new AccountDateChecker()
const rawResult = await checker.checkAccountDate(id)
if (!rawResult.success) {
return res.status(500).json({ status: false, criador: criador, erro: rawResult.error || 'Falha ao verificar conta' })
}
const formattedResult = checker.formatResult(rawResult, id)
res.json(formattedResult)
} catch (e) {
console.error(e)
res.json({ erro: 'Erro no Servidor Interno' })
}
})

app.get('/api/get/ff-player-profile', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, id } = req.query
if(!id) return res.json({status:false,message:'cade o parametro id'})
if(!apikey) return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const scraper = new PlayerProfileScraper()
const result = await scraper.getPlayerProfile(id)
res.json(result)
} catch (e) {
console.error(e)
res.json({ erro: 'Erro no Servidor Interno' })
}
})

app.get('/api/get/ff-send-like', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, id, regiao } = req.query
if(!id) return res.json({status:false,message:'cade o parametro id'})
if(!regiao) return res.json({status:false,message:'cade o parametro regiao'})
if(!apikey) return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!REGIOES_VALIDAS.includes(regiao)) {
return res.status(400).json({ status: false, criador: `${criador}`, resultados: { mensagem: `Região inválida. Regiões válidas: ${REGIOES_VALIDAS.join(', ')}`}})
}
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const scraper = new FreeFireLikesScraper();
scraper.salvarSessao();
const result = await scraper.enviarLike(id, regiao)
res.json({ status: true, criador: `${criador}`, resultados: result })
} catch (e) {
console.error(e)
res.json({ erro: 'Erro no Servidor Interno' })
}
})

app.get('/api/get/ff-reward', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, id } = req.query
if(!id) return res.json({status:false,message:'cade o parametro id'})
if(!apikey) return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await claimFreeFireReward(id)
res.json(result)
} catch (e) {
console.error(e)
res.json({ erro: 'Erro no Servidor Interno' })
}
})

app.get('/api/get/ff-prime-level', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, id } = req.query
if(!id) return res.json({status:false,message:'cade o parametro id'})
if(!apikey) return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await verificarNivelPrime(id)
res.json(result)
} catch (e) {
console.error(e)
res.json({ erro: 'Erro no Servidor Interno' })
}
})

app.get('/api/get/ff-bios', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, limit } = req.query
if(!apikey) return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const scraper = new FreeFireBioScraper()
const result = await scraper.getBios(limit || 30)
res.json(result)
} catch (e) {
console.error(e)
res.json({ erro: 'Erro no Servidor Interno' })
}
})

app.get('/api/get/ff-bios/search', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, term, limit } = req.query
if(!term) return res.json({status:false,message:'cade o parametro term'})
if(!apikey) return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const scraper = new FreeFireBioScraper()
const result = await scraper.searchBios(term, limit || 30)
res.json(result)
} catch (e) {
console.error(e)
res.json({ erro: 'Erro no Servidor Interno' })
}
})

app.get('/api/get/visitasff', async (req, res) => {
  const userIp = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  const { id, apikey } = req.query;
  const criador = 'KEN TAKAKURA'; // Definindo o criador

  // Validação dos parâmetros
  if (!id?.trim()) {
    return res.json({
      status: false,
      criador,
      by: '*_🔎 KEN TAKAKURA VISITAS FF🔍_*',
      message: `Parâmetro "id" inválido. Exemplo: /api/get/visitasff?id=168274223&apikey=abc123`,
    });
  }
  if (!/^\d+$/.test(id.trim())) {
    return res.json({
      status: false,
      criador,
      by: '*_🔎 KEN TAKAKURA VISITAS FF🔍_*',
      message: 'O ID deve conter apenas números.',
    });
  }
  if (!apikey) {
    return res.json({
      status: false,
      criador,
      by: '*_🔎 KEN TAKAKURA VISITAS FF🔍_*',
      message: 'Parâmetro "apikey" não fornecido.',
    });
  }
  if (!key.map(i => i.apikey).includes(apikey)) {
    return res.sendFile(path.join(__dirname, './public/', 'apikey_invalida.html'));
  }
  if (key[key.map(i => i.apikey).indexOf(apikey)].request <= 0) {
    return res.json({
      status: false,
      criador,
      by: '*_🔎 KEN TAKAKURA VISITAS FF🔍_*',
      message: 'Apikey inválida ou requests esgotados!',
    });
  }

  // Registrar uso da API key
  RegisKey(apikey, userIp);
  const ITC = key.map(i => i.apikey).indexOf(apikey);
  console.log(
    color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'),
    color('', 'red'),
    color('Request', 'red'),
    '• ' + color('Ping: ' + ping(), 'red')
  );

  const url = `https://world-ecletix.onrender.com/api/visitasff?id=${encodeURIComponent(id.trim())}`;

  try {
    const response = await fetch(url);
    const json = await response.json();

    if (response.ok && json.success) {
      // Sucesso: retornar o resultado completo da API externa
      return res.json({
        status: true,
        criador,
        by: '*_🔎 KEN TAKAKURA VISITAS FF🔍_*',
        result: json, // Inclui {"success": true, "message": "..."}
        message: json.message || '✅ Visitas enviadas com sucesso!',
      });
    } else {
      // Tratar erro específico da API externa
      return res.json({
        status: false,
        criador,
        by: '*_🔎 KEN TAKAKURA VISITAS FF🔍_*',
        result: json, // Inclui {"error": "ID do pedido não retornado."}
        message: json.error === 'ID do pedido não retornado.'
          ? '❌ ID do perfil inválido ou não reconhecido. Verifique o ID e tente novamente.'
          : '❌ Não foi possível enviar visitas. Tente novamente mais tarde.',
      });
    }
  } catch (err) {
    console.error('Erro na rota /api/get/visitasff:', err);
    return res.json({
      status: false,
      criador,
      by: '*_🔎 KEN TAKAKURA VISITAS FF🔍_*',
      message: '🚨 Ocorreu um erro ao tentar enviar as visitas.',
    });
  }
});

app.get('/api/freefire/stats/players', async (req, res, next) => {
  const userIp = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  const apikey = req.query.apikey;
  const playerId = req.query.id;

  console.log(chalk.yellow('[DEBUG] Recebido:', { apikey, playerId, userIp }));

  if (!apikey || !key.map(i => i.apikey)?.includes(apikey)) {
    console.log(chalk.red('[DEBUG] API Key inválida ou ausente'));
    return res.status(400).sendFile(path.join(__dirname, './public/', 'apikey_invalida.html'));
  }

  const keyIndex = key.map(i => i?.apikey)?.indexOf(apikey);
  if (key[keyIndex]?.request <= 0) {
    console.log(chalk.red('[DEBUG] Limite de requests esgotado'));
    return res.status(403).json({ error: 'Apikey inválida ou requests esgotados!' });
  }

  if (!playerId) {
    console.log(chalk.red('[DEBUG] ID do jogador ausente'));
    return res.status(400).json({ status: false, message: 'Por favor, forneça o ID do jogador.' });
  }

  RegisKey(apikey, userIp);
  console.log(chalk.red(`ApiKey: ${apikey} • Limite: ${key[keyIndex]?.request}`));

  try {
    let apiUrl = `https://api.bielnetwork.com.br/api/stats?id=${playerId}&region=br&match_mode=0`;
    console.log(chalk.yellow('[DEBUG] Chamando API:', apiUrl));
    let response = await fetch(apiUrl);
    console.log(chalk.yellow('[DEBUG] Status da API:', response.status));
    if (!response.ok) throw new Error(`Erro na API: ${response.status} - ${response.statusText}`);
    let result = await response.json();
    console.log(chalk.green('[LOG] Resposta da API:'), result);

    res.setHeader('Content-Type', 'application/json');
    res.json(result);
  } catch (error) {
    console.error(chalk.red('[ERRO] Rota stats:', error.message));
    res.status(500).json({ status: false, message: 'Erro ao buscar estatísticas.', error: error.message });
  }
});

app.get('/api/freefire/player-profile', async (req, res, next) => {
const userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress;
const { apikey, id } = req.query;
if (!id) return res.json({ status: false, message: 'Parâmetro id é obrigatório' });
if (!apikey) return res.json({ status: false, message: 'Parâmetro apikey é obrigatório' });
if (!key.map(i => i.apikey)?.includes(apikey)) {
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"));
}
const keyIndex = key.map(i => i?.apikey)?.indexOf(apikey);
if (key[keyIndex]?.request <= 0) {
    return res.json({ status: false, message: "Apikey inválida ou requests esgotados!" });
}
RegisKey(req.query.apikey, userIp);
console.log(
    color(' ApiKey:' + ` ${apikey} • Limite: ${key[keyIndex]?.request}\n`, 'red'),
    color('', 'red'),
    color('Request', 'red'),
    '• ' + color('Ping: ' + ping(), 'red')
);
try {
const url = `https://world-ecletix.onrender.com/api/infoff?id=${encodeURIComponent(id)}`;
const response = await fetch(url);
const json = await response.json();
if (!response.ok || !json.basicInfo) {
return res.json({ 
status: false, 
message: 'Erro ao obter informações do jogador ou jogador não encontrado'});
}
res.json({
status: true,
message: 'Dados obtidos com sucesso',
data: {
basicInfo: json.basicInfo,
petInfo: json.petInfo || {},
clanBasicInfo: json.clanBasicInfo || {},
profileInfo: json.profileInfo || {},
socialInfo: json.socialInfo || {},
creditScoreInfo: json.creditScoreInfo || {},
diamondCostRes: json.diamondCostRes || {}
}});
} catch (error) {
console.error('Erro no endpoint ff-player-profile:', error);
res.json({ 
status: false, 
message: 'Erro interno do servidor',
error: error.message });
}
});

app.get('/api/freefire/player-profilem', async (req, res) => {
    const userIp = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    const { apikey, uid } = req.query;

    if (!uid) return res.status(400).json({ status: false, message: 'Parâmetro uid obrigatório' });
    if (!/^\d+$/.test(uid)) return res.status(400).json({ status: false, message: 'Uid deve ser numérico' });
    if (!apikey) return res.status(400).json({ status: false, message: 'Parâmetro apikey obrigatório' });

    const keyIndex = key.findIndex(item => item?.apikey === apikey);
    if (keyIndex === -1) return res.status(401).sendFile(path.join(__dirname, 'public', 'apikey_invalida.html'));
    if (key[keyIndex].request <= 0) return res.status(429).json({ status: false, message: 'Apikey inválida ou sem requisições' });

    await RegisKey(apikey, userIp);
    console.log(color(`ApiKey: ${apikey} • Limite: ${key[keyIndex].request} • Ping: ${ping()}`, 'red'));

    try {
        const url = `https://discordbot.freefirecommunity.com/player_info_api?uid=${encodeURIComponent(uid)}&region=br`;
        const response = await axios.get(url, {
            headers: {
                'Origin': 'https://www.freefirecommunity.com',
                'Referer': 'https://www.freefirecommunity.com/ff-account-info/',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K)',
                'Accept': '*/*'
            }
        });

        if (!response.data.player_info) {
            return res.status(404).json({ status: false, message: 'Jogador não encontrado' });
        }

        const { basicInfo = {}, creditScoreInfo = {}, petInfo = {}, profileInfo = {}, socialInfo = {} } = response.data.player_info;
        const safe = (v, f = 'N/D') => v ?? f;
        const formatDate = (unix) => unix ? moment.unix(unix).format('DD/MM/YYYY HH:mm:ss') : 'N/D';

        const bannerImageUrl = `https://discordbot.freefirecommunity.com/outfit_image_api?uid=${encodeURIComponent(uid)}&region=br`;
        let bannerLink = 'https://files.catbox.moe/7evdvb.jpg';
        let outfitLink = bannerLink;

        try {
            const bannerResponse = await axios.get(bannerImageUrl, { responseType: 'arraybuffer' });
            if (bannerResponse.status === 200) {
                bannerLink = await upload2(Buffer.from(bannerResponse.data), `player_banner_${uid}.png`);
            }
        } catch (error) {
            console.log(chalk.yellow(`Falha no banner: ${error.message}`));
        }

        try {
            const outfitResponse = await axios.get(bannerImageUrl, { responseType: 'arraybuffer' });
            if (outfitResponse.status === 200) {
                outfitLink = await upload2(Buffer.from(outfitResponse.data), `player_outfit_${uid}.png`);
            }
        } catch (error) {
            console.log(chalk.yellow(`Falha no traje: ${error.message}`));
        }

        const playerData = {
            nickname: safe(basicInfo.nickname),
            accountId: safe(basicInfo.accountId),
            regiao: safe(basicInfo.region, 'Brasil'),
            nivel: safe(basicInfo.level),
            curtidas: safe(basicInfo.liked),
            rank: safe(basicInfo.rank),
            rankMaximo: safe(basicInfo.maxRank),
            rankCS: safe(basicInfo.csRank),
            exp: safe(basicInfo.exp),
            criadaEm: formatDate(basicInfo.createAt),
            ultimoLogin: formatDate(basicInfo.lastLoginAt),
            pontosRank: safe(basicInfo.rankingPoints),
            versaoLancamento: safe(basicInfo.releaseVersion),
            idTemporada: safe(basicInfo.seasonId),
            nivelPrime: safe(basicInfo.primeLevel?.level, '-'),
            custoDiamantes: safe(response.data.diamondCostRes?.diamondCost, '-'),
            pet: {
                nome: safe(petInfo.name, '-'),
                nivel: safe(petInfo.level, '-'),
                exp: safe(petInfo.exp, '-'),
                idSkin: safe(petInfo.skinId, '-'),
                idHabilidade: safe(petInfo.selectedSkillId, '-')
            },
            perfil: {
                idAvatar: safe(profileInfo.avatarId, '-'),
                roupas: Array.isArray(profileInfo.clothes?.ids) ? profileInfo.clothes.ids.join(', ') : '-',
                habilidadesEquipadas: Array.isArray(profileInfo.equippedSkills) ? profileInfo.equippedSkills.map(s => s.skillId).join(', ') : '-'
            },
            tagsBatalha: Array.isArray(socialInfo.battleTag) && socialInfo.battleTag.length > 0
                ? socialInfo.battleTag.map((t, i) => `${t} (${socialInfo.battleTagCount?.[i] || 0}x)`).join('\n')
                : 'N/D',
            idioma: safe(socialInfo.language),
            exibirRank: safe(socialInfo.rankShow),
            assinatura: safe(socialInfo.signature),
            pontuacaoCredito: safe(creditScoreInfo.creditScore),
            estadoRecompensa: safe(creditScoreInfo.rewardState),
            imagens: { banner: bannerLink, traje: outfitLink }
        };

        return res.status(200).json({
            status: true,
            message: 'Dados obtidos com sucesso',
            resultado: playerData
        });
    } catch (error) {
        console.log(chalk.red(`Erro na rota: ${error.message}`));
        const message = error.response?.status === 400 ? 'ID inválido ou não encontrado' : error.message;
        return res.status(500).json({ status: false, message: `Erro: ${message}`, resultado: 'error' });
    }
});

app.get('/api/get/ff-skins', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, id } = req.query

if(!id) return res.json({status:false,message:'cade o parametro id'})
if(!apikey) return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})

RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request FF-Skins', 'red'), '• ' + color('Ping: ' + ping(), 'red'))

try {
const scraper = new FreeFireSkinscraper()
const result = await scraper.getSkinsData(id)
res.json(result)
} catch (e) {
console.error(e)
res.json({ erro: 'Erro no Servidor Interno' })
}
})


/**
 * API endpoint para envio de likes
 * @developer {DEVELOPER}
 */
app.get('/api/get/likes-ff', async (req, res) => {
try {
    const userIp = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    const { uid, apikey } = req.query;

    if (!uid) return res.json({ status: false, message: 'Parâmetro UID não informado', developer: DEVELOPER });
    if (!key.some(item => item.apikey === apikey)) {
      return res.sendFile(path.join(__dirname, 'public', 'apikey_invalida.html'));
    }
    const keyIndex = key.findIndex(item => item.apikey === apikey);
    if (key[keyIndex].request <= 0) {
      return res.json({ status: false, message: 'API Key inválida ou limite esgotado', developer: DEVELOPER });
    }

    RegisKey(apikey, userIp);
    console.log(color(`[${DEVELOPER}] ApiKey: ${apikey} • Limite: ${key[keyIndex].request} • Ping: ${ping()}`, 'red'));

    const filePath = path.join(__dirname, 'database', 'likes_enviados.json');
    await ensureFileExists(filePath);
    const savedLikes = JSON.parse(await fspromises.readFile(filePath, 'utf8'));

    await cleanOldRecords(savedLikes, filePath);

    if (savedLikes[uid]) {
      const { nickname, likes_enviados, timestamp } = savedLikes[uid];
      const dateObj = new Date(timestamp);
      return res.json({
        status: false,
        message: 'Usuário já recebeu likes',
        data: {
          nickname: nickname || 'Desconhecido',
          data: dateObj.toLocaleDateString('pt-BR'),
          hora: dateObj.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
          ultima_quantidade_enviada: likes_enviados
        },
        developer: DEVELOPER
      });
    }

    const authKey = 'leroyadmff3m';
    const likeRes = await axios.get(`https://likes.ffgarena.cloud/api/v2/likes?uid=${uid}&amount_of_likes=100&auth=${authKey}`);
    const likeData = likeRes.data;

    if (!likeData || likeData.status !== 200) {
      return res.json({ status: false, message: 'Resposta inválida ou API offline', developer: DEVELOPER });
    }

    const { nickname, likes_antes, likes_depois, sent } = likeData;
    const likes_enviados = normalizeSentValue(sent);

    if (likes_enviados === 0) {
      return res.json({
        status: false,
        message: `Nenhum like enviado para ${nickname || 'Desconhecido'}. Possível limite atingido ou já processado por outro bot`,
        data: { nickname, likes_antes, likes_depois, likes_enviados },
        developer: DEVELOPER
      });
    }

    savedLikes[uid] = {
      nickname: nickname || 'Desconhecido',
      likes_enviados,
      timestamp: new Date().toISOString()
    };
    await fspromises.writeFile(filePath, JSON.stringify(savedLikes, null, 2));

    return res.json({
      status: true,
      message: 'Likes enviados com sucesso',
      data: { nickname, likes_antes, likes_depois, likes_enviados },
      developer: DEVELOPER
    });

  } catch (error) {
    console.error(`[${DEVELOPER}] Erro ao processar requisição de likes:`, error);
    return res.json({ status: false, message: 'ID incorreto ou problema na API', developer: DEVELOPER });
  }
});


app.get('/api/get/ff-banned-account', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, id } = req.query
if(!id) return res.json({status:false,message:'cade o parametro id'})
if(!apikey) return res.json({status:false,message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const scraper = new BannedAccountsScraper()
const result = await scraper.verificarContaBanida(id)
res.json(result)
} catch (e) {
console.error(e)
res.json({ erro: 'Erro no Servidor Interno' })
}
})

// --------------- FIM ----------------- //

app.get('/api/ttp',async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
if(!texto)return res.json({
status:false,
message:'Cade o parametro texto??'
})
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
cor = ["f702ff","ff0202","00ff2e","efff00","00ecff","3100ff","ffb400","ff00b0","00ff95","efff00"] //CORES COLOQUE QUALQUER UMA MAS EM CODE
fonte = ["Days%20One","Domine","Exo","Fredoka%20One","Gentium%20Basic","Gloria%20Hallelujah","Great%20Vibes","Orbitron","PT%20Serif","Pacifico"]//FONTS NÃO MEXA
cores = cor[Math.floor(Math.random() * (cor.length))]
fontes = fonte[Math.floor(Math.random() * (fonte.length))] 
sitee = `https://huratera.sirv.com/PicsArt_08-01-10.00.42.png?profile=Example-Text&text.0.text=${texto}&text.0.outline.color=000000&text.0.outline.blur=0&text.0.outline.opacity=55&text.0.color=${cores}&text.0.font.family=${fontes}&text.0.background.color=ff0000`
res.type('jpg')
res.send(await getBuffer(sitee))
})

app.get('/api/fbdown',(req,res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
url = req.query.url
if(!url)return res.json({
status:false,
message:'Cade o parametro url??'
})
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
down.fbdown(url)
.then(e => {
res.json({
status:true,
resultado: e})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/photooxy',(req,res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
url = req.query.url
text = req.query.text
if(!url)return res.json({
status:false,
message:'Cade o parametro url??'
})
if(!text)return res.json({
status:false,
message:'Cade o parametro text??'
})
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
photooxy(url, text)
.then(e => {
res.json({
status:true,
resultado: e})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/wallpaperanime', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
apikey = req.query.apikey
const q = 'papel de parede de anime'
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const images = await googleImageSearch(q)
if (images.length > 0) {
const randomIndex = Math.floor(Math.random() * images.length)
const imageUrl = images[randomIndex]
const response = await axios.get(imageUrl, { responseType: 'arraybuffer' })
const imageBuffer = Buffer.from(response.data, 'binary')
res.set('Content-Type', 'image/jpeg')
res.send(imageBuffer)
} else {
res.json({
status: false,
message: 'Não encontrei imagem'
})
}
} catch (e) {
console.error(e)
res.json({ erro: 'Erro no Servidor Interno' })
}
})

app.get("/api/google-img", async(req, res) => {
try {
apikey = req.query.apikey
nome = req.query.nome
if(!nome) return res.json({message: "Faltando o parametro nome"})
if(!apikey)return res.json({message:'cade o parametro apikey'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
await gis(nome, logResults)
function logResults(error, results) {
if (error) {
console.log(error)
return res.json({message: "Erro.."})
} else {
return res.send(results)
}
}
} catch (e) {
return res.json({message: "Erro.."})
}
})

app.get('/api/ssweb', async (req, res) => {
  try {
  userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
  
    const url = req.query.url
    const apikey = req.query.apikey

    if (!url) return res.json({ status: false, motivo: 'nao_tem_url' })

    if (!key.map(i => i.apikey)?.includes(apikey))
      return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))

    const ITC = key.map(i => i?.apikey)?.indexOf(apikey)
    if (key[ITC]?.request <= 0)
      return res.json({ message: "Apikey inválida ou requests esgotados!" })

    RegisKey(apikey, userIp)

    console.log(
      color(` ApiKey: ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'),
      color('', 'red'),
      color('Request', 'red'),
      '• ' + color('Ping: ' + ping(), 'red')
    )

    // ================================
    // 🔥 SCRAPPER EMBUTIDO AQUI 🔥
    // ================================

    const token = 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE1MjMzNjQ4MjQsIm5iZiI6MTUyMzM2NDgyNCwianRpIjoicHJvamVjdF9wdWJsaWNfYzkwNWRkMWMwMWU5ZmQ3NzY5ODNjYTQwZDBhOWQyZjNfT1Vzd2EwODA0MGI4ZDJjN2NhM2NjZGE2MGQ2MTBhMmRkY2U3NyJ9.qvHSXgCJgqpC4gd6-paUlDLFmg0o2DsOvb1EUYPYx_E'

    // 1) Upload
    const f1 = new FormData()
    f1.append('task', 't0bbjt9wrvbj7yAqlwgbt7r37dvdfmnthfz6zgmt15pt3j3scwp73hxkhyb63lzh5bkc9mj09Az5dmkww8b3nvA91dx2nld6djbdsd6n6vtyccphcj01j76q6vm9l26rct5yk4kf7bm35f6Axl11c4n6tq56jzjr1nh6mpfgv6xdtggvzbd1')
    f1.append('cloud_file', url)

    const up = await axios.post('https://api32.ilovepdf.com/v1/upload', f1, {
      headers: { ...f1.getHeaders(), authorization: token }
    })

    // 2) Preview
    const f2 = new FormData()
    f2.append('server_filename', up.data.server_filename)
    f2.append('task', 't0bbjt9wrvbj7yAqlwgbt7r37dvdfmnthfz6zgmt15pt3j3scwp73hxkhyb63lzh5bkc9mj09Az5dmkww8b3nvA91dx2nld6djbdsd6n6vtyccphcj01j76q6vm9l26rct5yk4kf7bm35f6Axl11c4n6tq56jzjr1nh6mpfgv6xdtggvzbd1')
    f2.append('url', url)
    f2.append('view_width', '596')
    f2.append('to_format', 'jpg')
    f2.append('block_ads', 'false')
    f2.append('remove_popups', 'false')

    const prev = await axios.post('https://api32.ilovepdf.com/v1/preview', f2, {
      headers: { ...f2.getHeaders(), authorization: token }
    })

    const finalImage = 'https://api32.ilovepdf.com/thumbnails/' + prev.data.thumbnail

    // 3) Baixar imagem final
    const img = await axios.get(finalImage, { responseType: 'arraybuffer' })

    res.type('jpg')
    res.send(img.data)

  } catch (e) {
    console.log(e)
    res.json({ erro: 'Erro no Servidor Interno' })
  }
})

app.get('/api/avatar',(req,res,next) => {
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
fetch(encodeURI(`https://nekos.life/api/v2/img/avatar`))
.then(response => response.json())
.then(async (data) => {
resultado =data
bala = await getBuffer(resultado.url)
res.type('jpg')
res.send(bala)
})
.catch(e => {
res.json({erro:'erro'})
})
})

app.get('/api/tempmail/criar-email', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
var resS = await axios.get('https://www.1secmail.com/api/v1/?action=genRandomMailbox')
var data = await resS.data
res.json({
status: true,
criador: `${criador}`,
resultado: data[0]
})
} catch (err) {
res.json({resultado: `Erro`})
}
})
 
app.get('/api/tempmail/ler-inbox', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { domain, login, apikey } = req.query
if(!domain) return res.json({status:false,resultado: 'Cadê o parâmetro domain?'})
if(!login) return res.json({status:false,resultado: 'Cadê o parâmetro login?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
var ress = await axios.get(`https://www.1secmail.com/api/v1/?action=getMessages&login=${login}&domain=${domain}`)
var data = ress.data
res.json({
status: true,
criador: `${criador}`, 
resultado: data
})
} catch (err) {
res.json({resultado: `Erro`})
}
})

app.get('/api/image2comic', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, url } = req.query
if(!apikey)return res.json({message:'cade o parametro apikey'})
if(!url) return res.json({message: "Faltando o parametro url"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await Image2Comic(url)
const imageResponse = await fetch(result.hasil)
if (!imageResponse.ok) {
throw new Error(`Erro ao baixar imagem processada: ${imageResponse.statusText}`)
}
const imageBuffer = await imageResponse.buffer()
const contentType = imageResponse.headers.get('content-type') || 'image/jpeg'
res.set({
'Content-Type': contentType,
'Content-Length': imageBuffer.length,
'Content-Disposition': 'inline; filename="comic-image.jpg"',
'Cache-Control': 'public, max-age=3600'
})
res.send(imageBuffer)
} catch (error) {
console.error('Erro no Image2Comic:', error)
res.status(500).json({ 
status: false, 
error: 'Erro ao processar imagem', 
details: error.message 
})
}
})

app.get('/api/legenda',async (req,res,next) => {
url = req.query.url
texto1 = req.query.texto1
texto2 = req.query.texto2
if(!url)return res.json({
status:false,
motivo:'nao_tem_url'
})
if(!texto1)return res.json({
status:false,
motivo:'nao_tem_texto_1'
})
if(!texto2)return res.json({
status:false,
motivo:'nao_tem_texto_2'
})
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
bala = await getBuffer(`https://api.memegen.link/images/custom/${texto1}/${texto2}.png?background=${url}`)
res.type('jpg')
res.send(bala)
})

app.get('/api/github',(req,res,next) => {
pessoa = req.query.usuario
if(!pessoa)return res.json({
status:false,
motivo:'cade_o_usuario'
})
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
fetch(encodeURI(`https://api.github.com/users/`+pessoa))
.then(response => response.json())
.then(date => {
gitData =date
res.json({
criador:"paulo_mod_domina ツ",
status:true,
resultado:{
username: gitData.login,
id: gitData.id,
Node_ID: gitData.node_id,
url: gitData.html_url,
local: (gitData.location == null) ? 'não_tem' : gitData.location,
bio: (gitData.bio == null) ? 'não_tem' : gitData.bio,
twitter:(gitData.twitter_username == null) ? 'não_tem' : gitData.twitter_username,
seguidores: gitData.followers,
seguindo: gitData.following,
criado: gitData.created_at,
atualizado: gitData.updated_at,
procura_trabalho: (gitData.hireable == null) ? 'Não' : gitData.hireable,
Site: (gitData.blog == "") ? 'Não' : gitData.blog,
repositorios: gitData.public_repos,
admin_de_Site: (gitData.site_admin == false) ? 'Não' : gitData.site_admin,
tipo: gitData.type,
empresa: (gitData.company == null) ? 'Não' : gitData.company,
email: (gitData.email == null) ? 'Não' : gitData.email
} 
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/wiki',(req,res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
texto = req.query.texto
if(!texto)return res.json({
status:false,
message:'Cade o parametro texto??'
})
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
wiki.search(`${texto}`, 'pt')
.then(async (wikip) => {
const wikis = await axiosapp.get(`https://pt.wikipedia.org/w/api.php?format=json&action=query&prop=extracts&exintro&explaintext&redirects=1&pageids=${wikip[0].pageid}`)
const getData = Object.keys(wikis.data.query.pages)

res.json({
status:true,
resultado:wikis.data.query.pages[getData].extract
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/dl/twitter2',(req,res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
url = req.query.url
if(!url)return res.json({status:false, message:'Cade o parametro url??'})
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
fetchTwitterMedia(url).then(data => {
res.json({status:true, resultado: data})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/ytsrc',(req,res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
q = req.query.q
if(!q)return res.json({
status:false,
message:'Cade o parametro q??'
})
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
ytSearch(q)
.then(e => {
res.json({
status:true,
resultado:e
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/ytsrc/videos',(req,res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
q = req.query.q
if(!q)return res.json({
status:false,
message:'Cade o parametro q??'
})
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
ytVideosSearch(q)
.then(e => {
res.json({
status:true,
resultado:e
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/ia/midjourney', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
var query = req.query.query
if(!query)return res.json({status:false,message:'- Cadê o parâmetro query?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
require('fs').writeFileSync(bla + '/assets/gostosinha.jpg', `https://aemt.me/ai/text2img?text=${query}`, 'base64')
res.sendFile(bla + '/assets/gostosinha.jpg')
} catch(e) {
console.log(e)
res.json({erro:'Erro no Servidor Interno'})
}
})

app.get('/api/ia/toanime', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, url } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "faltando o parametro: url"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const startTime = Date.now()
const result = await main(url)
const duration = Date.now() - startTime
const resultado = {
status: true,
criador: `${criador}`,
resultado: {
img: result.img_url,
duracao: `${duration}ms`
}
}
res.json(resultado)
} catch (error) {
console.error("Erro no processamento:", error)
res.status(500).json({ 
status: false,
error: "Ocorreu um erro ao processar a imagem",
detalhes: error.message
})
}
})



app.get('/api/ia/nano-banana', async (req, res) => {
  const userIp = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress
  const { apikey, url, prompt } = req.query

  if (!key.map(i => i.apikey)?.includes(apikey)) {
    return res.sendFile(path.join(__dirname, './public/', 'apikey_invalida.html'))
  }

  const ITC = key.map(i => i?.apikey)?.indexOf(apikey)
  if (key[ITC]?.request <= 0) {
    return res.json({ message: 'Apikey inválida ou requests esgotados!' })
  }

  if (!url) {
    return res.json({ status: false, message: 'faltando o parametro: url' })
  }

  RegisKey(apikey, userIp)

  try {
    const startTime = Date.now()
    const result = await nanoBananaFromUrl(url, prompt || 'transformar em anime')
    const duration = Date.now() - startTime

    if (!result.ok) {
      return res.status(500).json({
        status: false,
        error: result.error
      })
    }

    const resposta = {
      status: true,
      criador,
      resultado: {
        img: result.output,
        input: result.input,
        duracao: `${duration}ms`
      }
    }
    res.json(resposta)
  } catch (error) {
    console.error('Erro no processamento:', error)
    res.status(500).json({
      status: false,
      error: 'Ocorreu um erro ao processar a imagem',
      detalhes: error.message
    })
  }
})



app.get('/api/ia/tofigure', async (req, res, next) => {
  const userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress;
  const { apikey, url } = req.query;

  if (!key.map(i => i.apikey)?.includes(apikey)) {
    return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"));
  }

  const ITC = key.map(i => i?.apikey)?.indexOf(apikey);
  if (key[ITC]?.request <= 0) {
    return res.json({ message: "Apikey inválida ou requests esgotados!" });
  }

  if (!url) {
    return res.json({ status: false, message: "faltando o parametro: url" });
  }

  RegisKey(apikey, userIp);

  try {
    const startTime = Date.now();
    const resultBuffer = await tofigure(url); // retorna o buffer da imagem
    const duration = Date.now() - startTime;

    // Define cabeçalhos e envia a imagem diretamente
    res.setHeader("Content-Type", "image/jpeg");
    res.setHeader("X-Processing-Time", `${duration}ms`);
    res.send(resultBuffer);

  } catch (error) {
    console.error("Erro no processamento:", error);
    res.status(500).json({
      status: false,
      error: "Ocorreu um erro ao processar a imagem",
      detalhes: error.message
    });
  }
});

app.get('/api/ia/tozombie', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, url } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "faltando o parametro: url"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const startTime = Date.now()
const result = await toZombie(url)
const duration = Date.now() - startTime
const resultado = {
status: true,
criador: `${criador}`,
resultado: {
img: result,
duracao: `${duration}ms`
}
}
res.json(resultado)
} catch (error) {
console.error("Erro no processamento:", error)
res.status(500).json({ 
status: false,
error: "Ocorreu um erro ao transformar em zumbi",
detalhes: error.message
})
}
})

app.get('/api/ia/togta', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, url } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "faltando o parametro: url"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const startTime = Date.now()
const result = await img2gtas(url)
const duration = Date.now() - startTime
const resultado = {
status: true,
criador: `${criador}`,
resultado: {
img: result.img_url,
duracao: `${duration}ms`
}
}
res.json(resultado)
} catch (error) {
console.error("Erro no processamento:", error)
res.status(500).json({ 
status: false,
error: "Ocorreu um erro ao transformar para estilo GTA",
detalhes: error.message
})
}
})

/*
app.get('/api/ia/tohd', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
var { apikey, url } = req.query
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({ message: "Apikey inválida ou requests esgotados!" })
if (!url) return res.json({ status: false, message: "faltando o parametro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const resolutions = ['2k', '1080p', '720p', '480p'];
let result;
let lastError;
for (const resolution of resolutions) {
try {
console.log(`Tentando upscale em ${resolution}...`)
result = await upscale(url, resolution)
break;
} catch (error) {
lastError = error
console.log(`Falha em ${resolution}: ${error.message}`)
}
}
if (!result) {
return res.status(500).json({ error: 'Todas as resoluções falharam', details: lastError.message })
}
res.redirect(result.url)
} catch (error) {
console.error('Erro no endpoint:', error)
res.status(500).json({ error: 'Erro no processamento', details: error.message })
}
})
*/

app.get('/api/ia/tohd', async (req, res) => {
  const userIp =
    req.ip ||
    req.headers['x-forwarded-for'] ||
    req.connection.remoteAddress

  const { apikey, url } = req.query

  // 🔑 valida apikey
  if (!key.map(i => i.apikey)?.includes(apikey))
    return res.sendFile(
      path.join(__dirname, './public/', 'apikey_invalida.html')
    )

  const ITC = key.map(i => i?.apikey)?.indexOf(apikey)

  if (key[ITC]?.request <= 0)
    return res.json({
      status: false,
      message: 'Apikey inválida ou requests esgotados!'
    })

  if (!url)
    return res.json({
      status: false,
      message: 'faltando o parametro: url'
    })

  // 📊 registra request
  RegisKey(apikey, userIp)

  console.log(
    color(` ApiKey: ${apikey} • Limite: ${key[ITC]?.request}`, 'red'),
    color('Request', 'red'),
    '• ' + color('Ping: ' + ping(), 'red')
  )

  // 🧠 processamento
  try {
    const result = await imgUpscaleFromUrl(url)

    if (!result.ok) {
      return res.status(500).json({
        status: false,
        message: result.error
      })
    }

    res.set({
      'Content-Type': result.contentType,
      'X-Engine': result.engine,
      'Cache-Control': 'public, max-age=86400'
    })

    return res.send(result.buffer)

  } catch (err) {
    console.error('[UPSCALE ERROR]', err)
    return res.status(500).json({
      status: false,
      message: 'Erro interno no servidor'
    })
  }
})
app.get('/api/ia/tohdvideo', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
var { apikey, url, operation } = req.query
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({ message: "Apikey inválida ou requests esgotados!" })
if (!url) return res.json({ status: false, message: "faltando o parametro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const tempDir = path.join(__dirname, 'base de dados/tohd')
const tempVideoPath = path.join(tempDir, 'temp_video.mp4')
const outputVideoPath = path.join(tempDir, 'output_video_hd.mp4')
if (!fs.existsSync(tempDir)) {
fs.mkdirSync(tempDir, { recursive: true })
}
// Baixar o vídeo
const response = await axios({
url: url,
method: 'GET',
responseType: 'stream'
})
const writer = fs.createWriteStream(tempVideoPath)
response.data.pipe(writer)
writer.on('finish', () => {
ffmpeg(tempVideoPath)
.outputOptions([
'-vf', 'scale=-2:1440',
'-c:v', 'libx264',
'-crf', '23',
'-preset', 'medium',
'-movflags', '+faststart',
'-pix_fmt', 'yuv420p'
])
.on('start', commandLine => {
console.log('Comando FFmpeg: ' + commandLine)
})
.on('progress', progress => {
console.log('Progresso: ' + JSON.stringify(progress))
})
.on('error', (err, stdout, stderr) => {
console.error('Erro ao processar o vídeo:', err)
console.error('stdout:', stdout)
console.error('stderr:', stderr)
res.status(500).json({ error: "Erro ao processar o vídeo: " + err.message })
if (fs.existsSync(tempVideoPath)) fs.unlinkSync(tempVideoPath)
if (fs.existsSync(outputVideoPath)) fs.unlinkSync(outputVideoPath)
})
.on('end', () => {
console.log('Processamento de vídeo concluído')
const outputBuffer = fs.readFileSync(outputVideoPath)
res.writeHead(200, {
'Content-Type': 'video/mp4',
'Content-Length': outputBuffer.length
})
res.end(outputBuffer)
setTimeout(() => {
if (fs.existsSync(tempVideoPath)) fs.unlinkSync(tempVideoPath)
if (fs.existsSync(outputVideoPath)) fs.unlinkSync(outputVideoPath)
}, 3600000) // 1 hora em milissegundos
})
.save(outputVideoPath)
})
writer.on('error', (err) => {
console.error('Erro ao baixar o vídeo:', err)
res.status(500).json({ error: "Erro ao baixar o vídeo: " + err.message })
})
} catch (e) {
res.status(500).json({ status: 500, message: "Erro no Servidor Interno." })
}
})

app.get('/api/ia/removebg', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, url } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "faltando o parametro: url"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(`📥 Processando imagem para sem fundo: ${url}`)
const bufferSemFundo = await sfundo.executarFluxo(url)
if (!bufferSemFundo) {
return res.status(500).json({ erro: 'Erro ao remover fundo da imagem' })
}
res.setHeader('Content-Type', 'image/png')
res.send(bufferSemFundo)
} catch (erro) {
console.error('❌ Erro:', erro)
res.status(500).json({ erro: 'Erro interno ao processar a imagem' })
}
})

// ÍNICIO DOS WALLPAPERS

app.get('/api/wallpapers/random', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/ASIÁTICAS/','random.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers/china', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/ASIÁTICAS/','china.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers/hijaber', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/ASIÁTICAS/','hijaber.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers/indonesia', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/ASIÁTICAS/','indonesia.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers/japan', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/ASIÁTICAS/','japan.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers/korea', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/ASIÁTICAS/','korea.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers/malaysia', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/ASIÁTICAS/','malaysia.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers/thailand', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/ASIÁTICAS/','thailand.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers/vietnam', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/ASIÁTICAS/','vietnam.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/aesthetic', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','aesthetic.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/anjing', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','anjing.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/blackpink', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','blackpink.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/boneka', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','boneka.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/cecan', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','cecan.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/hekel', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','hekel.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/justina', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','justina.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/kayes', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','kayes.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/kucing', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','kucing.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/kpop', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','kpop.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/mobil', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','mobil.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/montor', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','montor.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/notnot', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','notnot.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/profil', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','profil.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/pubg', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','pubg.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/rose', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','rose.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/ryujin', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','ryujin.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/wallhp', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','wallhp.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

app.get('/api/wallpapers2/wallml', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const jsonFilePath = path.join('./base de dados/random/RANDOM-IMAGEM/','wallml.json')
if (!fs.existsSync(jsonFilePath)) {
return res.status(404).json({ message: 'Arquivo JSON da categoria não encontrado.' })
}
const imageUrls = JSON.parse(fs.readFileSync(jsonFilePath, 'utf8'))
if (!imageUrls || imageUrls.length === 0) {
return res.status(404).json({ message: 'Nenhuma imagem disponível para essa categoria.' })
}
const randomImage = imageUrls[Math.floor(Math.random() * imageUrls.length)]
const response = await axios({
url: randomImage,
method: 'GET',
responseType: 'arraybuffer'
})
res.writeHead(200, {
'Content-Type': 'image/jpeg',
'Content-Length': response.data.length
})
res.end(response.data)
} catch (error) {
console.error('Erro ao processar a imagem:', error)
res.status(500).json({ message: 'Erro ao processar a imagem.' })
}
})

// FIM DOS WALLPAPERS

router.get('/api/linkshort/tinyurl', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
var url = req.query.url
if(!url)return res.json({status:false,message:'- Cadê o parâmetro url?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
var islink = isUrl(url)
if (!islink) return res.json({ status : false, message : "[!] insira uma url válido"})
TinyURL.shorten(url, function(url, err) {
if (!err) return res.json({erro: "Erro no Servidor Interno"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
res.json({status: true, result: url})
})
})

router.get('/api/linkshort/cuttly', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
var url = req.query.url
if(!url)return res.json({status:false,message:'- Cadê o parâmetro url?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
var islink = isUrl(url)
if (!islink) return res.json({ status : false, message : "[!] insira uma url válido"})
let randomapicuttly = apicuttly[Math.floor(Math.random() * apicuttly.length)]
var hasil = await fetchJson(`https://cutt.ly/api/api.php?key=${randomapicuttly}&short=${url}`)
if (!hasil.url.shortLink) returnres.json({erro: "Erro no Servidor Interno"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
res.json({status: true, criador: `${criador}`,result: hasil.url.shortLink})
})


router.get('/api/linkshort/bitly', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
var url = req.query.url
if(!url)return res.json({status:false,message:'- Cadê o parâmetro url?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
var islink = isUrl(url)
if (!islink) return res.json({ status : false, message : "[!] insira uma url válido"})
let randomapibitly = apibitly[Math.floor(Math.random() * apibitly.length)]
const bitly = new BitlyClient(randomapibitly)
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
bitly.shorten(url).then(function(result) {
res.json({status: true, criador: `${criador}`, result : result.url})
}).catch(function(error) {
 res.json({erro: "Erro no Servidor Interno"})
})
})

router.get('/api/linkshort/tinyurlwithalias', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var url = req.query.url
var alias = req.query.alias
var apikey = req.query.apikey
if(!apikey)return res.json({status:false,message:'- Cadê o parâmetro apikey?'})
if(!alias)return res.json({status:false,message:'- Cadê o parâmetro alias?'})
if(!url)return res.json({status:false,message:'- Cadê o parâmetro url?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
var islink = isUrl(url)
if (!islink) return res.json({ status : false, message : "[!] insira parâmetros de URL"})
TinyURL.shortenWithAlias({url: url, alias: shortText(alias, 30)}).then(function(url){
if (url == "Error") return res.json({erro: "Erro no Servidor Interno"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
res.json({status: true, criador: `${criador}`, result: url})
})
})

router.get('/api/info/translate', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
text = req.query.texto
ling = req.query.ling
apikey = req.query.apikey
if (apikey === undefined) return res.status(404).send({status: 404, message: `insira o parâmetro apikey`})
if (!text ) return res.json({ status : false, message : "digite o parâmetro de texto."})
if (!ling ) return res.json({ status : false, message : "parâmetro de entrada: ling. Você pode ver a lista de idiomas em https://cloud.google.com/translate/docs/languages"})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
defaultLang = 'en'
tld = 'pt'
let result
try {
result = await translate(`${text}`, {
tld,
to: ling,
})
} catch (e) {
result = await translate(`${text}`, {
tld,
to: defaultLang,
})
} finally {
res.json({
status: true,
result: result[0]
})}})

app.get('/random/:categoria', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, categoria } = req.query
const categoriasValidas = ['aleatorios', 'bleach', 'chainsaw', 'demon_slayer', 'dragonball', 'hunter_edit', 'jujutsu_kaisen', 'narutoedit', 'zerotwo']
if (!categoria) {
return res.json({ status: false, message: "Parâmetro 'categoria' ausente" })
}
if (!categoriasValidas.includes(categoria)) {
return res.json({ message: "Categoria indisponível." })
}
const databases = {
aleatorios: "./base de dados/random/EDIT-ANIMES/ALEATORIOS.json",
bleach: "./base de dados/random/EDIT-ANIMES/BLEACH.json",
chainsaw: "./base de dados/random/EDIT-ANIMES/CHAINSAW.json",
demon_slayer: "./base de dados/random/EDIT-ANIMES/DEMON_SLAYER.json",
dragonball: "./base de dados/random/EDIT-ANIMES/DRAGONBALL.json",
hunter_edit: "./base de dados/random/EDIT-ANIMES/HUNTER_X.json",
jujutsu_kaisen: "./base de dados/random/EDIT-ANIMES/JUJUTSU_KAISEN.json",
narutoedit: "./base de dados/random/EDIT-ANIMES/NARUTO.json",
zerotwo: "./base de dados/random/EDIT-ANIMES/ZEROTWO.json"
}
if (!key.some(i => i.apikey === apikey)) {
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
}
const user = key.find(i => i.apikey === apikey)
if (user.request <= 0) {
return res.json({ message: "Apikey inválida ou requests esgotados!" })
}
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const data = JSON.parse(fs.readFileSync(databases[categoria]).toString())
const randomEdit = data[Math.floor(Math.random() * data.length)]
const editRest = await getBuffer(randomEdit)
res.type('mp4')
res.send(editRest)
} catch (error) {
res.json({ status: false, resultado: '❌️ Nenhuma resposta retornada ao servidor!️' })
}
})

app.get('/random/:categoria', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, categoria } = req.query
const categoriasValidas = ['aleatorios']
if (!categoria) {
return res.json({ status: false, message: "Parâmetro 'categoria' ausente" })
}
if (!categoriasValidas.includes(categoria)) {
return res.json({ message: "Categoria indisponível." })
}
const databases = {
aleatorios: "./base de dados/random/EDIT-ANIMES/ALEATORIOS.json"
}
if (!key.some(i => i.apikey === apikey)) {
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
}
const user = key.find(i => i.apikey === apikey)
if (user.request <= 0) {
return res.json({ message: "Apikey inválida ou requests esgotados!" })
}
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const data = JSON.parse(fs.readFileSync(databases[categoria]).toString())
const randomEdit = data[Math.floor(Math.random() * data.length)]
const editRest = await getBuffer(randomEdit)
res.type('mp4')
res.send(editRest)
} catch (error) {
res.json({ status: false, resultado: '❌️ Nenhuma resposta retornada ao servidor!️' })
}
})

app.get('/api/dl/scdl', (req, res) => {
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message : "Cade o parametro url?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
soundl(url).then(async(e) => {
res.type('mp4')
res.send(await getBuffer(e.link_dl))
}).catch(e => {
res.json({erro: "Erro: "+e})
})
})

app.get('/api/dl/ytaudio', async (req, res) => {
  const userIp = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  const { apikey, url, format = 'mp3' } = req.query;
  
  if (!key.some(i => i.apikey === apikey)) return res.sendFile(path.join(__dirname, './public/', 'apikey_invalida.html'));
  const keyIndex = key.findIndex(i => i.apikey === apikey);
  if (key[keyIndex].request <= 0) return res.json({ message: 'Apikey inválida ou requests esgotados!' });
  if (!url) return res.json({ status: false, message: 'Parâmetro URL não fornecido!' });
  
  RegisKey(apikey, userIp);
  console.log(color(`ApiKey: ${apikey} • Limite: ${key[keyIndex].request}\nRequest • Ping: ${ping()}`, 'red'));
  
  try {
    const result = await savetube.download(url, format);
    if (!result.status) return res.status(500).json({ status: false, message: result.error || 'Erro no download' });
    
    const response = await fetch(result.result.download);
    if (!response.ok) throw new Error('Falha ao buscar o áudio');
    
    console.log(chalk.green('[SUCESSO]'), chalk.cyan(`Link para download MP3: ${result.result.download}`));
    res.setHeader('Content-Type', 'audio/mpeg');
    
    // Sanitizar o nome do arquivo para remover caracteres inválidos
    const sanitizedTitle = result.result.title.replace(/[^a-zA-Z0-9\-\._]/g, '_').substring(0, 50);
    res.setHeader('Content-Disposition', `attachment; filename="${sanitizedTitle}.mp3"`);
    
    response.body.pipe(res);
  } catch (e) {
    console.error('Erro ao processar áudio:', e);
    res.status(500).json({ status: false, message: 'Erro interno ao processar áudio' });
  }
});




app.get('/api/dl/ytvideo5', async (req, res) => {
  const userIp = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  const { apikey, url, text, type } = req.query;

  // ===== API KEY =====
  if (!apikey || !key.some(k => k.apikey === apikey)) {
    return res.sendFile(path.join(__dirname, './public/', 'apikey_invalida.html'));
  }

  const keyIndex = key.findIndex(k => k.apikey === apikey);
  if (key[keyIndex].request <= 0) {
    return res.json({ status: false, message: 'Requests esgotados!' });
  }

  if (!url && !text) {
    return res.json({ status: false, message: 'Informe ?url= ou ?text=' });
  }

  RegisKey(apikey, userIp);

  try {
    const ytLink = url || text;
    if (!ytdl.validateURL(ytLink)) {
      return res.json({ status: false, message: 'URL inválida do YouTube' });
    }

    const info = await ytdl.getInfo(ytLink);
    const title = (info.videoDetails.title || 'video')
      .replace(/[^a-zA-Z0-9\-\.]/g, '')
      .substring(0, 60);

    // Escolhe formato: vídeo ou áudio
    const format = type === 'audio' ? 'audioonly' : 'highest';

    res.setHeader('Content-Type', type === 'audio' ? 'audio/mpeg' : 'video/mp4');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="${title}.${type === 'audio' ? 'mp3' : 'mp4'}"`
    );

    console.log(`[SUCESSO] Download iniciado: ${title}`);
    ytdl(ytLink, { quality: format }).pipe(res);

  } catch (err) {
    console.error('Erro YTVideo:', err);
    res.status(500).json({
      status: false,
      message: 'Erro interno ao processar vídeo'
    });
  }
});





app.get('/api/dl/ytvideo', async (req, res) => {
  const userIp = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress
  const { apikey, url, text, format } = req.query

  // ===== API KEY =====
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))

  const keyIndex = key.findIndex(k => k.apikey === apikey)
  if (key[keyIndex].request <= 0) {
    return res.json({ status: false, message: 'Requests esgotados!' })
  }

  if (!url && !text) {
    return res.json({ status: false, message: 'Informe ?url= ou ?text=' })
  }

  RegisKey(apikey, userIp)
  console.log(`[LOG] ApiKey: ${apikey} • Requests restantes: ${key[keyIndex].request}`)

  try {
    const ytLink = url || text
    console.log('[LOG] Iniciando download via scraper keepv...')

    const startTime = Date.now()
    const result = await keepv.download(ytLink, format || '720p', criador)
    const duration = Date.now() - startTime

    if (!result.dlurl) {
      return res.status(500).json({ status: false, message: 'Falha ao converter vídeo' })
    }

    console.log(`[SUCESSO] Redirecionando para download: ${result.dlurl}`)
    res.setHeader('X-Exec-Time', `${duration}ms`)
    return res.redirect(result.dlurl)
  } catch (err) {
    console.error('Erro YTVideo:', err)
    return res.status(500).json({
      status: false,
      message: 'Erro interno ao processar vídeo',
      detalhes: err.message
    })
  }
})

app.get('/api/dl/ytaudio2', async (req, res) => {
  userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
  const { apikey, url, format = 'mp3' } = req.query
  if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
  if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({ message: "Apikey inválida ou requests esgotados!" })
  if (!url) return res.json({ status: false, message: "Cade o parametro url?" })
  RegisKey(req.query.apikey, userIp)
  var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
  console.log(color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
  try {
    const yt = new Youtubers();
    const result = await yt.downloadyt(url, "128", "audio");
    if (!result.status) return res.status(500).json({ status: false, message: result.pesan || 'Erro no download' })
    const response = await fetch(result.url)
    if (!response.ok) throw new Error('Falha ao buscar o áudio')
    console.log(chalk.green('[SUCESSO]'), chalk.cyan(`Link para download MP3: ${result.url}`))
    res.setHeader('Content-Type', 'audio/mpeg')
    const sanitizedTitle = result.judul.replace(/[^a-zA-Z0-9\-\._]/g, '_').substring(0, 50)
    res.setHeader('Content-Disposition', `attachment; filename="${sanitizedTitle}.mp3"`)
    response.body.pipe(res)
  } catch (e) {
    console.error('Erro ao processar áudio:', e)
    res.status(500).json({ status: false, message: 'Erro interno ao processar áudio' })
  }
})

app.get('/api/dl/ytaudio3', async (req, res) => {
  userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
  apikey = req.query.apikey
  url = req.query.url
  if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
  if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({ message: "Apikey inválida ou requests esgotados!" })
  if (!url) return res.json({ status: false, message: "Cade o parametro url?" })
  RegisKey(req.query.apikey, userIp)
  var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
  console.log(color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
  try {
    const yt = new Youtubers();
    const result = await yt.downloadyt(url, "128", "audio");
    if (!result.status) return res.status(500).json({ status: false, message: result.pesan || 'Erro no download' })
    console.log(chalk.green('[SUCESSO]'), chalk.cyan('Link MP3:'), result.url)
    const client = result.url.startsWith('https') ? https : http
    client.get(result.url, (remoteRes) => {
      res.setHeader('Content-Type', 'audio/mpeg')
      res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(result.judul)}.mp3"`)
      remoteRes.pipe(res)
    }).on('error', (err) => {
      console.error('Erro no streaming:', err)
      res.status(500).json({ error: 'Falha no streaming de áudio' })
    })
  } catch (error) {
    console.error("Erro ao processar áudio:", error)
    res.status(500).json({ error: "Erro ao processar a requisição." })
  }
})

app.get('/api/dl/ytaudio4', async (req, res) => {
  userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
  apikey = req.query.apikey
  url = req.query.url
  if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
  if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({ message: "Apikey inválida ou requests esgotados!" })
  if (!url) return res.json({ status: false, message: "Cade o parametro url?" })
  RegisKey(req.query.apikey, userIp)
  var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
  console.log(color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
  try {
    const yt = new Youtubers();
    const result = await yt.downloadyt(url, "128", "audio");
    if (!result.status) return res.status(500).json({ status: false, message: result.pesan || 'Erro no download' })
    
    const filePath = path.join(__dirname, 'temp_audio.mp3');
    const response = await fetch(result.url);
    const writer = fs.createWriteStream(filePath);
    response.body.pipe(writer);
    await new Promise((resolve, reject) => {
      writer.on('finish', resolve);
      writer.on('error', reject);
    });
    
    console.log(chalk.green('[SUCESSO]'), chalk.cyan('Link para download MP3:'), filePath)
    res.setHeader('Content-Type', 'audio/mpeg')
    res.setHeader('Content-Disposition', 'inline; filename="audio.mp3"')
    res.sendFile(filePath, (err) => {
      if (err) console.error('Erro ao enviar o áudio:', err)
      fs.unlink(filePath, () => {})
    })
  } catch (error) {
    res.status(500).json({ error: 'Erro ao baixar o áudio' })
  }
})

// yt vídeo 
app.get('/api/dl/ytvideo2', async (req, res) => {
  userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
  const { apikey, url, format = '1080' } = req.query
  if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
  if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({ message: "Apikey inválida ou requests esgotados!" })
  if (!url) return res.json({ status: false, message: "Cade o parametro url?" })
  RegisKey(req.query.apikey, userIp)
  var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
  console.log(color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
  try {
    const yt = new Youtubers();
    const result = await yt.downloadyt(url, format, "video");
    if (!result.status) return res.status(500).json({ status: false, message: result.pesan || 'Erro no download' })
    const response = await fetch(result.url)
    if (!response.ok) throw new Error('Falha ao buscar o vídeo')
    console.log(chalk.green('[SUCESSO]'), chalk.cyan(`Link para download MP4: ${result.url}`))
    res.setHeader('Content-Type', 'video/mp4')
    const sanitizedTitle = result.judul.replace(/[^a-zA-Z0-9\-\._]/g, '_').substring(0, 50)
    res.setHeader('Content-Disposition', `attachment; filename="${sanitizedTitle}.mp4"`)
    response.body.pipe(res)
  } catch (e) {
    console.error('Erro ao processar vídeo:', e)
    res.status(500).json({ status: false, message: 'Erro interno ao processar vídeo' })
  }
})

app.get('/api/dl/ytvideo3', async (req, res) => {
  userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
  apikey = req.query.apikey
  url = req.query.url
  if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
  if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({ message: "Apikey inválida ou requests esgotados!" })
  if (!url) return res.json({ status: false, message: "Cade o parametro url?" })
  RegisKey(req.query.apikey, userIp)
  var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
  console.log(color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
  try {
    const yt = new Youtubers();
    const data = await yt.infoVideo(url);
    const bestQuality = data.kualitas.reduce((max, curr) => curr.kualitas > max.kualitas ? curr : max, {kualitas: 0});
    const quality = bestQuality.kualitas.toString();
    const result = await yt.downloadyt(url, quality, "video");
    if (!result.status) return res.status(500).json({ status: false, message: result.pesan || 'Erro no download' })
    console.log(chalk.green('[SUCESSO]'), chalk.cyan('Link MP4:'), result.url)
    const client = result.url.startsWith('https') ? https : http
    client.get(result.url, (remoteRes) => {
      res.setHeader('Content-Type', 'video/mp4')
      res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(result.judul)}.mp4"`)
      remoteRes.pipe(res)
    }).on('error', (err) => {
      console.error('Erro no streaming:', err)
      res.status(500).json({ error: 'Falha no streaming de vídeo' })
    })
  } catch (error) {
    console.error("Erro ao processar vídeo:", error)
    res.status(500).json({ error: "Erro ao processar a requisição." })
  }
})

app.get('/api/dl/ytvideo4', async (req, res) => {
  userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
  apikey = req.query.apikey
  url = req.query.url
  if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
  if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({ message: "Apikey inválida ou requests esgotados!" })
  if (!url) return res.json({ status: false, message: "Cade o parametro url?" })
  RegisKey(req.query.apikey, userIp)
  var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
  console.log(color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
  try {
    const yt = new Youtubers();
    const data = await yt.infoVideo(url);
    const bestQuality = data.kualitas.reduce((max, curr) => curr.kualitas > max.kualitas ? curr : max, {kualitas: 0});
    const quality = bestQuality.kualitas.toString();
    const result = await yt.downloadyt(url, quality, "video");
    if (!result.status) return res.status(500).json({ status: false, message: result.pesan || 'Erro no download' })
    
    const filePath = path.join(__dirname, 'temp_video.mp4');
    const response = await fetch(result.url);
    const writer = fs.createWriteStream(filePath);
    response.body.pipe(writer);
    await new Promise((resolve, reject) => {
      writer.on('finish', resolve);
      writer.on('error', reject);
    });
    
    console.log(chalk.green('[SUCESSO]'), chalk.cyan('Link para download MP4:'), filePath)
    res.setHeader('Content-Type', 'video/mp4')
    res.setHeader('Content-Disposition', 'inline; filename="video.mp4"')
    res.sendFile(filePath, (err) => {
      if (err) console.error('Erro ao enviar o vídeo:', err)
      fs.unlink(filePath, () => {})
    })
  } catch (error) {
    res.status(500).json({ error: 'Erro ao baixar o vídeo' })
  }
})
app.get('/api/dl/multidl2', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({ message: "Apikey inválida ou requests esgotados!" })
if (!url) return res.json({ status: false, message: "Cade o parametro url?" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const cleanUrl = url.match(/instagram\.com/) && url.includes('igsh=')
? url.replace(/([?&])igsh=[^&]+(&)?/, (_, sep, tail) => tail ? sep : '') : url
console.log(chalk.green('URL LIMPA:', cleanUrl))
const videoData = await downloadVideo(cleanUrl)
const videoPath = videoData.path
res.setHeader('Content-Type', 'video/mp4')
res.setHeader('Content-Disposition', 'inline; filename="video.mp4"')
const videoStream = fs.createReadStream(videoPath)
videoStream.on('error', (err) => {
console.error("Erro ao enviar o arquivo de vídeo:", err)
res.status(500).json({ error: "Erro ao enviar o arquivo de vídeo" })
})
videoStream.pipe(res)
res.on('finish', () => {
fs.unlink(videoPath, (unlinkErr) => {
if (unlinkErr) console.error("Erro ao excluir o arquivo de vídeo:", unlinkErr)
console.log(`Arquivo final ${videoPath} excluído.`)
})
})
} catch (err) {
console.error("Erro ao processar o download de vídeo:", err)
res.status(500).json({ error: "Erro ao processar o download de vídeo" })
}
})

app.get('/api/myinstants', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message: "Coloque o parametro: query"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
audioMeme.myinstants(query).then(data => {
res.json({resultado: data})
}).catch(e => {
res.json({status: 404, message: `Erro no Servidor Interno.`})
})
})

app.get('/api/tuna', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message: "Coloque o parametro: query"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
audioMeme.tuna(query).then(data => {
res.json({resultado: data})
}).catch(e => {
res.json({status: 404, message: `Erro no Servidor Interno.`})
})
})

app.get('/api/dl/gdrive', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
GDriveDl(url).then(data => {
res.json({resultado: data})
}).catch(e => {
res.json({status: 404, message: `Erro no Servidor Interno.`})
})
})

app.get('/api/dl/mediafire', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const fileInfo = await mediafireDl(url)
fileInfo.creator = `${criador}`
console.log(chalk.green(`[SUCESSO] Resultado obtido do módulo mediafireDl:`))
res.json({
creator: fileInfo.creator,
status: fileInfo.status,
link: fileInfo.link,
filename: fileInfo.filename,
filesize: fileInfo.filesize,
extension: fileInfo.extension,
mimetype: fileInfo.mimetype
})
} catch (error) {
console.error(chalk.red(`[ERRO] Falha ao processar a URL: ${error.message}`))
res.status(500).json({
error: `Falha ao processar a URL: ${error.message}`
})
}
})

app.get('/api/dl/mediafire3', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message : "Cade o parametro url?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const resultado = await mediafire(url)
return res.status(200).json(resultado)
} catch (error) {
return res.status(500).json({ error: 'Erro ao processar a requisição', detalhes: error.message })
}
})

app.get("/api/instagram/post", async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message : "Cade o parametro url?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await ig.fetchPost(url)
res.json({ status: true, criador: `${criador}`, resultado: result })
} catch (error) {
res.status(500).json({ status: false, criador, mensagem: "Erro ao buscar postagem.", erro: error.message })
}
})


app.get('/api/instagram/user', async (req, res) => {
  const userIp = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  const apikey = req.query.apikey;
  const username = req.query.username;

  if (!key.map((i) => i.apikey)?.includes(apikey)) {
    return res.sendFile(path.join(__dirname, './public/', 'apikey_invalida.html'));
  }

  const indiceChave = key.map((i) => i?.apikey)?.indexOf(apikey);
  if (key[indiceChave]?.request <= 0) {
    return res.json({ mensagem: 'Chave de API inválida ou limite de requisições esgotado!' });
  }

  if (!username) {
    return res.json({ status: false, mensagem: 'Por favor, forneça o parâmetro: username (nome de usuário do Instagram)' });
  }

  RegisKey(apikey, userIp);

  console.log(
    chalk.red(`Chave API: ${apikey} • Limite: ${key[indiceChave]?.request}`),
    chalk.red(''),
    chalk.red('Requisição'),
    '• ' + chalk.red(`Ping: ${ping()}`)
  );

  try {
    const formData = new URLSearchParams();
    formData.append('profile', username);

    const profileRes = await axios.post('https://tools.xrespond.com/api/instagram/profile-info', formData.toString(), {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'origin': 'https://bitchipdigital.com',
        'referer': 'https://bitchipdigital.com/',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
      },
    });

    const raw = profileRes.data?.data?.data;
    if (!raw || profileRes.data.status !== 'success') {
      throw new Error('Erro ao obter informações do perfil');
    }

    const seguidores = raw.follower_count ?? 0;

    const postsForm = new URLSearchParams();
    postsForm.append('profile', username);

    const postsRes = await axios.post('https://tools.xrespond.com/api/instagram/media/posts', postsForm.toString(), {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'origin': 'https://bitchipdigital.com',
        'referer': 'https://bitchipdigital.com/',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
      },
    });

    const itens = postsRes.data?.data?.data?.items || [];

    let totalCurtidas = 0;
    let totalComentarios = 0;
    const postsRecentes = [];

    for (const post of itens) {
      totalCurtidas += post.like_count || 0;
      totalComentarios += post.comment_count || 0;
      postsRecentes.push({
        url: post.permalink || '-',
        legenda: post.caption?.text || '-',
        tipo: post.media_type || 'DESCONHECIDO',
        curtidas: post.like_count || 0,
        comentarios: post.comment_count || 0,
        data_publicacao: post.taken_at || null,
      });
    }

    const totalEngajamento = totalCurtidas + totalComentarios;
    const taxaEngajamentoMedia = seguidores > 0 && itens.length > 0
      ? ((totalEngajamento / itens.length) / seguidores) * 100
      : 0;
    const mediaCurtidas = itens.length > 0 ? totalCurtidas / itens.length : 0;
    const mediaComentarios = itens.length > 0 ? totalComentarios / itens.length : 0;

    const resultado = {
      usuario: raw.username || '-',
      nome: raw.full_name || '-',
      bio: raw.biography || '-',
      categoria: raw.category_name || '-',
      seguidores,
      seguindo: raw.following_count ?? null,
      publicacoes: raw.media_count ?? null,
      foto_perfil: raw.hd_profile_pic_url_info?.url || raw.profile_pic_url_hd || '',
      verificado: raw.is_verified || raw.show_blue_badge_on_main_profile || false,
      taxa_engajamento: parseFloat(taxaEngajamentoMedia.toFixed(2)),
      media_curtidas: parseFloat(mediaCurtidas.toFixed(2)),
      media_comentarios: parseFloat(mediaComentarios.toFixed(2)),
      posts_recentes: postsRecentes.slice(0, 5),
    };

    res.json({ status: true, criador: "Paulo Mod", resultado });
  } catch (err) {
    res.json({ status: false, mensagem: err.message || 'Erro no servidor interno.' });
  }
});

app.get('/api/instagramv2/user', async (req, res) => {
    const userIp = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    const apikey = req.query.apikey;
    const username = req.query.username;

    // Validar chave de API
    if (!key.map((i) => i.apikey)?.includes(apikey)) {
        return res.sendFile(path.join(__dirname, './public/', 'apikey_invalida.html'));
    }

    const indiceChave = key.map((i) => i?.apikey)?.indexOf(apikey);
    if (key[indiceChave]?.request <= 0) {
        return res.json({ mensagem: 'Chave de API inválida ou limite de requisições esgotado!' });
    }

    // Validar username
    if (!username) {
        return res.json({ status: false, mensagem: 'Por favor, forneça o parâmetro: username (nome de usuário do Instagram)' });
    }

    // Registrar requisição
    RegisKey(apikey, userIp); // Presumindo que RegisKey está definido em outro lugar
    console.log(
        chalk.red(`Chave API: ${apikey} • Limite: ${key[indiceChave]?.request}`),
        chalk.red(''),
        chalk.red('Requisição'),
        '• ' + chalk.red(`Ping: ${ping()}`) // Presumindo que ping está definido em outro lugar
    );

    try {
        // Chamar função igstalk
        const data = await igstalk(username);

        // Construir resposta
        res.json({ status: true, criador: "Paulo Mod", resultado: data });
    } catch (err) {
        res.json({ status: false, mensagem: err.message || 'Erro no servidor interno.' });
    }
});

app.get("/api/instagramv3/user", async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
username = req.query.username
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!username) return res.json({ status : false,message: "cade o parametro username?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await ig.fetchUser(username)
res.json({ status: true, criador: `${criador}`, resultado: result })
} catch (error) {
res.status(500).json({ status: false, criador, mensagem: "Erro ao buscar usuário.", erro: error.message })
}
})

app.get("/api/instagram/stories", async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
username = req.query.username
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!username) return res.json({ status : false,message: "cade o parametro username?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await ig.fetchStories(username)
res.json({ status: true, criador: `${criador}`, resultado: result })
} catch (error) {
res.status(500).json({ status: false, criador, mensagem: "Erro ao buscar stories.", erro: error.message })
}
})

app.get("/api/instagram/highlights", async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
username = req.query.username
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!username) return res.json({ status : false,message: "cade o parametro username?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await ig.fetchHighlights(username)
res.json({ status: true, criador: `${criador}`, resultado: result })
} catch (error) {
res.status(500).json({ status: false, criador, mensagem: "Erro ao buscar highlights.", erro: error.message })
}
})

app.get('/api/convert/image', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
url = req.query.url
if(!url) return res.json({erro: "Faltando o parâmetro url"})
apikey = req.query.apikey
if(!apikey) return res.json({erro: "Faltando o parâmetro apikey"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
hasil = url
data = await fetch(hasil).then(v => v.buffer()) 
 await fs.writeFileSync(bla+'/assets/gostosinha.jpg', data)
res.sendFile(bla+'/assets/gostosinha.jpg') 
} catch (error) {
return res.status(404).json({resultado: `Erro`, status: 500})
}
})



  app.get("/api/tiktokStalk", async (req, res) => {
    // ---------- 1. IP ----------
    const ab = (n) =>
  Intl.NumberFormat("pt-BR", { notation: "compact", maximumFractionDigits: 1 }).format(n);
  
    const userIp =
      req.headers["x-forwarded-for"]?.split(",")[0]?.trim() ||
      req.ip ||
      req.connection.remoteAddress;

    // ---------- 2. PARÂMETROS ----------
    const { apikey, username } = req.query;

    // ---------- 3. VALIDAÇÃO DA API KEY ----------
    if (!key.some(i => i.apikey === apikey)) {
      return res.status(401).json({ status: false, message: "API key inválida." });
    }

    const keyIndex = key.findIndex(i => i.apikey === apikey);
    if (key[keyIndex].request <= 0) {
      return res.status(403).json({ status: false, message: "Limite de requisições da API key esgotado." });
    }

    // ---------- 4. VALIDAÇÃO DO USERNAME ----------
    if (!username) {
      return res.status(400).json({ status: false, message: 'Parâmetro "username" não fornecido.' });
    }

    // ---------- 5. REGISTRO E LOG ----------
    RegisKey(apikey, userIp);
    console.log(
      color(`ApiKey: ${apikey} • Limite: ${key[keyIndex].request}\n`, "red"),
      color("Request", "red"),
      color(` • Ping: ${ping()}`, "red")
    );

    // ---------- 6. DECREMENTA O LIMITE ----------
    key[keyIndex].request -= 1;

    // ---------- 7. SCRAPING COM @tobyg74 ----------
    try {
      const tts = await StalkUser(username);
      if (!tts?.result?.user) {
        return res.json({
          status: false,
          message: "Usuário não encontrado ou perfil privado.",
        });
      }

      const { user, stats } = tts.result;

      // ---------- 8. AVATAR EM BASE64 (opcional) ----------
      let avatarBase64 = null;
      if (user.avatarThumb) {
        try {
          const img = await axios.get(user.avatarThumb, { responseType: "arraybuffer" });
          avatarBase64 = `data:image/jpeg;base64,${Buffer.from(img.data).toString("base64")}`;
        } catch (e) {
          console.warn("⚠️ Falha ao baixar avatar:", e.message);
        }
      }

      // ---------- 9. RESPOSTA FINAL ----------
      res.json({
        status: true,
        provider: "Paulo Mod",
        username: user.username,
        nickname: user.nickname,
        bio: user.signature || "Sem bio",
        privado: user.privateAccount ? "Sim" : "Não",
        verificado: user.verified ? "Sim" : "Não",
        avatar: user.avatarThumb || null,
        avatar_base64: avatarBase64,
        estatisticas: {
          videos: stats.videoCount ?? 0,
          seguidores: ab(stats.followerCount ?? 0),
          seguindo: ab(stats.followingCount ?? 0),
          likes: ab(stats.heartCount ?? 0),
        },
        link: `https://www.tiktok.com/@${user.username}`,
      });
    } catch (e) {
      console.error("Erro na rota /api/tiktokStalk:", e);
      res.status(500).json({
        status: false,
        message: `Erro ao buscar dados do TikTok para ${username}: ${e.message || e}`,
      });
    }
  });

app.get('/api/tiktokstalker/v3', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
usuario = req.query.usuario
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!usuario) return res.json({ status : false,message: "cade o parametro usuario?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const userData = await tiktokStalk_v3(usuario)
if (userData.status) {
return res.json(userData)
} else {
return res.status(500).json({ status: false, message: 'Erro ao obter dados do TikTok.', msg: userData.message })
}
} catch (error) {
return res.status(500).json({ status: false, message: 'Erro interno do servidor.', error: error.message })
}
})

app.get('/api/stalker/github', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
usuario = req.query.usuario
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!usuario) return res.json({ status : false,message: "cade o parametro usuario?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const { stalk } = await import('scraper-jsc')
const result = await stalk.Github(usuario)
if (!result || Object.keys(result).length === 0) {
console.error(chalk.red(`[ERRO] Nenhuma informação encontrada para o usuário ${usuario}.`))
return res.status(404).send('Usuário não encontrado')
}
console.log(chalk.green(`[SUCESSO] Informações do perfil encontradas:`))
const userInfo = result.result.user
res.json({
developer: `${criador}`,
status: true,
resultado: userInfo
})
} catch (error) {
console.error(chalk.red(`[ERRO] Falha ao buscar informações no GitHub: ${error.message}`))
res.status(500).send('Erro ao buscar informações')
}
})

app.get('/api/sticker/search', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message: "cade o parametro query?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(chalk.yellow(`[INFO] Buscando stickers para: ${query}`))
let stickerData = await ton.StickerSearch(query)
res.json({
criador: `${criador}`,
status: true,
resultado: stickerData
})
} catch (error) {
console.error(chalk.red(`[ERRO] Falha ao realizar a busca de stickers: ${error.message}`))
res.status(500).json({
error: `Falha ao realizar a busca de stickers: ${error.message}`
})
}
})

app.get('/api/npm/search', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message: "cade o parametro query?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(chalk.yellow(`[INFO] Buscando pacotes npm para: ${query}`))
let npmData = await ton.npmSearch(query)
res.json({
criador: `${criador}`,
status: true,
resultado: npmData
})
} catch (error) {
console.error(chalk.red(`[ERRO] Falha ao realizar a busca de pacotes npm: ${error.message}`))
res.status(500).json({
error: `Falha ao realizar a busca de pacotes npm: ${error.message}`
})
}
})

app.get('/api/dl/multidl', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "cade o parametro url?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const cleanUrl = url.match(/instagram\.com/) && url.includes('igsh=')
? url.replace(/([?&])igsh=[^&]+(&)?/, (_, sep, tail) => tail ? sep : '') : url
console.log(chalk.green('URL LIMPA:', cleanUrl))
const downloadData = await scraper.MultiDownload(cleanUrl)
res.json(downloadData)
} catch (error) {
console.error("Erro ao baixar a mídia:", error)
res.status(500).json({ error: "Erro ao processar o download" })
}
})

app.get('/api/search/imdb', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message: "cade o parametro query?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
scraper.IMDb.searchFilm(query).then(data => {
res.json({status: 200, resultado: data})
}).catch(e => {
res.json({status: 404, message: `Erro no Servidor Interno`})
})
})

app.get('/api/search/imdb_info', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "cade o parametro url?"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
scraper.IMDb.infoFilm(url).then(data => {
res.json({status: 200, resultado: data})
}).catch(e => {
res.json({status: 404, message: `Erro no Servidor Interno`})
})
})

app.get('/api/rastreio', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, code } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!code) return res.json({ status : false,message: "faltando o parametro: code"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
rastrearEncomendas(code)
.then(response => {
res.json({status: 200, resultado: response})
}).catch(e => {
res.json({status: 404, message: `Erro no Servidor Interno.`})
})
})




app.get('/api/cantada', (req, res) => {
  const { apikey } = req.query;
  const userIp = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;

  // === VALIDA APIKEY ===
  if (!key.some(k => k.apikey === apikey)) 
    return res.status(403).json({ erro: "Apikey inválida" });

  const user = key.find(k => k.apikey === apikey);
  if (user.request <= 0) 
    return res.status(429).json({ erro: "Requests esgotados" });

  // === GASTA 1 REQUEST ===
  user.request--;
  RegisKey(apikey, userIp);

  // === ENTREGA 1 CANTADA ALEATÓRIA ===
  const cantada = CANTADAS[Math.floor(Math.random() * CANTADAS.length)];

  res.json({
    status: 200,
    cantada: cantada,
    autor: "Paulo Mod, o Cupido Cósmico",
    dica: "Manda agora no WhatsApp e conquista o crush!"
  });
});

app.get('/api/pesquisa/pensador', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, text } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!text) return res.json({ status : false,message: "faltando o parametro: text"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
pensador(text)
.then(response => {
res.json({status: 200, resultado: response})
}).catch(e => {
res.json({status: 404, message: `Erro no Servidor Interno.`})
})
})

app.get('/api/dl/spotify', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, url } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "faltando o parametro: url"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const resultado = await baixarFaixaSpotify(url)
res.json({criador: `${criador}`, resultado: resultado })
} catch (error) {
console.error("Erro ao baixar faixa do Spotify:", error.message)
res.json({status: 404, message: `Erro no Servidor Interno.`})
}
})

app.get('/api/dl/capcut', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await capcut(url)
if (result) {
console.log(chalk.green("🎥 Vídeo pronto para download!"))
res.json(result)
} else {
console.error(chalk.yellow("⚠️ Não foi possível obter os dados do vídeo."))
res.status(404).json({ erro: "Dados do vídeo não encontrados." })
}
} catch (error) {
console.error(chalk.red("❌ Ocorreu um erro inesperado:"), error.message);l
res.status(500).json({ erro: "Erro ao processar a solicitação." })
}
})

app.get('/api/dl/threads', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, url } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "faltando o parametro: url"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await threads(url)
if (result) {
console.log(chalk.green("🎥 Vídeo pronto para download!"))
res.json(result)
} else {
console.error(chalk.yellow("⚠️ Não foi possível obter os dados do vídeo."))
res.status(404).json({ erro: "Dados do vídeo não encontrados." })
}
} catch (error) {
console.error(chalk.red("❌ Ocorreu um erro inesperado:"), error.message)
res.status(500).json({ erro: "Erro ao processar a solicitação." })
}
})

app.get('/api/dl2/threads', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, url } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "faltando o parametro: url"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await threads2(url)
res.status(200).json({ status: true, criador: `${criador}`, resultado: result })
} catch (error) {
res.status(500).json({ error: error.message })
}
})

app.get('/api/dl/twitter', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, url } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "faltando o parametro: url"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(chalk.yellow(`[INFO] Baixando mídia do Twitter para o link: ${url}`))
const twitterMedia = await Qasim.xdown(url)
const { creator, found, ...filteredMedia } = twitterMedia
res.status(200).json({
criador: `${criador}`,
status: true,
resultado: filteredMedia
})
} catch (error) {
console.error(chalk.red(`[ERRO] Falha ao baixar a mídia do Twitter: ${error.message}`))
res.status(500).json({ error: 'Erro ao baixar a mídia do Twitter.' })
}
})

app.get('/api/spotify/search', async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, query } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message: "faltando o parametro: query"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const searchTrack = await search(query)
res.status(200).json({
success: true,
criador: `${criador}`,
resultado: searchTrack,
})
} catch (error) {
console.error(chalk.red('Erro na pesquisa:'), chalk.yellow(error))
res.status(500).json({
success: false,
message: 'Erro ao realizar a pesquisa no Spotify',
error: error.message,
})
}
})



app.get('/api/dl/spotify', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, url } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "faltando o parametro: url"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
    try {
        const j2 = new J2Download();
        const data = await j2.download(url);

        if (!data || !data.medias || !data.medias.length) {
            return res.json({
                status: false,
                message: "Falha ao obter o link de download."
            });
        }

        // pega o melhor áudio disponível
        const audio = data.medias.find(m => m.type === 'audio') || data.medias[0];

        return res.json({
            status: true,
            criador: "Paulo Mod",
            resultado: {
                titulo: data.title || null,
                artista: data.author || null,
                link: audio.url,
                metadata: {
                    cover: data.thumbnail || null,
                    duration: data.duration || null
                }
            }
        });

    } catch (e) {
        console.error("Erro no endpoint /api/dl/spotify:", e);
        return res.json({
            status: false,
            message: "Erro ao processar a música."
        });
    }
});

app.get('/api/dl/spotify/track', async (req, res) => {
  const userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
  const { apikey, url } = req.query

  if (!key.map(i => i.apikey)?.includes(apikey))
    return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))

  const ITC = key.map(i => i?.apikey)?.indexOf(apikey)
  if (key[ITC]?.request <= 0)
    return res.json({ status: false, message: "Apikey inválida ou requests esgotados!" })

  if (!url)
    return res.json({ status: false, message: "faltando o parametro: url" })

  RegisKey(apikey, userIp)

  console.log(
    color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'),
    color('Request', 'red'),
    '• ' + color('Ping: ' + ping(), 'red')
  )

  try {
    const spotify = new Spotify()
    const downTrack = await spotify.downloadTrack(url)

    return res.status(200).json({
      status: true,
      criador,
      resultado: downTrack
    })

  } catch (error) {
    console.error(chalk.red('Erro ao baixar track:'), chalk.yellow(error))
    return res.status(500).json({
      status: false,
      message: 'Erro ao baixar faixa.',
      error: error?.message || error
    })
  }
})

app.get('/api/dl/spotify/album', async (req, res) => {
  const userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
  const { apikey, url } = req.query

  if (!key.map(i => i.apikey)?.includes(apikey))
    return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))

  const ITC = key.map(i => i?.apikey)?.indexOf(apikey)
  if (key[ITC]?.request <= 0)
    return res.json({ status: false, message: "Apikey inválida ou requests esgotados!" })

  if (!url)
    return res.json({ status: false, message: "faltando o parametro: url" })

  RegisKey(apikey, userIp)

  console.log(
    color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'),
    color('Request', 'red'),
    '• ' + color('Ping: ' + ping(), 'red')
  )

  try {
    const spotify = new Spotify()

    const albumId = url.match(/album\/([a-zA-Z0-9]+)/)?.[1]
    if (!albumId)
      return res.json({ status: false, message: "URL de álbum inválida" })

    const creds = await spotify.spotifyCreds()

    const album = await axios.get(
      `https://api.spotify.com/v1/albums/${albumId}`,
      {
        headers: {
          Authorization: `Bearer ${creds.data.access_token}`
        }
      }
    )

    const tracks = await Promise.all(
      album.data.tracks.items.map(async (t) => ({
        name: t.name,
        duration: await spotify.toTime(t.duration_ms),
        artists: t.artists.map(a => a.name).join(', '),
        url: t.external_urls.spotify
      }))
    )

    return res.status(200).json({
      status: true,
      criador,
      album: {
        name: album.data.name,
        artists: album.data.artists.map(a => a.name).join(', '),
        release_date: album.data.release_date,
        total_tracks: album.data.total_tracks,
        images: album.data.images.map(i => i.url)
      },
      tracks
    })

  } catch (error) {
    console.error(chalk.red('Erro ao baixar álbum:'), chalk.yellow(error))
    return res.status(500).json({
      status: false,
      message: 'Erro ao processar álbum.',
      error: error?.message || error
    })
  }
})


app.get('/api/consulta/ip', async (req, res) => {
  const { token, query } = req.query

if(!query) return res.json({resultado: "KD o query"})
if(!token) return res.json({resultado: "KD o token?"})
if(!existPuxToken(token)) return  res.sendFile(path.join(__dirname, "./public/", "invalid_token.html"))
if(!getPuxToken(token).infinity && getPuxToken(token).expired) return res.json({resultado: `Os dias restantes de sua key acabaram... Você tem ${getPuxToken(token).quant}d para renovar a key, ou a mesma será deletada 😉`, bot: `Vá até o bot de atendimento no número wa.me/559784529259 e use o comando #comprarpvkey`})
  try {
    // ===== AQUI ENTRA O SCRAPPER / API =====
    const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args))
    const keyip = '02f275876abbce4466a211fd49289720'

    const reqApi = await fetch(`https://api.ipapi.com/api/${query}?access_key=${keyip}`)
    const data = await reqApi.json()

    if (data.error) {
      return res.json({
        status: false,
        message: 'Erro na consulta',
        error: data.error
      })
    }

    // ===== SALVA LOG DA CONSULTA =====
    saveRoutePuxToken(token,"ip",query)

    return res.json({
      status: true,
      criador: '</> 𝑷𝒂𝒖𝒍𝒐 𝑴𝒐𝒅𝒔 ᴶˢ',
      resultado: data
    })

  } catch (err) {
    return res.json({
      status: false,
      message: 'Erro interno',
      error: err.message
    })
  }
})

app.get('/vip/db/consultas', async (req, res) => {
    const { tipo, db, tabela, campo, token, query } = req.query;

    /* =======================
       VALIDAÇÕES BÁSICAS
    ======================= */
    if (!token) return res.json({ status: false, resultado: "❌ Token não informado" });
    if (!query) return res.json({ status: false, resultado: "❌ Query não informada" });

    if (!existPuxToken(token))
        return res.sendFile(path.join(__dirname, "./public/", "invalid_token.html"));

    const tokenData = getPuxToken(token);
    if (!tokenData.infinity && tokenData.expired) {
        return res.json({ status: false, resultado: "⏰ Token expirado" });
    }

    /* =======================
       TODAS AS DBs + SCHEMAS
    ======================= */
    const DBS = {
        ASSECC: {
            PF: ["DDD","TELEFONE","CPF","NOME","LOGRDOURO","ENDERECO","NUMERO","BAIRRO","CEP","CIDADE","UF"],
            PJ: ["DDD","TELEFONE","CNPJ","NOME","LOGRDOURO","ENDERECO","NUMERO","BAIRRO","CEP","CIDADE","UF"]
        },

        BIGDATA: {
            DADOS: ["CPF","NOME","RG","NOME_MAE","NOME_PAI","TITULO_ELEITOR"],
            EMAIL: ["EMAIL"],
            TELEFONE: ["DDD","TELEFONE"],
            ENDERECOS: ["LOGR_NOME","BAIRRO","CIDADE","CEP","UF"],
            PARENTES: ["CPF_Completo"],
            PIS: ["PIS"],
            SCORE: ["CONTATOS_ID"],
            PODER_AQUISITIVO: ["CONTATOS_ID"],
            TSE: ["TITULO_ELEITOR"]
        },

        DETRAN: {
            BV_DETRAN: ["placa","renavan","chassi","cpf"]
        },

        FOTO_RO: {
            FOTO_RO: ["CPF","NOME","RENACH","NUMERO_REGISTRO"]
        },

        JBR_PLACA: {
            JBR: ["placa","chassi","motor"]
        }
    };

    /* =======================
       MAPA AUTOMÁTICO (TIPO)
    ======================= */
    const tipoMap = {
        cpf:          { db: "BIGDATA", tabela: "DADOS", campo: "CPF" },
        nome:         { db: "BIGDATA", tabela: "DADOS", campo: "NOME" },
        telefone:     { db: "BIGDATA", tabela: "TELEFONE", campo: "TELEFONE" },
        email:        { db: "BIGDATA", tabela: "EMAIL", campo: "EMAIL" },
        endereco:     { db: "BIGDATA", tabela: "ENDERECOS", campo: "LOGR_NOME" },
        cep:          { db: "BIGDATA", tabela: "ENDERECOS", campo: "CEP" },
        parentes:     { db: "BIGDATA", tabela: "PARENTES", campo: "CPF_Completo" },
        pis:          { db: "BIGDATA", tabela: "PIS", campo: "PIS" },
        score:        { db: "BIGDATA", tabela: "SCORE", campo: "CONTATOS_ID" },
        poder:        { db: "BIGDATA", tabela: "PODER_AQUISITIVO", campo: "CONTATOS_ID" },

        cpf_assecc:   { db: "ASSECC", tabela: "PF", campo: "CPF" },
        cnpj:         { db: "ASSECC", tabela: "PJ", campo: "CNPJ" },

        placa:        { db: "DETRAN", tabela: "BV_DETRAN", campo: "placa" },
        renavam:      { db: "DETRAN", tabela: "BV_DETRAN", campo: "renavan" },
        chassi:       { db: "DETRAN", tabela: "BV_DETRAN", campo: "chassi" },

        cpf_foto:     { db: "FOTO_RO", tabela: "FOTO_RO", campo: "CPF" },

        placa_jbr:    { db: "JBR_PLACA", tabela: "JBR", campo: "placa" }
    };

    let database, table, consulta;

    /* =======================
       MODO MANUAL (DB)
    ======================= */
    if (db && tabela && campo) {
        if (!DBS[db] || !DBS[db][tabela] || !DBS[db][tabela].includes(campo)) {
            return res.json({
                status: false,
                resultado: "❌ DB, tabela ou campo inválido"
            });
        }
        database = db;
        table = tabela;
        consulta = campo;
    }

    /* =======================
       MODO AUTOMÁTICO (TIPO)
    ======================= */
    else {
        if (!tipo || !tipoMap[tipo]) {
            return res.json({
                status: false,
                resultado: "❌ Tipo inválido ou parâmetros incompletos"
            });
        }
        ({ db: database, tabela: table, campo: consulta } = tipoMap[tipo]);
    }

    const apiUrl = `http://193.34.212.46/api/search?db=${database}&tabela=${table}&consulta=${consulta}&query=${encodeURIComponent(query)}&apikey=api_melizin_dev`;

    try {
        const response = await fetch(apiUrl);
        const data = await response.json();

        if (!data.success || !data.related_data) {
            return res.json({ status: true, resultado: "Nenhum dado encontrado" });
        }

        res.json({
            status: true,
            develop: '</> 𝑷𝒂𝒖𝒍𝒐 𝑴𝒐𝒅𝒔 ᴶˢ',
            mensagem:" Ken Takakura Dbs",
            db: database,
            tabela: table,
            campo: consulta,
            resultado: data.related_data
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ status: false, resultado: "Erro interno" });
    }
})

app.get('/api/dl/spotify/playlist', async (req, res) => {
  userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
  var { apikey, url } = req.query

  if(!key.map(i => i.apikey)?.includes(apikey))
    return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))

  if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0)
    return res.json({ message: "Apikey inválida ou requests esgotados!" })

  if(!url)
    return res.json({ status: false, message: "faltando o parametro: url" })

  RegisKey(apikey, userIp)

  var ITC = key.map(i => i?.apikey)?.indexOf(apikey)

  console.log(
    color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'),
    color('Request', 'red'),
    '• ' + color('Ping: ' + ping(), 'red')
  )

  try {
    const spotify = new SpotifyDL()
    const result = await spotify.playlist(url)

    res.status(200).json({
      status: true,
      criador: `${criador}`,
      resultado: result
    })

  } catch (error) {
    console.error(chalk.red('Erro na playlist:'), chalk.yellow(error))
    res.status(500).json({
      status: false,
      message: 'Erro ao processar playlist.',
      error: error?.message || error
    })
  }
})

//=================================\\
app.get('/dono/pvkey/adc', (req, res) => {
var { apikey, dias, senha } = req.query
if(!apikey) return res.json({resultado:'Cade o parametro apikey?'})
if(!dias) return res.json({resultado:'Cade o parametro dias?'})
var senhaofc = SENHA_OFC
if(senha != senhaofc) return res.json({message: "[❗] senha inválida ou inexistente ❌"})
keyex = existConsultKeys(apikey)
if(keyex && getConsultKeys(apikey).infinity) return res.json({message: "[❗] impossível adc mais dias a esta key, pois a mesma é permanente 💢"})
addConsultKeys(apikey, dias);
return res.json({message: keyex ? `${dias}d foram adc a key ${apikey} com sucesso 🥰` : `A key ${apikey} foi adc ao sistema de puxadas com sucesso... Use com moderação ✌🏼😎`})
})

app.get('/dono/pvkey/rm', (req, res) => {
var { apikey, senha } = req.query
if(!apikey) return res.json({resultado:'Cade o parametro apikey?'})
var senhaofc = SENHA_OFC
if(senha != senhaofc) return res.json({message: "[❗] senha inválida ou inexistente ❌"})
if(!existConsultKeys(apikey)) return res.json({message: "[❗] key inválida ou inexistente ❌"})
rmConsultKeys(apikey);
return res.json({message: `A key ${apikey} foi deletada do sistema de puxadas com sucesso ✔`})
})

app.get('/dono/pvkey/list', (req, res) => {
var { senha } = req.query
var senhaofc = SENHA_OFC
if(senha != senhaofc) return res.json({message: "[❗] senha inválida ou inexistente ❌"})
return res.json(consultkeys)
})

app.get('/dono/puxadas/adc', (req, res) => {
var { token, dias, senha } = req.query
if(!token) return res.json({resultado:'Cade o parametro token?'})
if(!dias) return res.json({resultado:'Cade o parametro dias?'})
var senhaofc = SENHA_OFC
if(senha != senhaofc) return res.json({message: "[❗] senha inválida ou inexistente ❌"})
keyex = existPuxToken(token)
if(keyex && getPuxToken(token).infinity) return res.json({message: "[❗] impossível adc mais dias a esta key, pois a mesma é permanente 💢"})
addPuxToken(token, dias);
return res.json({message: keyex ? `${dias}d foram adc ao token ${token} com sucesso 🥰` : `O token ${token} foi adc ao sistema de puxadas com sucesso... Use com moderação ✌🏼😎`})
})

app.get('/dono/puxadas/rm', (req, res) => {
var { token, senha } = req.query
if(!token) return res.json({resultado:'Cade o parametro token?'})
var senhaofc = SENHA_OFC
if(senha != senhaofc) return res.json({message: "[❗] senha inválida ou inexistente ❌"})
if(!existPuxToken(token)) return res.json({message: "[❗] key inválida ou inexistente ❌"})
rmPuxToken(token);
return res.json({message: `O token ${token} foi deletado do sistema de puxadas com sucesso ✔`})
})

app.get('/dono/puxadas/list', (req, res) => {
var { senha } = req.query
var senhaofc = SENHA_OFC
if(senha != senhaofc) return res.json({message: "[❗] senha inválida ou inexistente ❌"})
return res.json(puxadas)
})
//=================================\\

app.get('/api/spotify/preview', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { apikey, url } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "faltando o parametro: url"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
const userAgentList = [
'googlebot',
'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
'Mozilla/5.0 (Linux; Android 11; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Mobile Safari/537.36',
'Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1',
'Mozilla/5.0 (compatible; Bingbot/2.0; +http://www.bing.com/bingbot.htm)',
]
const selectedUserAgent = userAgentList[Math.floor(Math.random() * userAgentList.length)]
try {
const spotifyData = await fetchSpotifyPreview(url, {
headers: {
'user-agent': selectedUserAgent,
},
})
res.status(200).json({
success: true,
criador: `${criador}`,
resultado: spotifyData,
})
} catch (error) {
console.log(chalk.red('Erro ao obter informações do Spotify:'), error.message)
res.status(500).json({
success: false,
message: 'Erro ao obter informações do Spotify.',
error: error.message,
})
}
})


// Rotas de Add Consultas.


// ----- Rotas consultas-----
/*
app.get('/consultas/bigdata/cpf', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Falando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/bigdata/${encodeURIComponent(query)}?type=cpf&token=${TOKEN}`
const apiRes = await fetch(url)
const jsonData = await apiRes.json()
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
resultado: {
CPF: jsonData.CPF,
NOME: jsonData.NOME,
SEXO: jsonData.SEXO,
DT_NASCIMENTO: jsonData.DT_NASCIMENTO,
IDADE: jsonData.IDADE,
ESTADO_CIVIL: jsonData.ESTADO_CIVIL,
TITULO_ELEITOR: jsonData.TITULO_ELEITOR,
PIS: jsonData.PIS,
DT_OBITO: jsonData.DT_OBITO,
NOME_MAE: jsonData.NOME_MAE,
NOME_PAI: jsonData.NOME_PAI,
CBO: jsonData.cbo,
REGISTRO_GERAL: jsonData.registro_geral,
DADOS_AQUISITIVOS: jsonData.dados_aquisitivos,
TELEFONES: jsonData.telefones || [],
EMAILS: jsonData.emails_arr || [],
PARENTES: jsonData.parentes_arr || [],
ENDERECOS: jsonData.enderecos_arr || []
}
})
} catch (err) {
console.error(err)
return res.status(500).json({ error: 'Erro ao consultar CPF BigData' })
}
})

app.get('/consultas/bigdata/nome', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Falando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/bigdata/${encodeURIComponent(query)}?type=nome&token=${TOKEN}`
const apiRes = await fetch(url)
const jsonData = await apiRes.json()
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
resultado: {
CPF: jsonData.CPF,
NOME: jsonData.NOME,
SEXO: jsonData.SEXO,
DT_NASCIMENTO: jsonData.DT_NASCIMENTO,
IDADE: jsonData.IDADE,
ESTADO_CIVIL: jsonData.ESTADO_CIVIL,
TITULO_ELEITOR: jsonData.TITULO_ELEITOR,
PIS: jsonData.PIS,
DT_OBITO: jsonData.DT_OBITO,
NOME_MAE: jsonData.NOME_MAE,
NOME_PAI: jsonData.NOME_PAI,
cbo: jsonData.cbo,
registro_geral: jsonData.registro_geral,
dados_aquisitivos: jsonData.dados_aquisitivos,
telefones: jsonData.telefones || [],
emails: jsonData.emails_arr || [],
parentes: jsonData.parentes_arr || [],
enderecos: jsonData.enderecos_array || []
}
})
} catch (err) {
console.error(err)
return res.status(500).json({ error: 'Erro ao consultar Nome BigData' })
}
})

app.get('/consultas/bigdata/nome2', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Falando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/bigdata/${encodeURIComponent(query)}?type=nome2&token=${TOKEN}`
const apiRes = await fetch(url)
const data = await apiRes.json()
if (!data || !data.hawk) {
return res.status(404).json({ error: 'Nenhum resultado encontrado.' })
}
return res.json({
status: true,
criador: `${criador}` || "Desconhecido",
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
quantidade: data.resultados || data.hawk.length,
resultado: data.hawk
})
} catch (err) {
console.error(err)
res.status(500).json({ error: 'Erro ao consultar Nome2 BigData' })
}
})

app.get('/consultas/bigdata/titulo_eleitor', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Falando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/bigdata/${encodeURIComponent(query)}?type=titulo_eleitor&token=${TOKEN}`
const apiRes = await fetch(url)
const jsonData = await apiRes.json()
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
resultado: {
CPF: jsonData.CPF,
NOME: jsonData.NOME,
SEXO: jsonData.SEXO,
DT_NASCIMENTO: jsonData.DT_NASCIMENTO,
IDADE: jsonData.IDADE,
ESTADO_CIVIL: jsonData.ESTADO_CIVIL,
TITULO_ELEITOR: jsonData.TITULO_ELEITOR,
PIS: jsonData.PIS,
DT_OBITO: jsonData.DT_OBITO,
NOME_MAE: jsonData.NOME_MAE,
NOME_PAI: jsonData.NOME_PAI,
cbo: {
NUM: jsonData.cbo?.NUM || "Não informado",
SUBGRUPO_PRINCIPAL: jsonData.cbo?.SUBGRUPO_PRINCIPAL || "Não informado",
OCUPACAO: jsonData.cbo?.OCUPACAO || "Não informado"
},
registro_geral: {
RG: jsonData.registro_geral?.RG || "Não informado",
ORGAO_EMISSOR: jsonData.registro_geral?.ORGÃO_EMISSOR || "Não informado",
UF_EMISSAO: jsonData.registro_geral?.UF_EMISSAO || "Não informado"
},
dados_aquisitivos: {
BASE_RENDA: jsonData.dados_aquisitivos?.BASE_RENDA || "Não informado",
PODER_AQUISITIVO: jsonData.dados_aquisitivos?.PODER_AQUISITIVO || "Não informado",
FX_PODER_AQUISITIVO: jsonData.dados_aquisitivos?.FX_PODER_AQUISITIVO || "Não informado",
SCORE_CSB8: jsonData.dados_aquisitivos?.SCORE_CSB8 || "Não informado",
CSB8_FAIXA: jsonData.dados_aquisitivos?.CSB8_FAIXA || "Não informado",
SCORE_CSBA: jsonData.dados_aquisitivos?.SCORE_CSBA || "Não informado",
CSBA_FAIXA: jsonData.dados_aquisitivos?.CSBA_FAIXA || "Não informado"
},
telefones: Array.isArray(jsonData.telefones) ? jsonData.telefones : [],
emails: Array.isArray(jsonData.emails_arr) ? jsonData.emails_arr : [],
parentes: Array.isArray(jsonData.parentes_arr) ? jsonData.parentes_arr : [],
enderecos: Array.isArray(jsonData.enderecos_array) ? jsonData.enderecos_array : []
}
})
} catch (err) {
console.error(err)
res.status(500).json({ error: 'Erro ao consultar Título de Eleitor BigData' })
}
})

app.get('/consultas/bigdata/nome_mae', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Falando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/bigdata/${encodeURIComponent(query)}?type=nome_mae&token=${TOKEN}`
const apiRes = await fetch(url)
const jsonData = await apiRes.json()
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
resultado: {
CPF: jsonData.CPF,
NOME: jsonData.NOME,
SEXO: jsonData.SEXO,
DT_NASCIMENTO: jsonData.DT_NASCIMENTO,
IDADE: jsonData.IDADE,
ESTADO_CIVIL: jsonData.ESTADO_CIVIL,
TITULO_ELEITOR: jsonData.TITULO_ELEITOR,
PIS: jsonData.PIS,
DT_OBITO: jsonData.DT_OBITO,
NOME_MAE: jsonData.NOME_MAE,
NOME_PAI: jsonData.NOME_PAI,
cbo: {
NUM: jsonData.cbo?.NUM,
SUBGRUPO_PRINCIPAL: jsonData.cbo?.SUBGRUPO_PRINCIPAL,
OCUPACAO: jsonData.cbo?.OCUPACAO
},
registro_geral: {
RG: jsonData.registro_geral?.RG,
ORGAO_EMISSOR: jsonData.registro_geral?.["ORGÃO_EMISSOR"],
UF_EMISSAO: jsonData.registro_geral?.UF_EMISSAO
},
dados_aquisitivos: {
BASE_RENDA: jsonData.dados_aquisitivos?.BASE_RENDA,
PODER_AQUISITIVO: jsonData.dados_aquisitivos?.PODER_AQUISITIVO,
FX_PODER_AQUISITIVO: jsonData.dados_aquisitivos?.FX_PODER_AQUISITIVO,
SCORE_CSB8: jsonData.dados_aquisitivos?.SCORE_CSB8,
CSB8_FAIXA: jsonData.dados_aquisitivos?.CSB8_FAIXA,
SCORE_CSBA: jsonData.dados_aquisitivos?.SCORE_CSBA,
CSBA_FAIXA: jsonData.dados_aquisitivos?.CSBA_FAIXA
},
telefones: Array.isArray(jsonData.telefones) ? jsonData.telefones : [],
emails: Array.isArray(jsonData.emails_arr) ? jsonData.emails_arr : [],
parentes: Array.isArray(jsonData.parentes_arr) ? jsonData.parentes_arr : [],
enderecos: Array.isArray(jsonData.enderecos_array) ? jsonData.enderecos_array : []
}
})
} catch (err) {
console.error(err)
res.status(500).json({ error: 'Erro ao consultar Nome da Mãe BigData' })
}
})

app.get('/consultas/bigdata/cep', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Falando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/bigdata/${encodeURIComponent(query)}?type=cep&token=${TOKEN}`
const apiRes = await fetch(url)
const data = await apiRes.json()
if (!data || !data.hawk) {
return res.status(404).json({ error: 'Nenhum resultado encontrado.' })
}
return res.json({
status: true,
criador: `${criador}` || "Desconhecido",
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
quantidade: data.resultados || data.hawk.length,
resultado: data.hawk
})
} catch (err) {
console.error(err)
res.status(500).json({ error: 'Erro ao consultar CEP BigData' })
}
})

// ----- Novas Rotas de Bigdata -----

app.get('/consultas/bigdata/desmasc_pix', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey, limit } = req.query
if (!query) return res.json({ resultado: "Faltando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/bigdata/${encodeURIComponent(query)}?type=desmasc_pix&token=${TOKEN}${limit ? `&limit=${limit}` : ''}`
const apiRes = await fetch(url)
const data = await apiRes.json()
if (!data || !data.hawk) {
return res.status(404).json({ error: 'Nenhum resultado encontrado.' })
}
return res.json({
status: true,
criador: `${criador}` || "Desconhecido",
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
quantidade: data.resultados || data.hawk.length,
resultado: data.hawk
})
} catch (err) {
console.error(err)
res.status(500).json({ error: 'Erro ao consultar Desmascaramento de PIX BigData' })
}
})

// ----- Rotas ASSECC -----

app.get('/consultas/assecc/cpf', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Falando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/assecc/${encodeURIComponent(query)}?type=cpf&token=${TOKEN}`
const apiRes = await fetch(url)
const data = await apiRes.json()
if (!data || !data.hawk) {
return res.status(404).json({ error: 'Nenhum resultado encontrado.' })
}
return res.json({
status: true,
criador: `${criador}` || "Desconhecido",
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
quantidade: data.resultados || data.hawk.length,
resultado: data.hawk
})
} catch (err) {
console.error(err)
res.status(500).json({ error: 'Erro ao consultar CPF Assecc' })
}
})

app.get('/consultas/assecc/telefone', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Falando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/assecc/${encodeURIComponent(query)}?type=telefone&token=${TOKEN}`
const apiRes = await fetch(url)
const data = await apiRes.json()
if (!data || !data.hawk) {
return res.status(404).json({ error: 'Nenhum resultado encontrado.' })
}
return res.json({
status: true,
criador: `${criador}` || "Desconhecido",
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
quantidade: data.resultados || data.hawk.length,
resultado: data.hawk
})
} catch (err) {
console.error(err)
res.status(500).json({ error: 'Erro ao consultar Telefone Assecc' })
}
})

app.get('/consultas/assecc/cep', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Falando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/assecc/${encodeURIComponent(query)}?type=cep&token=${TOKEN}`
const apiRes = await fetch(url)
const data = await apiRes.json()
if (!data || !data.hawk) {
return res.status(404).json({ error: 'Nenhum resultado encontrado.' })
}
return res.json({
status: true,
criador: `${criador}` || "Desconhecido",
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
quantidade: data.resultados || data.hawk.length,
resultado: data.hawk
})
} catch (err) {
console.error(err)
res.status(500).json({ error: 'Erro ao consultar CEP Assecc' })
}
})

// ---- Rotas DataSus ----

app.get('/consultas/datasus/cpf', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Faltando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) 
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) 
return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) 
return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) 
return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/datasus/${encodeURIComponent(query)}?type=cpf&token=${TOKEN}`
const apiRes = await fetch(url)
if (!apiRes.ok) {
return res.status(apiRes.status).json({ error: `Erro na consulta ao Data SUS: ${apiRes.statusText}` })
}
const jsonData = await apiRes.json()
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
resultado: {
CPF: jsonData.cpf,
NOME: jsonData.nome,
NOME_PAI: jsonData.nome_pai,
NOME_MAE: jsonData.nome_mae,
MUNICIPIO_NASCIMENTO: jsonData.municipio_nascimento,
CNS: jsonData.cns,
REGISTRO_GERAL: {
NUMERO: jsonData.registro_geral?.numero,
ORGAO_EMISSOR: jsonData.registro_geral?.orgao_emissor,
ESTADO_EMISSAO: jsonData.registro_geral?.estado_emissao,
DATA_EMISSAO: jsonData.registro_geral?.data_emissao
},
TELEFONES: {
TEL1: jsonData.telefones?.tel,
TEL2: jsonData.telefones?.tel2,
TEL3: jsonData.telefones?.tel3
},
ENDERECO: {
LOGRADOURO: jsonData.endereco?.logradouro,
BAIRRO: jsonData.endereco?.bairro,
NUMERO: jsonData.endereco?.numero,
CIDADE: jsonData.endereco?.cidade,
CEP: jsonData.endereco?.cep
}
}
})
} catch (err) {
console.error(err)
return res.status(500).json({ error: 'Erro ao consultar CPF no Data SUS',detalhes: err.message })
}
})

app.get('/consultas/datasus/cns', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Faltando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) 
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) 
return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) 
return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) 
return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/datasus/${encodeURIComponent(query)}?type=cns&token=${TOKEN}`
const apiRes = await fetch(url)
if (!apiRes.ok) {
return res.status(apiRes.status).json({ error: `Erro na consulta ao Data SUS: ${apiRes.statusText}` })
}
const jsonData = await apiRes.json()
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
resultado: {
CPF: jsonData.cpf,
NOME: jsonData.nome,
NOME_PAI: jsonData.nome_pai,
NOME_MAE: jsonData.nome_mae,
MUNICIPIO_NASCIMENTO: jsonData.municipio_nascimento,
CNS: jsonData.cns,
REGISTRO_GERAL: {
NUMERO: jsonData.registro_geral?.numero,
ORGAO_EMISSOR: jsonData.registro_geral?.orgao_emissor,
ESTADO_EMISSAO: jsonData.registro_geral?.estado_emissao,
DATA_EMISSAO: jsonData.registro_geral?.data_emissao
},
TELEFONES: {
TEL1: jsonData.telefones?.tel,
TEL2: jsonData.telefones?.tel2,
TEL3: jsonData.telefones?.tel3
},
ENDERECO: {
LOGRADOURO: jsonData.endereco?.logradouro,
BAIRRO: jsonData.endereco?.bairro,
NUMERO: jsonData.endereco?.numero,
CIDADE: jsonData.endereco?.cidade,
CEP: jsonData.endereco?.cep
}
}
})
} catch (err) {
console.error(err)
return res.status(500).json({ error: 'Erro ao consultar CNS no Data SUS',detalhes: err.message })
}
})

app.get('/consultas/datasus/nome_mae', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Faltando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) 
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) 
return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) 
return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) 
return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/datasus/${encodeURIComponent(query)}?type=nome_mae&token=${TOKEN}`
const apiRes = await fetch(url)
const data = await apiRes.json()
if (!data || !data.hawk) {
return res.status(404).json({ error: 'Nenhum resultado encontrado.' })
}
return res.json({
status: true,
criador: `${criador}` || "Desconhecido",
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
quantidade: data.resultados || data.hawk.length,
resultado: data.hawk
})
} catch (err) {
console.error(err)
res.status(500).json({ error: 'Erro ao consultar' })
}
})

app.get('/consultas/datasus/nome_pai', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Faltando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) 
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) 
return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) 
return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) 
return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/datasus/${encodeURIComponent(query)}?type=nome_pai&token=${TOKEN}`
const apiRes = await fetch(url)
const data = await apiRes.json()
if (!data || !data.hawk) {
return res.status(404).json({ error: 'Nenhum resultado encontrado.' })
}
return res.json({
status: true,
criador: `${criador}` || "Desconhecido",
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
quantidade: data.resultados || data.hawk.length,
resultado: data.hawk
})
} catch (err) {
console.error(err)
res.status(500).json({ error: 'Erro ao consultar' })
}
})

app.get('/consultas/datasus/rg', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Faltando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) 
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) 
return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) 
return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) 
return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/datasus/${encodeURIComponent(query)}?type=rg&token=${TOKEN}`
const apiRes = await fetch(url)
if (!apiRes.ok) {
return res.status(apiRes.status).json({ error: `Erro na consulta ao Data SUS: ${apiRes.statusText}` })
}
const jsonData = await apiRes.json()
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
resultado: {
CPF: jsonData.cpf,
NOME: jsonData.nome,
NOME_PAI: jsonData.nome_pai,
NOME_MAE: jsonData.nome_mae,
MUNICIPIO_NASCIMENTO: jsonData.municipio_nascimento,
CNS: jsonData.cns,
REGISTRO_GERAL: {
NUMERO: jsonData.registro_geral?.numero,
ORGAO_EMISSOR: jsonData.registro_geral?.orgao_emissor,
ESTADO_EMISSAO: jsonData.registro_geral?.estado_emissao,
DATA_EMISSAO: jsonData.registro_geral?.data_emissao
},
TELEFONES: {
TEL1: jsonData.telefones?.tel,
TEL2: jsonData.telefones?.tel2,
TEL3: jsonData.telefones?.tel3
},
ENDERECO: {
LOGRADOURO: jsonData.endereco?.logradouro,
BAIRRO: jsonData.endereco?.bairro,
NUMERO: jsonData.endereco?.numero,
CIDADE: jsonData.endereco?.cidade,
CEP: jsonData.endereco?.cep
}
}
})
} catch (err) {
console.error(err)
return res.status(500).json({ error: 'Erro ao consultar RG no Data SUS',detalhes: err.message })
}
})

// ---- Rotas CredAuto ----

app.get('/consultas/credauto/placa', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Faltando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) 
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) 
return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) 
return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) 
return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/credauto/${encodeURIComponent(query)}?type=placa&token=${TOKEN}`
const apiRes = await fetch(url)
if (!apiRes.ok) {
return res.status(apiRes.status).json({ error: `Erro na consulta ao Credauto: ${apiRes.statusText}` })
}
const jsonData = await apiRes.json()
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
resultado: {
PLACA: jsonData.placa,
MARCA: jsonData.marca,
MODELO: jsonData.modelo,
SITUACAO: jsonData.situacao,
COR: jsonData.cor,
CHASSI: jsonData.num_chassi,
RENAVAM: jsonData.num_renavam,
MOTOR: jsonData.num_motor,
QUILOMETRAGEM: jsonData.quilometragem,
DATA_QUILOMETRAGEM: jsonData.quilometragem_dt,
ANO_FABRICACAO: jsonData.ano_fab,
ANO_MODELO: jsonData.ano_modelo,
COMBUSTIVEL: jsonData.tipo_combustivel,
CARROCERIA: jsonData.carroceria,
NACIONALIDADE: jsonData.nacionalidade,
PASSAGEIROS: jsonData.num_passageiros,
JURISDICAO: jsonData.jurisdicao,
DATA_EMPLACAMENTO: jsonData.dt_emplacamento,
DOCUMENTO_FATURADO: jsonData.doc_faturado,
RESTRICOES: jsonData.restricoes || [],
PROPRIETARIOS: jsonData.proprietario || []
}
})
} catch (err) {
console.error(err)
return res.status(500).json({ error: 'Erro ao consultar placa no Credauto',detalhes: err.message })
}
})

app.get('/consultas/credauto/chassi', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Faltando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) 
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) 
return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) 
return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) 
return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/credauto/${encodeURIComponent(query)}?type=chassi&token=${TOKEN}`
const apiRes = await fetch(url)
if (!apiRes.ok) {
return res.status(apiRes.status).json({ error: `Erro na consulta ao Credauto: ${apiRes.statusText}` })
}
const jsonData = await apiRes.json()
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
resultado: {
PLACA: jsonData.placa,
MARCA: jsonData.marca,
MODELO: jsonData.modelo,
SITUACAO: jsonData.situacao,
COR: jsonData.cor,
CHASSI: jsonData.num_chassi,
RENAVAM: jsonData.num_renavam,
MOTOR: jsonData.num_motor,
QUILOMETRAGEM: jsonData.quilometragem,
DATA_QUILOMETRAGEM: jsonData.quilometragem_dt,
ANO_FABRICACAO: jsonData.ano_fab,
ANO_MODELO: jsonData.ano_modelo,
COMBUSTIVEL: jsonData.tipo_combustivel,
CARROCERIA: jsonData.carroceria,
NACIONALIDADE: jsonData.nacionalidade,
PASSAGEIROS: jsonData.num_passageiros,
JURISDICAO: jsonData.jurisdicao,
DATA_EMPLACAMENTO: jsonData.dt_emplacamento,
DOCUMENTO_FATURADO: jsonData.doc_faturado,
RESTRICOES: jsonData.restricoes || [],
PROPRIETARIOS: jsonData.proprietario || []
}
})
} catch (err) {
console.error(err)
return res.status(500).json({ error: 'Erro ao consultar chassi no Credauto', detalhes: err.message })
}
})

app.get('/consultas/credauto/renavam', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Faltando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) 
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) 
return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) 
return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) 
return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/credauto/${encodeURIComponent(query)}?type=renavam&token=${TOKEN}`
const apiRes = await fetch(url)
if (!apiRes.ok) {
return res.status(apiRes.status).json({ error: `Erro na consulta ao Credauto: ${apiRes.statusText}` })
}
const jsonData = await apiRes.json()
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
resultado: {
PLACA: jsonData.placa,
MARCA: jsonData.marca,
MODELO: jsonData.modelo,
SITUACAO: jsonData.situacao,
COR: jsonData.cor,
CHASSI: jsonData.num_chassi,
RENAVAM: jsonData.num_renavam,
MOTOR: jsonData.num_motor,
QUILOMETRAGEM: jsonData.quilometragem,
DATA_QUILOMETRAGEM: jsonData.quilometragem_dt,
ANO_FABRICACAO: jsonData.ano_fab,
ANO_MODELO: jsonData.ano_modelo,
COMBUSTIVEL: jsonData.tipo_combustivel,
CARROCERIA: jsonData.carroceria,
NACIONALIDADE: jsonData.nacionalidade,
PASSAGEIROS: jsonData.num_passageiros,
JURISDICAO: jsonData.jurisdicao,
DATA_EMPLACAMENTO: jsonData.dt_emplacamento,
DOCUMENTO_FATURADO: jsonData.doc_faturado,
RESTRICOES: jsonData.restricoes || [],
PROPRIETARIOS: jsonData.proprietario || []
}
})
} catch (err) {
console.error(err)
return res.status(500).json({ error: 'Erro ao consultar renavam no Credauto', detalhes: err.message })
}
})

app.get('/consultas/credauto/doc', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Faltando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) 
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) 
return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) 
return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) 
return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/credauto/${encodeURIComponent(query)}?type=doc&token=${TOKEN}`
const apiRes = await fetch(url)
if (!apiRes.ok) {
return res.status(apiRes.status).json({ error: `Erro na consulta ao Credauto: ${apiRes.statusText}` })
}
const jsonData = await apiRes.json()
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
resultado: {
NOME: jsonData.nome,
DOCUMENTO: jsonData.documento,
TIPO_DOCUMENTO: jsonData.tipo_documento,
VEICULOS: jsonData.veic || []
}
})
} catch (err) {
console.error(err)
return res.status(500).json({ error: 'Erro ao consultar documento no Credauto', detalhes: err.message })
}
})

app.get('/consultas/hydra/cpf_fullmax', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Faltando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) 
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) 
return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) 
return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) 
return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://hydraservices.shop/api/hydra/${encodeURIComponent(query)}?type=cpf_fullmax&token=${TOKEN}`
const apiRes = await fetch(url)
if (!apiRes.ok) {
return res.status(apiRes.status).json({ error: `Erro na consulta ao Hydra CPF Full: ${apiRes.statusText}` })
}
const jsonData = await apiRes.json()
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
resultado: {
CPF: jsonData.cpf,
CPF_FORMATADO: jsonData.cpf_formatado,
NOME: jsonData.nome,
SEXO: jsonData.sexo,
DATA_NASCIMENTO: jsonData.dt_nascimento,
IDADE: jsonData.idade,
MUNICIPIO_NASCIMENTO: jsonData.municipio_nascimento,
ESTADO_CIVIL: jsonData.estado_civil,
DATA_OBITO: jsonData.dt_obito,
DOCUMENTOS: {
CNS: jsonData.documentos?.cns,
TITULO_ELEITOR: jsonData.documentos?.titulo_eleitor,
PIS: jsonData.documentos?.pis,
RG_NUMERO: jsonData.documentos?.rg_numero,
RG_ORGAO_EMISSOR: jsonData.documentos?.rg_orgao_emissor,
RG_ESTADO_EMISSAO: jsonData.documentos?.rg_estado_emissao,
RG_DATA_EMISSAO: jsonData.documentos?.rg_data_emissao
},
FILIACAO: jsonData.filiacao || [],
CBO: jsonData.cbo || {},
DADOS_AQUISITIVOS: jsonData.dados_aquisitivos || {},
TELEFONES: jsonData.telefones || [],
ENDERECO: jsonData.endereco || {},
EMAILS: jsonData.emails || [],
PARENTES: jsonData.parentes || [],
VEICULOS: jsonData.veiculos || []
}
})
} catch (err) {
console.error(err)
return res.status(500).json({ error: 'Erro ao consultar CPF Full Max',detalhes: err.message })
}
})

// ---- Fotorj ----

app.get('/consultas/fotorj', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Faltando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) 
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) 
return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) 
return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) 
return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `http://n2.yoshinofenixbots.com:5126/AlizinHacker/fotorj?token=testedopaulo&cpf=${encodeURIComponent(query)}`
const apiRes = await fetch(url)
if (!apiRes.ok) {
return res.status(apiRes.status).json({ error: `Erro na consulta ao Fotorj: ${apiRes.statusText}` })
}
const jsonData = await apiRes.json()
let fotoUrl = "Não disponível"
if (jsonData.resultado?.foto?.base64) {
const base64Data = jsonData.resultado.foto.base64.replace(/^data:image\/\w+;base64,/, "")
const imageBuffer = Buffer.from(base64Data, 'base64')
fotoUrl = await uploadToCatbox2(imageBuffer) || "Erro ao gerar URL"
}
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
resultado: {
DADOS_PESSOAIS: {
NOME: jsonData.resultado.dados_pessoais.nome,
NASCIMENTO: jsonData.resultado.dados_pessoais.nascimento,
OBITO: jsonData.resultado.dados_pessoais.obito
},
FILIACAO: {
MAE: jsonData.resultado.filiacao.mae,
PAI: jsonData.resultado.filiacao.pai
},
DOCUMENTOS: {
RG: jsonData.resultado.documentos.rg
},
FOTO: fotoUrl
}
})
} catch (err) {
console.error(err)
return res.status(500).json({ error: 'Erro ao consultar Fotorj', detalhes: err.message })
}
})
*/

app.get('/consultas/serasa/rg', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Faltando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) 
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) 
return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) 
return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) 
return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://api-consultas.centralcybernet.com.br/api_serasa_consultas_modulo/consulta_rg/?rg=${encodeURIComponent(query)}`
const apiRes = await fetch(url)
const data = await apiRes.json()
if (!data || !data.dados || data.dados.length === 0) {
return res.status(404).json({ error: 'Nenhum resultado encontrado.' })
}
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
quantidade: data.qnt,
resultado: data.dados
})
} catch (err) {
console.error(err)
res.status(500).json({ error: 'Erro ao consultar RG no Serasa' })
}
})

app.get('/consultas/serasa/nome', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Faltando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) 
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) 
return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) 
return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) 
return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://api-consultas.centralcybernet.com.br/api_serasa_consultas_modulo/consulta_nome/?nome=${encodeURIComponent(query)}`
const apiRes = await fetch(url)
const data = await apiRes.json()
if (!data || !data.dados || data.dados.length === 0) {
return res.status(404).json({ error: 'Nenhum resultado encontrado.' })
}
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
quantidade: data.qnt,
resultado: data.dados
})
} catch (err) {
console.error(err)
res.status(500).json({ error: 'Erro ao consultar Nome no Serasa' })
}
})

app.get('/consultas/serasa/mae', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Faltando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) 
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) 
return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) 
return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) 
return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://api-consultas.centralcybernet.com.br/api_serasa_consultas_modulo/consulta_mae/?mae=${encodeURIComponent(query)}`
const apiRes = await fetch(url)
const data = await apiRes.json()
if (!data || !data.dados || data.dados.length === 0) {
return res.status(404).json({ error: 'Nenhum resultado encontrado.' })
}
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
quantidade: data.qnt,
resultado: data.dados
})
} catch (err) {
console.error(err)
res.status(500).json({ error: 'Erro ao consultar por Nome da Mãe' })
}
})

app.get('/consultas/serasa/cnpj', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Faltando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) 
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) 
return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) 
return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) 
return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://api-consultas.centralcybernet.com.br/apiConsultas_cnpj/consulta_cnpj/?token=mld_token&cnpj=${encodeURIComponent(query)}`
const apiRes = await fetch(url)
const data = await apiRes.json()
if (!data || !data.dados || data.dados.length === 0) {
return res.status(404).json({ error: 'Nenhum resultado encontrado.' })
}
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
quantidade: data.qnt,
resultado: data.dados
})
} catch (err) {
console.error(err)
res.status(500).json({ error: 'Erro ao consultar CNPJ' })
}
})

app.get('/consultas/serasa/cep', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Faltando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) 
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) 
return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) 
return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) 
return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://api-consultas.centralcybernet.com.br/api_serasa_consultas_modulo/consulta_cep/?cep=${encodeURIComponent(query)}`
const apiRes = await fetch(url)
const data = await apiRes.json()
if (!data || !data.dados || data.dados.length === 0) {
return res.status(404).json({ error: 'Nenhum resultado encontrado.' })
}
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
quantidade: data.qnt,
resultado: data.dados
})
} catch (err) {
console.error(err)
res.status(500).json({ error: 'Erro ao consultar CEP' })
}
})

app.get('/consultas/serasa/telefone', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var { query, apikey } = req.query
if (!query) return res.json({ resultado: "Faltando o parâmetro query" })
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if (!key.map(i => i.apikey)?.includes(apikey)) 
return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
if (key[ITC]?.consulta == 0) 
return res.json({ resultado: `[❗] Key inválida para uso de puxadas ❌` })
if (key[ITC]?.request <= 0) 
return res.json({ resultado: "Apikey inválida ou requests esgotados!" })
if (key[ITC]?.consulta < 2) 
return res.json({ resultado: "Apikey inválida ou consultas esgotadas!" })
key[ITC].request -= 1
key[ITC].consulta -= 2
RegisKey(req.query.apikey, userIp)
console.log(color(' ApiKey:' + ` ${apikey} • Requests restantes: ${key[ITC]?.request} • Consultas restantes: ${key[ITC]?.consulta}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const url = `https://api-consultas.centralcybernet.com.br/api_serasa_consultas_modulo/consulta_telefone/?telefone=${encodeURIComponent(query)}`
const apiRes = await fetch(url)
const data = await apiRes.json()
if (!data || !data.dados || data.dados.length === 0) {
return res.status(404).json({ error: 'Nenhum resultado encontrado.' })
}
return res.json({
status: true,
criador: `${criador}`,
by: "*_🔎 ZERO TWO CONSULTAS 🔍_*",
quantidade: data.qnt,
resultado: data.dados
})
} catch (err) {
console.error(err)
res.status(500).json({ error: 'Erro ao consultar Telefone' })
}
})

// ---- Fim ----

app.get('/vip/check-number', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
query = req.query.query
apikey = req.query.apikey
if(!query) return res.json({status:false, resultado:'Cade o parametro query??'})
if(!apikey) return res.json({resultado:'Cade o parametro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.consulta == 0) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
anu = await fetchJson(`http://apilayer.net/api/validate?access_key=d57f91cf25db296a9e223888cfdc064a&number=${query}`)
res.json({
status: true, 
criador: `${criador}`,
resultado: {
number: anu.number, 
local_format: anu.local_format ,
international_format: anu.international_format,
country_prefix: anu.country_prefix,
country_code: anu.country_code,
country_name: anu.country_name, 
location: anu.location,
carrier: anu.carrier,
line_type: anu.line_type, 
}
})
} catch (error) {
return res.status(404).json({ resultado: `[❗] Nenhuma resposta obtida... Favor, tente mais tarde 💢`, status: 500 })
}
})

app.get('/vip/gerar-cc', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
var apikey = req.query.apikey
if(!apikey) return res.json({resultado:'Cade o parametro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.consulta == 0) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
ABC = await fetchJson(`https://api.lolhuman.xyz/api/vccgenerator?apikey=1b0ebf01de8b0fbd59270f27&bin=${Math.floor(Math.random()*999899) + 100}`)
res.json({
status: true,
criador: `${criador}`,
resultado: ABC.result || []
})
} catch (error) {
return res.status(404).json({ resultado: `[❗] Nenhuma resposta obtida... Favor, tente mais tarde 💢`, status: 500 })
}
})

app.get('/animesfire/search', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
nome = req.query.nome
testProxyConnection()
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!nome) return res.json({ status : false,message: "Coloque o parametro: nome"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const results = await AnimeFire.search(nome)
res.json({ status: true, criador: `${criador}`, resultado: results })
} catch (error) {
console.error(error)
res.json({ status: false, criador: `${criador}`, message: "Erro ao buscar animes!" })
}
})

app.get('/animesfire/info', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
testProxyConnection()
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const info = await AnimeFire.serieInfo(url)
res.json({ status: true, criador: `${criador}`, resultado: info })
} catch (error) {
console.error(error)
res.json({ status: false, criador: `${criador}`, message: "Erro ao buscar animes!" })
}
})

app.get('/animesfire/download', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
testProxyConnection()
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status : false,message: "Coloque o parametro: url"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const downloadInfo = await AnimeFire.download(url)
res.json({ status: true, criador: `${criador}`, resultado: downloadInfo })
} catch (error) {
console.error(error)
res.json({ status: false, criador: `${criador}`, message: "Erro ao buscar animes!" })
}
})

app.get('/download/storyanime', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const response = await axios.get('https://api.tioo.eu.org/download/storyanime')
const apiData = response.data
const resultado = {
status: apiData.status,
criador: `${criador}`,
resultado: {
titulo: apiData.result.title,
url: apiData.result.url
}
}
res.json(resultado)
} catch (error) {
console.error("Erro ao acessar a API:", error)
res.status(500).json({ error: "Ocorreu um erro ao acessar a API" })
}
})

app.get('/api/imagine', async (req, res) => {
  const userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress;
  const apikey = req.query.apikey;
  const prompt = req.query.prompt;

  // validações de apikey
  if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!prompt) return res.json({ status : false,message: "Coloque o parametro: prompt"})


  RegisKey(req.query.apikey, userIp);
  const ITC = key.map(i => i?.apikey)?.indexOf(apikey);

  console.log(
    color(' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'),
    color('', 'red'),
    color('Request', 'red'),
    '• ' + color('Ping: ' + ping(), 'red')
  );

  try {
    // usa o scraper
    const result = await GPTImage.generate(prompt);

    if (!result.success) {
      throw new Error(result.message || "Falha ao gerar imagem");
    }

    const imageUrl = result.payload.image_url;
    const imageResponse = await fetch(imageUrl);

    if (!imageResponse.ok) {
      throw new Error(`Erro ao baixar imagem: ${imageResponse.statusText}`);
    }

    const imageBuffer = await imageResponse.buffer();
    const contentType = imageResponse.headers.get('content-type') || 'image/png';

    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Length', imageBuffer.length);
    res.setHeader('Cache-Control', 'public, max-age=604800');
    res.send(imageBuffer);

  } catch (error) {
    console.error('Erro:', error);
    res.status(500).send('Erro ao gerar imagem: ' + error.message);
  }
});

app.get('/api/veon-2', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
prompt = req.query.prompt
config = req.query.config
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!prompt) return res.json({ status : false,message: "Coloque o parametro: prompt"})
 RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const videoArrayBuffers = await generateVideo(prompt, config)
res.set({
'Content-Type': 'video/mp4',
'Content-Length': videoArrayBuffers[0].byteLength,
'Content-Disposition': 'inline; filename="generated-video.mp4"'
})
res.send(Buffer.from(videoArrayBuffers[0]))
} catch (error) {
res.status(500).json({ error: error instanceof VideoGenerationError ? error.message : 'Erro interno no servidor' })
}
})

/*
app.get('/gemini/texto/imagem', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, query, prompt, imageUrl } = req.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query && !prompt) return res.status(400).json({ error: "Por favor, forneça a pergunta no parâmetro 'query' ou 'prompt'." })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
let textResponse
const userPrompt = query || prompt
if (imageUrl) {
const response = await axios.get(imageUrl, { 
responseType: 'arraybuffer',
timeout: 15000,
headers: {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'}
})
let mimeType = 'image/jpeg'
const contentType = response.headers['content-type']
if (contentType && contentType.startsWith('image/')) {
mimeType = contentType
} else {
const extension = imageUrl.split('.').pop()?.toLowerCase()
if (extension === 'png') mimeType = 'image/png'
if (extension === 'gif') mimeType = 'image/gif'
if (extension === 'webp') mimeType = 'image/webp'
}
const base64Image = Buffer.from(response.data).toString('base64')
const contents = [{ role: 'user', parts: [{ text: userPrompt }, { inlineData: { data: base64Image, mimeType: mimeType }}]
}]
const result = await gemini.models.generateContent({
model: 'gemini-2.0-flash',
contents: contents,
config: {
maxOutputTokens: 2048,
temperature: 0.4
}
})
textResponse = result.text
} else {
const result = await gemini.models.generateContent({
model: 'gemini-2.0-flash',
contents: [{ role: 'user', parts: [{ text: userPrompt }]
}
],
config: {
maxOutputTokens: 2048,
temperature: 0.7
}
})
textResponse = result.text
}
return res.json({ 
status: true, 
criador: `${criador}`, 
url: "https://raw.githubusercontent.com/Otakump4/links-gerados/main/IMAGENS/gemini.jpeg", 
resposta: textResponse 
})
} catch (error) {
console.error('Erro detalhado na API Gemini:', {
message: error.message,
status: error.response?.status,
data: error.response?.data
})
return res.status(500).json({ error: 'Ocorreu um erro ao processar sua solicitação.', detalhes: error.response?.data || error.message })
}
})
*/

app.get("/api/gemini/v1", async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status: false, message: "Coloque o parâmetro: query" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(chalk.blue("Consultando a ferramenta Gemini via função do módulo 'kode-scrape'..."))
const geminiRes = await ai.gemini(query)
res.json({
criador: `${criador}`,
status: true,
resultado: {
url: geminiRes.url,
resposta: geminiRes.reply.replace(/\*\*/g, '*')
}
})
} catch (error) {
console.error(chalk.red("Erro ao consultar Gemini:"), error.message)
res.status(500).json({ erro: 'Erro ao consultar Gemini', detalhes: error.message })
}
})

app.get("/api/gemini/v2", async (req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status: false, message: "Coloque o parâmetro: query" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const apiUrl = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&pretty=1`
const response = await fetch(apiUrl)
const data = await response.json()
async function traduzirObjeto(obj) {
for (const key in obj) {
if (typeof obj[key] === 'string') {
obj[key] = await translateText(obj[key])
} else if (typeof obj[key] === 'object' && obj[key] !== null) {
await traduzirObjeto(obj[key])
}
}
return obj
}
const resultadoTraduzido = await traduzirObjeto(data)
res.json({
status: true,
criador: `${criador}`,
resultado: resultadoTraduzido
})
} catch (error) {
console.error(error)
return res.status(500).json({
resultado: `[❗] Nenhuma resposta obtida... Favor, tente mais tarde 💢`,
status: 500
})
}
})

app.get('/api/gemini/v3', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status: false, message: "Coloque o parâmetro: query" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
const geminiApiUrl = `https://api.vihangayt.com/ai/gemini?q=${encodeURIComponent(query)}`
try {
const response = await fetch(geminiApiUrl)
const geminiData = await response.json()
if (!geminiData.status) {
return res.status(500).json({
success: false,
message: 'Erro ao consultar a API Gemini.'
})
}
return res.json({
success: true,
criador: `${criador}`,
originalPrompt: geminiData.data.prompt,
originalResponse: geminiData.data.response,
duration: geminiData.data.duration
})
} catch (error) {
console.error('Erro ao processar a requisição:', error)
return res.status(500).json({
success: false,
message: 'Ocorreu um erro ao processar a sua solicitação.',
error: error.message
})
}
})

app.get('/quiz', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const randomId = Math.floor(Math.random() * 158) + 1
const { getQuizById } = new Quiz()
const quiz = await getQuizById(randomId)
if (!quiz) return res.status(500).json({ status: false, erro: 'Quiz não encontrado' })
const translatedQuestion = he.decode(await translateText(quiz.question))
const translatedOptions = await Promise.all(quiz.options.map(async option => he.decode(await translateText(option))))
//const translatedAnswer = he.decode(quiz.answer)
const translatedAnswer = await translateText(quiz.answer)
const waifuImageResponse = await axios.get(`${okarunsite}/random/waifu?apikey=${API_KEY_OKARUN}`, { responseType: 'arraybuffer' })
const imageBuffer = Buffer.from(waifuImageResponse.data, 'binary')
let waifuImageUrl = 'Não foi possível gerar o link da imagem'
try {
waifuImageUrl = await upload2(imageBuffer)
} catch (imageError) {
console.log(chalk.red('Erro ao gerar link da imagem:', imageError.message))
}
res.json({
status: true,
criador: `${criador}`,
imagem: waifuImageUrl,
pergunta: translatedQuestion,
opcoes: translatedOptions,
resposta: translatedAnswer
})
} catch (error) {
console.log(chalk.red('Erro ao gerar quiz:', error.message))
res.status(500).json({ status: false, erro: 'Erro ao gerar quiz' })
}
})

app.get('/api/bing-search', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status: false, message: "Coloque o parâmetro: query" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const response = await axios.get(`https://vapis.my.id/api/bingsrc?q=${query}`)
if (response.data && response.data.status) {
const modifiedResponse = {
status: response.data.status,
criador: `${criador}`,
resultado: response.data.data,
}
res.status(200).json(modifiedResponse)
} else {
res.status(404).json({ error: 'Nenhum dado encontrado.' })
}
} catch (error) {
console.error('Erro ao consumir a API:', error.message)
res.status(500).json({ error: 'Erro interno no servidor.' })
}
})

app.get('/api/bing-img', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status: false, message: "Coloque o parâmetro: query" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const response = await axios.get(`https://vapis.my.id/api/bingimg?q=${query}`)
if (response.data && response.data.status) {
const modifiedResponse = {
status: response.data.status,
criador: `${criador}`,
resultado: response.data.data,
}
res.status(200).json(modifiedResponse)
} else {
res.status(404).json({ error: 'Nenhum dado encontrado.' })
}
} catch (error) {
console.error('Erro ao consumir a API:', error.message)
res.status(500).json({ error: 'Erro interno no servidor.' })
}
})

app.get('/api/bing-video', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status: false, message: "Coloque o parâmetro: query" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const response = await axios.get(`https://vapis.my.id/api/bingvd?q=${query}`)
if (response.data && response.data.status) {
const modifiedResponse = {
status: response.data.status,
criador: `${criador}`,
resultado: response.data.data,
}
res.status(200).json(modifiedResponse)
} else {
res.status(404).json({ error: 'Nenhum dado encontrado.' })
}
} catch (error) {
console.error('Erro ao consumir a API:', error.message)
res.status(500).json({ error: 'Erro interno no servidor.' })
}
})

app.get('/anime/anichin-search', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status: false, message: "Coloque o parâmetro: query" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const response = await axios.get(`https://api.siputzx.my.id/api/anime/anichin-search?query=${query}`)
if (response.data && response.data.status) {
const modifiedResponse = {
status: response.data.status,
criador: `${criador}`,
resultado: response.data.data,
}
res.status(200).json(modifiedResponse)
} else {
res.status(404).json({ error: 'Nenhum dado encontrado.' })
}
} catch (error) {
console.error('Erro ao consumir a API:', error.message)
res.status(500).json({ error: 'Erro interno no servidor.' })
}
})

app.get('/anime/anichin-popular', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const response = await axios.get(`https://api.siputzx.my.id/api/anime/anichin-popular`)
if (response.data && response.data.status) {
const modifiedResponse = {
status: response.data.status,
criador: `${criador}`,
resultado: response.data.data,
}
res.status(200).json(modifiedResponse)
} else {
res.status(404).json({ error: 'Nenhum dado encontrado.' })
}
} catch (error) {
console.error('Erro ao consumir a API:', error.message)
res.status(500).json({ error: 'Erro interno no servidor.' })
}
})

app.get('/anime/anichin-latest', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const response = await axios.get(`https://api.siputzx.my.id/api/anime/latest`)
if (response.data && response.data.status) {
const modifiedResponse = {
status: response.data.status,
criador: `${criador}`,
resultado: response.data.data,
}
res.status(200).json(modifiedResponse)
} else {
res.status(404).json({ error: 'Nenhum dado encontrado.' })
}
} catch (error) {
console.error('Erro ao consumir a API:', error.message)
res.status(500).json({ error: 'Erro interno no servidor.' })
}
})

app.get('/anime/anichin-detail', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status: false, message: "Coloque o parâmetro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const response = await axios.get(`https://api.siputzx.my.id/api/anime/anichin-detail?url=${url}`)
if (response.data && response.data.status) {
const modifiedResponse = {
status: response.data.status,
criador: `${criador}`,
resultado: {
titulo: response.data.data.title,
thumbnail: response.data.data.thumbnail,
avaliacao: response.data.data.rating,
seguidores: response.data.data.followers,
sinopse: response.data.data.synopsis,
titulosAlternativos: response.data.data.alternativeTitles,
status: response.data.data.status,
rede: response.data.data.network,
estudio: response.data.data.studio,
lancamento: response.data.data.released,
duracao: response.data.data.duration,
temporada: response.data.data.season,
pais: response.data.data.country,
tipo: response.data.data.type,
episodios: response.data.data.episodes,
generos: response.data.data.genres
}
}
res.status(200).json(modifiedResponse)
} else {
res.status(404).json({ erro: 'Nenhum dado encontrado.' })
}
} catch (error) {
console.error('Erro ao consumir a API:', error.message)
res.status(500).json({ erro: 'Erro interno no servidor.' })
}
})

app.get('/anime/anichin-episode', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status: false, message: "Coloque o parâmetro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const response = await axios.get(`https://api.siputzx.my.id/api/anime/anichin-episode?url=${url}`)
if (response.data && response.data.status) {
const modifiedResponse = {
status: response.data.status,
criador: `${criador}`,
resultado: response.data.data,
}
res.status(200).json(modifiedResponse)
} else {
res.status(404).json({ error: 'Nenhum dado encontrado.' })
}
} catch (error) {
console.error('Erro ao consumir a API:', error.message)
res.status(500).json({ error: 'Erro interno no servidor.' })
}
})

app.get('/anime/anichin-download', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status: false, message: "Coloque o parâmetro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const response = await axios.get(`https://api.siputzx.my.id/api/anime/anichin-download?url=${url}`)
if (response.data && response.data.status) {
const modifiedResponse = {
status: response.data.status,
criador: `${criador}`,
resultado: response.data.data.map((item) => ({
resolucao: item.resolution,
links: item.links.map((linkItem) => ({
host: linkItem.host,
link: linkItem.link
}))
}))
}
res.status(200).json(modifiedResponse)
} else {
res.status(404).json({ erro: 'Nenhum dado encontrado.' })
}
} catch (error) {
console.error('Erro ao consumir a API:', error.message)
res.status(500).json({ erro: 'Erro interno no servidor.' })
}
})

app.get('/api/otakudesu/search', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status: false, message: "Coloque o parâmetro: query" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(chalk.blue(`Buscando por anime: ${query}...`))
let result = await anime.otakudesuSearch(query)
if (result) {
console.log(chalk.green("Resultados encontrados:"))
return res.json({ status: true, criador: `${criador}`, resultado: result })
} else {
console.log(chalk.yellow("Nenhum resultado encontrado."))
return res.status(404).json({ message: "Nenhum resultado encontrado para a busca." })
}
} catch (error) {
console.error(chalk.red("Erro ao buscar anime:"), error)
return res.status(500).json({ error: 'Erro ao buscar anime.' })
}
})

app.get('/api/otakudesu/download', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status: false, message: "Coloque o parâmetro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(chalk.blue(`Obtendo links de download para o anime de: ${url}...`))
let downloadLinks = await anime.otakudesuDownload(url)
if (downloadLinks) {
console.log(chalk.green("Links de download encontrados:"))
return res.json({ status: true, criador: `${criador}`, resultado: downloadLinks })
} else {
console.log(chalk.yellow("Links de download não encontrados."))
return res.status(404).json({ message: "Links de download não encontrados." })
}
} catch (error) {
console.error(chalk.red("Erro ao obter links de download:"), error)
return res.status(500).json({ error: 'Erro ao obter links de download.' })
}
})

app.get('/api/applemusic/search', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status: false, message: "Coloque o parâmetro: query" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const resultados = await search2(query)
res.json(resultados)
} catch (error) {
console.error('Erro ao buscar músicas:', error)
res.status(500).json({ status: 'error', message: 'Erro ao buscar músicas.' })
}
})

app.get('/api/applemusic/download', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status: false, message: "Coloque o parâmetro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const resultado = await download(url)
res.json(resultado)
} catch (error) {
console.error('Erro ao realizar download:', error)
res.status(500).json({ status: 'error', message: 'Erro ao realizar download.' })
}
})

app.get('/api/applemusic/preview', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status: false, message: "Coloque o parâmetro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const resultado = await download(url)
if (resultado.status && resultado.resultados) {
const linkPreview = resultado.resultados.preview_catbox || 
resultado.resultados.preview
if (linkPreview) {
return res.redirect(linkPreview)
}
}
} catch (error) {
console.error('Erro ao realizar download:', error)
res.status(500).json({ status: 'error', message: 'Erro ao realizar download.' })
}
})

app.get('/api/ia/zerotwo', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status : false,message : "Cade o parametro query?"}) 
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color(' ApiKey:'+ ` ${apikey} • Limite: ${key[ITC]?.request}\n`,'red'),color('','red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(chalk.blue("Consultando ZeroTwoIA via scraper"))
await ZeroTwoIA(query, res)
} catch (error) {
console.error('Erro ao processar a pergunta:', error)
return res.json({ status: false, message: 'Ocorreu um erro ao processar sua requisição.' })
}
})

app.get('/api/stalker/whatsapp-channel', async(req, res, next) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status: false, message: "Coloque o parâmetro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
itzpireStalker.WhatsAppChannel(url).then((resultGet) => {
console.log(chalk.blue("Consultando whatsapp stalker via scraper"))
res.json({ status: true, criador: `${criador}`, resultado: resultGet })
}).catch(error => {
res.json({status: 404, message: error})
})
})





// Rota brat → retorna imagem melhorada
app.get('/api/maker/brat', async (req, res) => {
  const apikey = req.query.apikey;
  const text = req.query.text;

  if (!key.map(i => i.apikey)?.includes(apikey)) {
    return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"));
  }
  if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) {
    return res.json({ status: false, message: "Apikey inválida ou requests esgotados!" });
  }
  if (!text) {
    return res.json({ status: false, message: "Parâmetro obrigatório: text" });
  }

  try {
    const buffer = await bratStaticService.fetchCommand(text);

    // upscale automático com sharp
    const upscaled = await sharp(buffer)
      .resize({ width: 1024, height: 1024, fit: 'contain' })
      .png({ quality: 90 })
      .toBuffer();

    res.type('image/png');
    res.send(upscaled);
  } catch (error) {
    res.json({ status: false, message: error.message || 'Erro desconhecido' });
  }
});

// Rota bratvideo → retorna vídeo original
app.get('/api/maker/bratvideo', async (req, res) => {
  const apikey = req.query.apikey;
  const text = req.query.text;

  if (!key.map(i => i.apikey)?.includes(apikey)) {
    return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"));
  }
  if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) {
    return res.json({ status: false, message: "Apikey inválida ou requests esgotados!" });
  }
  if (!text) {
    return res.json({ status: false, message: "Parâmetro obrigatório: text" });
  }

  try {
    const buffer = await bratAnimatedService.fetchCommand(text);

    res.type('video/mp4');
    res.send(buffer);
  } catch (error) {
    res.json({ status: false, message: error.message || 'Erro desconhecido' });
  }
});




app.get('/api/channel/react', async (req, res) => {
  const apikey = req.query.apikey
  const post_link = req.query.post
  const reacts = req.query.reacts // separado por vírgula ou espaço

  // validação apikey
  if (!key.map(i => i.apikey)?.includes(apikey)) {
    return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
  }
  if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) {
    return res.json({ message: "Apikey inválida ou requests esgotados!" })
  }
  if (!post_link || !reacts) {
    return res.json({ status: false, message: "Parâmetros obrigatórios: post e reacts" })
  }

  try {
    // scraper embutido
    const url = 'https://foreign-marna-sithaunarathnapromax-9a005c2e.koyeb.app/api/channel/react-to-post'
    const requestData = {
      post_link: post_link,
      reacts: reacts
    }
    const headers = {
      'Accept': 'application/json, text/plain, */*',
      'Content-Type': 'application/json',
      'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY5MzgyZDFhMTE0YWI3MTE5ZmNhNTdjZiIsImlhdCI6MTc2NTI4OTI0MiwiZXhwIjoxNzY1ODk0MDQyfQ.PyblreikWf2_fcPwRfrM_w-_VZmSlvk1vQtrrOuNFBo'
    }

    const response = await axios.post(url, requestData, { headers })
    const data = response.data

    const result = {
      message: data.message || 'Reação enviada com sucesso',
      botResponse: data.botResponse || null,
      post: post_link,
      reacts: reacts
    }

    res.json({ status: true, criador: `${criador}`, resultado: result })
  } catch (error) {
    let errMsg = { status: false, message: "Erro desconhecido" }
    if (error.response) {
      errMsg = {
        status: false,
        statusCode: error.response.status,
        message: error.response.data?.message || JSON.stringify(error.response.data)
      }
    } else if (error.request) {
      errMsg = { status: false, message: "Sem resposta do servidor" }
    } else {
      errMsg = { status: false, message: error.message }
    }
    res.json(errMsg)
  }
})



app.get('/api/tools/ngl', async (req, res) => {
  const apikey = req.query.apikey
  const user = req.query.user
  const message = req.query.message

  // validação apikey
  if (!key.map(i => i.apikey)?.includes(apikey)) {
    return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
  }
  if (key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) {
    return res.json({ message: "Apikey inválida ou requests esgotados!" })
  }
  if (!user || !message) {
    return res.json({ status: false, message: "Parâmetros obrigatórios: user e message" })
  }
  if (message.length > 1000) {
    return res.json({ status: false, message: "Mensagem excede 1000 caracteres" })
  }

  try {
    // scraper embutido
    let targetUser
    try {
      if (!user.includes('/') && !user.includes('.')) {
        targetUser = user
      } else {
        let urlString = user
        if (!urlString.startsWith('http://') && !urlString.startsWith('https://')) {
          urlString = 'https://' + urlString
        }
        const urlObj = new URL(urlString)
        const pathParts = urlObj.pathname.split('/').filter(p => p.length > 0)
        targetUser = pathParts.length > 0 ? pathParts[0] : null
      }
    } catch (err) {
      targetUser = user.replace(/^https?:\/\//, '')
                       .replace(/^ngl\.link\//, '')
                       .replace(/\/$/, '')
                       .split('/')[0]
    }

    if (!targetUser) return res.json({ status: false, message: "Username inválido" })

    const postData = new URLSearchParams({
      username: targetUser,
      question: message.trim(),
      deviceId: "",
      gameSlug: "",
      referrer: ""
    })

    const response = await fetch('https://ngl.link/api/submit', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': '*/*',
        'X-Requested-With': 'XMLHttpRequest',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10)',
        'Referer': `https://ngl.link/${targetUser}`
      },
      body: postData.toString()
    })

    const data = await response.json()
    if (!data) return res.json({ status: false, message: "Falha ao enviar mensagem" })

    const result = {
      target: targetUser,
      message: message.trim().substring(0, 100) + (message.length > 100 ? '...' : ''),
      time: new Date().toLocaleTimeString('pt-BR')
    }

    res.json({ status: true, criador: `${criador}`, resultado: result })
  } catch (error) {
    res.json({ status: false, message: error.message || 'Erro desconhecido' })
  }
})





app.get('/api/ai/editimg', async (req, res) => {
  const apikey = req.query.apikey
  const prompt = req.query.prompt
  const imageUrl = req.query.image

  // Validação de apikey
  if(!key.map(i => i.apikey)?.includes(apikey)) {
    return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
  }
  if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) {
    return res.json({message: "Apikey inválida ou requests esgotados!"})
  }
  if (!prompt) {
    return res.json({ status: false, message: "Coloque o parâmetro: prompt" })
  }
  if (!imageUrl) {
    return res.json({ status: false, message: "Coloque o parâmetro: image (URL da imagem)" })
  }

  try {
    console.log(chalk.blue("Consultando Image Editor via scraper"))

    // Função embutida dentro da rota
    const gen = await fetch("https://imgeditor.co/api/generate-image", {
      method: "POST",
      headers: {
        "accept": "/",
        "content-type": "application/json"
      },
      body: JSON.stringify({
        prompt,
        styleId: "realistic",
        mode: "image",
        imageUrl: imageUrl,
        imageUrls: [imageUrl],
        numImages: 1,
        outputFormat: "png",
        model: "nano-banana"
      })
    }).then(r => r.json())

    let status
    while (true) {
      await new Promise(r => setTimeout(r, 2000))
      status = await fetch(
        `https://imgeditor.co/api/generate-image/status?taskId=${gen.taskId}`,
        { headers: { "accept": "/" } }
      ).then(r => r.json())

      if (status.status === "completed") break
    }

    res.json({ status: true, criador: `${criador}`, resultado: status.imageUrl })
  } catch (error) {
    res.json({status: 404, message: error.message})
  }
})



app.get('/api/stalker/youtube-banner', async (req, res) => {
  const userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
  const apikey = req.query.apikey
  const url = req.query.url

  // Validação de apikey
  if(!key.map(i => i.apikey)?.includes(apikey)) {
    return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
  }
  if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) {
    return res.json({message: "Apikey inválida ou requests esgotados!"})
  }
  if (!url) {
    return res.json({ status: false, message: "Coloque o parâmetro: url" })
  }

  RegisKey(req.query.apikey, userIp)
  const ITC = key.map(i => i?.apikey)?.indexOf(apikey)

  console.log(
    chalk.red(`ApiKey: ${apikey} • Limite: ${key[ITC]?.request}`),
    chalk.red('Request'),
    '• ' + chalk.red('Ping: ' + ping())
  )

  // Função embutida para extrair banner e logo
  async function youtubeBannerDownloader(text){
    try {
      let channelId = ''
      if (text.includes('@')) {
        channelId = text.split('@')[1].split('/')[0].split('?')[0]
      } else if (text.includes('youtube.com/channel/')) {
        channelId = text.split('channel/')[1].split('/')[0].split('?')[0]
      } else if (text.includes('youtu.be/') || text.includes('youtube.com/watch')) {
        const videoId = text.includes('youtu.be/') 
          ? text.split('youtu.be/')[1].split('?')[0]
          : text.split('v=')[1]?.split('&')[0]
        if (!videoId) throw new Error('URL YouTube inválida')

        const videoInfo = await axios.get(`https://noembed.com/embed?url=${encodeURIComponent(`https://www.youtube.com/watch?v=${videoId}`)}`)
        const authorName = videoInfo.data.author_name
        channelId = `@${authorName.replace(/\s+/g, '').toLowerCase()}`
      } else {
        throw new Error('Formato URL não reconhecido')
      }

      const response = await axios.post(
        'https://tubepilot.ai/wp-admin/admin-ajax.php',
        `action=yt_banner_download&yt_url=https%3A%2F%2Fyoutube.com%2F${encodeURIComponent(channelId)}`,
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Accept': '*/*',
            'X-Requested-With': 'XMLHttpRequest'
          }
        }
      )

      const html = response.data
      if (!html || html.includes('not found') || html.includes('Note:')) {
        throw new Error('Channel não encontrado ou banner não disponível')
      }

      const bannerMatch = html.match(/href="([^"]+)"[^>]*>\s*<img[^>]*Banner\/Cover Image:/)
      const bannerUrl = bannerMatch ? bannerMatch[1] : null
      const bannerSizes = []
      const bannerSizeRegex = /<a class="size-link" href="([^"]+)"[^>]*>([^<]+)<\/a>/g
      let bannerMatchSize
      while ((bannerMatchSize = bannerSizeRegex.exec(html)) !== null) {
        bannerSizes.push({ url: bannerMatchSize[1], resolution: bannerMatchSize[2] })
      }

      const logoMatch = html.match(/href="([^"]+)"[^>]*>\s*<img[^>]*Logo\/Profile Picture:/)
      const logoUrl = logoMatch ? logoMatch[1] : null
      const logoSizes = []
      const logoSizeRegex = /<a class="size-link" href="([^"]+)"[^>]*>([^<]+)<\/a>/g
      const logoSection = html.split('Logo/Profile Picture:')[1]
      if (logoSection) {
        let logoMatchSize
        while ((logoMatchSize = logoSizeRegex.exec(logoSection)) !== null) {
          logoSizes.push({ url: logoMatchSize[1], resolution: logoMatchSize[2] })
        }
      }

      return {
        channelId,
        banner: { url: bannerUrl, sizes: bannerSizes },
        logo: { url: logoUrl, sizes: logoSizes }
      }
    } catch (e) {
      return { status: 'error', msg: e.message }
    }
  }

  try {
    console.log(chalk.blue("Consultando YouTube Banner Downloader via scraper"))
    const resultGet = await youtubeBannerDownloader(url)
    res.json({ status: true, criador: `${criador}`, resultado: resultGet })
  } catch (error) {
    res.json({status: 404, message: error.message})
  }
})



app.get('/api/stalker/twitter', async (req, res) => {
  const userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
  const apikey = req.query.apikey
  const username = req.query.username

  // Validação de apikey
  if(!key.map(i => i.apikey)?.includes(apikey)) {
    return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
  }
  if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) {
    return res.json({message: "Apikey inválida ou requests esgotados!"})
  }
  if (!username) {
    return res.json({ status: false, message: "Coloque o parâmetro: username" })
  }

  RegisKey(req.query.apikey, userIp)
  const ITC = key.map(i => i?.apikey)?.indexOf(apikey)

  console.log(
    chalk.red(`ApiKey: ${apikey} • Limite: ${key[ITC]?.request}`),
    chalk.red('Request'),
    '• ' + chalk.red('Ping: ' + ping())
  )

  // Função embutida de scraping para Twitter
  async function twitterstalk(username){
    try{
      const ch = await axios.get(
        'https://twittermedia.b-cdn.net/challenge/',
        {
          headers:{
            'User-Agent':'Mozilla/5.0 (Linux; Android 10)',
            'Accept':'application/json',
            origin:'https://snaplytics.io',
            referer:'https://snaplytics.io/'
          }
        }
      ).then(r => r.data)

      if(!ch.challenge_id) throw new Error('challenge failed')

      const hash = crypto
        .createHash('sha256')
        .update(String(ch.timestamp) + ch.random_value)
        .digest('hex')
        .slice(0,8)

      const r = await axios.get(
        'https://twittermedia.b-cdn.net/viewer/?data=' + username + '&type=profile',
        {
          headers:{
            'User-Agent':'Mozilla/5.0 (Linux; Android 10)',
            'Accept':'application/json',
            origin:'https://snaplytics.io',
            referer:'https://snaplytics.io/',
            'X-Challenge-ID':ch.challenge_id,
            'X-Challenge-Solution':hash
          }
        }
      )

      if(!r.data || !r.data.profile) throw new Error('no data')
      return r.data.profile

    }catch(e){
      return { status:'error', msg:e.message }
    }
  }

  try {
    console.log(chalk.blue("Consultando twitter stalker via scraper"))
    const resultGet = await twitterstalk(username)
    res.json({ status: true, criador: `${criador}`, resultado: resultGet })
  } catch (error) {
    res.json({status: 404, message: error.message})
  }
})


app.get('/api/stalker/discord', async (req, res) => {
  const userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
  const apikey = req.query.apikey
  const id = req.query.id

  // Validação de apikey
  if(!key.map(i => i.apikey)?.includes(apikey)) {
    return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
  }
  if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) {
    return res.json({message: "Apikey inválida ou requests esgotados!"})
  }
  if (!id) {
    return res.json({ status: false, message: "Coloque o parâmetro: id" })
  }

  RegisKey(req.query.apikey, userIp)
  const ITC = key.map(i => i?.apikey)?.indexOf(apikey)

  console.log(
    chalk.red(`ApiKey: ${apikey} • Limite: ${key[ITC]?.request}`),
    chalk.red('Request'),
    '• ' + chalk.red('Ping: ' + ping())
  )

  // Função embutida de scraping para Discord
  async function discordLookup(id){
    try{
      const r = await axios.get(`https://id.rappytv.com/${id}`, {
        headers:{
          'User-Agent':'Mozilla/5.0 (Linux; Android 10)'
        }
      })

      const $ = cheerio.load(r.data)

      return {
        id: $('span.resulth').first().text().trim() || id,
        global_name: $('strong:contains("Global Name")').parent().find('.resulth').text().trim() || null,
        display_name: $('strong:contains("Display Name")').parent().find('.resulth').text().trim() || null,
        avatar: $('.avyimg').attr('src') || null,
        created: $('strong:contains("Created")').parent().find('.resulth').text().trim() || null,
        banner_color: $('#color').attr('style')?.match(/background-color:\s*(#[0-9a-fA-F]+)/)?.[1] || null
      }

    }catch(e){
      return { status:'error', msg:e.message }
    }
  }

  try {
    console.log(chalk.blue("Consultando discord stalker via scraper"))
    const resultGet = await discordLookup(id)
    res.json({ status: true, criador: `${criador}`, resultado: resultGet })
  } catch (error) {
    res.json({status: 404, message: error.message})
  }
})





app.post('/api/ia/nanobanana', upload.single('image'), async (req, res) => {
  const userIp =
    req.ip ||
    req.headers['x-forwarded-for'] ||
    req.connection.remoteAddress;

  const apikey = req.query.apikey;
  const prompt = req.body.prompt || req.query.prompt;
  const imageUrl = req.body.url || req.query.url;

  // ===== APIKEY =====
  if (!key.map(i => i?.apikey).includes(apikey)) {
    return res.sendFile(
      path.join(__dirname, './public/', 'apikey_invalida.html')
    );
  }

  const ITC = key.map(i => i?.apikey).indexOf(apikey);

  if (key[ITC]?.request <= 0) {
    return res.json({
      status: false,
      message: 'Apikey inválida ou requests esgotados!'
    });
  }

  // ===== PROMPT =====
  if (!prompt) {
    return res.json({
      status: false,
      message: 'Cadê o parâmetro prompt?'
    });
  }

  let imageBuffer;

  try {
    // ===== IMAGEM VIA UPLOAD =====
    if (req.file) {
      imageBuffer = fs.readFileSync(req.file.path);
      fs.unlinkSync(req.file.path); // limpa upload
    }

    // ===== IMAGEM VIA URL =====
    else if (imageUrl) {
      const img = await axios.get(imageUrl, {
        responseType: 'arraybuffer',
        headers: {
          'user-agent':
            'Mozilla/5.0 (Linux; Android 15; SM-F958) AppleWebKit/537.36'
        }
      });
      imageBuffer = Buffer.from(img.data);
    }

    // ===== ERRO =====
    else {
      return res.json({
        status: false,
        message: 'Envie uma imagem por upload ou via URL'
      });
    }

    // ===== REGISTRO =====
    RegisKey(apikey, userIp);

    // ===== LOG =====
    console.log(
      color(
        ' ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`,
        'red'
      ),
      color('Request', 'red'),
      '• ' + color('Ping: ' + ping(), 'red')
    );

    console.log(chalk.blue('Consultando NanoBanana via scrapper...'));

    // ===== SCRAPPER =====
    const result = await nanobanana(prompt, imageBuffer);

    res.json({
      status: true,
      creator: 'Okarun Res APIs',
      model: 'nanobanana-scrape',
      result
    });

  } catch (error) {
    console.error(
      chalk.red('Erro ao consultar NanoBanana:'),
      error.message
    );

    res.status(500).json({
      status: false,
      erro: 'Erro ao consultar NanoBanana',
      detalhes: error.message
    });
  }
});

app.get('/api/bbb/reality', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await RealityBBB25()
res.json({ status: true, criador: `${criador}`, resultado: result })
} catch (error) {
console.error('Erro no scraper RealityBBB24:', error.message)
res.status(500).json({ success: false, error: error.message })
}
})

app.get('/api/bbb/bigdays', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await BigDaysBBB25()
res.json({ status: true, criador: `${criador}`, resultado: result })
} catch (error) {
console.error('Erro no scraper BigDaysBBB24:', error.message)
res.status(500).json({ success: false, error: error.message })
}
})

app.get('/api/bbb/foradacasa', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.body.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await ForaDaCasaBBB25()
res.json({ status: true, criador: `${criador}`, resultado: result })
} catch (error) {
console.error('Erro no scraper ForaDaCasaBBB24:', error.message)
res.status(500).json({ success: false, error: error.message })
}
})

app.post('/api/upload', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.body.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!req.files || !req.files.media) return res.status(400).json({ error: "Arquivo de mídia não encontrado." })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const mediaBuffer = req.files.media.data
const fileName = req.files.media.name || "file"
const fileUrl = await (async function (mediaBuffer, fileName) {
return new Promise(async (resolve, reject) => {
try {
console.log("Iniciando o processamento do media...")
if (Buffer.isBuffer(mediaBuffer)) {
console.log("Media recebido é um buffer. Preparando para upload...")
const mediaType = await fileType.fromBuffer(mediaBuffer)
if (!mediaType) return reject("Não foi possível determinar o tipo do arquivo.")
const { mime } = mediaType
let response
if (mime.startsWith('image/')) {
response = await bot.telegram.sendPhoto('6197020605', { source: mediaBuffer, filename: fileName })
} else if (mime.startsWith('video/')) {
response = await bot.telegram.sendVideo('6197020605', { source: mediaBuffer, filename: fileName })
} else if (mime.startsWith('audio/')) {
response = await bot.telegram.sendAudio('6197020605', { source: mediaBuffer, filename: fileName })
} else {
return reject("Tipo de mídia não suportado.")
}
let fileId
if (mime.startsWith('image/')) fileId = response.photo[response.photo.length - 1].file_id
else if (mime.startsWith('video/')) fileId = response.video.file_id
else if (mime.startsWith('audio/')) fileId = response.audio.file_id
if (fileId) {
const file = await bot.telegram.getFile(fileId)
const fileUrl = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`
resolve(fileUrl)
} else {
reject("Erro ao enviar a mídia. file_id não encontrado.")
}
} else {
reject("Formato do media não suportado. Envie um buffer.")
}
} catch (error) {
reject("Falha ao processar o media: " + error.message)
}
})
})(mediaBuffer, fileName)
res.json({ status: true, criador: `${criador}`, resultado: fileUrl })
console.log(chalk.green('[SUCESSO] Link de upload:'), fileUrl)
} catch (error) {
res.status(500).json({ success: false, error: error.message })
}
})

app.get("/api/ascii", async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status: false, message: "Coloque o parâmetro: query" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const asciiArt = await gerarAscii(query)
const resultadoFormatado = `\`\`\`\n${asciiArt}\n\`\`\``
res.json({ status: true, criador: `${criador}`, resultado: resultadoFormatado })
} catch (error) {
res.json({ error: "Erro ao gerar ASCII" })
}
})

app.get('/api/dl/aptoide', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status: false, message: "Coloque o parâmetro: query" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await buscarAptoide(query)
res.json({
criador: `${criador}`,
status: true,
resultado: {
nome: result.nome,
tamanho: result.tamanho,
desenvolvedor: result.desenvolvedor,
downloads: result.downloads,
link: result.link
}
})
} catch (error) {
res.status(500).json({ error: error.message })
}
})

app.get('/api/dados/episodio/download-ep', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status: false, message: "Coloque o parâmetro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const data = await GetDownloadEp(url)
res.json({ status: true, criador: `${criador}`, resultado: data })
} catch (error) {
res.status(500).json({ error: error.message })
}
})

app.get('/api/detalhes/episodio/episode', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status: false, message: "Coloque o parâmetro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const data = await GetEp(url)
res.json({ status: true, criador: `${criador}`, resultado: data })
} catch (error) {
res.status(500).json({ error: error.message })
}
})

app.get('/api/search/anime', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status: false, message: "Coloque o parâmetro: query" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const results = await SearchAnimeCC(query)
res.json({ status: true, criador: `${criador}`, resultado: results })
} catch (error) {
res.status(500).json({ error: error.message })
}
})

app.get('/api/anime/baixar-video', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status: false, message: "Coloque o parâmetro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const response = await axios({
method: 'GET',
url: `https://zero-two-animes.0.obrh.uno/scrape?url=${encodeURIComponent(url)}`,
responseType: 'stream'
})
res.setHeader('Content-Type', 'video/mp4')
if (response.headers['content-length']) {
res.setHeader('Content-Length', response.headers['content-length'])
}
pipeline(response.data, res, (err) => {
if (err) {
console.error('Falha na transmissão do pipeline:', err)
res.status(500).end()
}
})
} catch (error) {
console.error("Erro ao baixar e enviar vídeo:", error)
res.status(500).json({ error: error.message })
}
})

app.get('/api/anime/search', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
query = req.query.query
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!query) return res.json({ status: false, message: "Coloque o parâmetro: query" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const results = await searchAnime(query)
res.json({ status: true, criador: `${criador}`, resultado: results })
} catch (error) {
res.status(500).json({ error: 'Erro ao buscar animes' })
}
})

app.get('/api/getdetalhes/anime', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status: false, message: "Coloque o parâmetro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const animeData = await getAnime(url)
res.json({ status: true, criador: `${criador}`, resultado: animeData })
} catch (error) {
res.status(500).json({ error: 'Erro ao buscar detalhes do anime' })
}
})

app.get('/api/anime/download', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status: false, message: "Coloque o parâmetro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const tempFilePath = await downloadVideoAnime(url)
console.log('Enviando arquivo:', tempFilePath)
res.sendFile(tempFilePath, { 
headers: { 
'Content-Type': 'video/mp4',
'Content-Disposition': 'attachment; filename="anime.mp4"',
}
}, (err) => {
if (err) {
console.error('Erro ao enviar arquivo:', err)
return res.status(500).send('Erro ao enviar o arquivo de vídeo.')
}
console.log('Arquivo enviado com sucesso!')
fs.unlink(tempFilePath, (unlinkErr) => {
if (unlinkErr) console.error('Erro ao remover arquivo temporário:', unlinkErr)
else console.log('Arquivo temporário removido:', tempFilePath)
})
})
} catch (error) {
console.error('Erro ao processar o vídeo:', error)
res.status(500).send(`Erro ao processar o vídeo: ${error.message}`)
}
})

app.get('/api/encurtar/shorten', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status: false, message: "Coloque o parâmetro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const shortUrl = await shortenWithYandex(url)
res.json({ 
status: true, 
criador: `${criador}`, 
resultado: {
original: url,
short: shortUrl
}
})
} catch (error) {
res.status(500).json({ error: 'Erro ao encurtar link' })
}
})

app.get('/api/encurtar', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
const { apikey, url, alias, format } = req.query
if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' })
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status: false, message: "Coloque o parâmetro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const shortUrl = await shortenUrl(url, {
alias: alias || 'zero-two-apis.com.br',
// type: type ? parseInt(type) : null,
type: 1,
format: format || 'json'
})
if (format === 'text') {
res.type('text').send(shortUrl)
} else {
res.json({ 
status: true, 
criador: `${criador}`, 
resultado: {
original: url,
short: shortUrl
}
})
}
} catch (error) {
res.status(500).json({ error: error.message })
}
})

// ===== ROTAS TINDER ===== \\
app.get('/api/tinder/register', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
sender = req.query.sender
nome = req.query.nome
idade = req.query.idade
bio = req.query.bio
genero = req.query.genero
preferences = req.query.preferences
foto = req.query.foto
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!sender) return res.json({ status: false, message: "Coloque o parâmetro: sender" })
if (!nome) return res.json({ status: false, message: "Coloque o parâmetro: nome" })
if (!idade) return res.json({ status: false, message: "Coloque o parâmetro: idade" })
if (!bio) return res.json({ status: false, message: "Coloque o parâmetro: bio" })
if (!genero) return res.json({ status: false, message: "Coloque o parâmetro: genero" })
if (!preferences) return res.json({ status: false, message: "Coloque o parâmetro: preferences" })
if (!foto) return res.json({ status: false, message: "Coloque o parâmetro: foto" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(`Registrando usuário: ${nome} (${sender})`)
const usuario = TinderSystem.registerUser(sender, nome, idade, bio, genero, preferences, foto)
return res.json({ status: true, criador: `${criador}`, resultado: { usuario } })
} catch (error) {
console.error('Erro no registro de usuário:', error)
return res.status(500).send(`Erro no registro de usuário: ${error.message}`)
}
})

app.get('/api/tinder/like', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
sender = req.query.sender
targetId = req.query.targetId
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!sender) return res.json({ status: false, message: "Coloque o parâmetro: sender" })
if (!targetId) return res.json({ status: false, message: "Coloque o parâmetro: targetId" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(`Enviando like de ${sender} para o perfil ${targetId}`)
await TinderSystem.likeTinder(sender, targetId)
return res.json({ status: true, criador: `${criador}`, resultado: { mensagem: "Like enviado com sucesso!" } })
} catch (error) {
console.error('Erro ao enviar like:', error)
return res.status(500).send(`Erro ao enviar like: ${error.message}`)
}
})

app.get('/api/tinder/deslike', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
sender = req.query.sender
targetId = req.query.targetId
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!sender) return res.json({ status: false, message: "Coloque o parâmetro: sender" })
if (!targetId) return res.json({ status: false, message: "Coloque o parâmetro: targetId" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(`Enviando deslike de ${sender} para o perfil ${targetId}`)
await TinderSystem.deslikeTinder(sender, targetId)
return res.json({ status: true, criador: `${criador}`, resultado: { mensagem: "Deslike enviado com sucesso!" } })
} catch (error) {
console.error('Erro ao enviar deslike:', error)
return res.status(500).send(`Erro ao enviar deslike: ${error.message}`)
}
})

app.get('/api/tinder/search', (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
name = req.query.name
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!name) return res.json({ status: false, message: "Coloque o parâmetro: name" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(`Buscando usuário(s) com o nome: ${name}`)
const tinderData = TinderSystem.loadTinderData()
const resultados = [];
Object.entries(tinderData.TinderData.Users).forEach(([id, perfil]) => {
if (perfil.name.toLowerCase().includes(name.toLowerCase())) {
resultados.push({ name: perfil.name, registrationId: perfil.registrationInfo.registrationId })
}
})
if (resultados.length === 0) {
return res.json({ mensagem: "Nenhum usuário encontrado com esse nome!" })
}
return res.json({ status: true, criador: `${criador}`, resultados })
} catch (error) {
console.error('Erro ao buscar usuários:', error)
return res.status(500).send(`Erro ao buscar usuários: ${error.message}`)
}
})

app.get('/api/tinder/uploadFoto', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
sender = req.query.sender
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!sender) return res.json({ status: false, message: "Coloque o parâmetro: sender" })
if (!url) return res.json({ status: false, message: "Coloque o parâmetro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log(`Atualizando foto do usuário ${sender} com a URL: ${url}`)
const resultado = await TinderSystem.uploadFoto(sender, url)
return res.json({ status: true, criador: `${criador}`, resultado: { resultado } })
} catch (error) {
console.error('Erro ao atualizar a foto:', error)
return res.status(500).send(`Erro ao atualizar a foto: ${error.message}`)
}
})

app.get('/api/tinder/delete', (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
sender = req.query.sender
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!sender) return res.json({ status: false, message: "Coloque o parâmetro: sender" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const userId = sender.includes('@') ? sender.split('@')[0] : sender
console.log(`Deletando usuário: ${userId}`)
const resultado = TinderSystem.deleteUser(userId)
return res.json({ status: true, criador: `${criador}`, resultado })
} catch (error) {
console.error('Erro ao deletar usuário:', error)
return res.status(500).send(`Erro ao deletar usuário: ${error.message}`)
}
})

app.get('/api/tinder/ranking', (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
console.log("Obtendo ranking global...")
const ranking = TinderSystem.updateGlobalRanking()
return res.json({ status: true, criador: `${criador}`, resultado: { ranking } })
} catch (error) {
console.error('Erro ao obter rank:', error)
return res.status(500).send(`Erro ao obter rank: ${error.message}`)
}
})

app.get('/api/tinder/suggestions', (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
sender = req.query.sender
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!sender) return res.json({ status: false, message: "Coloque o parâmetro: sender" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const userId = sender.includes('@') ? sender.split('@')[0] : sender
console.log(`Obtendo sugestões inteligentes para o usuário: ${userId}`)
const suggestions = TinderSystem.generateSmartSuggestions(userId)
return res.json({ status: true, criador: `${criador}`, resultado: { suggestions } })
} catch (error) {
console.error('Erro ao obter sugestões:', error)
return res.status(500).send(`Erro ao obter sugestões: ${error.message}`)
}
})






// Rota de exemplo usando Google-Ia
app.get('/api/ia/search', async (req, res) => {
  const userIp = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress
  const { apikey, query } = req.query

  if (!apikey) return res.json({ status: false, message: '- Cadê o parâmetro apikey?' })

  const keyIndex = key.map(i => i.apikey).indexOf(apikey)
  if (!key.map(i => i.apikey).includes(apikey)) {
    return res.sendFile(path.join(__dirname, 'public', 'apikey_invalida.html'))
  }

  if (key[keyIndex].request <= 0) {
    return res.json({ status: false, message: 'Apikey inválida ou requests esgotados!' })
  }

  if (!query) return res.json({ status: false, message: 'Cade o parametro query?' })

  RegisKey(apikey, userIp)

  console.log(`ApiKey: ${apikey} • Limite: ${key[keyIndex].request} • IP: ${userIp}`)

  try {
    const result = await GoogleIa.search(query)

    if (result) {
      res.json({
        status: true,
        resultado: {
          query,
          resposta: result
        }
      })
    } else {
      res.status(500).json({
        status: false,
        error: 'Nenhum resultado encontrado'
      })
    }
  } catch (error) {
    res.status(500).json({
      status: false,
      error: 'Erro interno do servidor: ' + error.message
    })
  }
})



app.get('/api/ia/deepimage', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
prompt = req.query.prompt
style = req.query.style || 'realistic'
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!prompt) return res.json({ status: false, message: "Coloque o parâmetro: prompt" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const deviceId = `dev-${Math.floor(Math.random() * 1000000)}`
const apiResponse = await axios.post('https://api-preview.chatgot.io/api/v1/deepimg/flux-1-dev', {
prompt: `${prompt} -style ${style.toLowerCase()}`,
size: "1024x1024",
device_id: deviceId
}, {
headers: {
'Content-Type': 'application/json',
'Origin': 'https://deepimg.ai',
'Referer': 'https://deepimg.ai/',
}
});
const imageUrl = apiResponse.data?.data?.images?.[0]?.url
if (!imageUrl) {
return res.status(500).send('Erro ao gerar imagem')
}
const imageResponse = await axios.get(imageUrl, {
responseType: 'arraybuffer'
});
res.set({'Content-Type': imageResponse.headers['content-type'],
'Content-Length': imageResponse.headers['content-length'],
'Cache-Control': 'public, max-age=86400'
})
res.send(imageResponse.data)
} catch (err) {
console.error('Erro no processamento:', err.message)
}
})


app.get('/api/telegram-stickers', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status: false, message: "Coloque o parâmetro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const result = await getTelegramStickerPack(url)
res.json({
status: true,
criador: `${criador}`,
resultados: {
nome: result.name,
título: result.title,
contagem_de_adesivos: result.sticker_count,
criado_em: result.created_at
},
catbox_links: result.catbox_urls.map(sticker => ({
url: sticker.catbox_url,
emoji: sticker.emoji,
animado: sticker.is_animated,
index: sticker.index
})),
contagem_de_falhas: result.failed_stickers.length,
avisos: result.failed_stickers
})
} catch (error) {
res.status(500).json({ success: false, error: 'Erro no processamento', details: error.message })
}
})

app.get('/api/download-sticker', async (req, res) => {
userIp = req.ip || req.headers["x-forwarded-for"] || req.connection.remoteAddress
apikey = req.query.apikey
url = req.query.url
index = parseInt(req.query.index) || 0
if(!key.map(i => i.apikey)?.includes(apikey)) return res.sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"))
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.json({message: "Apikey inválida ou requests esgotados!"})
if (!url) return res.json({ status: false, message: "Coloque o parâmetro: url" })
RegisKey(req.query.apikey, userIp)
var ITC = key.map(i => i?.apikey)?.indexOf(apikey)
console.log(color('ApiKey:' + ` ${apikey} • Limite: ${key[ITC]?.request}\n`, 'red'), color('', 'red'), color('Request', 'red'), '• ' + color('Ping: ' + ping(), 'red'))
try {
const pack = await getTelegramStickerPack(url)
if (index < 0 || index >= pack.stickers.length) {
return res.status(400).json({ error: 'Índice de sticker inválido' })
}
const sticker = pack.stickers[index]
const filename = `${pack.name}_${index}.${sticker.is_animated ? 'tgs' : 'webp'}`
res.set({
'Content-Type': sticker.is_animated ? 'application/x-tgsticker' : 'image/webp',
'Content-Disposition': `attachment; filename="${filename}"`
})
res.send(sticker.buffer)
} catch (error) {
res.status(500).json({ error: 'Erro no processamento', details: error.message })
}
})

// --- ROTA DE VERIFICAÇÃO DE API KEY ---
app.get('/check', async (req, res) => {
const { apikey } = req.query
const userIp = req.ip
if (!apikey) {
console.log(color('[CHECK-FAIL]', 'yellow'), `Requisição sem API key do IP: ${userIp}`)
return res.status(400).json({ status: false, message: 'Parâmetro "apikey" ausente na requisição.'})
}
try {
const keyEntry = await Apikey.findOne({ apikey }).lean();
if (!keyEntry) {
console.log(color('[CHECK-INVALID]', 'red'), `API key inválida "${apikey}" tentou acesso do IP: ${userIp}`)
// Para segurança, você pode enviar uma resposta genérica ou um arquivo HTML
// return res.status(401).sendFile(path.join(__dirname, "./public/", "apikey_invalida.html"));
return res.status(401).json({ status: false, message: 'API key inválida ou não encontrada.'})
}
console.log(color(`[CHECK-OK]`, 'green'), color(`Key: ${apikey} • `, 'cyan') +color(`Requests: ${keyEntry.request || 0} • `, 'yellow') + color(`IP: ${userIp}`, 'magenta'));
return res.status(200).json({
status: true,
message: 'Key ativa e verificada com sucesso.',
data: {
requests_disponiveis: keyEntry.request || 0,
consultas: {
ativa: (keyEntry.consulta || 0) > 0,
quantidade: keyEntry.consulta || 0
},
developer: '@paulo_mod_domina'
}
})
} catch (err) {
console.error(color('[DB-ERROR]', 'red'), 'Falha ao consultar o banco de dados na rota /check:', err)
return res.status(500).json({ status: false, message: 'Erro interno no servidor. Não foi possível verificar a key.'})
}
})

app.use((req, res, next) => {
    const notFoundPage = path.join(__dirname, 'public', '404.html');
    res.status(404).sendFile(notFoundPage, (err) => {
        if (err) {
            res.status(404).send("Página não encontrada");
        }
    });
});
// ============== FIM DAS ROTAS ================ \\

// 🔥 Atualiza lista negra a cada 15 segundos
setInterval(() => {
fs.writeFileSync(BLACKLIST_FILE, [...blockedIPs].join('\n'))
}, 15 * 1000)
// 2. Função para Log de Rotas Registradas (Executar no final)
function logRegisteredRoutes(stack, prefix = '') {
const methodColors = {
get: chalk.green,
post: chalk.blue,
put: chalk.yellow,
delete: chalk.red,
patch: chalk.cyan,
head: chalk.magenta,
options: chalk.white
};
stack.forEach(layer => {
if (layer.route) {
// Rota direta (app.get, app.post, etc)
const methods = Object.keys(layer.route.methods).map(m => m.toUpperCase())
methods.forEach(method => {
 path = prefix + layer.route.path
const coloredMethod = methodColors[method.toLowerCase()]?.(method.padEnd(6)) || method
console.log(chalk.gray('[Route]'), coloredMethod, chalk.white(path))
})
} else if (layer.name === 'router' && layer.handle.stack) {
// Rotas em routers montados (ex: app.use('/admin', router))
const routerPrefix = prefix + (layer.regexp.source === '^\\/?(?=\\/|$)' ? '' : layer.regexp.source
.replace('^\\', '')
.replace('(?=\\/|$)', '')
.replace(/\\/g, '')
.replace(/^\^/g, '')
.replace(/\$$/g, '')
.replace(/\/i.*/, ''));
logRegisteredRoutes(layer.handle.stack, routerPrefix)
}
})
}

// 3. Execute após todas as rotas serem registradas (antes do app.listen)
setTimeout(() => {
console.log(chalk.yellow('\nRotas registradas:'));
logRegisteredRoutes(app._router.stack)
}, 0)

// ======================================================== \\

const dbDir = path.join(__dirname, 'database')
const scheduleFile = path.join(dbDir, 'lastExecution.json')
const intervalTime = 300000
if (!fs.existsSync(dbDir)) {
fs.mkdirSync(dbDir, { recursive: true })
}
function cleanTmp() {
exec('rm -rf /tmp/*', (error) => {
if (error) {
console.error('Erro na limpeza:', error)
} else {
console.log('Limpeza completa do diretório temporário realizada.')
}
})
const now = Date.now()
fs.writeFile(scheduleFile, JSON.stringify({ lastExecution: now }), (err) => {
if (err) {
console.error('Erro ao atualizar o registro de execução:', err)
}
})
}
fs.readFile(scheduleFile, 'utf8', (err, data) => {
if (!err && data) {
try {
const { lastExecution } = JSON.parse(data)
const now = Date.now()
if (now - lastExecution > intervalTime) {
cleanTmp()
}
} catch (e) {
console.error('Erro ao ler o arquivo de agendamento:', e)
cleanTmp()
}
} else {
cleanTmp()
}
})

setInterval(cleanTmp, intervalTime)
/*
////// MOSTRA SE O APP FOI ABERTO
app.listen(PORT, '0.0.0.0', () => {
const bannerst = cfonts.render(`ZERO TWO API`, {
font: 'block',
align: 'center',
gradient: ['yellow', 'red'],
});

const bannerst2 = cfonts.render(`CANAL YT: @Otaku.mp4 | INSTA: @paulo_mod_domina | WHATS: +55 94 99156-9380`, {
font: 'console',
align: 'center',
gradient: ['cyan', 'blue'],
});

console.log(bannerst.string);
console.log(bannerst2.string);
console.log(colors.cyan('REST-API LIGADA COM SUCESSO NA PORTA: ') + PORT, '\n\n🔥 API rodando e protegida a cada 15s!');
});
*/
app.listen(PORT, () => {

const bannerst = cfonts.render((`OKARUN API`), {
font: 'block',
align: "center",
gradient: ['yellow', 'red']
})

const bannerst2 = cfonts.render((`CANAL YT: @Otaku.mp4 | INSTA: @paulo_mod_domina | WHATS: +55 97 7400-4582 `), {
font: 'console',
align: 'center',
gradient: ['cyan', 'blue']
})

console.log(bannerst.string)
console.log(bannerst2.string)
successLog(colors.cyan('REST-API LIGADA COM SUCESSO NA PORTA: ') + PORT)
})



let okarun = require.resolve(__filename)
fs.watchFile(okarun, () => {
fs.unwatchFile(okarun)
infoLog(`ATUALIZANDO OKARUN.JS DA API`)
process.exit()
})


module.exports = router;