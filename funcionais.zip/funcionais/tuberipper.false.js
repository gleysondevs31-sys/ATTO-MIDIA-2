const axios = require("axios");
const https = require("node:https");
const fake = require("fake-useragent");
const formData = require("form-data");
const cheerio = require("cheerio");

class TubeRipper {
    constructor() {
        this.BASE = "https://tuberipper.com/32/";
        this.ENTRY = "https://tuberipper.com/entry";
        this.REG = /<input\s?id\=["']videoToken['"]\s?type\=['"]hidden["']\s?name\=['"]token['"]\s?value\=['"](\w+)['"]>/i;
        this.agent = new https.Agent({ keepAlive: true, rejectUnauthorized: false });
        this.headersList = {
            "authority": "tuberipper.com",
            "accept": "*/*",
            "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7,ru;q=0.6",
            "cache-control": "no-cache",
            "pragma": "no-cache",
            "priority": "u=1, i",
            "referer": "https://tuberipper.com/32/",
            "sec-ch-ua": '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "user-agent": fake()
        };
        this.headersListValid = {
            "accept": "*/*",
            "accept-encoding": "gzip, deflate, br, zstd",
            "accept-language": "id-ID,id;q=0.9",
            "cache-control": "no-cache",
            "content-length": "414",
            "content-type": "application/x-www-form-urlencoded",
            "origin": "https://tuberipper.com",
            "pragma": "no-cache",
            "priority": "u=1, i",
            "referer": "https://tuberipper.com/",
            "sec-ch-ua": '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site",
            "user-agent": fake()
        };
        this.vidToken = null;

        global.document = { innerHTML: () => {}, currentScript: { remove: () => {} } };
        global.atob = (str) => Buffer.from(str, 'base64').toString('utf-8');
        global.btoa = (str) => Buffer.from(str, 'utf-8').toString('base64');
    }

    _delay(msec) {
        return new Promise(resolve => setTimeout(resolve, msec));
    }

    _req({ url, method = "GET", data = null, params = null, head = null, response = "json" }) {
        return new Promise((resolve, reject) => {
            let headers = {};
            let param;
            let datas;

            if (head && (head === "original" || head === "ori")) {
                const uri = new URL(url);
                headers = {
                    authority: uri.hostname,
                    origin: "https://" + uri.hostname,
                    'Cache-Control': 'no-cache',
                    "user-agent": fake()
                };
            } else if (head && typeof head === "object") {
                headers = head;
            }
            if (params && typeof params === "object") {
                param = params;
            } else {
                param = "";
            }
            if (data) {
                datas = data;
            } else {
                datas = "";
            }

            const options = {
                url: url,
                method: method,
                headers,
                timeout: 30000,
                responseType: response,
                httpsAgent: this.agent,
                withCredentials: true,
                validateStatus: (status) => status <= 500,
                ...(!datas ? {} : { data: datas }),
                ...(!params ? {} : { params: param })
            };

            axios.request(options)
                .then(res => {
                    if (res.headers["set-cookie"]) {
                        res.headers["set-cookie"].forEach(v => {
                            head["cookie"] = v.split(";")[0];
                        });
                    }
                    resolve(res);
                })
                .catch(error => {
                    console.log(error);
                    reject(error);
                });
        });
    }

    _init() {
        return this._req({
            url: this.BASE,
            method: "GET",
            head: this.headersList,
            response: "text"
        })
            .then(res => {
                const ress = res.data.match(this.REG);
                if (ress) {
                    this.vidToken = ress[1];
                }
            })
            .catch(error => {
                console.log("Erro ao inicializar:", error);
                throw error;
            });
    }

    _send(url) {
        return this._init()
            .then(() => {
                const form = new formData();
                form.append("url", url);
                form.append("token", this.vidToken);

                return this._req({
                    url: this.ENTRY,
                    method: "POST",
                    data: form,
                    head: {
                        ...this.headersList,
                        ...form.getHeaders()
                    }
                });
            })
            .then(res => res.data)
            .catch(error => {
                console.log("Erro ao enviar requisição:", error);
                throw error;
            });
    }

    _generateSignature(payload) {
        return new Promise((resolve, reject) => {
            const __tr_app_cb = (data) => {
                resolve(data);
            };

            const dec = Buffer.from(payload, "base64").toString("utf-8");
            const repl = dec.replace("{callback}", "__tr_app_cb").replace(/window/g, "global");
            eval(repl);
        });
    }

    _info(payload, redirect) {
        const params = new URLSearchParams();
        params.set("payload", payload);

        return this._req({
            url: redirect,
            method: "POST",
            data: params,
            head: this.headersListValid
        })
            .then(res => res.data)
            .catch(error => {
                console.log("Erro ao obter informações:", error);
                throw error;
            });
    }

    _parse(html) {
        return new Promise((resolve, reject) => {
            const audio = {}, video = {}, muted_video = {};
            let i1 = 1, i2 = 1, i3 = 1;

            const $ = cheerio.load(html);
            const title = $(".col-lg-12 h2.text-center").text().trim();
            const thumbnail = $("a.list-image.list-image-playable img").attr("src").trim();
            const duration = $("a.list-image.list-image-playable div.duration").text().trim();

            // audio
            const down = $(".btn-group.btn-group-lg.btn-group-download").eq(0);
            const ul = $(down).find(".dropdown-menu");

            $(ul).find("li a").each((_, e) => {
                let tit = $(e).attr("data-format").trim();

                if (Object.keys(audio).includes(tit)) {
                    tit = tit + "_" + i1++;
                }

                audio[tit] = {
                    url: $(e).attr("href").trim(),
                    description: $(e).text().trim().split($(e).attr("data-format").trim())[1].trim().replaceAll("\n", "").replaceAll("", " ").replace(/[\(\)]/gi, "")
                };
            });

            // video
            const downv = $(".btn-group.btn-group-lg.btn-group-download").eq(1);
            const ulv = $(downv).find(".dropdown-menu");

            $(ulv).find("li a").each((_, e) => {
                let tit = $(e).attr("data-format").trim();

                if (Object.keys(video).includes(tit)) {
                    tit = tit + "_" + i2++;
                }

                video[tit] = {
                    url: $(e).attr("href").trim(),
                    description: $(e).text().trim().split($(e).attr("data-format").trim())[1].trim().replaceAll("\n", "").replaceAll("", " ").replace(/[\(\)]/gi, "")
                };
            });

            // muted video
            const downvm = $(".btn-group.btn-group-lg.btn-group-download").eq(2);
            const ulvm = $(downvm).find(".dropdown-menu");

            $(ulvm).find("li a").each((_, e) => {
                let tit = $(e).attr("data-format").trim();

                if (Object.keys(muted_video).includes(tit)) {
                    tit = tit + "_" + i3++;
                }

                muted_video[tit] = {
                    url: $(e).attr("href").trim(),
                    description: $(e).text().trim().split($(e).attr("data-format").trim())[1].trim().replaceAll("\n", "").replaceAll("", " ").replace(/[\(\)]/gi, "")
                };
            });

            resolve({
                title,
                thumbnail,
                duration,
                audio,
                video,
                muted_video
            });
        });
    }

    download(url) {
        return this._send(url).then(response => {
            return this._generateSignature(response.message.payload).then(sign => ({ sign, response }));
        }).then(({ sign, response }) => {
            return this._info(sign, response.message.url)
        }).then(info => this._parse(info.message)).catch(error => {
            console.log("Erro ao baixar informações do vídeo:", error);
            throw error;
        });
    }
}

module.exports = TubeRipper;