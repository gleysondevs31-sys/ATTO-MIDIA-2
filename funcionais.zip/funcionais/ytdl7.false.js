const fs = require('fs')
const path = require('path')
const ytdl = require('@distube/ytdl-core')
//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B
const COOKIES_FILE = path.join(__dirname, 'cookies.json')

// Função para carregar cookies no formato correto
function loadCookies() {
try {
const cookiesData = JSON.parse(fs.readFileSync(COOKIES_FILE, 'utf8'))
const cookiesObject = {}
cookiesData.forEach(cookie => {
if (cookie.name && cookie.value) {
cookiesObject[cookie.name] = cookie.value
}
})
return cookiesObject
} catch (error) {
console.error('Erro ao carregar os cookies:', error.message)
return {}
}
}

async function downloadYouTube(url, type = 'video') {
try {
console.log(`\n🔄 Iniciando download do ${type}...`)
const options = {
requestOptions: {
headers: {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
'Accept': '*/*',
'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'Origin': 'https://www.youtube.com',
'Referer': 'https://www.youtube.com/',
},
cookies: loadCookies(),
withCredentials: true
},
quality: type === 'audio' ? 'highestaudio' : 'highestvideo',
filter: type === 'audio' ? 'audioonly' : 'videoandaudio'
}
let buffer = Buffer.alloc(0)
let downloaded = 0
const stream = ytdl(url, options)
stream.on('progress', (_, downloadedBytes, totalBytes) => {
downloaded = downloadedBytes
const percent = ((downloaded / totalBytes) * 100).toFixed(2)
process.stdout.clearLine(0)
process.stdout.cursorTo(0)
process.stdout.write(`📥 Progresso: ${percent}% (${(downloaded / 1024 / 1024).toFixed(2)} MB)`)
})
return new Promise((resolve, reject) => {
stream.on('data', chunk => {
buffer = Buffer.concat([buffer, chunk])
})
stream.on('end', () => {
console.log(`\n✅ Download concluído (${(buffer.length / 1024 / 1024).toFixed(2)} MB)`)
resolve(buffer)
})
stream.on('error', err => {
console.error('❌ Erro no download:', err.message)
reject(err)
})
})
} catch (error) {
console.error('❌ Erro geral:', error.message)
throw error
}
}

module.exports = { downloadYouTube }