//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

/**
 * Free Fire Bio Scraper
 * 
 * Este script extrai bios coloridas do Free Fire do site freefiremania.com.br
 * Inclui códigos de cores e formatações especiais.
 * 
 * Exemplo de uso:
 * const scraper = new FreeFireBioScraper();
 * 
 * // Buscar 10 bios
 * scraper.getBios(10).then(result => {
 * console.log(result);
 * });
 * 
 * // Buscar por termo
 * scraper.searchBios('pro').then(result => {
 * console.log(result);
 * });
 */

const axios = require('axios')
const cheerio = require('cheerio')
const { promisify } = require('util')
const sleep = promisify(setTimeout);

class FreeFireBioScraper {
constructor() {
this.baseUrl = 'https://www.freefiremania.com.br';
this.bios = [];
this.offset = 0;
this.limit = 30;
this.creator = '@paulo_mod_domina';
}

async fetchBios(limit = 30) {
try {
console.log('🔍 Buscando bios do Free Fire...\n');
const response = await axios.get(`${this.baseUrl}/bio-free-fire-colorida-copiar.html`, {
headers: {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
},
responseType: 'text',
responseEncoding: 'utf8',
timeout: 10000
});
this.parseBios(response.data);
while (this.bios.length < limit) {
console.log(`🔍 Carregando mais bios... (${this.bios.length}/${limit})`);
const loaded = await this.loadMoreBios();
if (!loaded) break;
await sleep(1000);
}
return this.bios.slice(0, limit);
} catch (error) {
console.error('❌ Erro ao buscar bios:', error.message);
return this.bios.slice(0, limit);
}
}
parseBios(html) {
const $ = cheerio.load(html);
$('.bio-item').each((i, el) => {
const $el = $(el);
const $content = $el.find('.bio-content');
const originalBio = $content.attr('data-original-bio') || $content.text().trim();
if (originalBio) {
this.bios.push({
id: this.bios.length + 1,
content: originalBio,
formatted: $content.html()
});
}
});
}

async loadMoreBios() {
try {
const response = await axios.post(
`${this.baseUrl}/paginas/load_bios.php`,
`offset=${this.offset}&limit=${this.limit}`,
{
headers: {
'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
'X-Requested-With': 'XMLHttpRequest',
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
'Referer': `${this.baseUrl}/bio-free-fire-colorida-copiar.html`,
'Origin': this.baseUrl
},
responseType: 'text',
responseEncoding: 'utf8',
timeout: 10000
}
);
if (response.data) {
const prevLength = this.bios.length;
this.parseBios(response.data);
this.offset += this.limit;
return this.bios.length > prevLength;
}
return false;
} catch (error) {
console.error('❌ Erro ao carregar mais bios:', error.message);
return false;
}
}

/**
 * Formata a resposta
 * @param {Array} bios - Array de bios para formatar
 * @returns {Object} - Resposta formatada
 */
formatResponse(bios) {
return {
status: true,
criador: this.creator,
resultados: bios.map(bio => ({
id: bio.id,
bio: bio.content
}))
};
}

/**
 * Busca bios do Free Fire
 * @param {number} limit - Número máximo de bios a serem retornadas
 * @returns {Promise<Object>} - Promessa com as bios no formato {status, criador, resultados}
 */
async getBios(limit = 30) {
try {
await this.fetchBios(limit);
return this.formatResponse(this.bios.slice(0, limit));
} catch (error) {
return {
status: false,
criador: this.creator,
erro: 'Erro ao buscar bios: ' + error.message
};
}
}

/**
 * Busca bios que contenham o termo especificado
 * @param {string} term - Termo para busca
 * @param {number} limit - Número máximo de resultados
 * @returns {Promise<Object>} - Promessa com os resultados da busca
 */
async searchBios(term, limit = 30) {
try {
await this.fetchBios(limit);
const searchTerm = term.toLowerCase();
const results = this.bios.filter(bio => 
bio.content.toLowerCase().includes(searchTerm)
).slice(0, limit);
return this.formatResponse(results);
} catch (error) {
return {
status: false,
criador: this.creator,
erro: 'Erro na busca: ' + error.message
};
}
}
/**
 * Limpa o cache de bios
 */
clearCache() {
this.bios = [];
this.offset = 0;
}
}

// Exemplo de uso:
async function exemploUso() {
const scraper = new FreeFireBioScraper();

// Buscar 10 bios
const resultado = await scraper.getBios(10);
console.log(JSON.stringify(resultado, null, 2));
}

// Descomente para testar
// exemploUso().catch(console.error);

module.exports = FreeFireBioScraper