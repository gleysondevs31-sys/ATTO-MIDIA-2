//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

/*
Exemplo de uso:

const AccountDateChecker = require('./account-date-checker');
const checker = new AccountDateChecker();

checker.checkAccountDate('ID_DO_JOGADOR')
.then(result => console.log(result))
.catch(error => console.error(error));

*/

const axios = require('axios')
const FormData = require('form-data')
const readline = require('readline')

class AccountDateChecker {
constructor() {
this.apiUrl = 'https://freefirejornal.com/freefire/datacriacao/checknovo2025.php';
this.profileBaseUrl = 'https://freefirejornal.com/perfil-jogador-freefire';
this.rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});
}

async checkAccountDate(playerId) {
try {
const formData = new FormData();
formData.append('idjogador', playerId);
formData.append('lang', 'pt-br');
const response = await axios.post(this.apiUrl, formData, {
headers: {
...formData.getHeaders(),
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
'Referer': 'https://freefirejornal.com/free-fire-descubra-a-data-de-criacao-da-sua-conta-via-id/',
'Origin': 'https://freefirejornal.com',
'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'
}
});
if (response.data) {
const result = typeof response.data === 'string' ? JSON.parse(response.data) : response.data;
return {
success: true,
data: result,
profileUrl: `${this.profileBaseUrl}/${playerId}/`
};
}
return { success: false, error: 'Resposta vazia da API' };
} catch (error) {
console.error('Erro ao verificar a conta:', error.message);
return { 
success: false, 
error: error.response?.data?.message || error.message 
};
}
}

formatResult(result, playerId) {
if (!result.success || !result.data) {
return {
status: false,
criador: '@paulo_mod_domina',
erro: 'Não foi possível obter os dados da conta.'
};
}
const { data } = result;
const accountInfo = data.datadaconta;
const playerNameMatch = accountInfo.match(/A lenda ([^\n]+) da conta/);
const creationDateMatch = accountInfo.match(/foi criada exatamente no dia ([^\n]+)\./);
const rarityMatch = accountInfo.match(/raridade de (\d+\.?\d*)\%\./);
const accountAgeMatch = accountInfo.match(/A conta (é [^!]+!)/) || 
accountInfo.match(/(A conta [^!]+!)/);
const formattedResult = {
status: true,
criador: '@paulo_mod_domina',
resultados: {
id: playerId,
nome: playerNameMatch ? playerNameMatch[1].trim() : 'Não informado',
data_criacao: creationDateMatch ? creationDateMatch[1].trim() : 'Não informado',
raridade: rarityMatch ? `${rarityMatch[1]}%` : 'Não informado',
status_conta: accountAgeMatch ? accountAgeMatch[1].trim() : 'Status não disponível'
}
};
return formattedResult;
}

async startCLI() {
console.log('=== Verificador de Data de Criação de Conta Free Fire ===\n');
const askPlayerId = () => {
this.rl.question('🔢 Digite o ID do jogador (ou "sair" para sair): ', async (input) => {
if (input.toLowerCase() === 'sair') {
console.log('\nObrigado por usar o verificador de data de criação!');
this.rl.close();
return;
}
const playerId = input.trim();
if (!playerId || isNaN(playerId)) {
console.log('❌ Por favor, insira um ID de jogador válido.\n');
return askPlayerId();
}
console.log('\n🔍 Verificando dados da conta...\n');
const result = await this.checkAccountDate(playerId);
if (result.success) {
const formattedResult = this.formatResult(result, playerId);
console.log(JSON.stringify(formattedResult, null, 2));
console.log('\n✅ Verificação concluída!\n');
} else {
console.log(JSON.stringify({
status: false,
criador: '@paulo_mod_domina',
erro: result.error || 'Não foi possível verificar a conta'
}, null, 2));
console.log('\n❌ Erro na verificação\n');
}
askPlayerId();
});
};
askPlayerId();
}
}

// Se executado diretamente, inicia o modo CLI
if (require.main === module) {
const checker = new AccountDateChecker();
checker.startCLI();
}

module.exports = AccountDateChecker