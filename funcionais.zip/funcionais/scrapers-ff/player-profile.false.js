//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

/*
Exemplo de uso:
const PlayerProfileScraper = require('./player-profile');
const scraper = new PlayerProfileScraper();

// Modo CLI: node player-profile.js
// Ou como módulo:
scraper.getPlayerProfile('1989445071')
.then(resultado => console.log(resultado))
.catch(erro => console.error(erro));
*/

const axios = require('axios')
const cheerio = require('cheerio')
const readline = require('readline')
const FormData = require('form-data')
const fs = require('fs')
const puppeteer = require('puppeteer')

async function uploadToCatbox(imageUrl) {
try {
const response = await axios({
method: 'get',
url: imageUrl,
responseType: 'arraybuffer'
});
const buffer = Buffer.from(response.data, 'binary');
const formData = new FormData();
formData.append('reqtype', 'fileupload');
formData.append('userhash', '');
formData.append('fileToUpload', buffer, {
filename: `image_${Date.now()}.jpg`,
contentType: response.headers['content-type']
});
const uploadResponse = await axios.post('https://catbox.moe/user/api.php', formData, {
headers: formData.getHeaders()
});
return uploadResponse.data.trim();
} catch (error) {
console.error('Erro ao fazer upload da imagem para o Catbox:', error.message);
return null;
}
}

class PlayerProfileScraper {
constructor() {
this.baseUrl = 'https://freefirejornal.com/perfil-jogador-freefire';
this.headers = {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'Referer': 'https://freefirejornal.com/',
'Origin': 'https://freefirejornal.com',
'Connection': 'keep-alive'
};
}

async getPlayerProfile(playerId) {
try {
const url = `${this.baseUrl}/${playerId}/`;
const response = await axios.get(url, { headers: this.headers });
const $ = cheerio.load(response.data);
const profileData = {
id: playerId,
nome: '',
url_perfil: url,
data_consulta: this.formatarDataAtual(),
dados_grafico: {},
grafico_estatisticas: null
};
const browser = await puppeteer.launch({
headless: 'new',
args: ['--no-sandbox', '--disable-setuid-sandbox']
});
try {
const page = await browser.newPage();
await page.goto(url, { waitUntil: 'networkidle0' });
await page.waitForSelector('#playerCareerChart', { timeout: 5000 });
await new Promise(resolve => setTimeout(resolve, 2000));
const chartElement = await page.$('#playerCareerChart');
if (chartElement) {
const screenshot = await chartElement.screenshot({
encoding: 'binary'
});
const formData = new FormData();
formData.append('reqtype', 'fileupload');
formData.append('userhash', '');
formData.append('fileToUpload', screenshot, {
filename: `chart_${playerId}.png`,
contentType: 'image/png'
});
const uploadResponse = await axios.post('https://catbox.moe/user/api.php', formData, {
headers: formData.getHeaders()
});
profileData.grafico_estatisticas = uploadResponse.data.trim();
}
} catch (error) {
console.error('Erro ao capturar o gráfico:', error.message);
} finally {
await browser.close();
}
const title = $('title').text().trim();
profileData.nome = title.split('Perfil Do Jogador ')[1]?.split(':')[0]?.trim() || 'Nome não encontrado';
const infoItems = $('div.entry-content ul li').map((i, el) => $(el).text().trim()).get();
infoItems.forEach(item => {
if (item.includes('Nível:')) profileData.nivel = item.replace('Nível:', '').trim();
if (item.includes('Experiência (XP):')) profileData.xp = item.replace('Experiência (XP):', '').trim();
if (item.includes('Pontos de Ranqueada:')) profileData.ranqueada = item.replace('Pontos de Ranqueada:', '').trim();
if (item.includes('Influenciador:')) profileData.influenciador = item.replace('Influenciador:', '').trim();
if (item.includes('Likes:')) profileData.likes = item.replace('Likes:', '').trim();
if (item.includes('Último Login:')) profileData.ultimo_login = item.replace('Último Login:', '').trim();
if (item.includes('Conta Criada:')) profileData.data_criacao = item.replace('Conta Criada:', '').trim();
if (item.includes('Perfil Atualizado:')) profileData.ultima_atualizacao = item.replace('Perfil Atualizado:', '').trim();
if (item.includes('Assinatura - Bio:')) {
const bio = item.split('Assinatura - Bio:')[1].split('Copiado!')[0].trim();
profileData.bio = bio.replace(/\[|\]/g, '').trim();
}
});
const chartScript = $('script:contains("playerCareerChart")').html();
if (chartScript) {
const scriptContent = chartScript.replace(/[\n\r]/g, ' ').replace(/\s+/g, ' ');
const labelsMatch = scriptContent.match(/labels:\s*\[([^\]]+)\]/);
if (labelsMatch) {
const labels = labelsMatch[1].split(',').map(l => l.trim().replace(/'/g, ''));
const datasetsMatch = scriptContent.match(/datasets:\s*\[([\s\S]*?)\]\s*\}/);
if (datasetsMatch) {
const datasets = datasetsMatch[1].split('},').map(dataset => {
const dataMatch = dataset.match(/data:\s*\[([^\]]+)\]/);
return dataMatch ? dataMatch[1].split(',').map(d => parseFloat(d.trim())) : [];
});
if (datasets.length >= 4) {
profileData.dados_grafico = {
categorias: ['Vitórias', 'Abates', 'Tiros na Cabeça', 'Exploração', 'Sobrevivência'],
detalhes: {
vitorias: `Solo: ${datasets[1][0].toFixed(2)}% | Duo: ${datasets[2][0].toFixed(2)}% | Squad: ${datasets[3][0].toFixed(2)}%`,
abates: `Solo: ${datasets[1][1].toFixed(2)}% | Duo: ${datasets[2][1].toFixed(2)}% | Squad: ${datasets[3][1].toFixed(2)}%`,
headshots: `Solo: ${datasets[1][2].toFixed(2)}% | Duo: ${datasets[2][2].toFixed(2)}% | Squad: ${datasets[3][2].toFixed(2)}%`,
exploracao: `Solo: ${datasets[1][3].toFixed(2)}% | Duo: ${datasets[2][3].toFixed(2)}% | Squad: ${datasets[3][3].toFixed(2)}%`,
sobrevivencia: `Solo: ${datasets[1][4].toFixed(2)}% | Duo: ${datasets[2][4].toFixed(2)}% | Squad: ${datasets[3][4].toFixed(2)}%`
}
};
}
}
}
}
let descricao = 'Descrição não disponível';
const introDiv = $('div.jg-player-intro');
if (introDiv.length > 0) {
introDiv.find('script, style, button, .share-buttons, .ad-container').remove();
descricao = introDiv.html()
.replace(/<\/p>\s*<p[^>]*>/g, '\n\n')
.replace(/<[^>]+>/g, '')
.replace(/\s+/g, ' ')
.replace(/\s*,\s*/g, ', ')
.replace(/\s*\n\s*/g, '\n\n')
.trim();
} else {
const paragrafos = $('div.entry-content > p').map((i, el) => $(el).text().trim()).get();
const paragrafoSaudacao = paragrafos.find(p => 
p.includes('Bem-vindo ao perfil de') || 
p.includes('Perfil de') ||
p.includes('ID:')
);
if (paragrafoSaudacao) {
descricao = paragrafoSaudacao
.replace(/\s+/g, ' ')
.replace(/\s*,\s*/g, ', ')
.trim();
}
}
profileData.descricao = descricao.trim() || 'Descrição não disponível';
const statsText = $('div.entry-content').text();
if (statsText) {
const partidasMatch = statsText.match(/Partidas: Solo: (\d+) \| Duo: (\d+) \| Squad: (\d+)/);
if (partidasMatch) {
profileData.estatisticas = {
partidas: {
solo: parseInt(partidasMatch[1]),
duo: parseInt(partidasMatch[2]),
squad: parseInt(partidasMatch[3])
}
};
}
const vitoriasMatch = statsText.match(/Vitórias: Solo: (\d+) \| Duo: (\d+) \| Squad: (\d+)/);
if (vitoriasMatch) {
profileData.estatisticas.vitorias = {
solo: parseInt(vitoriasMatch[1]),
duo: parseInt(vitoriasMatch[2]),
squad: parseInt(vitoriasMatch[3])
};
if (profileData.estatisticas.partidas) {
profileData.estatisticas.taxa_vitoria = {
solo: ((profileData.estatisticas.vitorias.solo / profileData.estatisticas.partidas.solo) * 100).toFixed(2) + '%',
duo: ((profileData.estatisticas.vitorias.duo / profileData.estatisticas.partidas.duo) * 100).toFixed(2) + '%',
squad: ((profileData.estatisticas.vitorias.squad / profileData.estatisticas.partidas.squad) * 100).toFixed(2) + '%'
};
}
}
const abatesMatch = statsText.match(/Abates: Solo: (\d+) \| Duo: (\d+) \| Squad: (\d+)/);
if (abatesMatch) {
profileData.estatisticas.abates = {
solo: parseInt(abatesMatch[1]),
duo: parseInt(abatesMatch[2]),
squad: parseInt(abatesMatch[3])
};
if (profileData.estatisticas.vitorias && profileData.estatisticas.partidas) {
const totalMortesSolo = profileData.estatisticas.partidas.solo - profileData.estatisticas.vitorias.solo;
const totalMortesDuo = profileData.estatisticas.partidas.duo - profileData.estatisticas.vitorias.duo;
const totalMortesSquad = profileData.estatisticas.partidas.squad - profileData.estatisticas.vitorias.squad;
profileData.estatisticas.kd_ratio = {
solo: totalMortesSolo > 0 ? (profileData.estatisticas.abates.solo / totalMortesSolo).toFixed(2) : profileData.estatisticas.abates.solo.toFixed(2),
duo: totalMortesDuo > 0 ? (profileData.estatisticas.abates.duo / totalMortesDuo).toFixed(2) : profileData.estatisticas.abates.duo.toFixed(2),
squad: totalMortesSquad > 0 ? (profileData.estatisticas.abates.squad / totalMortesSquad).toFixed(2) : profileData.estatisticas.abates.squad.toFixed(2)
};
}
}
const topMatch = statsText.match(/Top 10\/5\/3: Solo: (\d+) \| Duo: (\d+) \| Squad: (\d+)/);
if (topMatch) {
profileData.estatisticas.top_posicoes = {
solo: parseInt(topMatch[1]),
duo: parseInt(topMatch[2]),
squad: parseInt(topMatch[3])
};
if (profileData.estatisticas.partidas) {
profileData.estatisticas.taxa_top = {
solo: ((profileData.estatisticas.top_posicoes.solo / profileData.estatisticas.partidas.solo) * 100).toFixed(2) + '%',
duo: ((profileData.estatisticas.top_posicoes.duo / profileData.estatisticas.partidas.duo) * 100).toFixed(2) + '%',
squad: ((profileData.estatisticas.top_posicoes.squad / profileData.estatisticas.partidas.squad) * 100).toFixed(2) + '%'
};
}
}
const danoMatch = statsText.match(/Média de Dano: Solo: (\d+) \| Duo: (\d+) \| Squad: (\d+)/);
if (danoMatch) {
profileData.estatisticas.dano_medio = {
solo: parseInt(danoMatch[1]),
duo: parseInt(danoMatch[2]),
squad: parseInt(danoMatch[3])
};
}
const headshotsMatch = statsText.match(/Tiros na Cabeça: Solo: (\d+) \| Duo: (\d+) \| Squad: (\d+)/);
if (headshotsMatch) {
profileData.estatisticas.headshots = {
solo: parseInt(headshotsMatch[1]),
duo: parseInt(headshotsMatch[2]),
squad: parseInt(headshotsMatch[3])
};
if (profileData.estatisticas.abates) {
profileData.estatisticas.taxa_headshots = {
solo: ((profileData.estatisticas.headshots.solo / profileData.estatisticas.abates.solo) * 100).toFixed(2) + '%',
duo: ((profileData.estatisticas.headshots.duo / profileData.estatisticas.abates.duo) * 100).toFixed(2) + '%',
squad: ((profileData.estatisticas.headshots.squad / profileData.estatisticas.abates.squad) * 100).toFixed(2) + '%'
};
}
}
const kmMatch = statsText.match(/Média de KM Percorrido: Solo: ([^|]+) \| Duo: ([^|]+) \| Squad: ([^\n]+)/);
if (kmMatch) {
profileData.estatisticas.km_percorrido = {
solo: parseFloat(kmMatch[1]),
duo: parseFloat(kmMatch[2]),
squad: parseFloat(kmMatch[3])
};
}
const sobrevivenciaMatch = statsText.match(/Média de Sobrevivência: Solo: ([^|]+) \| Duo: ([^|]+) \| Squad: ([^\n]+)/);
if (sobrevivenciaMatch) {
profileData.estatisticas.sobrevivencia_media = {
solo: sobrevivenciaMatch[1].trim(),
duo: sobrevivenciaMatch[2].trim(),
squad: sobrevivenciaMatch[3].trim()
};
}
const maxAbatesMatch = statsText.match(/Máximo de Abates em Jogo: Solo: (\d+) \| Duo: (\d+) \| Squad: (\d+)/);
if (maxAbatesMatch) {
profileData.estatisticas.max_abates = {
solo: parseInt(maxAbatesMatch[1]),
duo: parseInt(maxAbatesMatch[2]),
squad: parseInt(maxAbatesMatch[3])
};
}
const veiculoMatch = statsText.match(/Abates com Veículo: Solo: (\d+) \| Duo: (\d+) \| Squad: (\d+)/);
if (veiculoMatch) {
profileData.estatisticas.abates_veiculo = {
solo: parseInt(veiculoMatch[1]),
duo: parseInt(veiculoMatch[2]),
squad: parseInt(veiculoMatch[3])
};
}
}
const estatisticasLimpas = this.cleanStatistics(profileData.estatisticas || {});
let bio = 'Nenhuma bio fornecida';
try {
const bioElement = $('.bio-text').first();
if (bioElement.length) {
bio = bioElement.text().trim();
}
} catch (error) {
console.error('Erro ao extrair a bio:', error.message);
}
let graficoURL = 'Não disponível';
try {
console.log('Iniciando navegador para capturar o gráfico...');
const browser = await puppeteer.launch({
headless: 'new',
args: ['--no-sandbox', '--disable-setuid-sandbox']
});
try {
const page = await browser.newPage();
await page.setViewport({ width: 1200, height: 800 });
await page.goto(url, { waitUntil: 'networkidle0', timeout: 60000 });
//console.log('Aguardando o carregamento do gráfico...');
await page.waitForSelector('canvas#playerCareerChart', { visible: true, timeout: 10000 });
await new Promise(resolve => setTimeout(resolve, 3000));
//console.log('Capturando o gráfico...');
const graficoBase64 = await page.evaluate(() => {
const canvas = document.querySelector('canvas#playerCareerChart');
return canvas ? canvas.toDataURL('image/png') : null;
});
if (graficoBase64) {
//console.log('Fazendo upload do gráfico para o Catbox...');
const base64Data = graficoBase64.replace(/^data:image\/png;base64,/, '');
const buffer = Buffer.from(base64Data, 'base64');
const formData = new FormData();
formData.append('reqtype', 'fileupload');
formData.append('userhash', '');
formData.append('fileToUpload', buffer, {
filename: `grafico_${Date.now()}.png`,
contentType: 'image/png'
});
const uploadResponse = await axios.post('https://catbox.moe/user/api.php', formData, {
headers: formData.getHeaders()
});
graficoURL = uploadResponse.data.trim();
console.log('Gráfico enviado para:', graficoURL);
} else {
console.log('Não foi possível capturar o gráfico: elemento canvas não encontrado');
}
} catch (error) {
console.error('Erro ao capturar o gráfico:', error.message);
} finally {
await browser.close();
}
} catch (error) {
console.error('Erro ao iniciar o navegador:', error.message);
}
const resultados = {
id: profileData.id || 'Não informado',
nome: profileData.nome || 'Não informado',
nivel: profileData.nivel || 'Não informado',
xp: profileData.xp || 'Não informado',
ranqueada: profileData.ranqueada || 'Não informado',
influenciador: profileData.influenciador || 'Não informado',
likes: profileData.likes || 'Não informado',
bio: bio,
ultimo_login: profileData.ultimo_login || 'Não informado',
data_criacao: profileData.data_criacao || 'Não informado',
ultima_atualizacao: profileData.ultima_atualizacao || 'Não informado',
estatisticas: estatisticasLimpas || {},
dados_grafico: profileData.dados_grafico || {},
grafico_canvas: graficoURL,
descricao: descricao || 'Nenhuma descrição fornecida',
skins_equipadas: profileData.skins_equipadas || []
};
const result = {
status: true,
criador: '@paulo_mod_domina',
resultados: {}
};
Object.entries(resultados).forEach(([key, value]) => {
if (value !== undefined && value !== '' && value !== null) {
if (typeof value === 'object' && Object.keys(value).length === 0) {
return;
}
result.resultados[key] = value;
}
});
return result;
} catch (error) {
console.error('Erro ao obter perfil do jogador:', error.message);
return {
status: false,
criador: '@paulo_mod_domina',
erro: error.message
};
}
}

extractFromMeta($, key) {
const metaElement = $(`meta[property*="${key}" i], meta[name*="${key}" i]`);
return metaElement.attr('content') || metaElement.attr('value') || 'Não informado';
}

cleanText(text) {
if (!text) return 'Não informado';
return text.replace(/\s+/g, ' ').replace(/[\n\t]/g, '').trim();
}

extractNumber(text) {
if (!text && text !== 0) return 0;
const num = parseFloat(text.toString().replace(/[^\d,-]/g, '').replace(',', '.'));
return isNaN(num) ? 0 : num;
}

cleanStatistics(stats) {
if (!stats) return {};
const cleanStats = (obj) => {
if (!obj || typeof obj !== 'object') return obj;
const result = {};
for (const [key, value] of Object.entries(obj)) {
if (value === undefined || value === null) continue;
if (typeof value === 'object') {
const cleaned = cleanStats(value);
if (Object.keys(cleaned).length > 0) {
result[key] = cleaned;
}
} else if (typeof value === 'number' && isNaN(value)) {
result[key] = 0;
} else if (value !== '') {
result[key] = value;
}
}
return result;
};
return cleanStats(stats);
}

formatarDataAtual() {
const data = new Date();
return data.toLocaleString('pt-BR', {
day: '2-digit',
month: '2-digit',
year: 'numeric',
hour: '2-digit',
minute: '2-digit',
second: '2-digit',
hour12: false
});
}
}

// Se executado diretamente, inicia o modo CLI
if (require.main === module) {
class PlayerProfileScraperCLI {
constructor() {
this.scraper = new PlayerProfileScraper();
}
async run() {
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});
const askForId = async () => {
return new Promise((resolve) => {
rl.question('\nDigite o ID do jogador (ou "sair" para sair): ', async (playerId) => {
if (playerId.toLowerCase() === 'sair') {
console.log('Encerrando...');
rl.close();
resolve();
return;
}
console.log(`\nBuscando perfil do jogador ${playerId}...\n`);
try {
const result = await this.scraper.getPlayerProfile(playerId);
console.log(JSON.stringify(result, null, 2));
console.log('\n' + '=' * 50 + '\n');
} catch (error) {
console.error('Erro ao buscar perfil:', error.message);
}
await askForId();
});
});
};
await askForId();
}
}
const cli = new PlayerProfileScraperCLI();
cli.run();
}

module.exports = PlayerProfileScraper