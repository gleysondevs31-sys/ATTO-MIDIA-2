const axios = require('axios')
const cheerio = require('cheerio')
const FormData = require('form-data')
const { createCanvas, loadImage } = require('canvas')

class FreeFireSkinscraper {
  constructor() {
    this.baseUrl = 'https://www.freefiremania.com.br'
    this.timeout = 60000; // Increased timeout
    this.headers = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
      'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
      'Referer': 'https://www.freefiremania.com.br/',
      'Origin': 'https://www.freefiremania.com.br',
      'Sec-Ch-Ua': '"Chromium";v="142", "Google Chrome";v="142", "Not?A_Brand";v="99"',
      'Sec-Ch-Ua-Mobile': '?0',
      'Sec-Ch-Ua-Platform': '"Windows"',
      'Sec-Fetch-Dest': 'document',
      'Sec-Fetch-Mode': 'navigate',
      'Sec-Fetch-Site': 'same-origin',
      'Sec-Fetch-User': '?1',
      'Upgrade-Insecure-Requests': '1'
    }
  }

  async getSkinsData(profileId) {
    try {
      console.log(`🔍 Buscando skins para ID: ${profileId}`)

      const profileUrl = `${this.baseUrl}/perfil/${profileId}.html`

      // Buscar nome do jogador usando método mais robusto
      let playerName = null
      try {
        const profileResponse = await axios.get(profileUrl, {
          headers: this.headers,
          timeout: this.timeout
        })
        const $profile = cheerio.load(profileResponse.data)

        // Múltiplas tentativas para encontrar o nome
        playerName = $('.perfil-component .nome').text().trim() ||
                     $('.player-name').text().trim() ||
                     $('.nickname').text().trim() ||
                     $('h1').first().text().trim() ||
                     $('h2').first().text().trim() ||
                     $('strong').filter((_, el) => $profile(el).text().includes('Nick:')).text().replace('Nick:', '').trim()

        // Limpeza se necessário
        if (playerName && playerName.startsWith('Perfil de ')) {
          playerName = playerName.replace('Perfil de ', '').split(':')[0].trim()
        }

        // Se ainda não encontrou, tentar extrair de elementos que contenham o ID
        if (!playerName) {
          $profile('*').each((_, el) => {
            const text = $profile(el).text()
            if (text.includes(profileId) && text.length > profileId.length && text.length < 100) {
              const possibleName = text.replace(profileId, '').replace(/[^\w\s@.-]/g, '').trim()
              if (possibleName.length > 2 && possibleName.length < 50) {
                playerName = possibleName
                return false // break
              }
            }
          })
        }

        // Tentativa adicional: extrair de título ou meta
        if (!playerName) {
          const title = $('title').text().trim()
          if (title.startsWith('Perfil de ')) {
            playerName = title.replace('Perfil de ', '').split(':')[0].trim()
          }
        }

        console.log(`👤 Nome encontrado: ${playerName || 'Não encontrado'}`)
      } catch (profileError) {
        console.warn('⚠️ Erro ao buscar nome do jogador:', profileError.message)
      }

      // Buscar skins via API com referer do perfil
      const skinsUrl = `${this.baseUrl}/paginas/dados-jogador-api-roupas.php?tag=${profileId}`
      const skinsHeaders = { ...this.headers, 'Referer': profileUrl, 'Sec-Fetch-Dest': 'empty', 'Sec-Fetch-Mode': 'cors' } // Adjusted for API call
      const { data } = await axios.get(skinsUrl, {
        headers: skinsHeaders,
        timeout: this.timeout
      })

      if (!data || data.trim().length < 50) {
        return {
          status: false,
          mensagem: 'Jogador não encontrado ou sem skins'
        }
      }

      // Extrair skins do HTML
      const $ = cheerio.load(data)
      const skins = []
      $('img').each((_, img) => {
        const src = $(img).attr('src')
        if (src) {
          skins.push({
            imagem: this.normalizeImageUrl(src)
          })
        }
      })

      console.log(`👕 ${skins.length} skins encontradas`)

      if (skins.length === 0) {
        return {
          status: false,
          mensagem: 'Nenhuma skin encontrada para este ID'
        }
      }

      // Gerar avaliação
      const avaliacao = this.generateRating(profileId, skins.length)

      // Baixar imagens das skins (máximo 8)
      console.log(`📥 Baixando imagens das skins...`)
      const maxSkins = Math.min(skins.length, 8)
      const skinsImgs = await Promise.all(skins.slice(0, maxSkins).map(async (skin, i) => {
        const img = await this.safeLoadImage(skin.imagem)
        console.log(`📷 Skin ${i+1} ${img ? '✅' : '❌'}`)
        return img
      }))

      // Criar montagem
      console.log(`🎨 Criando montagem...`)
      const imageUrl = await this.createSkinsCanvas(profileId, playerName, skins, skinsImgs, avaliacao)

      return {
        status: true,
        criador: '',
        resultados: {
          id: profileId,
          jogador: playerName || `Jogador ${profileId}`,
          avaliacao: avaliacao,
          totalSkins: skins.length,
          skinsExibidas: maxSkins,
          imagem: imageUrl,
          classificacao: this.getClassification(avaliacao)
        }
      }

    } catch (error) {
      console.error('❌ Erro ao processar skins:', error.message)
      return {
        status: false,
        mensagem: error.message
      }
    }
  }

  async createSkinsCanvas(profileId, playerName, allSkins, skinsImgs, avaliacao) {
    const canvasWidth = 1200
    const canvasHeight = 800
    const canvas = createCanvas(canvasWidth, canvasHeight)
    const ctx = canvas.getContext('2d')

    // Fundo gradiente mais vibrante (temático Free Fire: preto para laranja/vermelhado)
    const grad = ctx.createLinearGradient(0, 0, canvasWidth, canvasHeight)
    grad.addColorStop(0, '#000000')
    grad.addColorStop(0.3, '#1a1a1a')
    grad.addColorStop(0.7, '#ff4500') // Laranja avermelhado para tema de fogo
    grad.addColorStop(1, '#ff8c00')
    ctx.fillStyle = grad
    ctx.fillRect(0, 0, canvasWidth, canvasHeight)

    // Adicionar um overlay sutil de "fogo" ou pattern, mas simples: linhas diagonais sutis
    ctx.save()
    ctx.globalAlpha = 0.05
    ctx.strokeStyle = '#ff4500'
    ctx.lineWidth = 1
    for (let i = -canvasHeight; i < canvasWidth; i += 50) {
      ctx.beginPath()
      ctx.moveTo(i, 0)
      ctx.lineTo(i + canvasHeight, canvasHeight)
      ctx.stroke()
    }
    ctx.restore()

    // Título "YOUR OUTFITS" com gradiente e glow mais forte
    ctx.save()
    const titleGrad = ctx.createLinearGradient(0, 40, 0, 100)
    titleGrad.addColorStop(0, '#00d4ff')
    titleGrad.addColorStop(1, '#00bfff')
    ctx.font = 'bold 60px Arial' // Aumentado o tamanho
    ctx.fillStyle = titleGrad
    ctx.textAlign = 'center'
    ctx.shadowColor = 'rgba(0, 212, 255, 0.8)'
    ctx.shadowBlur = 30
    ctx.shadowOffsetX = 0
    ctx.shadowOffsetY = 0
    ctx.fillText('YOUR OUTFITS', canvasWidth / 2, 90)
    ctx.restore()

    // Nome do jogador com sombra
    if (playerName) {
      ctx.save()
      ctx.font = 'bold 32px Arial'
      ctx.fillStyle = '#ffffff'
      ctx.textAlign = 'center'
      ctx.shadowColor = 'rgba(255, 255, 255, 0.5)'
      ctx.shadowBlur = 10
      ctx.fillText(playerName, canvasWidth / 2, 140)
      ctx.restore()
    }

    // ID do jogador
    ctx.save()
    ctx.font = 'italic 24px Arial' // Adicionado italic para estilo
    ctx.fillStyle = '#dddddd'
    ctx.textAlign = 'center'
    ctx.fillText(`ID: ${profileId}`, canvasWidth / 2, 170)
    ctx.restore()

    // Grid de skins
    const skinSize = 180
    const borderRadius = 15 // Raio para cantos arredondados
    const maxSkins = skinsImgs.length
    const cols = Math.min(4, Math.ceil(Math.sqrt(maxSkins)))
    const rows = Math.ceil(maxSkins / cols)
    const spacing = 40 // Aumentado o espaçamento para melhor visual
    const totalWidth = cols * skinSize + (cols - 1) * spacing
    const totalHeight = rows * skinSize + (rows - 1) * spacing
    const startX = (canvasWidth - totalWidth) / 2
    const startY = 200

    // Desenhar skins com cantos arredondados e sombra
    skinsImgs.forEach((img, i) => {
      const row = Math.floor(i / cols)
      const col = i % cols
      const x = startX + col * (skinSize + spacing)
      const y = startY + row * (skinSize + spacing)

      ctx.save()
      // Sombra externa
      ctx.shadowColor = 'rgba(255, 165, 0, 0.8)' // Laranja para tema
      ctx.shadowBlur = 20
      ctx.shadowOffsetX = 5
      ctx.shadowOffsetY = 5

      // Desenhar retângulo arredondado para borda
      ctx.beginPath()
      ctx.roundRect(x - 4, y - 4, skinSize + 8, skinSize + 8, borderRadius + 4)
      ctx.fillStyle = '#ffc107' // Borda dourada mais larga
      ctx.fill()

      // Clip para a imagem com arredondamento
      ctx.beginPath()
      ctx.roundRect(x, y, skinSize, skinSize, borderRadius)
      ctx.clip()

      if (img) {
        ctx.drawImage(img, x, y, skinSize, skinSize)
      } else {
        ctx.fillStyle = '#333333'
        ctx.fillRect(x, y, skinSize, skinSize)
        ctx.fillStyle = '#666666'
        ctx.font = '16px Arial'
        ctx.textAlign = 'center'
        ctx.fillText('Skin não', x + skinSize/2, y + skinSize/2 - 10)
        ctx.fillText('carregada', x + skinSize/2, y + skinSize/2 + 10)
      }
      ctx.restore()
    })

    // Informações na parte inferior com fundo semi-transparente
    const infoY = startY + totalHeight + 60
    const infoHeight = 120
    ctx.save()
    ctx.fillStyle = 'rgba(0, 0, 0, 0.6)' // Fundo semi-transparente para destaque
    ctx.beginPath()
    ctx.roundRect(canvasWidth / 2 - 300, infoY - 40, 600, infoHeight, 10)
    ctx.fill()
    ctx.restore()

    ctx.save()
    ctx.font = 'bold 28px Arial'
    ctx.fillStyle = '#ffc107'
    ctx.textAlign = 'center'
    ctx.shadowColor = 'rgba(255, 193, 7, 0.5)'
    ctx.shadowBlur = 10
    ctx.fillText(`Avaliação: ${avaliacao}/100`, canvasWidth / 2, infoY)

    ctx.font = '24px Arial'
    ctx.fillStyle = '#ffffff'
    ctx.shadowColor = 'rgba(255, 255, 255, 0.3)'
    ctx.shadowBlur = 5
    ctx.fillText(`Total de Skins: ${allSkins.length}`, canvasWidth / 2, infoY + 40)

    // Classificação com cor baseada no nível
    const classificacao = this.getClassification(avaliacao)
    let classColor = '#00ff00' // Verde padrão
    if (avaliacao >= 80) classColor = '#ffd700' // Dourado para top
    else if (avaliacao >= 65) classColor = '#00bfff' // Azul para pro
    else if (avaliacao >= 50) classColor = '#ff4500' // Laranja para bom
    ctx.font = 'bold 26px Arial'
    ctx.fillStyle = classColor
    ctx.shadowColor = classColor.replace(')', ', 0.5)').replace('rgb', 'rgba')
    ctx.shadowBlur = 15
    ctx.fillText(classificacao, canvasWidth / 2, infoY + 80)
    ctx.restore()

    // Assinatura com estilo
    ctx.save()
    ctx.font = 'italic 18px Arial'
    ctx.fillStyle = '#aaaaaa'
    ctx.textAlign = 'right'
    ctx.fillText('Gerado Por ZERO TWO • FreeFire Mania', canvasWidth - 20, canvasHeight - 20)
    ctx.restore()

    // Upload
    const buffer = canvas.toBuffer('image/png')
    const form = new FormData()
    form.append('reqtype', 'fileupload')
    form.append('fileToUpload', buffer, { 
      filename: 'ff-skins.png', 
      contentType: 'image/png' 
    })

    const uploadResponse = await axios.post('https://catbox.moe/user/api.php', form, { 
      headers: form.getHeaders(), 
      timeout: this.timeout 
    })

    return uploadResponse.data.trim()
  }

  safeLoadImage(url, timeout = 8000) {
    if (!url) return Promise.resolve(null);
    return Promise.race([
      loadImage(url),
      new Promise(resolve => setTimeout(() => resolve(null), timeout))
    ]).catch(() => null)
  }

  normalizeImageUrl(url) {
    if (!url) return null
    try {
      if (url.startsWith('http')) return url
      if (url.startsWith('/')) return `${this.baseUrl}${url}`
      return `${this.baseUrl}${url}`
    } catch (error) {
      return null
    }
  }

  generateRating(profileId, skinsCount) {
    let hash = 0
    const str = profileId + skinsCount.toString()
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i)
      hash = ((hash << 5) - hash) + char
      hash = hash & hash
    }
    return (Math.abs(hash) % 51) + 50 // 50-100
  }

  getClassification(avaliacao) {
    if (avaliacao >= 80) return 'TOP PLAYER! 🏆'
    if (avaliacao >= 65) return 'JOGADOR PRO! 💎'
    if (avaliacao >= 50) return 'BOM JOGADOR! ⚡'
    return 'INICIANTE! 📈'
  }
}

module.exports = FreeFireSkinscraper