//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

/*

 * EXEMPLO:
 
const { FreeFireLikesScraper, REGIOES_VALIDAS } = require('./likes-ff')
const scraperff = new FreeFireLikesScraper()

app.get('/sendlike', async (req, res) => {
const { id, regiao } = req.query
if (!id || !regiao) {
return res.status(400).json({
status: false,
criador: '@lucas_mod_domina',
resultados: {
mensagem: 'Parâmetros "id" e "regiao" são obrigatórios'
}
})
}
if (!/^\d+$/.test(id)) {
return res.status(400).json({
status: false,
criador: '@lucas_mod_domina',
resultados: {
mensagem: 'ID deve conter apenas números'
}
})
}
if (!REGIOES_VALIDAS.includes(regiao)) {
return res.status(400).json({
status: false,
criador: '@lucas_mod_domina',
resultados: {
mensagem: `Região inválida. Regiões válidas: ${REGIOES_VALIDAS.join(', ')}`
}
})
}
try {
const resultado = await scraperff.enviarLike(id, regiao)
const respostaFinal = {
status: resultado.status,
criador: '@lucas_mod_domina',
resultados: resultado
}
let statusCode = 200
if (!resultado.status) {
statusCode = resultado.tipoErro === 'TEMPO_ESPERA' ? 429 : 400
}
res.status(statusCode).json(respostaFinal)
} catch (error) {
res.status(500).json({
status: false,
criador: '@lucas_mod_domina',
resultados: {
mensagem: 'Erro interno no servidor',
detalhes: error.message
}
})
}
})

*/

const axios = require('axios');
const fs = require('fs');
const path = require('path');

const CONFIG = {
urlBase: 'https://www.freefiremania.com.br',
endpoints: {
adicionarLikes: '/paginas/free-fire-ferramenta-ganhar-likes-add.php',
obterFila: '/paginas/free-fire-ferramenta-ganhar-likes-carregar.php'
},
tempoEspera: 18 * 60 * 60 * 1000, // 18 horas
timeoutRequisicao: 30000,
navegadores: [
'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36',
'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0',
'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36',
'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.54 Safari/537.36'
]
};

const REGIOES_VALIDAS = ['br', 'sg', 'ind', 'id', 'tw', 'us', 'sac', 'th', 'me', 'pk', 'cis', 'bd'];

class FreeFireLikesScraper {
constructor() {
this.axios = axios.create({
baseURL: CONFIG.urlBase,
headers: {
'User-Agent': this.obterAgenteUsuarioAleatorio(),
'Accept': 'application/json, text/plain, */*',
'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'Content-Type': 'application/json',
'Origin': CONFIG.urlBase,
'Referer': `${CONFIG.urlBase}/ganhar-likes-free-fire.html`,
'Sec-Fetch-Dest': 'empty',
'Sec-Fetch-Mode': 'cors',
'Sec-Fetch-Site': 'same-origin'
},
timeout: CONFIG.timeoutRequisicao
});
this.arquivoSessao = path.join(__dirname, 'sessao-likes.json');
this.sessao = this.carregarSessao();
}

obterAgenteUsuarioAleatorio() {
return CONFIG.navegadores[Math.floor(Math.random() * CONFIG.navegadores.length)];
}

carregarSessao() {
try {
if (fs.existsSync(this.arquivoSessao)) {
return JSON.parse(fs.readFileSync(this.arquivoSessao, 'utf8'));
}
} catch (erro) {
console.error('Erro ao carregar sessão:', erro);
}
return {};
}

salvarSessao() {
try {
fs.writeFileSync(this.arquivoSessao, JSON.stringify(this.sessao, null, 2));

// Agendar a exclusão do arquivo após 15 segundos
setTimeout(() => {
try {
// Verificar se o arquivo ainda existe antes de tentar remover
if (fs.existsSync(this.arquivoSessao)) {
fs.unlinkSync(this.arquivoSessao);
console.log(`Arquivo de sessão removido após 15 segundos: ${this.arquivoSessao}`);
} else {
console.log(`Arquivo de sessão não encontrado para remoção: ${this.arquivoSessao}`);
}
} catch (erro) {
console.error('Erro ao remover arquivo de sessão:', erro);
}
}, 15000); // 15 segundos em milissegundos

} catch (erro) {
console.error('Erro ao salvar sessão:', erro);
}
}

obterTempoEspera() {
if (!this.sessao.ultimoPedido) return 0;
const tempoDesdeUltimoPedido = Date.now() - this.sessao.ultimoPedido;
return Math.max(0, CONFIG.tempoEspera - tempoDesdeUltimoPedido);
}

formatarTempoEspera(ms) {
if (ms <= 0) return '0 segundos';
const segundos = Math.floor(ms / 1000) % 60;
const minutos = Math.floor(ms / (1000 * 60)) % 60;
const horas = Math.floor(ms / (1000 * 60 * 60));
const partes = [];
if (horas > 0) partes.push(`${horas}h`);
if (minutos > 0 || horas > 0) partes.push(`${minutos}min`);
if (segundos > 0 || partes.length === 0) partes.push(`${segundos}s`);
return partes.join(' ');
}

async enviarLike(idJogador, regiao) {
const agora = Date.now();
const tempoRestante = this.obterTempoEspera();
if (tempoRestante > 0) {
const proximoHorario = new Date(Date.now() + tempoRestante);
return {
status: false,
tipoErro: 'TEMPO_ESPERA',
mensagem: `Aguarde antes de enviar mais likes`,
tempoRestante: tempoRestante,
tempoFormatado: this.formatarTempoEspera(tempoRestante),
proximoHorario: proximoHorario.toISOString(),
podeEnviar: false
};
}

try {
const resposta = await this.axios.post(
CONFIG.endpoints.adicionarLikes,
JSON.stringify({ id: idJogador, regiao: regiao })
);

this.sessao.ultimoPedido = agora;
this.salvarSessao();

if (resposta.data?.status === 'success') {
const proximoHorario = new Date(agora + CONFIG.tempoEspera);
return {
mensagem: 'Like enviado com sucesso!',
jogador: {
id: idJogador,
nickname: resposta.data.nickname_utilizado || 'Desconhecido'
},
estatisticas: {
likesAcumulados: resposta.data.likes_acumulados_no_banco || 0,
likesEnviados: resposta.data.sucessos_enviados || 0
},
tempo: {
enviadoEm: new Date(agora).toISOString(),
proximoEnvio: proximoHorario.toISOString(),
tempoEsperaProximo: CONFIG.tempoEspera
}
};
}

return {
status: false,
tipoErro: 'ERRO_API',
mensagem: resposta.data?.message || 'Erro desconhecido na API',
codigoStatus: resposta.status,
dadosBrutos: resposta.data
};

} catch (erro) {
let mensagemErro = 'Erro desconhecido';
let codigoStatus = 500;
if (erro.response) {
mensagemErro = `Erro ${erro.response.status}: ${erro.response.statusText}`;
codigoStatus = erro.response.status;
} else if (erro.request) {
mensagemErro = 'Sem resposta do servidor';
} else {
mensagemErro = erro.message;
}
return {
status: false,
tipoErro: 'ERRO_REDE',
mensagem: mensagemErro,
codigoStatus: codigoStatus
};
}
}
}

module.exports = { FreeFireLikesScraper, REGIOES_VALIDAS };