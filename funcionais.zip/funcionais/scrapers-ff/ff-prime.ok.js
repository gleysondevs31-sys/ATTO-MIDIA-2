// By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
// Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

/*

 * EXEMPLO DE USO:
 
const { verificarNivelPrime } = require('./ff-prime');

app.get('/nivel-prime', async (req, res) => {
const id = req.query.id;
if (!id) {
return res.json({ 
status: false, 
error: 'Envie seu ID! Ex: /nivel-prime?id=12345678' 
});
}

try {
const resultado = await verificarNivelPrime(id);
res.json(resultado);
} catch (erro) {
res.json({ 
status: false, 
error: erro.message,
criador: "@paulo_mod_domina"
});
}
});

*/

const axios = require('axios');

async function verificarNivelPrime(playerId) {
try {
if (!playerId || !/^\d+$/.test(playerId)) {
return {
status: false,
criador: "@paulo_mod_domina",
error: "ID inválido! Deve conter apenas números."
};
}
const response = await axios.post(
'https://freefirejornal.com/ffstats/prime.php',
`idjogador=${encodeURIComponent(playerId)}`,
{
headers: {
'Content-Type': 'application/x-www-form-urlencoded',
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
'Accept': 'application/json, text/javascript, */*; q=0.01',
'Origin': 'https://freefirejornal.com',
'Referer': 'https://freefirejornal.com/descubra-seu-nivel-prime-no-free-fire-e-quantos-diamantes-voce-comprou/'
},
timeout: 10000
}
);
const data = response.data;
if (data.error) {
return {
status: false,
criador: "@paulo_mod_domina",
error: data.error
};
}
const limparHTML = (str) => {
return str ? str.replace(/<[^>]*>/g, '').trim() : '';
};
const ultimaVez = limparHTML(data.ultima_vez);
const conta = limparHTML(data.addconta);
const privilegios = Array.isArray(data.privilegios) 
? data.privilegios.map(limparHTML) 
: [];
const descricao = `O Sistema Prime no Free Fire é dividido em 8 níveis, cada um com suas próprias recompensas e privilégios. Confira o que você pode conquistar em cada etapa:\n\nNível 1 – 100 diamantes\nAvatar e Banner Iniciante Prime | Símbolo Prime 1\nPerfeito para quem está começando a explorar o sistema!\n\nNível 2 – 1.000 diamantes\nPresentes exclusivos | Lista de Bloqueios Ampliada | Símbolo Prime 2\nIdeal para quem quer mais personalização e controle no jogo.\n\nNível 3 – 3.000 diamantes\nParede de Gel – Honra do Prime | Espaço extra de traje | Símbolo Prime 3\nUm toque de estilo com itens práticos para o gameplay.\n\nNível 4 – 10.000 diamantes\nEmote Fala Mais Alto | Avatar e Banner: Avanço do Prime | +100 vagas para amigos | Símbolo Prime 4\nPara quem quer se destacar e expandir a rede de contatos.\n\nNível 5 – 30.000 diamantes\nApelido Colorido | Convite Prime | Símbolo Prime 5\nUm visual único que chama atenção em qualquer partida!\n\nNível 6 – 60.000 diamantes\nAnimação do Perfil Prime | Perfil Prime | Símbolo Prime 6\nPerfeito para quem busca exclusividade total no perfil.\n\nNível 7 – 120.000 diamantes\nAcesso Antecipado a novidades | Loja Prime exclusiva | Avatar e Banner: Máximo do Prime | Símbolo Prime 7\nO ápice do status PRIME com benefícios premium!\n\nNível 8 – 200.000 diamantes\nMoldura de Avatar Prime | Compartilhamento de Traje | Emblema Prime | Símbolo Prime 8\nO nível máximo para os verdadeiros mestres do Free Fire!\nLançado em 1º de junho de 2025, o Sistema Prime permite que você veja se está no Nível 1 ou já domina o Nível 8, além de calcular o investimento em diamantes – em reais ou dólares!`
return {
status: true,
criador: "@paulo_mod_domina",
resultados: {
id: playerId,
ultima_vez: ultimaVez || "Não disponível",
conta: conta || "Informação não encontrada",
privilegios: privilegios.length > 0 ? privilegios : ["Nenhum privilégio encontrado"],
descrição: descricao
}
};
} catch (error) {
let errorMsg = "Erro desconhecido";
if (error.response) {
errorMsg = `Servidor retornou status ${error.response.status}`;
} else if (error.request) {
errorMsg = "Sem resposta do servidor";
} else {
errorMsg = error.message;
}
return {
status: false,
criador: "@paulo_mod_domina",
error: `Falha na verificação: ${errorMsg}`
};
}
}

module.exports = { verificarNivelPrime }