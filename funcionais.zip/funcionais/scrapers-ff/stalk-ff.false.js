//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

/*

 * EXEMPLO:
 
const FreeFireScraper = require('./freefire-scraper');

app.get('/perfil/:id', async (req, res) => {
const scraper = new FreeFireScraper();
const resultado = await scraper.getProfileData(req.params.id);
res.json(resultado);
});
 
*/

const axios = require('axios')
const cheerio = require('cheerio')
const FormData = require('form-data')
const { URL } = require('url')
const { createCanvas, loadImage } = require('canvas')

class FreeFireScraper {
constructor() {
this.baseUrl = 'https://www.freefiremania.com.br'
this.timeout = 30000;
this.headers = {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
}
}

async getProfileData(profileId) {
try {
const profileUrl = `${this.baseUrl}/perfil/${profileId}.html`
console.log(`🔍 Buscando perfil: ${profileUrl}`)
const response = await axios.get(profileUrl, {
headers: this.headers,
timeout: this.timeout
})
const $ = cheerio.load(response.data)
const extrairPasseBooyah = $ => {
const el = $('li:contains("Passe Booyah")').first();
if (el.length) {
return el.text().replace(/⭐️ Passe Booyah:/, '').trim();
}
return null;
}
const profileData = {
id: profileId,
apelido: $('.perfil-component .nome').text().trim(),
nivel: parseInt($('.perfil-component .level').text().trim()) || 0,
dataCriacao: this.formatarData(this.extrairInfo($, '📅 Conta criada em:')),
ultimoLogin: this.formatarData(this.extrairInfo($, 'Último login em:')),
versaoJogo: this.extrairInfo($, 'Versão do jogo:'),
experiencia: this.extrairExperiencia($),
curtidas: this.extrairCurtidas($),
regiao: this.extrairInfo($, 'Região:'),
biografia: this.extrairBiografia($),
passeBooyah: extrairPasseBooyah($),
imagem: null
}
const avatarUrl = this.normalizeImageUrl($('.perfil-component .avatar').attr('src'))
const bannerUrl = this.normalizeImageUrl($('.perfil-component .banner-fundo').attr('src'))
const guildInfo = this.extrairInfoGuilda($)
if (guildInfo) {
profileData.guilda = guildInfo
}
let skins = []
try {
skins = (await this.buscarSkins(profileId)).map(s => s.imagem)
} catch (error) {
console.warn('⚠️ Não foi possível carregar as skins:', error.message)
}
function safeLoadImage(url, timeout = 8000) {
if (!url) return Promise.resolve(null);
return Promise.race([
loadImage(url),
new Promise(resolve => setTimeout(() => resolve(null), timeout))
]).catch(() => null)
}
console.log('Baixando avatar...');
const avatarImg = await safeLoadImage(avatarUrl);
console.log('Avatar baixado');
console.log('Baixando banner...');
const bannerImg = await safeLoadImage(bannerUrl);
console.log('Banner baixado');
console.log('Baixando skins...');
const skinsImgs = await Promise.all(skins.slice(0, 5).map(async (url, i) => {
const img = await safeLoadImage(url);
console.log(`Skin ${i+1} ${img ? 'baixada' : 'falhou/corrompida'}`);
return img;
}));
console.log('Todas as skins processadas');
const width = 1280
const height = 720
const canvas = createCanvas(width, height)
const ctx = canvas.getContext('2d')
const grad = ctx.createLinearGradient(0, 0, width, height)
grad.addColorStop(0, '#181818')
grad.addColorStop(1, '#23272b')
ctx.fillStyle = grad
ctx.fillRect(0, 0, width, height)
ctx.save()
ctx.shadowColor = 'rgba(0,0,0,0.4)'
ctx.shadowBlur = 24
ctx.beginPath()
ctx.moveTo(320, 40)
ctx.lineTo(1180, 40)
ctx.quadraticCurveTo(1220, 40, 1220, 80)
ctx.lineTo(1220, 240)
ctx.quadraticCurveTo(1220, 280, 1180, 280)
ctx.lineTo(320, 280)
ctx.quadraticCurveTo(280, 280, 280, 240)
ctx.lineTo(280, 80)
ctx.quadraticCurveTo(280, 40, 320, 40)
ctx.closePath()
ctx.clip()
if (bannerImg) ctx.drawImage(bannerImg, 280, 40, 940, 240)
else {
ctx.fillStyle = '#333';
ctx.fillRect(280, 40, 940, 240);
ctx.font = 'bold 40px Arial';
ctx.fillStyle = '#fff';
ctx.textAlign = 'center';
ctx.fillText('Imagem corrompida', 750, 160);
}
ctx.restore()
ctx.save()
ctx.shadowColor = 'rgba(0,0,0,0.7)'
ctx.shadowBlur = 18
ctx.strokeStyle = '#ffc107'
ctx.lineWidth = 10
ctx.beginPath()
ctx.rect(80, 60, 200, 200)
ctx.stroke()
ctx.closePath()
ctx.clip()
if (avatarImg) ctx.drawImage(avatarImg, 80, 60, 200, 200)
else {
ctx.fillStyle = '#333';
ctx.fillRect(80, 60, 200, 200);
ctx.font = 'bold 24px Arial';
ctx.fillStyle = '#fff';
ctx.textAlign = 'center';
ctx.fillText('Imagem corrompida', 180, 160);
}
ctx.restore()
let skinX = 100, skinY = 340, skinW = 180, skinH = 180, gap = 40
skinsImgs.forEach((img, i) => {
ctx.save()
ctx.shadowColor = 'rgba(0,0,0,0.7)'
ctx.shadowBlur = 14
if (img) ctx.drawImage(img, skinX + i*(skinW+gap), skinY, skinW, skinH)
else {
ctx.fillStyle = '#333';
ctx.fillRect(skinX + i*(skinW+gap), skinY, skinW, skinH);
ctx.font = 'bold 18px Arial';
ctx.fillStyle = '#fff';
ctx.textAlign = 'center';
ctx.fillText('Imagem corrompida', skinX + i*(skinW+gap) + skinW/2, skinY + skinH/2);
}
ctx.restore()
})
ctx.font = 'bold 22px Arial'
ctx.fillStyle = '#bbb'
ctx.textAlign = 'right'
ctx.fillText('Imagem gerada por @paulo_mod_domina • API Stalk FF', width-40, height-30)
const buffer = canvas.toBuffer('image/png')
const form = new FormData()
form.append('reqtype', 'fileupload')
form.append('fileToUpload', buffer, { filename: 'ff-stalk.png', contentType: 'image/png' })
const uploadResponse = await axios.post('https://catbox.moe/user/api.php', form, { headers: form.getHeaders(), timeout: this.timeout })
const imageUrl = uploadResponse.data.trim()
profileData.imagem = imageUrl
return {
status: true,
criador: '@paulo_mod_domina',
resultados: profileData
}
} catch (error) {
console.error('❌ Erro ao processar o perfil:', error.message)
return {
status: false,
mensagem: error.message
}
}
}

async buscarSkins(profileId) {
const skinsUrl = `${this.baseUrl}/paginas/dados-jogador-api-roupas.php?tag=${profileId}`
const { data } = await axios.get(skinsUrl, {
headers: this.headers,
timeout: this.timeout
})
const $ = cheerio.load(data)
const skins = [];
$('img').each((_, img) => {
const src = $(img).attr('src')
if (src) {
skins.push({
imagem: this.normalizeImageUrl(src)
})
}
})
return skins
}

async uploadParaCatbox(imageUrl) {
try {
if (!imageUrl) return null
const response = await axios.get(imageUrl, {
responseType: 'arraybuffer',
timeout: this.timeout
})
const form = new FormData();
form.append('reqtype', 'fileupload');
form.append('fileToUpload', response.data, {
filename: 'image.png',
contentType: response.headers['content-type']
})
const uploadResponse = await axios.post('https://catbox.moe/user/api.php', form, {
headers: form.getHeaders(),
timeout: this.timeout
})
return uploadResponse.data.trim()
} catch (error) {
console.warn('⚠️ Erro no upload para Catbox:', error.message)
return imageUrl
}
}

extrairInfo($, label) {
const element = $(`li:contains("${label}")`).first()
if (element.length) {
return element.text().replace(label, '').replace(':', '').trim()
}
return null
}

extrairExperiencia($) {
const smallText = $('li:contains("🏷️ Level:") small').text();
const match = smallText.match(/Exp:?\s*([\d.,]+)/);
if (!match) return { raw: 0, formatada: '0' };
const raw = parseInt(match[1].replace(/\./g, ''), 10);
return { raw, formatada: this.formatarNumero(raw) };
}

formatarNumero(number) {
return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

extrairCurtidas($) {
const likesText = $('li:contains("❤️ Likes:")').text()
const match = likesText.match(/([\d.,]+)/)
return match ? parseInt(match[1].replace(/\./g, '')) : 0
}

extrairBiografia($) {
const bioElement = $('#bioContent')
if (bioElement.length) {
return (bioElement.attr('data-original-bio') || bioElement.text()).replace(/\/\w+/g, '').trim()
}
return null
}

extrairInfoGuilda($) {
const guildElement = $('li:contains("👥 Guilda:")')
if (!guildElement.length) return null
const guildText = guildElement.text()
const guildMatch = guildText.match(/👥 Guilda:([^\n]+)/)
const levelMatch = guildText.match(/Nível:\s*(\d+)/i)
const membersMatch = guildText.match(/Membros:\s*([\d,]+)/i)
return {
nome: guildMatch ? guildMatch[1].trim() : 'Nenhuma',
nivel: levelMatch ? parseInt(levelMatch[1]) : 0,
membros: membersMatch ? parseInt(membersMatch[1].replace(/\./g, '')) : 0
}
}

extrairIdadeConta($) {
const el = $('.alert.alert-warning.mt-4.shadow-sm');
if (!el.length) return null;
const paragraphText = el.find('p').text().replace(/\s+/g, ' ').trim();
const match = paragraphText.match(/(\d+) anos?,\s*(\d+) meses?\s*e\s*(\d+) dias/);
if (!match) return null;
const anos = parseInt(match[1], 10);
const meses = parseInt(match[2], 10);
const dias = parseInt(match[3], 10);
const totalDias = anos * 365 + meses * 30 + dias;
const strongs = el.find('p strong').map((i, node) => $(node).text().trim()).get();
const percentual = strongs.reverse().find(s => s.endsWith('%')) || null;
const frase = percentual
? `Esta conta é mais antiga que ${percentual} dos jogadores de Free Fire no mundo inteiro!`
: null;
return { anos, meses, dias, totalDias, maisAntigaQue: frase };
}

formatarData(dataStr) {
if (!dataStr) return dataStr
return dataStr.replace(/(\d{2})(\d{2}:\d{2})/g, '$1:$2')
}
normalizeImageUrl(url) {
if (!url) return null
try {
if (url.startsWith('http')) return url
if (url.startsWith('/')) return new URL(url, this.baseUrl).toString()
return new URL(url, this.baseUrl + '/perfil/').toString()
} catch (error) {
return null
}
}
delay(ms) {
return new Promise(resolve => setTimeout(resolve, ms))
}
}

// Exemplo de uso
async function main() {
try {
const scraper = new FreeFireScraper()
const profileId = '1989445071'
const result = await scraper.getProfileData(profileId)
if (result.status) {
console.log(JSON.stringify(result, null, 2))
} else {
console.error('❌ Erro:', result.mensagem)
}
} catch (error) {
console.error('❌ Erro no processo principal:', error.message)
}
}
if (require.main === module) {
main()
}

module.exports = FreeFireScraper