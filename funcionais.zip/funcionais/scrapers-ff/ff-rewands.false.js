//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

/*

 * CRÉDITOS: z E r O input ᴍᴇʟɪ
 * EXEMPLO:
 
const { claimFreeFireReward } = require('./ff-rewands')

app.get('/recompensa', async (req, res) => {
const id = req.query.id
if (!id) {
return res.json({ erro: 'Precisa enviar seu ID! Exemplo: /recompensa?id=12345678' })
}
try {
const resultado = await claimFreeFireReward(userId)
res.json(resultado)
} catch (erro) {
res.json({ sucesso: false, erro: erro.message })
}
})

*/

const puppeteer = require('puppeteer')
const chalk = require('chalk')

async function claimFreeFireReward(userId) {
let browser;
try {
browser = await puppeteer.launch({
headless: true,
args: [
'--no-sandbox',
'--disable-setuid-sandbox',
'--disable-dev-shm-usage',
'--single-process'
],
executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || null
});
const page = await browser.newPage();
await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
await page.goto('https://freefirejornal.com/items-gratis-free-fire/', {
waitUntil: 'networkidle2',
timeout: 60000
});
await page.type('#reward_playerId', userId);
await page.evaluate(() => {
document.querySelector('#reward_submitButton').disabled = false;
});
await Promise.all([
page.waitForNavigation({waitUntil: 'networkidle2'}),
page.click('#reward_submitButton')
]);
await page.waitForSelector('#reward_response', {visible: true, timeout: 15000});
const responseText = await page.$eval('#reward_response', el => el.innerText.trim());
return {
status: true,
criador: "@paulo_mod_domina",
resultados: {
id: userId,
resposta: responseText,
descrição: "E aí, jogador de Free Fire! Quer dar aquele up na sua conta com skins, diamantes e itens exclusivos sem gastar nada? Então cola com a gente! É só colocar o ID da sua conta no formulário aqui embaixo e pronto: você já tá na corrida por recompensas iradas. Todo dia tem novidade, então não vacila — dá uma checada diária pra não perder nenhuma skin ou cubo mágico. Ativa as notificações do site pra ficar por dentro de tudo e garantir seus prêmios antes que acabem!\n\nDepois de resgatar sua recompensa, corre pro correio do jogo pra pegar seus itens. Não apareceu nada? Dá um restart no Free Fire que às vezes isso resolve. As recompensas são por tempo limitado, então fica ligado no site e deixa as notificações on pra ser o primeiro a saber quando pintar algo novo. É sua chance de brilhar nas partidas com itens que todo mundo vai invejar!",
chance_de_ganhar: "Participando das nossas recompensas grátis, você pode faturar itens que vão fazer sua conta se destacar no Free Fire. Olha só o que pode rolar:\n\n• Skins insanas: Armas estilosas, roupas diferenciadas e acessórios que gritam personalidade.\n• Caixas surpresa: Cheias de itens raros pra turbinar seu inventário.\n• Diamantes: A grana do jogo pra você comprar o que quiser.\n• Cubo Mágico: O passe pra desbloquear recompensas épicas.\n• Personagens novos: Heróis com habilidades que vão mudar seu jogo.\n• Emotes e acessórios exclusivos: Mostre seu estilo com danças e itens únicos.\n• Itens sazonais: Tickets, pacotes temáticos e muito mais!"
}
}
} catch (error) {
return {
status: false,
error: `Falha no scraping: ${error.message}`,
criador: "@paulo_mod_domina"
}
} finally {
if (browser) {
await browser.close();
console.log(chalk.magenta('[SCRAPER] Navegador fechado'))
}
}
}

module.exports = { claimFreeFireReward }