//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

/*
Exemplo de uso:

const BannedAccountsScraper = require('./banned-accounts');
const scraper = new BannedAccountsScraper();

// Verificar uma conta
scraper.verificarContaBanida('123456789')
.then(resultado => console.log(resultado))
.catch(erro => console.error(erro));

// Executar no modo CLI: node banned-accounts.js
*/

const axios = require('axios')
const cheerio = require('cheerio')

const CONFIG = {
urlBase: 'https://www.freefiremania.com.br',
timeoutRequisicao: 15000,
headers: {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'Content-Type': 'application/x-www-form-urlencoded',
'Origin': 'https://www.freefiremania.com.br',
'Referer': 'https://www.freefiremania.com.br/conta-banida-free-fire.html',
'X-Requested-With': 'XMLHttpRequest'
}
};

class BannedAccountsScraper {
constructor() {
this.axios = axios.create({
baseURL: CONFIG.urlBase,
headers: CONFIG.headers,
timeout: CONFIG.timeoutRequisicao
});
}

/**
 * Verifica se uma conta está banida pelo ID
 * @param {string} accountId - ID da conta do Free Fire
 * @returns {Promise<Object>} Objeto com o status e os resultados
 */
async verificarContaBanida(accountId) {
try {
const response = await this.axios.post(
'/paginas/checar-conta-banida.php',
`id-free-fire=${encodeURIComponent(accountId)}`
);
const $ = cheerio.load(response.data);
let mensagemStatus = '';
let estaBanido = false;
let motivoBanimento = null;
$('div').each((i, el) => {
const texto = $(el).text().trim();
if (texto.includes('banida') || texto.includes('liberada') || texto.includes('evidências')) {
mensagemStatus = texto;
estaBanido = texto.includes('banida');
if (estaBanido) {
const match = texto.match(/\(([^)]+)\)/);
motivoBanimento = match ? match[1] : 'Motivo não especificado';
}
return false;
}
});
const dataAtual = new Date();
const dataFormatada = dataAtual.toLocaleString('pt-BR', {
day: '2-digit',
month: '2-digit',
year: 'numeric',
hour: '2-digit',
minute: '2-digit',
second: '2-digit',
hour12: false
});
return {
status: true,
criador: '@paulo_mod_domina',
resultados: {
id: accountId,
esta_banido: estaBanido,
mensagem: mensagemStatus || 'Status desconhecido',
motivo_banimento: motivoBanimento,
data_consulta: dataFormatada
//timestamp: dataAtual.getTime()
}
};
} catch (error) {
return {
status: false,
erro: {
codigo: error.response?.status || 500,
mensagem: error.message || 'Erro ao verificar a conta',
detalhes: error.response?.data || null
},
criador: '@paulo_mod_domina'
};
}
}
}

if (require.main === module) {
const scraper = new BannedAccountsScraper();
const readline = require('readline');
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});
console.log('=== Verificador de Contas Banidas do Free Fire ===');
console.log('By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄\n');
const askForId = async () => {
rl.question('Digite o ID da conta (ou "sair" para encerrar): ', async (input) => {
if (input.toLowerCase() === 'sair') {
console.log('Encerrando o verificador...');
rl.close();
return;
}
const accountId = input.trim();
if (!accountId) {
console.log('Por favor, insira um ID válido.\n');
return askForId();
}
console.log('\nVerificando...');
const resultado = await scraper.verificarContaBanida(accountId);
console.log('\n=== RESULTADO ===');
console.log(JSON.stringify(resultado, null, 2));
console.log('=================\n');
askForId();
});
};
askForId()
}

module.exports = BannedAccountsScraper;