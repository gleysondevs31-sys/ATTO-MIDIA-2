//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

/*

EXEMPLO:

const generateTTS = require('./base de dados/google-tts.js')

app.get('/api/tts', async (req, res) => {
const { text, lang, slow } = req.query
if (!text) return res.status(400).json({ error: 'Parâmetro "text" ausente' })
try {
const audioBuffer = await generateTTS(text, lang || 'pt', slow ? slow === 'true' : false)
res.set({
'Content-Type': 'audio/mpeg',
'Content-Length': audioBuffer.length,
'Content-Disposition': 'inline; filename="tts-audio.mp3"',
'Cache-Control': 'public, max-age=3600',
'Accept-Ranges': 'bytes'
})
res.send(audioBuffer)
} catch (error) {
res.status(500).json({ error: 'Erro no TTS', details: error.message })
}
})

*/

const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args))
const googleTTS = require('google-tts-api')

async function generateTTS(text, language = 'id', slow = false) {
try {
if (text.length > 200) {
throw new Error('Texto muito longo (máximo 200 caracteres)')
}
const url = googleTTS.getAudioUrl(text, {
lang: language,
slow: slow,
host: 'https://translate.google.com'
});
const response = await fetch(url)
if (!response.ok) {
throw new Error(`Falha no TTS: ${response.status} ${response.statusText}`)
}
return await response.buffer()
} catch (error) {
console.error("Erro no TTS:", error)
throw new Error(`Falha ao gerar áudio: ${error.message}`)
}
}

module.exports = generateTTS