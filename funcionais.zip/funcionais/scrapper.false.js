/*
• Créditos: @Darkzy7 | @Vitinho | @SabAPIs | @lucas_mod_domina
• Usamos a documentação betabotz-tools, postado por Lann(BetaBotz) no NPMJS. 
• Link do módulo: https://www.npmjs.com/package/betabotz-tools
*/

const fs = require('fs')
const path = require('path')
const axios = require('axios')
const Jimp = require('jimp')
const FormData = require('form-data')

// Função para criar o diretório se não existir
function ensureDirectoryExists(dirPath) {
if (!fs.existsSync(dirPath)) {
fs.mkdirSync(dirPath, { recursive: true })
}
}

const APIKEY__ = ["GfJvbnSm", "6EbqDVxp", "iuicJ7Dn", "P5zrBdRv", "3pXcz2ML", "xnd8ihxp", "XR3UAqFD", "XxuJnFNR"]
const BETA_APIKEY = APIKEY__[Math.floor(Math.random() * APIKEY__.length)]

class ScrapperData {

// FILTRO ZOMBIE
static async imageToZombie(url) {
 const image = await Jimp.read(url);
const buffer = await new Promise((resolve, reject) => {
image.getBuffer(Jimp.MIME_JPEG, (err, buf) => {
if (err) {reject("Ocorreu um erro ao recuperar dados...")} else {resolve(buf)}})});
const form = new FormData();
form.append('image', buffer, {filename: 'tozombie.jpg'});
try {
const { data } = await axios.post("https://tools.betabotz.org/ai/tozombie", form, {headers: { ...form.getHeaders(), 'accept': 'application/json'}});
return {image_data: data.result, image_size: data.size};
} catch (error) {
console.error('Falha na identificação:', error);
return {error:'Falha na identificação.'};
}
}

// FILTRO ANIME
static async imageToAnime(url) {
 const image = await Jimp.read(url);
const buffer = await new Promise((resolve, reject) => {
image.getBuffer(Jimp.MIME_JPEG, (err, buf) => {
if (err) {reject("Ocorreu um erro ao recuperar dados...")} else {resolve(buf)}})});
const form = new FormData();
form.append('image', buffer, {filename: 'tozombie.jpg'});
try {
const { data } = await axios.post("https://tools.betabotz.org/ai/toanime", form, {headers: { ...form.getHeaders(), 'accept': 'application/json'}});
return {image_data: data.result, image_size: data.size};
} catch (error) {
console.error('Falha na identificação:', error);
return {error:'Falha na identificação.'};
}
}

// HD
static vyroEngine(imageData, operation) {
return new Promise(async (resolve, reject) => {
const availableOperations = ["enhance", "recolor", "dehaze"];
if (!availableOperations.includes(operation)) {
operation = availableOperations[0];
}
const baseUrl = "https://inferenceengine.vyro.ai/" + operation + ".vyro";
const formData = new FormData();
formData.append("image", Buffer.from(imageData), {
filename: "enhance_image_body.jpg",
contentType: "image/jpeg",
});
formData.append("model_version", 1, {
"Content-Transfer-Encoding": "binary",
contentType: "multipart/form-data; charset=utf-8",
});
formData.submit(
{
url: baseUrl,
host: "inferenceengine.vyro.ai",
path: "/" + operation,
protocol: "https:",
headers: {
"User-Agent": "okhttp/4.9.3",
"Connection": "Keep-Alive",
"Accept-Encoding": "gzip",
},
},
function (err, res) {
if (err) return reject(err)
const chunks = [];
res.on("data", (chunk) => {
chunks.push(chunk)
});
res.on("end", () => {
resolve(Buffer.concat(chunks))
});
res.on("error", (err) => {
reject(err)
});
}
)
})
}

// REMOVER FUNDO
static async RemoveBG(url) {
const image = await Jimp.read(url);
const buffer = await new Promise((resolve, reject) => {
image.getBuffer(Jimp.MIME_JPEG, (err, buf) => {
if (err) {reject("Ocorreu um erro ao recuperar dados...")} else {resolve(buf)}})});
const form = new FormData();
form.append('image', buffer, {filename: 'tozombie.jpg'});
try {
const { data } = await axios.post("https://tools.betabotz.org/ai/removebg", form, {headers: { ...form.getHeaders(), 'accept': 'application/json'}});
return {image_data: data.result, image_size: data.size};
} catch (error) {
console.error('Falha na identificação:', error);
return {error:'Falha na identificação.'};
}
}

static CapcutDownloader(url) {
return new Promise((resolve, reject) => {
try {
axios.get(`https://tools.betabotz.org/tools/capcutdl?url=`+url).then((res) => {
 resolve({title: res.data.result.title, description: res.data.result.description, fullUse: res.data.result.digunakan, videoOriginal: res.data.result.video_ori, authorProfile: res.data.result.author_profile})
 })
} catch(e) {
 reject(e)
 }
 })
}

static ThreadsDownloader(url) {
return new Promise((resolve, reject) => {
try {
axios.get(`https://tools.betabotz.org/tools/threadsdl?url=`+url).then((res) => {
 resolve(res.data.result)
 })
} catch(e) {
 reject(e)
 }
 })
}

static SpotifyDownloader(url) {
return new Promise((resolve, reject) => {
try {
axios.get(`https://api.betabotz.org/api/download/spotify?url=${url}&apikey=${BETA_APIKEY}`).then((res) => {
 resolve(res.data.result.data)
 })
} catch(e) {
 reject(e)
 }
 })
}

static TwitterDownloader(url) {
return new Promise((resolve, reject) => {
try {
 axios.get(`https://api.lolhuman.xyz/api/twitter?apikey=Space&url=`+url).then((res) => {
 resolve(res.data.result)
 })
} catch(e) {
 reject(e)
 }
 })
}

}

module.exports = new Object({
 toZombie: (url) => ScrapperData.imageToZombie(url),
 toAnime: (url) => ScrapperData.imageToAnime(url),
 vyroEngine: (url) => ScrapperData.vyroEngine(url),
 RemoveBG: (url) => ScrapperData.RemoveBG(url),
 CapcutDL: (url) => ScrapperData.CapcutDownloader(url),
 ThreadsDL: (url) => ScrapperData.ThreadsDownloader(url),
 TwitterDL: (url) => ScrapperData.TwitterDownloader(url),
 SpotifyDL: (url) => ScrapperData.SpotifyDownloader(url)
})