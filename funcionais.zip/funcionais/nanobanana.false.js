const axios = require('axios')
const CryptoJS = require('crypto-js')
const fs = require('fs')
const path = require('path')
const crypto = require('crypto')

const tmpDir = path.join(__dirname, 'tmp')
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir)

const AES_KEY = 'ai-enhancer-web__aes-key'
const AES_IV = 'aienhancer-aesiv'

/* serial fake */
function genSerial() {
  return crypto.randomBytes(16).toString('hex')
}

/* baixar imagem por url */
async function downloadImage(url, filePath) {
  const res = await axios.get(url, { responseType: 'stream' })
  const writer = fs.createWriteStream(filePath)
  res.data.pipe(writer)

  return new Promise((resolve, reject) => {
    writer.on('finish', resolve)
    writer.on('error', reject)
  })
}

/* encriptação AES para settings */
function encryptSettings(obj) {
  return CryptoJS.AES.encrypt(
    JSON.stringify(obj),
    CryptoJS.enc.Utf8.parse(AES_KEY),
    {
      iv: CryptoJS.enc.Utf8.parse(AES_IV),
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    }
  ).toString()
}

/* enhancer */
async function nanoBananaFromUrl(url, prompt) {
  let tempFile
  try {
    const serial = genSerial()
    tempFile = path.join(tmpDir, `nb_${Date.now()}.jpg`)

    await downloadImage(url, tempFile)
    const imgBase64 = fs.readFileSync(tempFile, 'base64')

    const settings = encryptSettings({
      prompt,
      size: '2K',
      aspect_ratio: 'match_input_image',
      output_format: 'jpeg',
      max_images: 1
    })

    const headers = {
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10)',
      'Content-Type': 'application/json',
      'product-serial': serial,
      Origin: 'https://aienhancer.ai',
      Referer: 'https://aienhancer.ai/ai-image-editor'
    }

    // criar job
    const create = await axios.post(
      'https://aienhancer.ai/api/v1/k/image-enhance/create',
      {
        model: 2,
        image: `data:image/jpeg;base64,${imgBase64}`,
        settings
      },
      { headers }
    )

    const id = create.data.data.id

    // polling
    for (let i = 0; i < 15; i++) {
      await new Promise(r => setTimeout(r, 3000))

      const r = await axios.post(
        'https://aienhancer.ai/api/v1/k/image-enhance/result',
        { task_id: id },
        { headers }
      )

      const data = r.data.data

      if (data.status === 'success') {
        return {
          ok: true,
          id,
          output: data.output,
          input: data.input,
          engine: 'nanobanana'
        }
      }

      if (data.status === 'failed') {
        return { ok: false, error: data.error || 'processo falhou' }
      }
    }

    return { ok: false, error: 'timeout sem resultado' }
  } catch (e) {
    return { ok: false, error: e.message }
  } finally {
    if (tempFile && fs.existsSync(tempFile)) fs.unlinkSync(tempFile)
  }
}

module.exports = { nanoBananaFromUrl }