const cheerio = require('cheerio');
const puppeteer = require('puppeteer'); // Use puppeteer completo

async function mediafire(url) {
    return new Promise(async (resolve, reject) => {
        try {
            const browser = await puppeteer.launch({
                headless: true, // Executar no modo headless
            });
            const page = await browser.newPage();
            await page.goto(url, { waitUntil: 'networkidle2' });
            await page.waitForSelector('a[href*="download"]', { timeout: 10000 });
            const content = await page.content();
            const $ = cheerio.load(content);
            const nomeArquivo = $('.filename').first().text().trim();
            const tamanho = $('ul.details li:contains("File size") span').text().trim();
            const dataUpload = $('ul.details li:contains("Uploaded") span').text().trim();
            const link = $('#downloadButton').attr('href');
            const resultado = {
                nome: nomeArquivo.split('.')[0] || link.split('/')[5],
                Data_Upload: dataUpload,
                Tamanho: tamanho,
                Tipo: link.split('/')[5].split('.').pop(),
                Link: link,
            };
            resolve(resultado);
            await browser.close();
        } catch (error) {
            reject(error);
            console.error('Erro:', error);
        }
    });
}

module.exports = { mediafire };