const express = require('express')
const axios = require('axios')
const Tiktok = require('@tobyg74/tiktok-api-dl')
const app = express()
var criador = "@paulo_mod_domina"

// Função Para Extrair O Cookie De Um Site
async function getCookie() {
try {
const { data: cookie } = await axios.get("https://pastebin.com/raw/ELJjcbZT")
return cookie;
} catch (e) {
return { status: "error", message: "Failed to fetch cookie." }
}
}

// Scrapper Extraindo Do Módulo Tiktok
async function tiktokStalk(username) {
try {
username = username.replace("@", "")
const data = await Tiktok.StalkUser(username, { cookie: await getCookie() })
if (!data || !data?.result || !data?.result?.users || !data?.result?.stats) {
return { status: false, message: 'Usuário não encontrado.' }
}
const userData = data.result.users
const statsData = data.result.stats
return {
status: true,
criador: criador,
resultado: {
username: userData.username,
nickname: userData.nickname,
profilePicture: userData.avatarLarger,
description: userData.signature,
verificado: userData.verified,
contaPriv: userData.privateAccount,
contaComercial: userData.commerceUser,
região: userData.region,
seguidores: statsData.followerCount,
seguindo: statsData.followingCount,
amigos: statsData.friendCount,
likes: statsData.heartCount,
videos: statsData.videoCount,
posts: statsData.postCount
}
}
} catch (e) {
return { status: false, message: e.message }
}
}

module.exports = {
tiktokStalk,
getCookie
}