const { instagramGetUrl } = require("instagram-url-direct");

class InstagramDownloader {
  constructor(config = {}) {
    this.config = {
      retries: config.retries || 5,
      delay: config.delay || 1000,
    };
  }

  async getMedia(url) {
    try {
      const result = await instagramGetUrl(url, this.config);
      return {
        status: true,
        criador: "@paulo_mod_domina",
        total: result.results_number,
        resultados: result.media_details.map((media, index) => ({
          tipo: media.type,
          url: media.url,
          index: index,
          ...(media.type === "video" && {
            thumbnail: media.thumbnail,
            views: media.video_view_count,
          }),
          dimensoes: media.dimensions,
        })),
        post_info: {
          caption: result.post_info.caption || "Sem legenda",
          owner_username: result.post_info.owner_username,
          owner_fullname: result.post_info.owner_fullname,
          is_verified: result.post_info.is_verified,
          likes: result.post_info.likes,
          is_private: result.post_info.is_private,
          is_ad: result.post_info.is_ad,
        },
        media_details: result.media_details,
      };
    } catch (error) {
      return {
        status: false,
        criador: "@paulo_mod_domina",
        total: 0,
        resultados: [],
        post_info: { caption: "ERRO INTERNO. CONTATE O SUPORTE" },
        media_details: [],
        error: error.message,
      };
    }
  }

  async getVideoUrls(url) {
    const result = await this.getMedia(url);
    if (!result.status) return [];
    return result.resultados
      .filter((media) => media.tipo === "video")
      .map((media) => media.url);
  }

  async getImageUrls(url) {
    const result = await this.getMedia(url);
    if (!result.status) return [];
    return result.resultados
      .filter((media) => media.tipo === "image")
      .map((media) => media.url);
  }

  async getAllUrls(url) {
    const result = await this.getMedia(url);
    if (!result.status) return [];
    return result.resultados.map((media) => media.url);
  }

  async getPostInfo(url) {
    const result = await this.getMedia(url);
    return result.post_info;
  }
}


module.exports = { InstagramDownloader };
