/**
 * Copilot Scraper (WS → resposta final)
 * by Josué
 *
 * Dep.: npm i ws node-fetch
 */

const WebSocket = require('ws');
const fetch = require('node-fetch');

const copilot = {
  name: 'Microsoft Copilot',
  path: '/api/copilot',
  type: 'get',
  description: 'Chat com o Microsoft Copilot.',
  tags: 'IA',
  params: {
    text: 'Pergunta ou prompt para o Copilot'
  },
  hidden: false,
  isDisable: false,

  code: async (req, res) => {
    try {
      if (copilot.isDisable) {
        return res.json({ status: false, msg: 'rota em manutenção' });
      }

      const question = (req.query.text || '').trim();
      if (!question) {
        return res.status(400).json({ status: false, error: 'Use ?text=' });
      }

      async function createConversationID() {
        const r = await fetch('https://copilot.microsoft.com/c/api/conversations', {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            'user-agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/123 Safari/537.36',
            'origin': 'https://copilot.microsoft.com',
            'referer': 'https://copilot.microsoft.com/',
          },
        });
        if (!r.ok) {
          const t = await r.text().catch(() => '');
          throw new Error(`Conversations ${r.status} ${r.statusText}\n${t.slice(0, 200)}`);
        }
        const j = await r.json();
        if (!j?.id) throw new Error('Resposta sem id de conversa.');
        return j.id;
      }

      async function askCopilot(q) {
        const url =
          'wss://copilot.microsoft.com/c/api/chat?api-version=2&features=-,ncedge,edgepagecontext&setflight=-,ncedge,edgepagecontext&ncedge=1';

        const conversationId = await createConversationID();
        const payload = {
          event: 'send',
          content: [{ type: 'text', text: q }],
          conversationId,
        };

        const full = {
          conversationId,
          messageId: null,
          text: '',
          suggestions: [],
        };

        return new Promise((resolve, reject) => {
          const ws = new WebSocket(url);

          let closed = false;
          const finish = (ok = true) => {
            if (closed) return;
            closed = true;
            try {
              ws.close();
            } catch {}
            ok ? resolve(full) : reject(new Error('encerrado'));
          };

          const killTimer = setTimeout(() => finish(false), 120000); // 120s

          ws.on('open', () => {
            ws.send(JSON.stringify(payload));
          });

          ws.on('message', (buf) => {
            const txt = buf.toString('utf8').trim();
            if (!txt) return;
            const lines = txt.split(/\r?\n/).filter(Boolean);
            for (const line of lines) {
              let data;
              try {
                data = JSON.parse(line);
              } catch {
                continue;
              }

              if (data?.event === 'startMessage') {
                full.messageId = data.messageId;
              } else if (data?.event === 'appendText' && data.messageId === full.messageId) {
                full.text += data.text || '';
              } else if (data?.event === 'suggestedFollowups') {
                full.suggestions = data.suggestions || [];
                clearTimeout(killTimer);
                finish(true);
              } else if (data?.event === 'done') {
                clearTimeout(killTimer);
                finish(true);
              }
            }
          });

          ws.on('error', (err) => {
            clearTimeout(killTimer);
            reject(err);
          });

          ws.on('close', () => {
            clearTimeout(killTimer);
            if (!closed) finish(true);
          });
        });
      }

      const pack = await askCopilot(question);

      return res.json({
        status: true,
        creator: 'Eduh Dev </>',
        conversationId: pack.conversationId,
        messageId: pack.messageId,
        result: (pack.text || '').replace(/\s+$/g, '').replace(/\n{3,}/g, '\n\n'),
        suggestions: (pack.suggestions || []).map((s) => s?.text || s).filter(Boolean),
      });
    } catch (e) {
      return res.status(500).json({
        status: false,
        error: e.message || String(e),
      });
    }
  },
};

module.exports = copilot;

/* Rota Express
app.get("/ia/copilot", async (req, res) => {
  try {
    req.query.text = req.query.query ?? "";
    req.query.model = req.query.model ?? "default";

    const originalJson = res.json.bind(res);

    res.json = (data) => {
      if (typeof data === "object" && data !== null) {
        if (!data.result || String(data.result).trim() === "") {
          data.result = "⚠️ Não consegui gerar uma resposta para sua pergunta.";
        }
        data.criador = "</> 𝑷𝒂𝒖𝒍𝒐 𝑴𝒐𝒅𝒔 ᴶˢ";
      }
      return originalJson(data);
    };

    return await copilot.code(req, res);

  } catch (e) {
    return res.json({
      status: false,
      criador: "</> 𝑷𝒂𝒖𝒍𝒐 𝑴𝒐𝒅𝒔 ᴶˢ",
      erro: e?.message || String(e)
    });
  }
});*/