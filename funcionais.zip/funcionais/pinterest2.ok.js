const axios = require('axios')
const cheerio = require('cheerio')
const chalk = require('chalk')
var criador = "@lucas_mod_domina"

const logInfo = (message) => {
console.log(chalk.blue(message))
}
const logSuccess = (message) => {
console.log(chalk.green.bold(message))
}
const logError = (message) => {
console.log(chalk.red.bold(message))
}
async function searchPinterest(query) {
logInfo(`Iniciando a busca no Pinterest por: "${query}"`)
try {
const searchUrl = `https://id.pinterest.com/search/pins/?autologin=true&q=${encodeURIComponent(query)}`
const response = await axios.get(searchUrl, {
headers: {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
"cookie": "_auth=1; _b=\"AVna7S1p7l1C5I9u0+nR3YzijpvXOPc6d09SyCzO+DcwpersQH36SmGiYfymBKhZcGg=\"; _pinterest_sess=TWc9PSZHamJOZ0JobUFiSEpSN3Z4a2NsMk9wZ3gxL1NSc2k2NkFLaUw5bVY5cXR5alZHR0gxY2h2MVZDZlNQalNpUUJFRVR5L3NlYy9JZkthekp3bHo5bXFuaFZzVHJFMnkrR3lTbm56U3YvQXBBTW96VUgzVUhuK1Z4VURGKzczUi9hNHdDeTJ5Y2pBTmxhc2owZ2hkSGlDemtUSnYvVXh5dDNkaDN3TjZCTk8ycTdHRHVsOFg2b2NQWCtpOWxqeDNjNkk3cS85MkhhSklSb0hwTnZvZVFyZmJEUllwbG9UVnpCYVNTRzZxOXNJcmduOVc4aURtM3NtRFo3STlmWjJvSjlWTU5ITzg0VUg1NGhOTEZzME9SNFNhVWJRWjRJK3pGMFA4Q3UvcHBnWHdaYXZpa2FUNkx6Z3RNQjEzTFJEOHZoaHRvazc1c1UrYlRuUmdKcDg3ZEY4cjNtZlBLRTRBZjNYK0lPTXZJTzQ5dU8ybDdVS015bWJKT0tjTWYyRlBzclpiamdsNmtpeUZnRjlwVGJXUmdOMXdTUkFHRWloVjBMR0JlTE5YcmhxVHdoNzFHbDZ0YmFHZ1VLQXU1QnpkM1FqUTNMTnhYb3VKeDVGbnhNSkdkNXFSMXQybjRGL3pyZXRLR0ZTc0xHZ0JvbTJCNnAzQzE0cW1WTndIK0trY05HV1gxS09NRktadnFCSDR2YzBoWmRiUGZiWXFQNjcwWmZhaDZQRm1UbzNxc21pV1p5WDlabm1UWGQzanc1SGlrZXB1bDVDWXQvUis3elN2SVFDbm1DSVE5Z0d4YW1sa2hsSkZJb1h0MTFpck5BdDR0d0lZOW1Pa2RDVzNySWpXWmUwOUFhQmFSVUpaOFQ3WlhOQldNMkExeDIvMjZHeXdnNjdMYWdiQUhUSEFBUlhUVTdBMThRRmh1ekJMYWZ2YTJkNlg0cmFCdnU2WEpwcXlPOVZYcGNhNkZDd051S3lGZmo0eHV0ZE42NW8xRm5aRWpoQnNKNnNlSGFad1MzOHNkdWtER0xQTFN5Z3lmRERsZnZWWE5CZEJneVRlMDd2VmNPMjloK0g5eCswZUVJTS9CRkFweHc5RUh6K1JocGN6clc1JmZtL3JhRE1sc0NMTFlpMVErRGtPcllvTGdldz0=; _ir=0"
}
})
const $ = cheerio.load(response.data)
const result = []
const videoPromises = []
$('div[data-test-id="pinWrapper"]').each((i, el) => {
const pinLink = $(el).find('a[aria-label]').attr('href')
const fullPinLink = pinLink ? `https://br.pinterest.com${pinLink}` : null
if (fullPinLink) {
videoPromises.push(
axios.get(fullPinLink).then(async res => {
const $ = cheerio.load(res.data)
let videoInfo
try {
videoInfo = JSON.parse($('script[data-test-id="video-snippet"]').text())
} catch (e) {
videoInfo = null
}
if (videoInfo && videoInfo.contentUrl) {
result.push({
type: 'video',
criador: `${criador}`,
titulo: videoInfo.name || 'Sem título',
thumb: videoInfo.thumbnailUrl,
link: videoInfo.contentUrl
})
}
}).catch(e => {
logError(`Erro ao processar o vídeo: ${e.message}`)
})
);
}
})
await Promise.all(videoPromises)
if (result.length > 0) {
logSuccess('Vídeos encontrados.')
return result
} else {
logError('Nenhum vídeo encontrado.')
return []
}
} catch (error) {
logError(`Erro ao buscar por "${query}": ${error.message}`)
return { error: error.message }
}
}

module.exports = { searchPinterest }