//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
const axios = require("axios")
const cheerio = require("cheerio")
const path = require("path")
const util = require("util")
const BodyForm = require('form-data')
const { fromBuffer } = require('file-type')
const fs = require('fs')
const child_process = require('child_process')
const ffmpeg = require('fluent-ffmpeg')
const { unlink } = require('fs').promises
const FormData = require('form-data')

// Função de dormir (delay)
exports.sleep = async (ms) => {
return new Promise(resolve => setTimeout(resolve, ms))
}

// Função para buscar JSON a partir de uma URL
exports.fetchJson = async (url, options = {}) => {
try {
const res = await axios({
method: 'GET',
url: url,
headers: {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'
},
...options
})
return res.data
} catch (err) {
return err
}
}

// Função para buscar Buffer a partir de uma URL
exports.fetchBuffer = async (url, options = {}) => {
try {
const res = await axios({
method: "GET",
url,
headers: {
"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.70 Safari/537.36",
'DNT': 1,
'Upgrade-Insecure-Request': 1
},
...options,
responseType: 'arraybuffer'
})
return res.data
} catch (err) {
return err
}
}

// Função para converter WebP para MP4
exports.webp2mp4File = async (filePath) => {
return new Promise((resolve, reject) => {
const form = new BodyForm()
form.append('new-image-url', '')
form.append('new-image', fs.createReadStream(filePath))
axios({
method: 'post',
url: 'https://s6.ezgif.com/webp-to-mp4',
data: form,
headers: {
'Content-Type': `multipart/form-data; boundary=${form._boundary}`
}
}).then(({ data }) => {
const bodyFormThen = new BodyForm()
const $ = cheerio.load(data)
const file = $('input[name="file"]').attr('value')
bodyFormThen.append('file', file)
bodyFormThen.append('convert', "Convert WebP to MP4!")
axios({
method: 'post',
url: 'https://ezgif.com/webp-to-mp4/' + file,
data: bodyFormThen,
headers: {
'Content-Type': `multipart/form-data; boundary=${bodyFormThen._boundary}`
}
}).then(({ data }) => {
const $ = cheerio.load(data)
const result = 'https:' + $('div#output > p.outfile > video > source').attr('src')
resolve({
status: true,
message: "Created By Lucas Mod Domina",
result: result
})
}).catch(reject)
}).catch(reject)
})
}

// Função para buscar URL
exports.fetchUrl = async (url, options = {}) => {
try {
const res = await axios({
method: 'GET',
url: url,
headers: {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'
},
...options
})
return res.data
} catch (err) {
return err
}
}

// Função para obter a versão do WhatsApp Web
exports.WAVersion = async () => {
let get = await exports.fetchUrl("https://web.whatsapp.com/check-update?version=1&platform=web")
let version = [get.currentVersion.replace(/[.]/g, ", ")]
return version
}

// Função para gerar um nome de arquivo aleatório com extensão
exports.getRandom = (ext) => {
return `${Math.floor(Math.random() * 10000)}${ext}`
}

// Função para verificar se a string é uma URL
exports.isUrl = (url) => {
return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/, 'gi'))
}

// Função para verificar se o valor é um número
exports.isNumber = (number) => {
const int = parseInt(number)
return typeof int === 'number' && !isNaN(int)
}

// Função para upload de arquivos para o Imgur
exports.uploadToImgur = async (Path) => {
return new Promise(async (resolve, reject) => {
try {//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
if (!fs.existsSync(Path)) return reject(new Error("File not Found"))
const imageBuffer = fs.readFileSync(Path);
const base64Image = imageBuffer.toString('base64')
const response = await axios.post('https://api.imgur.com/3/image', {
image: base64Image,
type: 'base64'
}, {
headers: {
'Authorization': 'Client-ID b3db908dbe6a8a1' 
}
})
if (response.data && response.data.data && response.data.data.link) {
resolve(response.data.data.link)
} else {
reject(new Error('Erro no retorno da API do Imgur: ' + JSON.stringify(response.data)))
}
} catch (erro) {
reject(new Error('Erro no upload para o Imgur: ' + erro.message))
}
})
}

// Função para upload de arquivos para o Telegra.ph com fallback para Imgur
exports.TelegraPh = (Path) => {
return new Promise(async (resolve, reject) => {
if (!fs.existsSync(Path)) return reject(new Error("File not Found"))
try {//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
const form = new FormData()
form.append("file", fs.createReadStream(Path))
const data = await axios({
url: "https://telegra.ph/upload",
method: "POST",
headers: {
...form.getHeaders()
},
data: form
})
return resolve("https://telegra.ph" + data.data[0].src)
} catch (err) {
console.log(`Erro no upload para Telegra.ph: ${err.message}. Tentando Imgur...`)
try {
const imgurLink = await exports.uploadToImgur(Path)
return resolve(imgurLink)
} catch (imgurErro) {
return reject(new Error(`Falha no upload tanto para Telegra.ph quanto para Imgur: ${imgurErro.message}`))
}
}
})
}

// Função para converter GIF para MP4 usando ffmpeg
exports.buffergif = async (image) => {
const filename = `${Math.random().toString(36)}`
await fs.writeFileSync(`./audio/${filename}.gif`, image)
child_process.exec(
`ffmpeg -i ./audio/${filename}.gif -movflags faststart -pix_fmt yuv420p -vf "scale=trunc(iw/2)*2:trunc(ih/2)*2" ./audio/${filename}.mp4`
);
await exports.sleep(4000)

const buffer5 = await fs.readFileSync(`./audio/${filename}.mp4`)
Promise.all([unlink(`./audio/${filename}.mp4`), unlink(`./audio/${filename}.gif`)])
return buffer5
}