//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B
const { InferenceClient } = require("@huggingface/inference")
const client = new InferenceClient("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")

async function deepseek(query) {
const chatCompletion = await client.chatCompletion({
provider: "novita",
model: "deepseek-ai/DeepSeek-R1",
messages: [
{
role: "user",
content: query,
},
],
});
let content = chatCompletion.choices[0].message.content;
content = content.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
content = content.replace(/(\*{1,})([^*]+?)\1/g, '*$2*');
return {
status: true,
criador: "@paulo_mod_domina",
resultado: content,
};
}

module.exports = deepseek