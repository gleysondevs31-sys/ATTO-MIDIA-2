const figlet = require("figlet")
const fontes = ["Slant", "Big", "Standard", "3D", "Doom", "Larry 3D", "Shadow", "Block"]
const gerarAscii = (texto) => {
return new Promise((resolve, reject) => {
const fonteAleatoria = fontes[Math.floor(Math.random() * fontes.length)]
figlet.text(texto, { font: fonteAleatoria, horizontalLayout: "default" }, (err, data) => {
if (err) return reject("Erro ao gerar ASCII.")
resolve(data)
})
})
}
if (require.main === module) {
const texto = process.argv.slice(2).join(" ") || "Teste"
gerarAscii(texto)
.then(console.log)
.catch(console.error)
}

module.exports = gerarAscii