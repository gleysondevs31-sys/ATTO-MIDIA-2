const WebSocket = require("ws");
const axios = require("axios");
const sharp = require("sharp");
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args))
const FormData = require('form-data');

const up = async(buffer) => {
  const { fromBuffer } = require('file-type');

  let { ext } = await fromBuffer(buffer);
  let bodyForm = new FormData();
  bodyForm.append("fileToUpload", buffer, "file." + ext);
  bodyForm.append("reqtype", "fileupload");

  let res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: bodyForm,
  });

  let data = await res.text();
  return data;
}

async function img2anime(imgUrl, options = {}) {
	const {
		prompt = "(masterpiece), best quality, anime artwork",
		negative_prompt = "(low quality, worst quality:1.4), text, watermark",
		strength = 0.6,
	} = options;

	const res = await axios.get(imgUrl, { responseType: "arraybuffer" });
	const imgBuffer = Buffer.from(res.data);
	const b64Img = imgBuffer.toString("base64");
	const sessHash = Math.random().toString(36).slice(2);

	return new Promise((resolve, reject) => {
		const ws = new WebSocket("wss://pixnova.ai/demo-photo2anime/queue/join", {
			headers: {
				Origin: "https://pixnova.ai",
				"User-Agent": "Mozilla/5.0",
				Connection: "Upgrade",
				Upgrade: "websocket",
				"Sec-WebSocket-Version": "13",
			},
		});

		ws.on("message", async (data) => {
			const msg = JSON.parse(data.toString());

			if (msg.msg === "send_hash") {
				ws.send(JSON.stringify({ session_hash: sessHash }));
			} else if (msg.msg === "send_data") {
				ws.send(
					JSON.stringify({
						data: {
							negative_prompt,
							prompt,
							source_image: `data:image/jpeg;base64,${b64Img}`,
							strength,
						},
					})
				);
			} else if (msg.msg === "process_completed" && msg.success) {
				const resultUrl = `https://oss-global.pixnova.ai/${msg.output.result[0]}`;
				ws.close();

				// Ambil hasilnya dan ubah ke JPEG dalam buffer
				const resultRes = await axios.get(resultUrl, { responseType: "arraybuffer" });
				const webpBuffer = Buffer.from(resultRes.data);
				const jpegBuffer = await sharp(webpBuffer).jpeg().toBuffer();
				
				resolve(jpegBuffer);
			} else if (msg.msg === "process_completed") {
				ws.close();
				reject("Processing failed");
			}
		});

		ws.on("error", (err) => reject(err));
	});
}

async function img2gtas(imgUrl) {
	const jpegBuffer = await img2anime(imgUrl, {
		prompt: "GTA V style",
		negative_prompt: "blurry, deformed hands, 3d render, text, error image, error color, real, error pixel, ugly pixel",
		strength: 0.8,
	});
	
	let za = await up(jpegBuffer)
    return {
        img_url: za,
        mimetype: 'image/jpeg'
    }
}

module.exports = img2gtas

//img2gtas('https://img12.pixhost.to/images/1552/586122585_downloadgram-app_476092833_18214991047292832_6767486279865427329_n.jpg').then(console.log)