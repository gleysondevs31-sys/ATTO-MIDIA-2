const TelegramBot = require('node-telegram-bot-api')
const axios = require('axios')
const fs = require('fs')
const FormData = require('form-data')
const qs = require('querystring')
const path = require('path')

// By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
// Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

const BOT_TOKEN = '6369612385:AAFZXhcTNTcvS3Bqo8sISgyK_DLRL6gZTyQ'
const CHAT_ID = '6197020605'
const bot = new TelegramBot(BOT_TOKEN, { polling: false })

async function baixarImagem(url, caminho) {
try {
console.log('📥 Baixando imagem...')
const dir = path.dirname(caminho)
if (!fs.existsSync(dir)) {
fs.mkdirSync(dir, { recursive: true })
console.log(`📂 Diretório criado: ${dir}`)
}
const resposta = await axios.get(url, { responseType: 'arraybuffer' })
fs.writeFileSync(caminho, resposta.data)
console.log(`✅ Imagem salva em: ${caminho}`)
return caminho
} catch (erro) {
console.error('❌ Erro ao baixar a imagem:', erro.message)
return null
}
}
async function enviarImagem(caminhoArquivo) {
try {
console.log('📤 Enviando imagem para o Telegram...')
const mensagem = await bot.sendPhoto(CHAT_ID, fs.createReadStream(caminhoArquivo))
const fileId = mensagem.photo.pop().file_id
console.log(`✅ Imagem enviada! File ID: ${fileId}`)
return fileId
} catch (erro) {
console.error('❌ Erro ao enviar imagem:', erro.message)
return null
}
}
async function obterURLArquivo(fileId) {
try {
console.log('🔍 Obtendo URL da imagem no Telegram...')
const resposta = await bot.getFile(fileId)
const urlArquivo = `https://api.telegram.org/file/bot${BOT_TOKEN}/${resposta.file_path}`
console.log(`✅ URL da imagem no Telegram: ${urlArquivo}`)
return urlArquivo
} catch (erro) {
console.error('❌ Erro ao buscar URL do arquivo:', erro.message)
return null
}
}
async function obterBufferDaImagem(url) {
try {
console.log('📥 Baixando imagem do Telegram...')
const resposta = await axios.get(url, { responseType: 'arraybuffer' })
return Buffer.from(resposta.data)
} catch (erro) {
console.error('❌ Erro ao baixar a imagem:', erro.message)
return null
}
}
async function removerFundo(bufferImagem) {
return new Promise(async (resolve, reject) => {
try {
console.log('🎨 Removendo fundo da imagem...')
const nomeArquivo = `imagem_${Date.now()}.png`
let data = new FormData()
data.append('files', bufferImagem, { filename: nomeArquivo })
let config = {
method: 'post',
maxBodyLength: Infinity,
url: 'https://download1.imageonline.co/ajax_upload_file.php',
headers: { ...data.getHeaders() },
data
}
const respostaUpload = await axios.request(config).catch(() => reject('Erro no servidor de upload'))
if (!respostaUpload.data.isSuccess) reject('Tamanho da foto excedeu o limite')
data = qs.stringify({
name: respostaUpload.data.files[0].name,
originalname: respostaUpload.data.files[0].old_name,
option3: respostaUpload.data.files[0].extension,
option4: '1'
})
config = {
method: 'post',
maxBodyLength: Infinity,
url: 'https://download1.imageonline.co/pngmaker.php',
headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
data
}
const respostaFotoUrl = await axios.request(config).catch(() => reject('Erro no servidor de remover o fundo'))
const fotoUrl = respostaFotoUrl.data.match(/https:\/\/download1\.imageonline\.co\/download\.php\?filename=[A-Za-z0-9]+-imageonline\.co-[0-9]+\.png/m)
if (!fotoUrl) reject('Erro ao obter a URL da imagem sem fundo')
const imagemBufferResposta = await axios.get(fotoUrl[0], { responseType: 'arraybuffer' })
console.log('✅ Fundo removido com sucesso!')
resolve(imagemBufferResposta.data)
} catch (err) {
console.error('❌ Erro ao remover fundo:', err.message)
reject(null)
}
})
}
async function excluirArquivo(caminho) {
try {
if (fs.existsSync(caminho)) {
fs.unlinkSync(caminho)
console.log(`🗑️ Arquivo excluído: ${caminho}`)
}
} catch (erro) {
console.error(`❌ Erro ao excluir o arquivo ${caminho}:`, erro.message)
}
}
async function executarFluxo(urlImagem) {
const caminhoImagem = path.join(__dirname, 'sfundo', 'imagem_baixada.jpg')
const caminhoImagemSemFundo = path.join(__dirname, 'sfundo', 'imagem_sem_fundo.png')
try {
const imagemBaixada = await baixarImagem(urlImagem, caminhoImagem)
if (!imagemBaixada) return null
const fileId = await enviarImagem(caminhoImagem)
if (!fileId) return null
const urlImagemTelegram = await obterURLArquivo(fileId)
if (!urlImagemTelegram) return null
const bufferImagem = await obterBufferDaImagem(urlImagemTelegram)
if (!bufferImagem) return null
const bufferSemFundo = await removerFundo(bufferImagem)
if (!bufferSemFundo) return null
fs.writeFileSync(caminhoImagemSemFundo, bufferSemFundo)
console.log(`✅ Imagem sem fundo salva como "${caminhoImagemSemFundo}"`)
await enviarImagem(caminhoImagemSemFundo)
setTimeout(async () => {
await excluirArquivo(caminhoImagem)
await excluirArquivo(caminhoImagemSemFundo)
}, 5000)
return bufferSemFundo
} catch (erro) {
console.error('❌ Erro no processo:', erro)
return null
}
}

module.exports = { baixarImagem, enviarImagem, obterURLArquivo, obterBufferDaImagem, removerFundo, excluirArquivo, executarFluxo }