//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

/*

EXEMPLO:

const getTelegramStickerPack = require('./base de dados/sticker-telegram-download.js')

app.get('/api/telegram-stickers', async (req, res) => {
const stickerUrl = req.query.url
if (!stickerUrl) return res.status(400).json({ error: 'Parâmetro URL ausente' })
try {
const result = await getTelegramStickerPack(stickerUrl)
res.json({
status: true,
criador: `${criador}`,
resultados: {
nome: result.name,
título: result.title,
contagem_de_adesivos: result.sticker_count,
criado_em: result.created_at
},
catbox_links: result.catbox_urls.map(sticker => ({
url: sticker.catbox_url,
emoji: sticker.emoji,
animado: sticker.is_animated,
index: sticker.index
})),
contagem_de_falhas: result.failed_stickers.length,
avisos: result.failed_stickers
})
} catch (error) {
res.status(500).json({ success: false, error: 'Erro no processamento', details: error.message })
}
})

app.get('/api/download-sticker', async (req, res) => {
const stickerUrl = req.query.url
const index = parseInt(req.query.index) || 0
if (!stickerUrl) eturn res.status(400).json({ error: 'Parâmetro URL ausente' })
try {
const pack = await getTelegramStickerPack(stickerUrl)
if (index < 0 || index >= pack.stickers.length) {
return res.status(400).json({ error: 'Índice de sticker inválido' })
}
const sticker = pack.stickers[index]
const filename = `${pack.name}_${index}.${sticker.is_animated ? 'tgs' : 'webp'}`
res.set({
'Content-Type': sticker.is_animated ? 'application/x-tgsticker' : 'image/webp',
'Content-Disposition': `attachment; filename="${filename}"`
})
res.send(sticker.buffer)
} catch (error) {
res.status(500).json({ error: 'Erro no processamento', details: error.message })
}
})

*/

const axios = require('axios')
const FormData = require('form-data')
const { Sticker } = require('wa-sticker-formatter')

const BOT_TOKEN = '6369612385:AAFX2OILvoBbnth2DKcq1RXWj08qe40AGGo'
const API_BASE = `https://api.telegram.org/bot${BOT_TOKEN}`
const CATBOX_API = 'https://catbox.moe/user/api.php'

async function uploadToCatbox(buffer, filename) {
try {
const form = new FormData();
form.append('reqtype', 'fileupload');
form.append('userhash', '5081fa2c5bdb166369cec4199');
form.append('fileToUpload', buffer, {
filename: filename,
contentType: 'application/octet-stream'
});
const response = await axios.post(CATBOX_API, form, {
headers: {
...form.getHeaders(),
'Accept': 'text/plain'
},
responseType: 'text'
});
return response.data;
} catch (error) {
throw new Error(`Catbox upload failed: ${error.message}`);
}
}

async function getTelegramStickerPack(stickerUrl) {
try {
const match = stickerUrl.match(/https:\/\/t\.me\/addstickers\/([^\/\?#]+)/i);
if (!match) throw new Error('URL de sticker inválida');
const packName = match[1];
const { data: packData } = await axios.get(`${API_BASE}/getStickerSet?name=${packName}`);
const stickers = await Promise.all(
packData.result.stickers.map(async (sticker, index) => {
try {
const { data: fileData } = await axios.get(
`${API_BASE}/getFile?file_id=${sticker.file_id}`
);
const fileUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${fileData.result.file_path}`
const { data } = await axios.get(fileUrl, { responseType: 'arraybuffer' });
const buffer = Buffer.from(data);
const isAnimated = sticker.is_animated || fileData.result.file_path.endsWith('.tgs');
const extension = isAnimated ? 'tgs' : 'webp';
const filename = `${packName}_${index}.${extension}`;
const catboxUrl = await uploadToCatbox(buffer, filename);
return {
emoji: sticker.emoji || '❓',
is_animated: isAnimated,
catbox_url: catboxUrl,
telegram_url: fileUrl,
index: index
};
} catch (error) {
console.error(`Erro no sticker ${index}:`, error);
return {
error: `Sticker ${index} falhou: ${error.message}`,
index: index
};
}
})
);
return {
name: packData.result.name,
title: packData.result.title,
sticker_type: packData.result.sticker_type,
sticker_count: packData.result.stickers.length,
catbox_urls: stickers.filter(s => !s.error),
failed_stickers: stickers.filter(s => s.error),
created_at: new Date().toISOString()
};
} catch (error) {
console.error('Erro no processamento:', error)
throw new Error(`Falha ao obter stickers: ${error.message}`)
}
}

module.exports = getTelegramStickerPack