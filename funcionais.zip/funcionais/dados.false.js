const moment = require('moment-timezone');

const fs = require('fs');

const sendHours = (formato) => {
return moment.tz('America/Sao_Paulo').format(formato)}

function saveJSON(inter, caminho) {fs.writeFileSync(caminho, JSON.stringify(inter, null, 2))}

const contarDias = (dataFim, dataInicio = '01/01/0001') => {
    let inicio = dataInicio.split('/').join('-').split('-').reverse().join('-');
    let fim = dataFim.split('/').join('-').split('-').reverse().join('-');

    var d1 = new Date(inicio);
    var d2 = new Date(fim);

    var diferencaEmMilissegundos = Math.abs(d2.getTime() - d1.getTime());

    var milissegundosPorDia = 1000 * 60 * 60 * 24;
    var dias = Math.ceil(diferencaEmMilissegundos / milissegundosPorDia);
    return dias;
}

const randomNumber = (nmr) => {return Math.floor(Math.random()*nmr)}

module.exports = { sendHours, saveJSON, contarDias, randomNumber }



