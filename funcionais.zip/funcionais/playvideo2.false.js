// ytvideo2.js — CommonJS

const crypto = require("crypto");
const fetch = require("node-fetch");

// =======================
// SCRAPER YT1S (CJS)
// =======================
const yt = {
  baseUrl: { origin: "https://v2.yt1s.biz" },

  baseHeaders: {
    accept: "application/json, text/plain, */*",
    "accept-encoding": "gzip, deflate, br, zstd",
    "user-agent":
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36",
    origin: "https://v2.yt1s.biz"
  },

  validateString(str, desc) {
    if (typeof str !== "string" || !str.trim().length)
      throw new Error(`${desc} can't be empty`);
  },

  handleFormat(userFormat) {
    const validFormat = [
      "64kbps","96kbps","128kbps","256kbps","320kbps",
      "144p","240p","360p","480p","720p","1080p"
    ];

    if (!validFormat.includes(userFormat)) {
      throw new Error(`Formato inválido. Use: ${validFormat.join(", ")}`);
    }

    const path = /p$/.test(userFormat) ? "/video" : "/audio";
    const m = userFormat.match(/\d+/);
    const quality = m ? m[0] : "0";

    return { path, quality };
  },

  async hit(description, url, opts) {
    const res = await fetch(url, opts);
    const text = await res.text();

    if (!res.ok) {
      throw new Error(`${description}: ${res.status} ${res.statusText}`);
    }

    try {
      return { data: JSON.parse(text), headers: res.headers };
    } catch {
      return { data: text, headers: res.headers };
    }
  },

  async getSessionToken() {
    const api = "https://fast.dlsrv.online/";
    const { headers } = await this.hit("get session", api, {
      headers: this.baseHeaders
    });

    const token = headers.get("x-session-token");
    if (!token) throw new Error("Session token vazio!");

    return token;
  },

  pow(session, path, startNonce = 0) {
    let nonce = startNonce;
    while (true) {
      const data = `${session}:${path}:${nonce}`;
      const hash = crypto.createHash("sha256").update(data).digest("hex");
      if (hash.startsWith("0000")) {
        return { nonce: String(nonce), powHash: hash };
      }
      nonce++;
    }
  },

  apiSignature(session, path, timestamp) {
    const dataToSign = `${session}:${path}:${timestamp}`;
    const secretKey = "a8d4e2456d59b90c8402fc4f060982aa";
    return crypto
      .createHmac("sha256", secretKey)
      .update(dataToSign)
      .digest("hex");
  },

  async download(videoId, userFormat = "128kbps") {
    this.validateString(videoId, "videoId");
    const { path, quality } = this.handleFormat(userFormat);

    const sessionToken = await this.getSessionToken();
    const timestamp = Date.now().toString();
    const signature = this.apiSignature(sessionToken, path, timestamp);
    const { nonce, powHash } = this.pow(sessionToken, path);

    const headers = {
      "content-type": "application/json",
      "x-api-auth":
        "Ig9CxOQPYu3RB7GC21sOcgRPy4uyxFKTx54bFDu07G3eAMkrdVqXY9bBatu4WqTpkADrQ",
      "x-session-token": sessionToken,
      "x-signature": signature,
      "x-signature-timestamp": timestamp,
      nonce,
      powhash: powHash,
      ...this.baseHeaders
    };

    const api = `https://fast.dlsrv.online/gateway${path}`;
    const body = JSON.stringify({ videoId, quality });

    let attempt = 0;
    while (true) {
      const { data } = await this.hit("download", api, {
        method: "POST",
        headers,
        body
      });

      if (typeof data === "string") {
        if (data.trim() === "OK" && attempt < 5) {
          attempt++;
          await new Promise(r => setTimeout(r, 1500));
          continue;
        }
        throw new Error("Resposta desconhecida do servidor.");
      }

      return data;
    }
  }
};

// =======================
// EXTRACT ID
// =======================
function extractYouTubeId(input) {
  const reg = /(?:v=|youtu\.be\/|shorts\/|embed\/)([a-zA-Z0-9_-]{6,})/;
  const m = input.match(reg);
  return m ? m[1] : input;
}

// =======================
// EXPORTAR FUNÇÃO
// =======================
module.exports = async function ytvideo2(url, format = "1080p") {
  const videoId = extractYouTubeId(url);
  const result = await yt.download(videoId, format);

  const downloadUrl =
    result?.download_url ||
    result?.url ||
    result?.direct_link ||
    result?.link ||
    null;

  if (!downloadUrl) throw new Error("Falha ao obter link final.");

  return {
    status: true,
    videoId,
    format,
    download: downloadUrl
  };
};