/**
 * Scraper YouTube MP4 Search
 * by Josué
 */

const yts = require('yt-search');
const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'Play Vídeo Search',
  path: '/api/ytmp4',
  type: 'get',
  description: 'Baixa vídeo YouTube em MP4 por nome ou link',
  tags: 'Downloads',
  params: {
    text: 'Nome ou link do YouTube'
  },
  hidden: false,
  isDisable: false,
  code: async (req, res, {}) => {
    if (module.exports.isDisable) return res.json({ status: false, msg: 'Manutenção' });

    const text = req.query.text;
    if (!text) return res.status(400).json({ status: false, error: 'Defina ?text=' });

    try {
      let link = text;
      let infoYT;

      if (!/^https?:\/\//i.test(text)) {
        const r = await yts(text);
        if (!r?.videos?.length) return res.json({ status: false, error: 'Nenhum resultado.' });
        infoYT = r.videos[0];
        link = infoYT.url;
      } else {
        const idMatch = text.match(/v=([^&]+)/) || text.match(/be\/([^?]+)/);
        if (idMatch) {
          const r = await yts({ videoId: idMatch[1] });
          infoYT = r;
        }
      }

      const headers = {
        accept: "*/*",
        "accept-language": "pt-BR,pt;q=0.9",
        Referer: "https://id.ytmp3.mobi/"
      };

      const initRes = await fetch(`https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`, { headers });
      const init = await initRes.json();

      const id = infoYT.videoId || (link.match(/v=([^&]+)/)?.[1]);
      const convertUrl = init.convertURL + `&v=${id}&f=mp4&_=${Math.random()}`;
      const convFetch = await fetch(convertUrl, { headers });
      const convert = await convFetch.json();

      let prog = {};
      for (let i = 0; i < 4; i++) {
        const r = await fetch(convert.progressURL, { headers });
        prog = await r.json();
        if (prog.progress === 3) break;
        await new Promise(r2 => setTimeout(r2, 1200));
      }

      if (!convert.downloadURL) return res.json({ status: false, error: 'Falha ao converter.' });

     
      const buffer = await (await fetch(convert.downloadURL)).buffer();
      const nomeFinal = `ytmp4-${Date.now()}.mp4`;
      const dir = path.join(__dirname, '../../public/tmp');
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      const caminho = path.join(dir, nomeFinal);
      fs.writeFileSync(caminho, buffer);

     
      setTimeout(() => {
        fs.unlink(caminho, err => {
          if (err) console.error("Erro ao remover mp4:", err);
          else console.log("Apagado:", nomeFinal);
        });
      }, 60 * 1000);

      res.json({
        status: true,
        title: prog.title || infoYT?.title,
        author: infoYT?.author?.name,
        duration: infoYT?.timestamp,
        thumbnail: infoYT?.image,
        youtube_url: link,
        download_vid_url: `http://${req.headers.host}/tmp/${nomeFinal}`
      });

    } catch (e) {
      res.status(500).json({ status: false, error: e.message });
    }
  }
};