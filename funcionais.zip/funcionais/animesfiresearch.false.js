//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

const axios = require('axios')
const axiosRetry = require('axios-retry').default
const cheerio = require('cheerio')
const { CookieJar } = require('tough-cookie')
const { HttpsProxyAgent } = require('https-proxy-agent')
const crypto = require('crypto')
const chalk = require('chalk')

const CONFIG = {
browserProfiles: ['chrome', 'firefox', 'safari', 'edge'],
requestTimeout: 45000,
}

class ProxyManager {
constructor(config) {
this.config = config
this._agent = new HttpsProxyAgent(`http://${config.auth.username}:${config.auth.password}@${config.host}:${config.port}`)
}

getAgent() {
return this._agent
}
}

const cookieJar = new CookieJar()
const proxyManager = new ProxyManager({
host: 'dc.oxylabs.io',
port: 8001,
auth: {
username: 'user-Lucas_6WMio',
password: 'xNe0AN_4t02HeHe',
},
})

const client = axios.create({
jar: cookieJar,
withCredentials: true,
timeout: CONFIG.requestTimeout,
proxy: false,
})

axiosRetry(client, {
retries: 3,
retryDelay: axiosRetry.exponentialDelay,
retryCondition: (error) => error.response && error.response.status === 403,
})

async function customGet(url, config = {}) {
try {
return await client.get(url, { ...config, httpsAgent: proxyManager.getAgent() })
} catch (error) {
if (error.response && error.response.status === 403) {
console.log(chalk.yellow('Proxy falhou (403). Utilizando IP local: 45.181.238.134'))
return await client.get(url, config)
}
throw error
}
}

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms))
const randomDelay = (min = 500, max = 1500) => Math.floor(Math.random() * (max - min + 1)) + min

class BrowserProfile {
static _hardwareSpecs = {
resolutions: ['3840x2160', '1920x1080', '2560x1440'],
memory: [8, 16, 32],
cores: [4, 8, 12],
}

static generate() {
const profile = CONFIG.browserProfiles[Math.floor(Math.random() * CONFIG.browserProfiles.length)]
const userAgent = this._getUserAgent(profile)
return {
resolution: this._hardwareSpecs.resolutions[Math.floor(Math.random() * this._hardwareSpecs.resolutions.length)],
deviceMemory: this._hardwareSpecs.memory[Math.floor(Math.random() * this._hardwareSpecs.memory.length)],
hardwareConcurrency: this._hardwareSpecs.cores[Math.floor(Math.random() * this._hardwareSpecs.cores.length)],
userAgent,
platform: profile === 'safari' ? 'iPhone' : 'Win32',
securityHash: crypto.createHash('sha3-256').update(crypto.randomBytes(16)).digest('hex').substring(0, 24),
secChUa: `"Chromium";v="125", "Not A;Brand";v="24", "Google Chrome";v="125"`,
secChUaPlatform: profile === 'safari' ? `"iOS"` : `"Windows"`,
secChUaMobile: profile === 'safari' ? '?1' : '?0',
}
}

static _getUserAgent(profile) {
const versions = {
chrome: '125.0.6422.112',
firefox: '127.0.3',
safari: '19.1',
edge: '124.0.2478.51',
}
const agents = {
chrome: `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${versions.chrome} Safari/537.36`,
firefox: `Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:${versions.firefox}) Gecko/20100101 Firefox/${versions.firefox}`,
safari: `Mozilla/5.0 (iPhone; CPU iPhone OS 19_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/${versions.safari} Mobile/15E148 Safari/604.1`,
edge: `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${versions.chrome} Safari/537.36 Edg/${versions.edge}`,
}
return agents[profile]
}
}

class AnimeFire {
static isUrl(url) {
return /^https?:\/\/[\w.-]+(?:\.[\w\.-]+)+[/\w._~:/?#[\]@!$&'()*+,;=-]*$/.test(url)
}

static async getHTML(url, config = {}) {
try {
await sleep(randomDelay())
const profile = BrowserProfile.generate()
const defaultHeaders = {
'User-Agent': profile.userAgent,
'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
'Accept-Language': 'en-US,en;q=0.9',
'Accept-Encoding': 'gzip, deflate, br',
'Connection': 'keep-alive',
'Referer': 'https://animefire.plus/',
'Upgrade-Insecure-Requests': '1',
'Cache-Control': 'max-age=0',
'Sec-Fetch-Dest': 'document',
'Sec-Fetch-Mode': 'navigate',
'Sec-Fetch-Site': 'same-origin',
'Sec-Fetch-User': '?1',
'Sec-CH-UA': profile.secChUa,
'Sec-CH-UA-Platform': profile.secChUaPlatform,
'Sec-CH-UA-Mobile': profile.secChUaMobile,
'DNT': '1'
}
const response = await customGet(url, { headers: defaultHeaders, ...config })
return response.data
} catch (error) {
throw new Error(`Erro ao obter HTML (${url}): ${error.message}`)
}
}

static async search(query) {
try {
await sleep(randomDelay())
const formattedQuery = query
.toLowerCase()
.normalize('NFD')
.replace(/[̀-ͯ]/g, '')
.replace(/\s+/g, '-')
const url = `https://animefire.plus/pesquisar/${formattedQuery}`
const profile = BrowserProfile.generate()
const headers = {
'User-Agent': profile.userAgent,
'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
'Accept-Language': 'en-US,en;q=0.9',
'Accept-Encoding': 'gzip, deflate, br',
'Connection': 'keep-alive',
'Referer': 'https://animefire.plus/',
'Origin': 'https://animefire.plus',
'Upgrade-Insecure-Requests': '1',
'Cache-Control': 'max-age=0',
'Sec-Fetch-Dest': 'document',
'Sec-Fetch-Mode': 'navigate',
'Sec-Fetch-Site': 'same-origin',
'Sec-Fetch-User': '?1',
'Sec-CH-UA': profile.secChUa,
'Sec-CH-UA-Platform': profile.secChUaPlatform,
'Sec-CH-UA-Mobile': profile.secChUaMobile,
'DNT': '1'
}
const response = await customGet(url, {
headers: headers,
jar: cookieJar,
withCredentials: true,
})
const html = response.data
const $ = cheerio.load(html)
const results = []
$('.divCardUltimosEps').each((_, element) => {
const title = $(element).attr('title')
let link = $(element).find('a').attr('href')
const imageUrl = $(element).find('img').attr('data-src')
const rating = $(element).find('.horaUltimosEps').text().trim()
const ageRating = $(element).find('.text-blockCapaAnimeTags span').text().trim()
const [mainTitle, suffix] = title.split('-').map(t => t.trim())
const type = suffix === 'Todos os Episódios' ? 'Série' : suffix === 'Filme' ? 'Filme' : ''
if (type === 'Filme') link = link.replace(/-todos-os-episodios/i, '').trim()
results.push({ mainTitle, link, imageUrl, rating, ageRating, type })
})
return results
} catch (error) {
throw new Error(`Erro na busca: ${error.message}`)
}
}

static async serieInfo(url) {
try {
if (!this.isUrl(url)) throw new Error('URL inválida. Insira uma URL válida.')
await sleep(randomDelay())
const html = await this.getHTML(url)
const $ = cheerio.load(html)
const episodes = []
$('.div_video_list a').each((_, el) => episodes.push({
titulo: $(el).text().trim(),
url: $(el).attr('href'),
}))
const genres = $('.animeInfo .spanGeneros').map((_, el) => $(el).text().trim()).get()
return {
title: $('.div_anime_names h1').text().trim(),
synopsis: $('.divSinopse .spanAnimeInfo').text().trim(),
score: $('#anime_score').text().trim(),
votes: $('#anime_votos').text().trim(),
classification: $('.spanAnimeInfo').first().text().trim(),
studio: $('.animeInfo').eq(2).find('.spanAnimeInfo').text().trim(),
publishDate: $('.animeInfo').eq(6).find('.spanAnimeInfo').text().trim(),
audio: $('.animeInfo').eq(3).find('.spanAnimeInfo').text().trim(),
year: $('.animeInfo').eq(7).find('.spanAnimeInfo').text().trim(),
episodes,
genres,
}
} catch (error) {
throw new Error(`Erro ao obter informações da série: ${error.message}`)
}
}

static async download(link) {
try {
if (!this.isUrl(link)) throw new Error('Esse não é um link válido')
await sleep(randomDelay())
const html = await this.getHTML(link)
const $ = cheerio.load(html)
const nome = $('h1.sectionVideoEpTitle.text-white').text()
const desc = $('#video_sinopse').text()?.trim()
const videoDataUrl = $('#my-video').attr('data-video-src')
if (!videoDataUrl) throw new Error('Link de vídeo não encontrado')
const profile = BrowserProfile.generate()
const headers = {
'User-Agent': profile.userAgent,
'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
'Accept-Language': 'en-US,en;q=0.9',
'Accept-Encoding': 'gzip, deflate, br',
'Connection': 'keep-alive',
'Referer': 'https://animefire.plus/',
'Origin': 'https://animefire.plus',
'Upgrade-Insecure-Requests': '1',
'Cache-Control': 'max-age=0',
'Sec-Fetch-Dest': 'document',
'Sec-Fetch-Mode': 'navigate',
'Sec-Fetch-Site': 'same-origin',
'Sec-Fetch-User': '?1',
'Sec-CH-UA': profile.secChUa,
'Sec-CH-UA-Platform': profile.secChUaPlatform,
'Sec-CH-UA-Mobile': profile.secChUaMobile,
'DNT': '1'
}
const videoDataResponse = await customGet(videoDataUrl, {
headers: headers
})
const videoData = videoDataResponse.data
const videoLinks = videoData.data.map(item => ({
label: item.label,
src: item.src,
}))
return {
status: 200,
autor: 'paulo_mod_domina',
nome,
sinopse: desc.startsWith('Sinopse:') ? desc.slice(9).trim() : desc.trim(),
video_links: videoLinks,
}
} catch (error) {
throw new Error(`Erro no download: ${error.message}`)
}
}
}

async function testProxyConnection() {
try {
const profile = BrowserProfile.generate()
const headers = {
'User-Agent': profile.userAgent,
'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
'Accept-Language': 'en-US,en;q=0.9',
'Accept-Encoding': 'gzip, deflate, br',
'Connection': 'keep-alive',
'Referer': 'https://animefire.plus/',
'Origin': 'https://animefire.plus',
'Upgrade-Insecure-Requests': '1',
'Cache-Control': 'max-age=0',
'Sec-Fetch-Dest': 'document',
'Sec-Fetch-Mode': 'navigate',
'Sec-Fetch-Site': 'same-origin',
'Sec-Fetch-User': '?1',
'Sec-CH-UA': profile.secChUa,
'Sec-CH-UA-Platform': profile.secChUaPlatform,
'Sec-CH-UA-Mobile': profile.secChUaMobile,
'DNT': '1'
}
const response = await customGet('https://httpbin.org/ip', { headers })
console.log(chalk.green('Proxy conectado com sucesso. IP usado:'), response.data.origin)
} catch (error) {
console.error(chalk.red('Erro ao conectar ao proxy:'), error.message)
}
}

module.exports = { AnimeFire, testProxyConnection }