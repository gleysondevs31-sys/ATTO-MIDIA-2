const axios = require('axios');
const qs = require('qs');

// Credenciais para autenticação no Spotify
const credentials = {
    clientId: '271f6e790fb943cdb34679a4adcc34cc',
    clientSecret: 'c009525564304209b7d8b705c28fd294'
};

/**
 * Função para baixar informações e áudio de uma faixa do Spotify.
 * @param {string} url URL da faixa do Spotify a ser baixada
 * @returns {Promise<object>} Objeto contendo informações da faixa e o áudio baixado
 */
async function baixarFaixaSpotify(url) {
    try {
        // Obter informações detalhadas da faixa
        const infoDetalhada = await obterInfoDetalhadaFaixa(url);

        // Obter token de acesso para a API do Spotify
        const accessToken = await obterAccessToken();

        // Configuração do Axios com token de acesso
        const axiosInstance = axios.create({
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            }
        });

        // Requisição para baixar o áudio da faixa
        const response = await axiosInstance({
            method: 'get',
            url: `https://api.spotify.com/v1/tracks/${obterIdFaixa(url)}`,
            responseType: 'json'
        });

        // Construir objeto de resposta
        const resposta = {
            detalhes: infoDetalhada,
            audio: response.data // Aqui você pode ajustar conforme a estrutura de resposta desejada
        };

        return resposta;
    } catch (error) {
        throw new Error('Erro ao baixar faixa do Spotify: ' + error.message);
    }
}

/**
 * Função para obter informações detalhadas de uma faixa do Spotify.
 * @param {string} url URL da faixa do Spotify
 * @returns {Promise<object>} Objeto contendo informações detalhadas da faixa
 */
async function obterInfoDetalhadaFaixa(url) {
    try {
        // Obter token de acesso para a API do Spotify
        const accessToken = await obterAccessToken();

        // Configuração do Axios com token de acesso
        const axiosInstance = axios.create({
            headers: {
                'Authorization': `Bearer ${accessToken}`
            }
        });

        // Requisição para obter informações da faixa
        const response = await axiosInstance({
            method: 'get',
            url: `https://api.spotify.com/v1/tracks/${obterIdFaixa(url)}`
        });

        // Montar objeto com informações detalhadas da faixa
        const detalhes = {
            nome: response.data.name,
            artistas: response.data.artists.map(artist => artist.name).join(', '),
            album: response.data.album.name,
            duracao_ms: response.data.duration_ms,
            popularidade: response.data.popularity,
            preview_url: response.data.preview_url,
            imagem_album: response.data.album.images.length > 0 ? response.data.album.images[0].url : null
        };

        return detalhes;
    } catch (error) {
        throw new Error('Erro ao obter informações da faixa do Spotify: ' + error.message);
    }
}

/**
 * Função auxiliar para obter o ID da faixa a partir da URL do Spotify.
 * @param {string} url URL da faixa do Spotify
 * @returns {string} ID da faixa
 */
function obterIdFaixa(url) {
    const partesUrl = url.split('/');
    return partesUrl[partesUrl.length - 1];
}

/**
 * Função para obter um token de acesso válido para a API do Spotify.
 * @returns {Promise<string>} Token de acesso
 */
async function obterAccessToken() {
    try {
        const response = await axios({
            method: 'post',
            url: 'https://accounts.spotify.com/api/token',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            auth: {
                username: credentials.clientId,
                password: credentials.clientSecret
            },
            data: qs.stringify({
                grant_type: 'client_credentials'
            })
        });

        return response.data.access_token;
    } catch (error) {
        throw new Error('Erro ao obter token de acesso do Spotify: ' + error.message);
    }
}

module.exports = { baixarFaixaSpotify };