//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

const { createCanvas, loadImage } = require('canvas')
const twemoji = require('twemoji')
const emojiRegex = require('emoji-regex')
const fs = require('fs/promises')
const path = require('path')
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args))
const TWEMOJI_CACHE_DIR = path.join(__dirname, 'twemoji-cache')

async function ensureCacheDir() {
try {
await fs.mkdir(TWEMOJI_CACHE_DIR, { recursive: true });
} catch (e) {}
}

async function getTwemojiPng(emoji) {
await ensureCacheDir();
const code = twemoji.convert.toCodePoint(emoji);
const fileName = code + '.png';
const filePath = path.join(TWEMOJI_CACHE_DIR, fileName);
try {
await fs.access(filePath);
return filePath;
} catch {
const url = `https://cdn.jsdelivr.net/gh/twitter/twemoji@latest/assets/72x72/${fileName}`;
try {
const res = await fetch(url);
if (!res.ok) throw new Error('Twemoji not found');
const buffer = await res.buffer();
await fs.writeFile(filePath, buffer);
return filePath;
} catch (e) {
console.error('Erro ao baixar emoji:', url, e);
return null;
}
}
}

function wrapTextLines(ctx, text, maxWidth, font) {
ctx.font = font;
const lines = [];
let line = '';
for (const char of text) {
const testLine = line + char;
const { width } = ctx.measureText(testLine);
if (width > maxWidth && line.length > 0) {
lines.push(line);
line = char;
} else {
line = testLine;
}
}
if (line) lines.push(line);
return lines;
}

function tokenizeWithEmojiRegex(line, twemoji, emojiRegex) {
const regex = emojiRegex();
let tokens = [];
let lastIndex = 0;
let match;
while ((match = regex.exec(line)) !== null) {
const emoji = match[0];
const emojiIndex = match.index;
if (emojiIndex > lastIndex) {
tokens.push({ type: 'text', text: line.slice(lastIndex, emojiIndex) });
}
tokens.push({ type: 'emoji', emoji });
lastIndex = emojiIndex + emoji.length;
}
if (lastIndex < line.length) {
tokens.push({ type: 'text', text: line.slice(lastIndex) });
}
return tokens.length ? tokens : [{ type: 'text', text: line }];
}

async function measureTokenizedLine(ctx, tokens, font, emojiSize) {
let width = 0;
for (const token of tokens) {
if (token.type === 'emoji') {
width += emojiSize;
} else {
ctx.font = font;
width += ctx.measureText(token.text).width;
}
}
return width;
}

async function drawTokenizedLine(ctx, tokens, x, y, font, emojiSize) {
let currX = x;
for (const token of tokens) {
if (token.type === 'emoji') {
try {
const pngPath = await getTwemojiPng(token.emoji);
if (pngPath) {
const img = await loadImage(pngPath);
ctx.drawImage(img, currX, y - emojiSize / 2, emojiSize, emojiSize);
}
currX += emojiSize;
} catch (e) {
console.error('Erro ao renderizar emoji:', token.emoji, e);
currX += emojiSize;
}
} else {
ctx.font = font;
ctx.fillText(token.text, currX, y);
currX += ctx.measureText(token.text).width;
}
}
}

async function drawTextWithEmojis(ctx, text, x, y, maxWidth, font, lineHeight, align = 'center', twemoji, emojiRegex) {
ctx.font = font;
ctx.textBaseline = 'middle';
ctx.textAlign = 'left';
const lines = wrapTextLines(ctx, text, maxWidth, font);
let emojiSize = lineHeight * 0.95;
for (let i = 0; i < lines.length; i++) {
let line = lines[i];
let tokens = tokenizeWithEmojiRegex(line, twemoji, emojiRegex);
const lineWidth = await measureTokenizedLine(ctx, tokens, font, emojiSize);
let startX = x - lineWidth / 2;
await drawTokenizedLine(ctx, tokens, startX, y + i * lineHeight, font, emojiSize);
}
return lines.length;
}

async function drawNglCard(canvas, {
title = 'send me anonymous messages!',
text = '@paulo_mod_domina',
width = 480,
minHeight = 420,
padding = 32,
twemoji = null,
emojiRegex = null
} = {}) {
const ctx = canvas.getContext('2d');
ctx.clearRect(0, 0, canvas.width, canvas.height);
const cardRadius = 32;
const cardWidth = width - padding * 2;
const gradHeightMin = 90;
const whitePad = 32;
const titleFont = "bold 22px Arial, sans-serif";
const textFont = "bold 28px Arial, sans-serif";
const maxTextWidth = cardWidth - 40;
const titleLineHeight = 30;
const textLineHeight = 38;
ctx.font = titleFont;
const titleLines = wrapTextLines(ctx, title, maxTextWidth, titleFont);
ctx.font = textFont;
const textLines = wrapTextLines(ctx, text, maxTextWidth, textFont);
const gradHeight = Math.max(gradHeightMin, titleLines.length * titleLineHeight + 32);
const cardHeight = gradHeight + whitePad + (textLines.length * textLineHeight) + 80;
canvas.width = width;
canvas.height = cardHeight + padding * 2;
ctx.save();
ctx.shadowColor = "rgba(0,0,0,0.18)";
ctx.shadowBlur = 18;
ctx.shadowOffsetY = 6;
ctx.fillStyle = "#fff";
drawRoundedRect(ctx, padding, padding, cardWidth, cardHeight, cardRadius);
ctx.restore();
const grad = ctx.createLinearGradient(padding, padding, padding, padding + gradHeight);
grad.addColorStop(0, "#fd297b");
grad.addColorStop(0.5, "#ff5864");
grad.addColorStop(1, "#ff655b");
ctx.save();
ctx.beginPath();
roundedRectPath(ctx, padding, padding, cardWidth, gradHeight, cardRadius);
ctx.closePath();
ctx.clip();
ctx.fillStyle = grad;
ctx.fillRect(padding, padding, cardWidth, gradHeight);
ctx.restore();
ctx.font = titleFont;
ctx.textAlign = "left";
ctx.textBaseline = "middle";
const titleBlockHeight = titleLines.length * titleLineHeight;
let titleY = padding + gradHeight / 2 - titleBlockHeight / 2 + titleLineHeight / 2;
await drawTextWithEmojis(ctx, title, width / 2, titleY, maxTextWidth, titleFont, titleLineHeight, 'center', twemoji, emojiRegex);
ctx.font = textFont;
ctx.textAlign = "left";
ctx.textBaseline = "middle";
const textBlockHeight = textLines.length * textLineHeight;
let textY = padding + gradHeight + whitePad + (cardHeight - gradHeight - whitePad - 80) / 2 - textBlockHeight / 2 + textLineHeight / 2;
await drawTextWithEmojis(ctx, text, width / 2, textY, maxTextWidth, textFont, textLineHeight, 'center', twemoji, emojiRegex);
const iconY = cardHeight + padding - 40;
ctx.save();
ctx.beginPath();
ctx.arc(width / 2 - 70 + 22, iconY, 22, 0, 2 * Math.PI);
ctx.closePath();
ctx.fillStyle = '#fd297b';
ctx.fill();
ctx.strokeStyle = '#fff';
ctx.lineWidth = 2.2;
ctx.beginPath();
ctx.moveTo(width / 2 - 70 + 8, iconY - 8);
ctx.lineTo(width / 2 - 70 + 36, iconY - 8);
ctx.lineTo(width / 2 - 70 + 36, iconY + 8);
ctx.lineTo(width / 2 - 70 + 8, iconY + 8);
ctx.closePath();
ctx.stroke();
ctx.beginPath();
ctx.moveTo(width / 2 - 70 + 8, iconY - 8);
ctx.lineTo(width / 2 - 70 + 22, iconY + 6);
ctx.lineTo(width / 2 - 70 + 36, iconY - 8);
ctx.stroke();
ctx.restore();
ctx.save();
ctx.beginPath();
ctx.arc(width / 2 + 70 - 22, iconY, 22, 0, 2 * Math.PI);
ctx.closePath();
ctx.fillStyle = "#eee";
ctx.fill();
ctx.strokeStyle = '#bbb';
ctx.lineWidth = 2;
ctx.stroke();
ctx.strokeStyle = "#888";
ctx.lineWidth = 2.5;
ctx.beginPath();
ctx.rect(width / 2 + 70 - 31, iconY - 8, 18, 13);
ctx.moveTo(width / 2 + 70 - 22, iconY - 8);
ctx.lineTo(width / 2 + 70 - 22, iconY - 13);
ctx.arc(width / 2 + 70 - 22, iconY - 2, 4, 0, 2 * Math.PI);
ctx.stroke();
ctx.restore();
}

function drawRoundedRect(ctx, x, y, width, height, radius) {
ctx.beginPath();
ctx.moveTo(x + radius, y);
ctx.lineTo(x + width - radius, y);
ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
ctx.lineTo(x + width, y + height - radius);
ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
ctx.lineTo(x + radius, y + height);
ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
ctx.lineTo(x, y + radius);
ctx.quadraticCurveTo(x, y, x + radius, y);
ctx.closePath();
ctx.fill();
}

function roundedRectPath(ctx, x, y, width, height, radius) {
ctx.beginPath();
ctx.moveTo(x + radius, y);
ctx.lineTo(x + width - radius, y);
ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
ctx.lineTo(x + width, y + height - radius);
ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
ctx.lineTo(x + radius, y + height);
ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
ctx.lineTo(x, y + radius);
ctx.quadraticCurveTo(x, y, x + radius, y);
ctx.closePath();
}

async function generateNglCanvas({ title = 'send me anonymous messages!', text = '@username', width = 480, minHeight = 420 }) {
const tempCanvas = createCanvas(width, minHeight);
const ctx = tempCanvas.getContext('2d');
const cardWidth = width - 32 * 2;
const maxTextWidth = cardWidth - 40;
const titleFont = "bold 22px Arial, sans-serif";
const textFont = "bold 28px Arial, sans-serif";
const titleLineHeight = 30;
const textLineHeight = 38;
ctx.font = titleFont;
const titleLines = wrapTextLines(ctx, title, maxTextWidth, titleFont);
ctx.font = textFont;
const textLines = wrapTextLines(ctx, text, maxTextWidth, textFont);
const gradHeight = Math.max(90, titleLines.length * titleLineHeight + 32);
const cardHeight = gradHeight + 32 + (textLines.length * textLineHeight) + 80;
const canvas = createCanvas(width, cardHeight + 32 * 2);
await drawNglCard(canvas, { title, text, width, minHeight, padding: 32, twemoji, emojiRegex });
return canvas.toBuffer('image/png');
}

module.exports = { drawNglCard, generateNglCanvas }