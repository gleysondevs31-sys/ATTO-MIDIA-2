// FEITA POR 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
// NÃO TIRE MEUS CRÉDITOS SEU RANDOM BAGULHO DEU TRABALHO PRA FAZER

const express = require('express')
const ytdl = require('@distube/ytdl-core')
const yts = require('youtube-yts')
const readline = require('readline')
const ffmpeg = require('fluent-ffmpeg')
const ffmpegPath = require('@ffmpeg-installer/ffmpeg').path
ffmpeg.setFfmpegPath(ffmpegPath)
const NodeID3 = require('node-id3')
const fs = require('fs')
const path = require('path')
const { fetchBuffer } = require("./myfunc2")
const ytM = import('node-youtube-music')
const { randomBytes } = require('crypto')
const audioDir = path.join(__dirname, 'audio')
if (!fs.existsSync(audioDir)) {
fs.mkdirSync(audioDir)
}
const ytIdRegex = /(?:youtube\.com\/\S*(?:(?:\/e(?:mbed))?\/|watch\?(?:\S*?&?v\=))|youtu\.be\/)([a-zA-Z0-9_-]{6,11})/

class YT {
static isYTUrl(url) {
return ytIdRegex.test(url)
}

static getVideoID(url) {
if (!this.isYTUrl(url)) throw new Error('is not YouTube URL')
return ytIdRegex.exec(url)[1]
}

static async WriteTags(filePath, Metadata) {
return NodeID3.write({
title: Metadata.Title,
artist: Metadata.Artist,
originalArtist: Metadata.Artist,
image: {
mime: 'jpeg',
type: { id: 3, name: 'front cover' },
imageBuffer: (await fetchBuffer(Metadata.Image)).buffer,
description: `Cover of ${Metadata.Title}`,
},
album: Metadata.Album,
year: Metadata.Year || ''
}, filePath)
}

static async search(query, options = {}) {
const search = await yts.search({ query, hl: 'id', gl: 'ID', ...options })
return search.videos
}

static async searchTrack(query) {
let ytMusic = await ytM.searchMusics(query)
return ytMusic.map(track => ({
isYtMusic: true,
title: `${track.title} - ${track.artists.map(x => x.name).join(' ')}`,
artist: track.artists.map(x => x.name).join(' '),
id: track.youtubeId,
url: 'https://youtu.be/' + track.youtubeId,
album: track.album,
duration: {
seconds: track.duration.totalSeconds,
label: track.duration.label
},
image: track.thumbnailUrl.replace('w120-h120', 'w600-h600')
}))
}

static async downloadMusic(query) {
try {
const getTrack = Array.isArray(query) ? query : await this.searchTrack(query)
const search = getTrack[0]
const videoInfo = await ytdl.getInfo('https://www.youtube.com/watch?v=' + search.id, { lang: 'id' })
let stream = ytdl(search.id, { filter: 'audioonly', quality: 140 })
let mp4Path = path.join(audioDir, `${randomBytes(3).toString('hex')}.mp4`)
stream.on('error', err => console.log(err))

const file = await new Promise((resolve, reject) => {
ffmpeg(stream)
.audioFrequency(44100)
.audioChannels(2)
.audioBitrate(128)
.audioCodec('libmp3lame')
.audioQuality(5)
.toFormat('mp3')
.save(mp4Path)
.on('end', () => resolve(mp4Path))
.on('error', (err) => reject(err))
})

await this.WriteTags(file, { Title: search.title, Artist: search.artist, Image: search.image, Album: search.album, Year: videoInfo.videoDetails.publishDate.split('-')[0] })
return {
meta: search,
path: file,
size: fs.statSync(mp4Path).size
}
} catch (error) {
throw new Error(error)
}
}

static async mp4(url, quality = 134) {
try {
if (!url) throw new Error('Video ID or YouTube URL is required')

const videoId = this.isYTUrl(url) ? this.getVideoID(url) : url
const videoUrl = `https://www.youtube.com/watch?v=${videoId}`
const videoInfo = await ytdl.getInfo(videoUrl, { lang: 'id' })

if (!videoInfo || !videoInfo.formats) {
throw new Error('Informações do vídeo estão incompletas ou não disponíveis.')
}

const format = ytdl.chooseFormat(videoInfo.formats, { filter: 'audioandvideo', quality: 'highest' })
const stream = ytdl(videoUrl, { format })
const mp4Path = path.join(audioDir, `${randomBytes(3).toString('hex')}.mp4`)

let starttime, total

stream.once('response', (res) => {
total = parseInt(res.headers['content-length'], 10)
starttime = Date.now()
})

stream.on('progress', (chunkLength, downloaded) => {
const percent = (downloaded / total) * 100
const downloadedMB = (downloaded / 1024 / 1024).toFixed(2)
const totalMB = (total / 1024 / 1024).toFixed(2)
const elapsedMinutes = (Date.now() - starttime) / 1000 / 60
const estimatedDownloadTime = (elapsedMinutes / (percent / 100)) - elapsedMinutes

readline.cursorTo(process.stdout, 0)
process.stdout.write(`${percent.toFixed(2)}% downloaded `)
process.stdout.write(`(${downloadedMB}MB of ${totalMB}MB)\n`)
process.stdout.write(`Running for: ${elapsedMinutes.toFixed(2)} minutes`)
process.stdout.write(`, estimated time left: ${estimatedDownloadTime.toFixed(2)} minutes `)
readline.moveCursor(process.stdout, 0, -1)
})

stream.on('end', () => {
process.stdout.write('\n\nDownload completed.\n')
})

stream.on('error', (err) => {
console.error('Stream error:', err)
throw err
})

const mp4File = await new Promise((resolve, reject) => {
ffmpeg(stream)
.videoCodec('libx264')
.audioCodec('aac')
.outputOptions(['-strict -2', '-c:a aac', '-b:a 192k'])
.save(mp4Path)
.on('end', () => {
console.log('Arquivo MP4 criado com sucesso:', mp4Path)
resolve(mp4Path)
})
.on('error', (err) => {
console.error('Erro no ffmpeg:', err)
reject(err)
})
})

return {
title: videoInfo.videoDetails.title,
thumb: videoInfo.videoDetails.thumbnails.slice(-1)[0],
date: videoInfo.videoDetails.publishDate,
duration: videoInfo.videoDetails.lengthSeconds,
channel: videoInfo.videoDetails.ownerChannelName,
quality: format.qualityLabel,
contentLength: format.contentLength,
description: videoInfo.videoDetails.description,
videoUrl: format.url,
path: mp4File
}
} catch (error) {
throw error
}
}

static async mp3(url, metadata = {}, autoWriteTags = false) {
try {
if (!url) throw new Error('Video ID or YouTube Url is required')
url = this.isYTUrl(url) ? 'https://www.youtube.com/watch?v=' + this.getVideoID(url) : url
const { videoDetails } = await ytdl.getInfo(url, { lang: 'id',
requestOptions: {
headers: {
cookie: 'YSC=CWgC4PfP24s; VISITOR_INFO1_LIVE=flOArU6bUuc; VISITOR_PRIVACY_METADATA=CgJCUhIEGgAgSg%3D%3D; _gcl_au=1.1.1479343865.1728537620; HSID=AWvfTwHzGE6SMRC3f; SSID=Ao5GqmAfvfGPIyexf; APISID=crgYppYIT62PmQAn/Ae3Q2yyurx1FzEJ_-; SAPISID=UqiEIVEySqM6RtLo/AF0wRH8Tg8G1xMxy2; __Secure-1PAPISID=UqiEIVEySqM6RtLo/AF0wRH8Tg8G1xMxy2; __Secure-3PAPISID=UqiEIVEySqM6RtLo/AF0wRH8Tg8G1xMxy2; SID=g.a000owhGrRhk6tNJ2UDgyiTD5ZDnezkOR7gXjUSC-ERtgjidkEoznDfc9QO_byBeZf9w-N84zgACgYKAZYSARQSFQHGX2MiFA_Ui1PjmzQ4PCWb0REVARoVAUF8yKq1-f9pli-jXu4UNSp7ZLDn0076; __Secure-1PSID=g.a000owhGrRhk6tNJ2UDgyiTD5ZDnezkOR7gXjUSC-ERtgjidkEoz_gQDgpAsx9LFkN2ipCkHZwACgYKAX4SARQSFQHGX2Mi5tyb0xyve1GL2zYJfokkMBoVAUF8yKpxjDAcwTgkYskjsuaX9KIm0076; __Secure-3PSID=g.a000owhGrRhk6tNJ2UDgyiTD5ZDnezkOR7gXjUSC-ERtgjidkEozXGVF8qY9M7MbsSKnIYgGeQACgYKAY0SARQSFQHGX2Mifm_kUYvU_7tr3njyk-T5xhoVAUF8yKosbd0zTrX8Wr_aO1P--VGP0076; LOGIN_INFO=AFmmF2swRQIge8_rVCt6tQQ4kDS37NTajsFAEK6l7rFW5YGvbCOpXVoCIQCpjh0IV3ThK4aygMtCbpgeCMWsQfnHMlHXv34xwVvrZg:QUQ3MjNmd1hnV0VtTl9lcXdvNXYwZWpIZGZBWjlHYjZBZmN2MU9XSFdhMmgweGhKS3pmS2FKOWxNWlJ3bHFaVWV5c0V0SXdIUUFubWl5TFBKSVhOaXo5YzFNbTJVZEZaR1BiSm90UTROWXFfT1gwd25SQTdRdThvYzJUOHdOZV9ZM2FHUUN1RVJCWXFldkl6OUd0MWlySVhnNnBoZFlFdkZ3; PREF=volume=20&f6=40000080&repeat=NONE&tz=America.Sao_Paulo&f5=30000&f7=100&guide_collapsed=true&autoplay=true; ST-3opvp5=session_logininfo=AFmmF2swRQIge8_rVCt6tQQ4kDS37NTajsFAEK6l7rFW5YGvbCOpXVoCIQCpjh0IV3ThK4aygMtCbpgeCMWsQfnHMlHXv34xwVvrZg%3AQUQ3MjNmd1hnV0VtTl9lcXdvNXYwZWpIZGZBWjlHYjZBZmN2MU9XSFdhMmgweGhKS3pmS2FKOWxNWlJ3bHFaVWV5c0V0SXdIUUFubWl5TFBKSVhOaXo5YzFNbTJVZEZaR1BiSm90UTROWXFfT1gwd25SQTdRdThvYzJUOHdOZV9ZM2FHUUN1RVJCWXFldkl6OUd0MWlySVhnNnBoZFlFdkZ3; __Secure-1PSIDTS=sidts-CjIBQT4rX5HkQik0-jY4_x3bGZ9xUCx7xGg3hx75IVBoeMqYFX2TQZQvaUHciHHccaparBAA; __Secure-3PSIDTS=sidts-CjIBQT4rX5HkQik0-jY4_x3bGZ9xUCx7xGg3hx75IVBoeMqYFX2TQZQvaUHciHHccaparBAA; SIDCC=AKEyXzWnFF5rqfY34zuW8nE9F5pcrSA1fN8iF0lIVrlMzyI-EfpyT0_j0pG_TiZ2zI5msQyDmtVT; __Secure-1PSIDCC=AKEyXzVZG1xAvqhbRHY_dGRT0B8JlNauxzAM6uErX8tKa5FmrMkLiNI7IfMYvNAX88AjHWkFx2A; __Secure-3PSIDCC=AKEyXzVWFObS2whzEmamHOL7mp1n7WN4BxMsoE3JbZ5LphsPw8QaUpG0FBOkUXb2V3PvfqGKHt4'
}
}
})
let stream = ytdl(url, { filter: 'audioonly', quality: 140 })
let mp4Path = path.join(audioDir, `${randomBytes(3).toString('hex')}.mp4`)

let starttime
stream.once('response', () => {
starttime = Date.now()
})
stream.on('progress', (chunkLength, downloaded, total) => {
const percent = downloaded / total
const downloadedMinutes = (Date.now() - starttime) / 1000 / 60
const estimatedDownloadTime = (downloadedMinutes / percent) - downloadedMinutes
readline.cursorTo(process.stdout, 0)
process.stdout.write(`${(percent * 100).toFixed(2)}% downloaded `)
process.stdout.write(`(${(downloaded / 1024 / 1024).toFixed(2)}MB of ${(total / 1024 / 1024).toFixed(2)}MB)\n`)
process.stdout.write(`running for: ${downloadedMinutes.toFixed(2)}minutes`)
process.stdout.write(`, estimated time left: ${estimatedDownloadTime.toFixed(2)}minutes `)
readline.moveCursor(process.stdout, 0, -1)
})
stream.on('end', () => process.stdout.write('\n\n'))
stream.on('error', err => console.log(err))

const file = await new Promise((resolve, reject) => {
console.log('Iniciando ffmpeg com o caminho:', mp4Path)
ffmpeg(stream)
.audioFrequency(44100)
.audioChannels(2)
.audioBitrate(128)
.audioCodec('libmp3lame')
.audioQuality(5)
.toFormat('mp3')
.save(mp4Path)
.on('end', () => {
console.log('Arquivo MP3 criado com sucesso:', mp4Path)
resolve(mp4Path)
})
.on('error', (err) => {
console.error('Erro no ffmpeg:', err)
reject(err)
})
})

if (Object.keys(metadata).length !== 0) {
await this.WriteTags(file, metadata)
}
if (autoWriteTags) {
await this.WriteTags(file, { Title: videoDetails.title, Album: videoDetails.author.name, Year: videoDetails.publishDate.split('-')[0], Image: videoDetails.thumbnails.slice(-1)[0].url })
}
return {
meta: {
title: videoDetails.title,
channel: videoDetails.author.name,
seconds: videoDetails.lengthSeconds,
image: videoDetails.thumbnails.slice(-1)[0].url
},
path: file,
size: fs.statSync(mp4Path).size
}
} catch (error) {
throw error
}
}
}

module.exports = YT