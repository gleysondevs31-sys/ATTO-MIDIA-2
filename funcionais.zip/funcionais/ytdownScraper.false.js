//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Vb69bDnAe5VmzSMwBH11

require('dotenv').config();
const axios = require("axios");
const FormData = require("form-data");
const crypto = require("crypto");
const criador = process.env.CRIADOR

function generateCookies() {
const timestamp = Date.now();
const phpsessid = crypto
.createHash('md5')
.update(timestamp.toString())
.digest('hex')
.substring(0, 26);
const gaClientId = `GA1.1.${timestamp}.${crypto.randomInt(1000000000, 9999999999)}`;
const gaSessionId = `GS2.1.s${timestamp}${String(Math.random()).substring(2, 4)}$${crypto.randomInt(0, 2)}$${crypto.randomInt(0, 2)}$${timestamp}$${crypto.randomInt(10, 99)}$${crypto.randomInt(0, 1)}$${crypto.randomInt(0, 1)}`;
return `PHPSESSID=${phpsessid}; _ga=${gaClientId}; _ga_2K69M9RN1B=${gaSessionId}`;
}

async function obterUrlFinal(urlProcessamento, tentativas = 0, maxTentativas = 10) {
try {
console.log(`[DEBUG] Tentativa ${tentativas + 1}/${maxTentativas} - Buscando URL: ${urlProcessamento}`);
const response = await axios.get(urlProcessamento, {
headers: {
"accept": "*/*",
"accept-language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
"referer": "https://ytdown.to/",
"sec-ch-ua": '"Google Chrome";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
"sec-ch-ua-mobile": "?1",
"sec-ch-ua-platform": '"Android"',
"sec-fetch-dest": "empty",
"sec-fetch-mode": "cors",
"sec-fetch-site": "cross-site",
"user-agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36"
},
timeout: 15000,
decompress: true, // Força descompressão automática
responseType: 'json' // Espera JSON na resposta
});
const data = response.data;
console.log(`[DEBUG] Resposta recebida:`, JSON.stringify(data, null, 2));
if (data.percent === "Completed" && data.fileUrl) {
console.log(`[DEBUG] ✅ Download pronto! URL: ${data.fileUrl}`);
return {
status: true,
urlDownload: data.fileUrl,
nomeArquivo: data.fileName,
tamanhoArquivo: data.fileSize,
processId: data.processId
};
}
if (data.percent && data.percent !== "Completed" && tentativas < maxTentativas) {
const delayMs = 2000 + (tentativas * 500); // Aumenta o delay progressivamente
console.log(`[DEBUG] ⏳ Processamento em ${data.percent}%. Aguardando ${delayMs}ms...`);
await new Promise(resolve => setTimeout(resolve, delayMs));
return obterUrlFinal(urlProcessamento, tentativas + 1, maxTentativas);
}
console.log(`[DEBUG] ❌ Falha: ${JSON.stringify(data)}`);
return {
status: false,
mensagem: `Não foi possível obter a URL de download. Status: ${data.percent || 'desconhecido'}`
};
} catch (error) {
console.error(`[DEBUG] ❌ Erro na requisição:`, error.message);
if (error.response) {
console.error(`[DEBUG] Status HTTP: ${error.response.status}`);
console.error(`[DEBUG] Resposta:`, error.response.data);
}
return {
status: false,
mensagem: "Erro ao obter URL final: " + error.message
};
}
}

async function ytdown2(url) {
try {
const form = new FormData();
form.append("url", url);
const cookies = generateCookies();
const headers = {
"accept": "*/*",
"accept-encoding": "gzip, deflate, br, zstd",
"accept-language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
"cookie": cookies,
"origin": "https://ytdown.to",
"priority": "u=1, i",
"referer": "https://ytdown.to/pt/",
"sec-ch-ua": '"Google Chrome";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
"sec-ch-ua-mobile": "?1",
"sec-ch-ua-platform": '"Android"',
"sec-fetch-dest": "empty",
"sec-fetch-mode": "cors",
"sec-fetch-site": "same-origin",
"user-agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36",
"x-requested-with": "XMLHttpRequest",
...form.getHeaders()
};
const response = await axios.post("https://ytdown.to/proxy.php", form, { headers });
const data = response.data;
if (!data || !data.api || data.api.status !== "OK") {
return {
status: false,
criador,
mensagem: "Erro ao processar o vídeo"
};
}
const videos = data.api.mediaItems
.filter(item => item.type === "Video")
.sort((a, b) => {
const qualityOrder = { "FHD": 3, "HD": 2, "SD": 1 };
return (qualityOrder[b.mediaQuality] || 0) - (qualityOrder[a.mediaQuality] || 0);
});
const audios = data.api.mediaItems
.filter(item => item.type === "Audio")
.sort((a, b) => {
const getKbps = (quality) => parseInt(quality.replace('K', '')) || 0;
return getKbps(b.mediaQuality) - getKbps(a.mediaQuality);
});
return {
status: true,
criador,
resultado: {
id: data.api.id,
titulo: data.api.title,
descricao: data.api.description,
linkPermanente: data.api.permanentLink,
imagemPreview: data.api.imagePreviewUrl,
duracao: videos[0]?.mediaDuration || audios[0]?.mediaDuration || "00:00",
informacoesCanal: {
nome: data.api.userInfo.name,
usuario: data.api.userInfo.username,
biografia: data.api.userInfo.userBio,
avatar: data.api.userInfo.userAvatar,
urlInterna: data.api.userInfo.internalUrl,
urlExterna: data.api.userInfo.externalUrl,
pais: data.api.userInfo.accountCountry,
dataEntrada: data.api.userInfo.dateJoined,
verificado: data.api.userInfo.isVerified
},
estatisticas: {
totalVideos: data.api.mediaStats.mediaCount,
inscritos: data.api.mediaStats.followersCount,
visualizacoes: data.api.mediaStats.viewsCount
},
videos: videos.map(v => ({
nome: v.name,
qualidade: v.mediaQuality,
resolucao: v.mediaRes,
formato: v.mediaExtension,
tamanho: v.mediaFileSize,
duracao: v.mediaDuration,
urlProcessamento: v.mediaUrl,
urlPreview: v.mediaPreviewUrl,
thumbnail: v.mediaThumbnail
})),
audios: audios.map(a => ({
nome: a.name,
qualidade: a.mediaQuality,
formato: a.mediaExtension,
tamanho: a.mediaFileSize,
duracao: a.mediaDuration,
urlProcessamento: a.mediaUrl,
urlPreview: a.mediaPreviewUrl,
thumbnail: a.mediaThumbnail
}))
}
};
} catch (error) {
return {
status: false,
criador,
mensagem: "Erro ao processar requisição: " + error.message
};
}
}

async function obterVideo(url, formatoDesejado = '1080') {
const resultado = await ytdown2(url);
if (!resultado.status) return resultado;
const videos = resultado.resultado.videos;
if (!videos || videos.length === 0) {
return {
status: false,
criador,
mensagem: "Nenhum vídeo disponível para download"
};
}
const mapaQualidade = {
'1080': 'FHD',
'720': 'HD',
'480': 'SD',
'360': 'SD',
'240': 'SD',
'144': 'SD'
};
const qualidadeDesejada = mapaQualidade[formatoDesejado] || 'FHD';
let videoEscolhido = videos.find(v => 
v.resolucao.includes(formatoDesejado) || v.qualidade === qualidadeDesejada
);
if (!videoEscolhido) {
videoEscolhido = videos[0];
}
const urlFinal = await obterUrlFinal(videoEscolhido.urlProcessamento);
if (!urlFinal.status) {
return {
status: false,
criador,
mensagem: urlFinal.mensagem || "Erro ao obter URL de download"
};
}
return {
status: true,
criador,
resultado: {
titulo: resultado.resultado.titulo,
thumbnail: resultado.resultado.imagemPreview,
duracao: resultado.resultado.duracao,
download: urlFinal.urlDownload,
nomeArquivo: urlFinal.nomeArquivo,
qualidade: videoEscolhido.qualidade,
resolucao: videoEscolhido.resolucao,
tamanho: urlFinal.tamanhoArquivo || videoEscolhido.tamanho,
formato: videoEscolhido.formato
}
};
}

async function obterAudio(url, formatoDesejado = 'mp3') {
const resultado = await ytdown2(url);
if (!resultado.status) return resultado;
const audios = resultado.resultado.audios;
if (!audios || audios.length === 0) {
return {
status: false,
criador,
mensagem: "Nenhum áudio disponível para download"
};
}
const audioEscolhido = audios[0];
const urlFinal = await obterUrlFinal(audioEscolhido.urlProcessamento);
if (!urlFinal.status) {
return {
status: false,
criador,
mensagem: urlFinal.mensagem || "Erro ao obter URL de download"
};
}
return {
status: true,
criador,
resultado: {
titulo: resultado.resultado.titulo,
thumbnail: resultado.resultado.imagemPreview,
duracao: resultado.resultado.duracao,
download: urlFinal.urlDownload,
nomeArquivo: urlFinal.nomeArquivo,
qualidade: audioEscolhido.qualidade,
tamanho: urlFinal.tamanhoArquivo || audioEscolhido.tamanho,
formato: audioEscolhido.formato
}
};
}

module.exports = { ytdown2, generateCookies, obterVideo, obterAudio, obterUrlFinal }