const { yts, ytmp4, ytmp3, alldl, ai } = require("@hiudyy/ytdl")

async function downloadMp4(url) {
return await ytmp4(url)
}

async function downloadMp3(url) {
return await ytmp3(url)
}

module.exports = { downloadMp4, downloadMp3 }