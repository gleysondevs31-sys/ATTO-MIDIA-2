const fs = require('fs')
const path = require('path')
const ytdl = require('@distube/ytdl-core')
const ffmpeg = require('fluent-ffmpeg')

//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

const yt_agent = ytdl.createAgent([
{ 
name: 'cookie1', 
value: 'GPS=1; YSC=CkypMSpfgiI; VISITOR_INFO1_LIVE=4nF8vxPW1gU; VISITOR_PRIVACY_METADATA=CgJCUhIEGgAgZA%3D%3D; PREF=f6=40000000&tz=America.Sao_Paulo; SID=g.a000lggw9yBHfdDri-OHg79Bkk2t6L2X7cbwK7jv8BYZZa4Q1hDbH4SZC5IHPqi_QBmSiigPHAACgYKAYgSARASFQHGX2Mi3N21zLYOMAku61_CaeccrxoVAUF8yKo3X97N4REFyHP4du4RIo1b0076; __Secure-1PSIDTS=sidts-CjIB3EgAEmNr03Tidygwml9aTrgDf0woi14K6jndMv5Ox5uI22tYDMNEYiaAoEF0KjGYgRAA; __Secure-3PSIDTS=sidts-CjIB3EgAEmNr03Tidygwml9aTrgDf0woi14K6jndMv5Ox5uI22tYDMNEYiaAoEF0KjGYgRAA; __Secure-1PSID=g.a000lggw9yBHfdDri-OHg79Bkk2t6L2X7cbwK7jv8BYZZa4Q1hDbYpnHl6jq9y45aoBaqMd96QACgYKAR4SARASFQHGX2MiqFuOgRtuIS_FKmulaCrckxoVAUF8yKpX5r8ISh5S5eQ4eofBuyCg0076; __Secure-3PSID=g.a000lggw9yBHfdDri-OHg79Bkk2t6L2X7cbwK7jv8BYZZa4Q1hDb_8Q3teG8nn23ceeF8jiOvwACgYKAY0SARASFQHGX2MiwBtnenbu4CRMpjQza-asfhoVAUF8yKoFXx_Zxl4MvxGnWSSsnv1z0076; HSID=AWgIQn3iifuaU_eRW; SSID=AR8Jlj2XTnPAmL5kf; APISID=l6PTqM9Dy8G_2E6P/A-sAusHOyG1pQ3T75; SAPISID=OSmwE6VjdFmB1u5-/A2N-7DiRQUreUSpgT; __Secure-1PAPISID=OSmwE6VjdFmB1u5-/A2N-7DiRQUreUSpgT; __Secure-3PAPISID=OSmwE6VjdFmB1u5-/A2N-7DiRQUreUSpgT; LOGIN_INFO=AFmmF2swRQIgShGx2tfQkQV4F8lyKnh4mwj54yTOPJqEdI44sDTtsrwCIQD870Le1gTMDFpz7rRHS6Fk0HzraG_SxHw_PdyLjUDXxg:QUQ3MjNmeVpqbVhSQlNCMnFFZXBKQkhCTHJxY1NXOVlYcG50SHNNOGxGZGZ3Z2ZobWwyOW95WGJ2LVplelNaZ0RfbGU3Tm1uYktDdHBnVm9fd3N3T0NncVpTN0ZaNlRoTTVETDJHSjV6QkxUWmdYWGx0eVFYeEFqa0gxUGdBYUJKbG5oQ2pBd3RBb0ROWXBwcFQwYkpBRktEQXlWbmZIbHJB; SIDCC=AKEyXzXkXTftuhPOtObUSCLHxp1byOAtlesMkptSGp8hyE3d97Dvy2UHd4-2ePWBpzUbQhV6; __Secure-1PSIDCC=AKEyXzXlrhkCIONPS4jCvhmtFb8nAKr8fEFCCFEFqN8BKyrw8tKHFh3-r8EWjrqjAKH9Z9fq0A; __Secure-3PSIDCC=AKEyXzWLIbNbh8dxdyKhTafkyKIbEBwVKGR4lNRhhYX5u_v1k4vBnu4eAS9lgpP-JK2PgiSDJw'
}
], {
requestOptions: {
headers: {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
'Accept-Language': 'en-US,en;q=0.9',
'Referer': 'https://www.youtube.com/',
'Origin': 'https://www.youtube.com/'
}
}
})

/**
 * Função para baixar apenas o áudio (MP3)
 */
async function baixarMP3(url) {
return new Promise((resolve, reject) => {
const output = path.join(__dirname, 'audio', 'audio.mp3')
const audioStream = ytdl(url, { quality: 'highestaudio', filter: 'audioonly', agent: yt_agent })
const writeStream = fs.createWriteStream(output)
audioStream.pipe(writeStream)
writeStream.on('finish', () => {
console.log(`Áudio salvo como: ${output}`)
resolve(output)
})
writeStream.on('error', reject)
})
}

/**
 * Função para baixar vídeo e áudio juntos e mesclar com FFmpeg
 */
async function baixarMP4(url) {
const videoFile = path.join(__dirname, 'video', 'temp_video.mp4')
const audioFile = path.join(__dirname, 'audio', 'temp_audio.mp3')
const output = path.join(__dirname, 'video', 'video.mp4')
try {
console.log('Baixando vídeo e áudio...')
await Promise.all([
new Promise((resolve, reject) => {
const videoStream = ytdl(url, { quality: 'highestvideo', agent: yt_agent })
const videoWriteStream = fs.createWriteStream(videoFile)
videoStream.pipe(videoWriteStream)
videoWriteStream.on('finish', () => resolve(videoFile))
videoWriteStream.on('error', reject)
videoStream.on('error', reject)
}),
new Promise((resolve, reject) => {
const audioStream = ytdl(url, { quality: 'highestaudio', filter: 'audioonly', agent: yt_agent })
const audioWriteStream = fs.createWriteStream(audioFile)
audioStream.pipe(audioWriteStream)
audioWriteStream.on('finish', () => resolve(audioFile))
audioWriteStream.on('error', reject)
audioStream.on('error', reject)
})
])
console.log('Mesclando vídeo e áudio...')
await new Promise((resolve, reject) => {
ffmpeg()
.input(videoFile)
.input(audioFile)
.outputOptions('-c:v copy')
.outputOptions('-c:a aac')
.output(output)
.on('end', () => {
console.log(`Vídeo finalizado: ${output}`)
resolve(output)
})
.on('error', reject)
.run()
})
setTimeout(() => {
[videoFile, audioFile].forEach(file => {
if (fs.existsSync(file)) {
fs.unlinkSync(file)
console.log(`Arquivo deletado: ${file}`)
}
})
}, 15000)
return output
} catch (error) {
console.error('Erro:', error)
throw error
}
}

module.exports = { baixarMP3, baixarMP4 }