const { instagramGetUrl } = require("instagram-url-direct");

class InstagramDownloader {
  constructor(config = {}) {
    this.config = {
      retries: config.retries || 5,
      delay: config.delay || 1000,
    };
  }

  async getMedia(url) {
    try {
      const result = await instagramGetUrl(url, this.config);

      console.log(`[SUCESSO IGDL]`);

      return {
        status: true,
        criador: "@paulo_mod_domina",
        total: result.results_number,
        resultados: result.media_details.map((media, index) => ({
          tipo: media.type,
          url: media.url,
          index: index,
          ...(media.type === "video" && {
            thumbnail: media.thumbnail,
            views: media.video_view_count,
          }),
          dimensoes: media.dimensions,
        })),
        post_info: {
          caption: result.post_info.caption || "Sem legenda",
          owner_username: result.post_info.owner_username,
          owner_fullname: result.post_info.owner_fullname,
          is_verified: result.post_info.is_verified,
          likes: result.post_info.likes,
          is_private: result.post_info.is_private,
          is_ad: result.post_info.is_ad,
        },
        media_details: result.media_details,
      };
    } catch (error) {
      console.error(`[ERRO IGDL]: ${error}`);
      return {
        status: false,
        criador: "@paulo_mod_domina",
        total: 0,
        resultados: [],
        post_info: { caption: "ERRO INTERNO. CONTATE O SUPORTE" },
        media_details: [],
        error: error.message,
      };
    }
  }

  async getVideoUrls(url) {
    const result = await this.getMedia(url);
    if (!result.status) return [];

    return result.resultados
      .filter((media) => media.tipo === "video")
      .map((media) => media.url);
  }

  async getImageUrls(url) {
    const result = await this.getMedia(url);
    if (!result.status) return [];

    return result.resultados
      .filter((media) => media.tipo === "image")
      .map((media) => media.url);
  }

  async getAllUrls(url) {
    const result = await this.getMedia(url);
    if (!result.status) return [];

    return result.resultados.map((media) => media.url);
  }

  async getPostInfo(url) {
    const result = await this.getMedia(url);
    return result.post_info;
  }

  handleError(error) {
    if (error.message.includes("Only posts/reels supported")) {
      console.error("[IGDL] URL inválida ou tipo de conteúdo não suportado");
    } else if (error.message.includes("Failed instagram request")) {
      console.error(
        "[IGDL] Falha na requisição ao Instagram (rate limit ou bloqueio)",
      );
    } else if (error.message.includes("CSRF token not found")) {
      console.error("[IGDL] Falha ao obter token CSRF do Instagram");
    } else {
      console.error("[IGDL] Erro desconhecido:", error.message);
    }
  }
}

async function main() {
  const downloader = new InstagramDownloader({
    retries: 3,
    delay: 2000,
  });

/*  try {
    const url =
      "https://www.instagram.com/reel/DSv5JdDjP92/?igsh=MW5jZXF4ZXBsNXV3eg==";

    const media = await downloader.getMedia(url);
    console.log("Resultado:", JSON.stringify(media, null, 2));

    if (media.status) {
      console.log(`Total de mídias: ${media.total}`);
      media.resultados.forEach((item) => {
        console.log(`[${item.index}] ${item.tipo}: ${item.url}`);
      });
    }
  } catch (error) {
    console.error("[ERRO IGDL]:", error);
  }
}

main();*/

module.exports = { InstagramDownloader };
