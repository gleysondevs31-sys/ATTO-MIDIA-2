/*
  Scraper Keepv.id
  Base    : https://keepv.id/62/
  Node    : v24.4.0
  Nota    : Entrada é URL do YouTube. Suporta áudio e vídeo.
            Param 1 = url yt
            Param 2 = formato (opcional). Se vazio, padrão = audio
            Valores válidos: audio, 240p, 360p, 480p, 720p, 1080p, best_video
            Param 3 = identificador (opcional). Só para exibir nos logs.
*/

const fetch = require('node-fetch')

const keepv = {
  tools: {
    gerarHex: (length = 10, config = { prefix: "" }) => {
      const charSet = "0123456789abcdef"
      const arr = charSet.split("")
      const rand = (a) => a[Math.floor(Math.random() * a.length)]
      const str = Array.from({ length }, _ => rand(arr)).join("")
      return config.prefix + str
    },
    gerarTokenValidade: () => (Date.now() + (1000 * 60 * 20)).toString().substring(0, 10),
    pedirJson: async (descricao, url, options) => {
      try {
        console.log(`[LOG] Requisitando ${descricao} -> ${url}`)
        const r = await fetch(url, options)
        if (!r.ok) throw Error(`${r.status} ${r.statusText}`)
        const json = await r.json()
        console.log(`[LOG] Resposta ${descricao}:`, json)
        return json
      } catch (err) {
        throw Error(`Falha em pedirJson ${descricao} -> ${err.message}`)
      }
    },
    validarString: (descricao, variavel) => {
      if (typeof variavel !== "string" || variavel.trim().length === 0) {
        throw Error(`Variável ${descricao} deve ser string e não pode ser vazia`)
      }
    },
    esperar: async (ms) => new Promise(r => setTimeout(r, ms)),
    tratarFormato: (formato) => {
      const validos = ["audio", "240p", "360p", "480p", "720p", "1080p", "best_video"]
      if (!validos.includes(formato)) throw Error(`Formato inválido. Escolha: ${validos.join(", ")}`)
      let result = formato.match(/^(\d+)p/)?.[1]
      if (!result) result = formato === "audio" ? formato : "10000"
      return result
    }
  },

  constantes: {
    origem: "https://keepv.id",
    headersBase: {
      "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
    }
  },

  async obterCookie(origem, headers) {
    console.log("[LOG] Obtendo cookie inicial...")

    const r = await fetch(origem, { headers })
    if (!r.ok) throw Error(`Erro ao obter cookie: ${r.status} ${r.statusText}`)

    // node-fetch expõe cookies em headers.raw()
    const raw = r.headers.raw()
    const setCookies = raw['set-cookie'] || []

    // fallback para fetch nativo Node >=18
    // const setCookieHeader = r.headers.get('set-cookie')
    // const setCookies = setCookieHeader ? [setCookieHeader] : []

    const primeiro = setCookies[0]
    if (!primeiro) throw Error("Nenhum Set-Cookie recebido do servidor")

    const cookie = primeiro.split(';')[0] // ex: PHPSESSID=xxxxx
    console.log("[LOG] Cookie obtido:", cookie)

    return { cookie, urlRedirect: r.url }
  },

  async validarCookie(result, origem, ytUrl, headers, formato) {
    console.log("[LOG] Validando cookie...")
    const { cookie, urlRedirect } = result
    const headersFinal = { cookie, referer: urlRedirect, ...headers }
    const path = formato === "audio" ? "button" : "vidbutton"
    const url = `${origem}/${path}/?url=${ytUrl}`
    const r = await fetch(url, { headers: headersFinal })
    if (!r.ok) throw Error(`Erro validar cookie: ${r.status}`)
    console.log("[LOG] Cookie validado com sucesso")
    return { cookie, referer: url }
  },

  async converter(result, origem, ytUrl, headers, formato) {
    console.log("[LOG] Iniciando conversão...")
    const { cookie, referer } = result
    const headersFinal = {
      "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
      cookie,
      referer,
      origin: origem,
      "x-requested-with": "XMLHttpRequest",
      ...headers
    }
    const payload = {
      url: ytUrl,
      convert: "gogogo",
      token_id: this.tools.gerarHex(64, { prefix: "t_" }),
      token_validto: this.tools.gerarTokenValidade()
    }
    if (formato !== "audio") payload.height = formato
    const body = new URLSearchParams(payload)
    const path = formato === "audio" ? "convert" : "vidconvert"
    const url = `${origem}/${path}/`
    const resultJson = await this.tools.pedirJson("converter", url, { headers: headersFinal, body, method: "POST" })
    console.log("[LOG] Conversão iniciada. JobID:", resultJson.jobid)
    return resultJson
  },

  async checarJob(resultVC, resultConvert, origem, headers, formato, identificador) {
    console.log("[LOG] Checando progresso do job...")
    const { cookie, referer } = resultVC
    const { jobid } = resultConvert
    const headersFinal = { cookie, referer, "x-requested-with": "XMLHttpRequest", ...headers }
    const usp = new URLSearchParams({ jobid, time: Date.now() })
    const path = formato === "audio" ? "convert" : "vidconvert"
    const url = `${origem}/${path}/?${usp}`
    let tentativas = 0
    while (tentativas < 60) {
      tentativas++
      const r = await fetch(url, { headers: headersFinal })
      const data = await r.json()
      if (data.dlurl) {
        console.log("[LOG] Download pronto:", data.dlurl)
        return data
      }
      console.log(`[${identificador}] progresso: ${data.retry}`)
      await this.tools.esperar(5000)
    }
    throw Error("Limite máximo de tentativas atingido")
  },

  async download(ytUrl, formatoUser = "audio", dono = "") {
    this.tools.validarString("youtube url", ytUrl)
    const formato = this.tools.tratarFormato(formatoUser)
    const identificador = this.tools.gerarHex(4, { prefix: dono ? `${dono}-` : "" })
    console.log(`[NOVA TAREFA] ${identificador}`)

    const origem = this.constantes.origem
    const headers = this.constantes.headersBase

    const resultGC = await this.obterCookie(origem, headers)
    const resultVC = await this.validarCookie(resultGC, origem, ytUrl, headers, formato)
    const resultConvert = await this.converter(resultVC, origem, ytUrl, headers, formato)
    const resultFinal = await this.checarJob(resultVC, resultConvert, origem, headers, formato, identificador)

    const tipo = formatoUser === "audio" ? "audio" : "video"
    return { ...resultFinal, identifier: identificador, type: tipo }
  }
}

module.exports = keepv

// Exemplo de uso:
// keepv.download("https://www.youtube.com/watch?v=gPDcwjJ8pLg", "360p", "paulo")
//   .then(console.log)
//   .catch(err => console.error("Erro:", err.message))