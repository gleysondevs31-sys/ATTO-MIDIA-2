const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args))
const { JSDOM } = require('jsdom');

async function gerarnick(texto) {
const resposta = await fetch("http://qaz.wtf/u/convert.cgi?text=" + encodeURIComponent(texto));
const html = await resposta.text();
const dom = new JSDOM(html);
const tabela = dom.window.document.querySelector("table");
const linhas = tabela.rows;
const resultados = [];

for (const linha of linhas) {
const celula = linha.cells[1];
const textoFormatado = celula.textContent.replace(/\n/g, '');
resultados.push(textoFormatado);
}

return resultados;
}

module.exports = gerarnick;