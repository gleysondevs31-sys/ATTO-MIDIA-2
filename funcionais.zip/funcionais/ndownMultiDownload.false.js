// FEITA POR 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
// NÃO TIRE MEUS CRÉDITOS SEU RANDOM BAGULHO DEU TRABALHO PRA FAZER

const { ttdl, ytsearch, igdl, fbdl, ytmp3, ytmp4 } = require('ruhend-scraper')
const fs = require('fs')
const path = require('path')
const axios = require('axios')

/**
 * Processa o download e obtenção de informações de vídeo a partir de diferentes plataformas.
 * @param {string} url - URL do vídeo de qualquer plataforma (YouTube, TikTok, Instagram, Facebook).
 * @param {string} resolution - Resolução desejada (apenas para YouTube).
 * @returns {Promise<object>} - Retorna um objeto com informações do vídeo ou erro.
 */

async function downloadVideo(url, resolution = "720p (HD)") {
try {
let videoData
if (!url || !/^https?:\/\/.*/.test(url)) {
throw new Error("URL inválida detectada.")
}
console.log('🔍 Verificando a URL fornecida:', url)
if (url.includes('youtube')) {
console.log('🔍 Buscando vídeo no YouTube...')
const { video } = await ytsearch(url)
if (video.length === 0) throw new Error("Nenhum vídeo encontrado no YouTube.")
videoData = video[0]
console.log('🔍 Baixando vídeo do YouTube...')
const { video: videoMp4 } = await ytmp4(url, resolution)
videoData = { ...videoData, video: videoMp4 }
} else if (url.includes('tiktok')) {
console.log('🔍 Buscando vídeo no TikTok...')
videoData = await ttdl(url)
if (!videoData || !videoData.video) throw new Error("Nenhum vídeo encontrado no TikTok.")
} else if (url.includes('instagram')) {
console.log('🔍 Buscando vídeo no Instagram...')
const res = await igdl(url)
const data = res.data
if (data.length === 0) throw new Error("Nenhum vídeo encontrado no Instagram.")
videoData = data[0]
} else if (url.includes('facebook')) {
console.log('🔍 Buscando vídeo no Facebook...')
const res = await fbdl(url)
const data = res.data
if (data.length === 0) throw new Error("Nenhum vídeo encontrado no Facebook.")
videoData = data[0]
} else {
throw new Error("Plataforma não suportada.")
}

const videoUrl = videoData.video || videoData.url
console.log('🔍 URL do vídeo encontrado:', videoUrl)
if (!videoUrl || !/^https?:\/\/.*/.test(videoUrl)) {
throw new Error("URL do vídeo inválida detectada.")
}
const videoFileName = path.basename(videoUrl).split("?")[0] + ".mp4"
const downloadPath = path.join(__dirname, 'video', videoFileName)
console.log(`📥 Iniciando o download do vídeo para: ${downloadPath}`)
const response = await axios({
url: videoUrl,
method: 'GET',
responseType: 'stream',
})
const writer = fs.createWriteStream(downloadPath)
response.data.pipe(writer)
await new Promise((resolve, reject) => {
writer.on('finish', () => {
console.log(`✅ Download concluído com sucesso: ${downloadPath}`)
resolve()
})
writer.on('error', (err) => {
console.error('❌ Erro ao salvar o arquivo:', err)
reject(err)
})
})

return {
status: "Sucesso",
title: videoData.title || "Sem título",
description: videoData.description || "Sem descrição",
duration: videoData.duration || "Desconhecido",
url: videoUrl,
path: downloadPath,
thumbnail: videoData.cover || "Sem imagem de capa",
}
} catch (error) {
console.error("⚠️ Erro ao processar o download:", error.message)
throw error
}
}

/**
 * Processa o download de áudio a partir de diferentes plataformas.
 * @param {string} url - URL do vídeo de qualquer plataforma (YouTube, TikTok, Instagram, Facebook).
 * @returns {Promise<object>} - Retorna um objeto com informações do áudio ou erro.
 */

async function downloadAudio(url) {
try {
let audioData
if (!url || !/^https?:\/\/.*/.test(url)) {
throw new Error("URL inválida detectada.")
}
console.log('🔍 Verificando a URL fornecida para áudio:', url)
if (url.includes('youtube')) {
console.log('🔍 Buscando áudio no YouTube...')
const { video } = await ytsearch(url)
if (video.length === 0) throw new Error("Nenhum áudio encontrado no YouTube.")
audioData = video[0]
console.log('🔍 Baixando áudio do YouTube...')
const { audio: audioMp3 } = await ytmp3(url)
audioData = { ...audioData, audio: audioMp3 }
} else if (url.includes('tiktok')) {
console.log('🔍 Buscando áudio no TikTok...')
audioData = await ttdl(url)
if (!audioData || !audioData.audio) throw new Error("Nenhum áudio encontrado no TikTok.")
} else if (url.includes('instagram')) {
console.log('🔍 Buscando áudio no Instagram...')
const res = await igdl(url)
const data = res.data
if (data.length === 0) throw new Error("Nenhum áudio encontrado no Instagram.")
audioData = data[0]
} else if (url.includes('facebook')) {
console.log('🔍 Buscando áudio no Facebook...')
const res = await fbdl(url)
const data = res.data
if (data.length === 0) throw new Error("Nenhum áudio encontrado no Facebook.")
audioData = data[0]
} else {
throw new Error("Plataforma não suportada.")
}

const audioUrl = audioData.audio || audioData.url
console.log('🔍 URL do áudio encontrado:', audioUrl)
if (!audioUrl || !/^https?:\/\/.*/.test(audioUrl)) {
throw new Error("URL do áudio inválida detectada.")
}
const audioFileName = path.basename(audioUrl).split("?")[0] + ".mp3"
const downloadPath = path.join(__dirname, 'audio', audioFileName)
console.log(`📥 Iniciando o download do áudio para: ${downloadPath}`)
const response = await axios({
url: audioUrl,
method: 'GET',
responseType: 'stream',
})

const writer = fs.createWriteStream(downloadPath)
response.data.pipe(writer)
await new Promise((resolve, reject) => {
writer.on('finish', () => {
console.log(`✅ Download concluído com sucesso: ${downloadPath}`)
resolve()
})
writer.on('error', (err) => {
console.error('❌ Erro ao salvar o arquivo:', err)
reject(err)
})
})

return {
status: "Sucesso",
title: audioData.title || "Sem título",
description: audioData.description || "Sem descrição",
url: audioUrl,
path: downloadPath,
}
} catch (error) {
console.error("⚠️ Erro ao processar o download do áudio:", error.message)
throw error
}
}

module.exports = { downloadVideo, downloadAudio }