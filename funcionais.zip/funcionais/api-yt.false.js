//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

const fetch = require('node-fetch')

const VIDEO_FORMAT_PRIORITY = ['4k', '1440', '1080', '720', '480', '360'];
const AUDIO_FORMAT_PRIORITY = ['mp3'];
const MIN_FILE_SIZE = {
audio: 100 * 1024, // 100 KB
video: 500 * 1024// 500 KB
};

async function checkFileSize(url, minSize) {
try {
const headResponse = await fetch(url, {
method: 'HEAD',
headers: {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
},
timeout: 8000
});
if (!headResponse.ok) return false;
const contentLength = headResponse.headers.get('content-length');
const fileSize = parseInt(contentLength, 10);
return fileSize > minSize;
} catch (error) {
return false;
}
}

async function getDownloadLink(youtubeUrl, type = 'mp3') {
try {
const isVideo = type.toLowerCase() === 'mp4';
const apiPath = isVideo ? '/download/youtube' : '/download/youtube2';
const minSize = isVideo ? MIN_FILE_SIZE.video : MIN_FILE_SIZE.audio;
const formats = isVideo ? VIDEO_FORMAT_PRIORITY : AUDIO_FORMAT_PRIORITY;
for (const format of formats) {
try {
const apiUrl = `https://apizell.web.id${apiPath}?url=${youtubeUrl}&format=${format}`;
console.log("ACESSO A ROTA 2 DO DONWLOAD YT, REQUISIÇÃO:", apiUrl)
const controller = new AbortController();
const timeout = setTimeout(() => controller.abort(), 10000);
const response = await fetch(apiUrl, {
headers: {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
'Accept': 'application/json'
},
signal: controller.signal
});
clearTimeout(timeout);
if (!response.ok) continue;
const data = await response.json();
const success = data.status || data.success || data.sucesso;
const downloadLink = data.download;
if (success && downloadLink) {
const isValidSize = await checkFileSize(downloadLink, minSize);
if (isValidSize) {
return {
download: downloadLink,
format: format,
type: isVideo ? 'video' : 'audio',
thumbnail: data.thumbnail,
title: data.title || data.título
};
} else {
console.warn(`Arquivo muito pequeno para ${format}, tentando próximo formato`);
}
}
} catch (error) {
// Ignora erros individuais e tenta o próximo formato
continue;
}
}
throw new Error('Nenhum formato disponível retornou um arquivo válido')
} catch (error) {
throw new Error(`Falha ao obter link: ${error.message}`)
}
}

module.exports = getDownloadLink