//By: 𖧄 𝐋𝐔𝐂𝐀𝐒 𝐌𝐎𝐃 𝐃𝐎𝐌𝐈𝐍𝐀 𖧄
//Canal: https://whatsapp.com/channel/0029Va6riekH5JLwLUFI7P2B

// ===============================
// PALETAS HEX SUGERIDAS PARA O CANVAS
// ===============================
// mainColor (cor do ping, anel, detalhes):
// - Rosa Neon: #FF0095
// - Azul Neon: #00eaff
// - Verde Limão: #00ffb0
// - Laranja Neon: #ff7a00
// - Vermelho Neon: #ff0055
// - Amarelo Neon: #fffb00
// - Roxo Neon: #8e2de2
// - Azul Royal: #3a86ff
// - Verde Aqua: #00ffc6
// - Branco: #ffffff
//
// titleColor (cor do título, gradientes):
// - Roxo: #8e2de2
// - Azul Claro: #00eaff
// - Rosa Claro: #ff6ec4
// - Laranja: #ffb86c
// - Verde: #00ffb0
// - Azul Escuro: #23233a
// - Cinza Claro: #e0e0e0
// - Dourado: #ffd700
// - Vermelho: #ff0055
// - Branco: #ffffff
//
// Exemplos de gradientes modernos:
// - Rosa Neon → Azul Neon:#FF0095 → #00eaff
// - Roxo → Azul Claro:#8e2de2 → #00eaff
// - Laranja → Amarelo Neon: #ff7a00 → #fffb00
// - Verde Limão → Azul Royal: #00ffb0 → #3a86ff
// - Rosa Claro → Roxo:#ff6ec4 → #8e2de2
//
// Use os parâmetros 'hex' e 'hex2' para customizar as cores do seu canvas.
// ===============================
// EXEMPLO DE USO EM UMA ROTA EXPRESS
// ===============================
// const express = require('express');
// const { generatePingCanvas } = require('./ping-canvas');
// const app = express();
//
// app.get('/api/pingcanvas', async (req, res) => {
// const params = {
// title: req.query.title,
// nome: req.query.nome,
// hex: req.query.hex, // cor do ping
// hex2: req.query.hex2, // cor do título
// perfil: req.query.perfil, // url da imagem de perfil
// message: req.query.message,
// fundo: req.query.fundo // url da imagem de fundo
// };
// try {
// const buffer = await generatePingCanvas(params);
// res.set('Content-Type', 'image/png');
// res.send(buffer);
// } catch (e) {
// res.status(500).send('Erro ao gerar canvas');
// }
// });
//
// app.listen(3000, () => console.log('Servidor rodando na porta 3000'));
// ===============================

const { createCanvas, loadImage } = require('canvas')

function normalizeHex(hex, fallback) {
if (!hex || typeof hex !== 'string') return fallback;
let h = hex.trim().replace(/^#/, '');
if (h.length === 3) h = h.split('').map(c => c + c).join('');
if (!/^([0-9a-fA-F]{6})$/.test(h)) return fallback;
return `#${h}`;
}

function hexWithAlpha(hex, alpha) {
hex = normalizeHex(hex, '#000000');
const r = parseInt(hex.slice(1, 3), 16);
const g = parseInt(hex.slice(3, 5), 16);
const b = parseInt(hex.slice(5, 7), 16);
return `rgba(${r},${g},${b},${alpha})`;
}

function getBrasiliaTimeAndDate() {
const now = new Date();
const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
const brt = new Date(utc - (3 * 3600000));
const hours = brt.getHours().toString().padStart(2, '0');
const minutes = brt.getMinutes().toString().padStart(2, '0');
const seconds = brt.getSeconds().toString().padStart(2, '0');
const time = `${hours}:${minutes}:${seconds}`;
const dias = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
const meses = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
const diaSemana = dias[brt.getDay()];
const dia = brt.getDate();
const mes = meses[brt.getMonth()];
const ano = brt.getFullYear();
const dataCompleta = `${diaSemana}, ${dia} de ${mes} de ${ano}`;
return { time, dataCompleta };
}

function isValidUrl(string) {
try {
new URL(string);
return true;
} catch (_) {
return false;
}
}

async function loadImageSafe(url, timeout = 10000) {
if (!url || !isValidUrl(url)) {
throw new Error('URL inválida');
}
return new Promise((resolve, reject) => {
const timeoutId = setTimeout(() => {
reject(new Error('Timeout ao carregar imagem'));
}, timeout);
loadImage(url)
.then(img => {
clearTimeout(timeoutId);
resolve(img);
})
.catch(err => {
clearTimeout(timeoutId);
reject(err);
});
});
}

async function generatePingCanvas(title, nome, hex, hex2, perfil, message, fundo) {
const width = 1280;
const height = 620;
const canvas = createCanvas(width, height);
const ctx = canvas.getContext('2d');
const mainColor = normalizeHex(hex, '#FF0095');
const titleColor = normalizeHex(hex2, '#8e2de2');
const { time, dataCompleta } = getBrasiliaTimeAndDate();
if (fundo && isValidUrl(fundo)) {
try {
console.log('Tentando carregar imagem de fundo:', fundo);
const bg = await loadImageSafe(fundo);
ctx.drawImage(bg, 0, 0, width, height);
console.log('Imagem de fundo carregada com sucesso');
} catch (error) {
console.error('Erro ao carregar imagem de fundo:', error.message);
ctx.fillStyle = '#181828';
ctx.fillRect(0, 0, width, height);
}
} else {
console.log('URL de fundo inválida ou não fornecida, usando fundo padrão');
ctx.fillStyle = '#181828';
ctx.fillRect(0, 0, width, height);
}
ctx.save();
ctx.globalAlpha = 0.18;
ctx.fillStyle = '#181828';
ctx.fillRect(0, 0, width, height);
ctx.restore();
ctx.save();
ctx.globalAlpha = 0.13;
const grad1 = ctx.createRadialGradient(80, 80, 10, 80, 80, 120);
grad1.addColorStop(0, '#fff');
grad1.addColorStop(1, 'rgba(255,255,255,0)');
ctx.beginPath();
ctx.arc(80, 80, 120, 0, Math.PI * 2);
ctx.closePath();
ctx.fillStyle = grad1;
ctx.fill();
ctx.restore();
ctx.save();
ctx.globalAlpha = 0.10;
const grad2 = ctx.createRadialGradient(width - 120, 100, 10, width - 120, 100, 140);
grad2.addColorStop(0, mainColor);
grad2.addColorStop(0.5, titleColor);
grad2.addColorStop(1, 'rgba(255,255,255,0)');
ctx.beginPath();
ctx.arc(width - 120, 100, 140, 0, Math.PI * 2);
ctx.closePath();
ctx.fillStyle = grad2;
ctx.fill();
ctx.restore();
ctx.save();
ctx.globalAlpha = 0.10;
const grad3 = ctx.createRadialGradient(90, height - 80, 10, 90, height - 80, 100);
grad3.addColorStop(0, titleColor);
grad3.addColorStop(1, 'rgba(255,255,255,0)');
ctx.beginPath();
ctx.arc(90, height - 80, 100, 0, Math.PI * 2);
ctx.closePath();
ctx.fillStyle = grad3;
ctx.fill();
ctx.restore();
ctx.save();
ctx.globalAlpha = 0.10;
ctx.strokeStyle = hexWithAlpha(mainColor, 0.18);
ctx.lineWidth = 4;
ctx.beginPath();
ctx.moveTo(width - 60, height - 60);
ctx.bezierCurveTo(width - 180, height - 40, width - 120, height - 180, width - 40, height - 180);
ctx.stroke();
for (let i = 0; i < 4; i++) {
ctx.beginPath();
const px = width - 60 - i * 32;
const py = height - 60 - i * 18;
ctx.arc(px, py, 10 + i * 3, 0, Math.PI * 2);
ctx.fillStyle = hexWithAlpha('#fff', 0.13 - i * 0.02);
ctx.fill();
}
ctx.restore();
for (let i = 0; i < 32; i++) {
const snowX = Math.random() * width;
const snowY = Math.random() * height;
const snowR = 2 + Math.random() * 4;
ctx.save();
ctx.globalAlpha = 0.10 + Math.random() * 0.10;
ctx.beginPath();
ctx.arc(snowX, snowY, snowR, 0, Math.PI * 2);
ctx.closePath();
ctx.fillStyle = hexWithAlpha('#fff', 0.7);
ctx.shadowColor = hexWithAlpha(mainColor, 0.10);
ctx.shadowBlur = 6;
ctx.fill();
ctx.restore();
}
ctx.save();
ctx.font = 'bold 30px Arial, Segoe UI, sans-serif';
ctx.textAlign = 'left';
ctx.textBaseline = 'top';
ctx.globalAlpha = 0.62;
ctx.fillStyle = hexWithAlpha('#fff', 0.62);
ctx.shadowColor = hexWithAlpha(mainColor, 0.10);
ctx.shadowBlur = 4;
ctx.fillText(time, 44, 24);
ctx.restore();
ctx.save();
ctx.font = 'bold 26px Arial, Segoe UI, sans-serif';
ctx.textAlign = 'right';
ctx.textBaseline = 'top';
ctx.globalAlpha = 0.62;
ctx.fillStyle = hexWithAlpha('#fff', 0.62);
ctx.shadowColor = hexWithAlpha(mainColor, 0.10);
ctx.shadowBlur = 4;
ctx.fillText(dataCompleta, width - 44, 28);
ctx.restore();
const avR = 110;
const avY = height * 0.27;
if (perfil && isValidUrl(perfil)) {
try {
console.log('Tentando carregar imagem de perfil:', perfil);
const avatar = await loadImageSafe(perfil);
console.log('Imagem de perfil carregada com sucesso');
ctx.save();
ctx.beginPath();
ctx.arc(width / 2, avY, avR + 7, 0, Math.PI * 2);
ctx.strokeStyle = hexWithAlpha(mainColor, 0.5);
ctx.lineWidth = 8;
ctx.globalAlpha = 0.38;
ctx.shadowColor = hexWithAlpha(mainColor, 0.18);
ctx.shadowBlur = 18;
ctx.stroke();
ctx.restore();
ctx.save();
ctx.beginPath();
ctx.arc(width / 2, avY, avR, 0, Math.PI * 2);
ctx.closePath();
ctx.clip();
const ar = avatar.width / avatar.height;
const targetR = avR;
let drawW, drawH, dx, dy;
if (ar > 1) {
drawH = targetR * 2;
drawW = drawH * ar;
dx = width / 2 - drawW / 2;
dy = avY - targetR;
} else {
drawW = targetR * 2;
drawH = drawW / ar;
dx = width / 2 - targetR;
dy = avY - drawH / 2;
}
ctx.drawImage(avatar, dx, dy, drawW, drawH);
ctx.restore();
} catch (error) {
console.error('Erro ao carregar imagem de perfil:', error.message);
ctx.save();
ctx.beginPath();
ctx.arc(width / 2, avY, avR, 0, Math.PI * 2);
ctx.fillStyle = mainColor;
ctx.globalAlpha = 0.5;
ctx.fill();
ctx.restore();
}
} else {
console.log('URL de perfil inválida ou não fornecida, usando fallback');
ctx.save();
ctx.beginPath();
ctx.arc(width / 2, avY, avR, 0, Math.PI * 2);
ctx.fillStyle = mainColor;
ctx.globalAlpha = 0.5;
ctx.fill();
ctx.restore();
}
const titleY = avY + avR + 38;
ctx.save();
ctx.font = 'bold 56px Arial, Segoe UI, sans-serif';
ctx.textAlign = 'center';
ctx.textBaseline = 'middle';
ctx.fillStyle = titleColor;
ctx.shadowColor = hexWithAlpha(titleColor, 0.25);
ctx.shadowBlur = 10;
ctx.fillText(title || 'PING CANVAS', width / 2, titleY);
ctx.restore();
const pingY = height * 0.68;
ctx.save();
ctx.font = '900 64px Arial, Segoe UI, sans-serif';
ctx.textAlign = 'center';
ctx.textBaseline = 'middle';
ctx.shadowColor = hexWithAlpha(mainColor, 0.25);
ctx.shadowBlur = 12;
ctx.fillStyle = mainColor;
ctx.fillText(nome || 'PING', width / 2, pingY);
ctx.restore();
const msgY = height * 0.83;
const msg = (message || 'ZERO TWO BETA').toString();
ctx.save();
ctx.font = 'bold 38px Arial, Segoe UI, sans-serif';
ctx.textAlign = 'center';
ctx.textBaseline = 'middle';
let totalWidth = 0;
for (let i = 0; i < msg.length; i++) {
totalWidth += ctx.measureText(msg[i]).width;
}
let x = width / 2 - totalWidth / 2;
for (let i = 0; i < msg.length; i++) {
const letter = msg[i];
const letterWidth = ctx.measureText(letter).width;
ctx.globalAlpha = 0.38;
ctx.fillStyle = hexWithAlpha('#fff', 0.82);
ctx.shadowColor = hexWithAlpha(mainColor, 0.10);
ctx.shadowBlur = 4;
ctx.fillText(letter, x + letterWidth / 2, msgY);
ctx.save();
ctx.globalAlpha = 0.18;
ctx.setTransform(1, 0, 0, -1, 0, 0);
ctx.drawImage(canvas,
x, msgY - 20, letterWidth, 40,
x, -(msgY + 20), letterWidth, 40
);
ctx.restore();
x += letterWidth;
}
ctx.restore();
ctx.save();
ctx.font = 'bold 22px Arial, Segoe UI, sans-serif';
ctx.fillStyle = hexWithAlpha('#fff', 0.72);
ctx.globalAlpha = 1;
ctx.textAlign = 'center';
ctx.textBaseline = 'bottom';
ctx.shadowColor = hexWithAlpha(mainColor, 0.13);
ctx.shadowBlur = 6;
ctx.fillText('pingcanvas - @paulo_mod_domina', width / 2, height - 24);
ctx.restore();
return canvas.toBuffer('image/png');
}

module.exports = { generatePingCanvas }